import 'package:flutter/material.dart';

import 'app_colors.dart';
import 'app_tokens.dart';

/// Tipografi PLANIFY (Tahap 3 §2.2). Font Plus Jakarta Sans di-bundle sebagai
/// aset agar tetap tersedia saat offline.
abstract final class AppTypography {
  static const String fontFamily = 'PlusJakartaSans';

  static const List<FontFeature> tabularFigures = <FontFeature>[
    FontFeature.tabularFigures(),
  ];

  /// Angka Pomodoro: 64/72, bold, digit lebar tetap.
  static const TextStyle timerDisplay = TextStyle(
    fontFamily: fontFamily,
    fontSize: 64,
    height: 72 / 64,
    fontWeight: FontWeight.w700,
    letterSpacing: -1,
    fontFeatures: tabularFigures,
  );

  static const TextTheme textTheme = TextTheme(
    displaySmall: TextStyle(
      fontFamily: fontFamily,
      fontSize: 36,
      height: 44 / 36,
      fontWeight: FontWeight.w700,
    ),
    headlineSmall: TextStyle(
      fontFamily: fontFamily,
      fontSize: 24,
      height: 32 / 24,
      fontWeight: FontWeight.w700,
    ),
    titleLarge: TextStyle(
      fontFamily: fontFamily,
      fontSize: 20,
      height: 28 / 20,
      fontWeight: FontWeight.w700,
    ),
    titleMedium: TextStyle(
      fontFamily: fontFamily,
      fontSize: 16,
      height: 24 / 16,
      fontWeight: FontWeight.w600,
    ),
    titleSmall: TextStyle(
      fontFamily: fontFamily,
      fontSize: 14,
      height: 20 / 14,
      fontWeight: FontWeight.w600,
    ),
    bodyLarge: TextStyle(
      fontFamily: fontFamily,
      fontSize: 16,
      height: 24 / 16,
      fontWeight: FontWeight.w400,
    ),
    bodyMedium: TextStyle(
      fontFamily: fontFamily,
      fontSize: 14,
      height: 20 / 14,
      fontWeight: FontWeight.w400,
    ),
    bodySmall: TextStyle(
      fontFamily: fontFamily,
      fontSize: 12,
      height: 16 / 12,
      fontWeight: FontWeight.w400,
    ),
    labelLarge: TextStyle(
      fontFamily: fontFamily,
      fontSize: 14,
      height: 20 / 14,
      fontWeight: FontWeight.w600,
    ),
    labelMedium: TextStyle(
      fontFamily: fontFamily,
      fontSize: 12,
      height: 16 / 12,
      fontWeight: FontWeight.w600,
    ),
    labelSmall: TextStyle(
      fontFamily: fontFamily,
      fontSize: 11,
      height: 16 / 11,
      fontWeight: FontWeight.w600,
    ),
  );
}

/// Tema light dan dark PLANIFY ("Calm Clarity", Material 3).
abstract final class AppTheme {
  static final ThemeData _light = _build(Brightness.light);
  static final ThemeData _dark = _build(Brightness.dark);

  static ThemeData light() => _light;
  static ThemeData dark() => _dark;

  static const ColorScheme lightScheme = ColorScheme(
    brightness: Brightness.light,
    primary: AppPalette.lightPrimary,
    onPrimary: AppPalette.lightOnPrimary,
    primaryContainer: AppPalette.lightPrimaryContainer,
    onPrimaryContainer: AppPalette.lightOnPrimaryContainer,
    secondary: AppPalette.lightSecondary,
    onSecondary: AppPalette.lightOnSecondary,
    secondaryContainer: AppPalette.lightSecondaryContainer,
    onSecondaryContainer: AppPalette.lightOnSecondaryContainer,
    error: AppPalette.lightError,
    onError: Color(0xFFFFFFFF),
    errorContainer: AppPalette.lightErrorContainer,
    onErrorContainer: AppPalette.lightOnErrorContainer,
    surface: AppPalette.lightSurface,
    onSurface: AppPalette.lightTextPrimary,
    onSurfaceVariant: AppPalette.lightTextSecondary,
    surfaceContainerHighest: AppPalette.lightSurfaceMuted,
    outline: AppPalette.lightOutline,
    outlineVariant: AppPalette.lightBorderSubtle,
    shadow: Color(0xFF000000),
    scrim: Color(0xFF000000),
    inverseSurface: AppPalette.lightTextPrimary,
    onInverseSurface: AppPalette.lightBackground,
    inversePrimary: AppPalette.darkPrimary,
    surfaceTint: Color(0x00000000),
  );

  static const ColorScheme darkScheme = ColorScheme(
    brightness: Brightness.dark,
    primary: AppPalette.darkPrimary,
    onPrimary: AppPalette.darkOnPrimary,
    primaryContainer: AppPalette.darkPrimaryContainer,
    onPrimaryContainer: AppPalette.darkOnPrimaryContainer,
    secondary: AppPalette.darkSecondary,
    onSecondary: AppPalette.darkOnSecondary,
    secondaryContainer: AppPalette.darkSecondaryContainer,
    onSecondaryContainer: AppPalette.darkOnSecondaryContainer,
    error: AppPalette.darkError,
    onError: Color(0xFF4A1C1C),
    errorContainer: AppPalette.darkErrorContainer,
    onErrorContainer: AppPalette.darkOnErrorContainer,
    surface: AppPalette.darkSurface,
    onSurface: AppPalette.darkTextPrimary,
    onSurfaceVariant: AppPalette.darkTextSecondary,
    surfaceContainerHighest: AppPalette.darkSurfaceMuted,
    outline: AppPalette.darkOutline,
    outlineVariant: AppPalette.darkBorderSubtle,
    shadow: Color(0xFF000000),
    scrim: Color(0xFF000000),
    inverseSurface: AppPalette.darkTextPrimary,
    onInverseSurface: AppPalette.darkBackground,
    inversePrimary: AppPalette.lightPrimary,
    surfaceTint: Color(0x00000000),
  );

  static ThemeData _build(Brightness brightness) {
    final bool isDark = brightness == Brightness.dark;
    final ColorScheme scheme = isDark ? darkScheme : lightScheme;
    final AppColors colors = isDark ? AppColors.dark : AppColors.light;
    const TextTheme text = AppTypography.textTheme;

    const RoundedRectangleBorder buttonShape =
        RoundedRectangleBorder(borderRadius: AppRadius.mdAll);
    final TextStyle buttonText =
        text.labelLarge!.copyWith(fontSize: 16, height: 1.25);

    OutlineInputBorder inputBorder(Color color, double width) {
      return OutlineInputBorder(
        borderRadius: AppRadius.mdAll,
        borderSide: BorderSide(color: color, width: width),
      );
    }

    return ThemeData(
      brightness: brightness,
      colorScheme: scheme,
      fontFamily: AppTypography.fontFamily,
      textTheme: text,
      scaffoldBackgroundColor: colors.background,
      extensions: <ThemeExtension<dynamic>>[colors],
      visualDensity: VisualDensity.standard,
      appBarTheme: AppBarThemeData(
        backgroundColor: colors.background,
        foregroundColor: scheme.onSurface,
        elevation: 0,
        scrolledUnderElevation: 0,
        surfaceTintColor: Colors.transparent,
        centerTitle: false,
        toolbarHeight: 64,
        titleTextStyle: text.titleLarge!.copyWith(color: scheme.onSurface),
      ),
      cardTheme: CardThemeData(
        color: scheme.surface,
        elevation: 0,
        margin: EdgeInsets.zero,
        surfaceTintColor: Colors.transparent,
        shape: RoundedRectangleBorder(
          borderRadius: AppRadius.lgAll,
          side: BorderSide(color: colors.borderSubtle),
        ),
      ),
      filledButtonTheme: FilledButtonThemeData(
        style: FilledButton.styleFrom(
          minimumSize: const Size(64, AppSizes.buttonHeight),
          padding: const EdgeInsets.symmetric(horizontal: AppSpacing.xl),
          shape: buttonShape,
          textStyle: buttonText,
        ),
      ),
      outlinedButtonTheme: OutlinedButtonThemeData(
        style: OutlinedButton.styleFrom(
          minimumSize: const Size(64, AppSizes.buttonHeight),
          padding: const EdgeInsets.symmetric(horizontal: AppSpacing.xl),
          shape: buttonShape,
          foregroundColor: scheme.onSurface,
          side: BorderSide(color: scheme.outline),
          textStyle: buttonText,
        ),
      ),
      textButtonTheme: TextButtonThemeData(
        style: TextButton.styleFrom(
          minimumSize: const Size(48, AppSizes.compactButtonHeight),
          padding: const EdgeInsets.symmetric(horizontal: AppSpacing.md),
          shape: buttonShape,
          textStyle: text.labelLarge!.copyWith(fontSize: 15),
        ),
      ),
      iconButtonTheme: IconButtonThemeData(
        style: IconButton.styleFrom(
          minimumSize: const Size.square(AppSizes.minTouchTarget),
        ),
      ),
      inputDecorationTheme: InputDecorationThemeData(
        filled: true,
        fillColor: scheme.surface,
        contentPadding: const EdgeInsets.symmetric(
          horizontal: 14,
          vertical: 14,
        ),
        hintStyle: text.bodyLarge!.copyWith(color: colors.textSecondary),
        helperStyle: text.bodySmall!.copyWith(color: colors.textSecondary),
        errorStyle: text.bodySmall!.copyWith(
          color: scheme.error,
          fontWeight: FontWeight.w600,
        ),
        prefixIconColor: colors.textSecondary,
        suffixIconColor: colors.textSecondary,
        border: inputBorder(scheme.outline, 1),
        enabledBorder: inputBorder(scheme.outline, 1),
        disabledBorder: inputBorder(colors.borderSubtle, 1),
        focusedBorder: inputBorder(scheme.primary, 2),
        errorBorder: inputBorder(scheme.error, 2),
        focusedErrorBorder: inputBorder(scheme.error, 2),
      ),
      navigationBarTheme: NavigationBarThemeData(
        height: 80,
        elevation: 0,
        backgroundColor: scheme.surface,
        surfaceTintColor: Colors.transparent,
        indicatorColor: scheme.primaryContainer,
        indicatorShape: const StadiumBorder(),
        labelBehavior: NavigationDestinationLabelBehavior.alwaysShow,
        labelTextStyle: WidgetStateProperty.resolveWith((states) {
          final bool selected = states.contains(WidgetState.selected);
          return text.labelMedium!.copyWith(
            fontWeight: selected ? FontWeight.w700 : FontWeight.w600,
            color: selected ? scheme.onSurface : colors.textSecondary,
          );
        }),
        iconTheme: WidgetStateProperty.resolveWith((states) {
          final bool selected = states.contains(WidgetState.selected);
          return IconThemeData(
            size: AppSizes.iconSize,
            color: selected ? scheme.onPrimaryContainer : colors.textSecondary,
          );
        }),
      ),
      floatingActionButtonTheme: FloatingActionButtonThemeData(
        backgroundColor: scheme.primary,
        foregroundColor: scheme.onPrimary,
        elevation: 3,
        shape: const RoundedRectangleBorder(borderRadius: AppRadius.lgAll),
        extendedTextStyle: buttonText.copyWith(fontSize: 15),
      ),
      chipTheme: ChipThemeData(
        backgroundColor: scheme.surface,
        selectedColor: scheme.primaryContainer,
        disabledColor: colors.surfaceMuted,
        checkmarkColor: scheme.onPrimaryContainer,
        labelStyle: text.labelLarge!.copyWith(color: scheme.onSurface),
        secondaryLabelStyle:
            text.labelLarge!.copyWith(color: scheme.onPrimaryContainer),
        side: BorderSide(color: scheme.outline),
        shape: const RoundedRectangleBorder(borderRadius: AppRadius.smAll),
        padding: const EdgeInsets.symmetric(horizontal: AppSpacing.sm),
      ),
      snackBarTheme: SnackBarThemeData(
        behavior: SnackBarBehavior.floating,
        shape: const RoundedRectangleBorder(borderRadius: AppRadius.mdAll),
        backgroundColor: scheme.inverseSurface,
        contentTextStyle:
            text.bodyMedium!.copyWith(color: scheme.onInverseSurface),
        actionTextColor: scheme.inversePrimary,
      ),
      dialogTheme: DialogThemeData(
        backgroundColor: scheme.surface,
        surfaceTintColor: Colors.transparent,
        shape: const RoundedRectangleBorder(borderRadius: AppRadius.xlAll),
        titleTextStyle:
            text.titleLarge!.copyWith(fontSize: 18, color: scheme.onSurface),
        contentTextStyle:
            text.bodyMedium!.copyWith(color: colors.textSecondary),
      ),
      bottomSheetTheme: BottomSheetThemeData(
        backgroundColor: scheme.surface,
        surfaceTintColor: Colors.transparent,
        showDragHandle: true,
        dragHandleColor: scheme.outline,
        shape: const RoundedRectangleBorder(
          borderRadius: BorderRadius.vertical(
            top: Radius.circular(AppRadius.xl),
          ),
        ),
      ),
      dividerTheme: DividerThemeData(
        color: colors.borderSubtle,
        thickness: 1,
        space: 1,
      ),
      listTileTheme: ListTileThemeData(
        iconColor: colors.textSecondary,
        titleTextStyle: text.titleSmall!.copyWith(
          fontSize: 15,
          color: scheme.onSurface,
        ),
        subtitleTextStyle:
            text.bodyMedium!.copyWith(color: colors.textSecondary),
        contentPadding:
            const EdgeInsets.symmetric(horizontal: AppSpacing.lg),
      ),
      progressIndicatorTheme: ProgressIndicatorThemeData(
        color: scheme.primary,
        linearTrackColor: scheme.primaryContainer,
      ),
    );
  }
}
