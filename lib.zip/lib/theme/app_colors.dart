import 'package:flutter/material.dart';

/// Nilai HEX dari design system Tahap 3 §2.1.
///
/// Widget tidak boleh memakai HEX langsung. Pakai `Theme.of(context).colorScheme`
/// atau `context.appColors` (lihat [AppColors]).
abstract final class AppPalette {
  // ---------- Light ----------
  static const Color lightPrimary = Color(0xFF2D5BD7);
  static const Color lightOnPrimary = Color(0xFFFFFFFF);
  static const Color lightPrimaryContainer = Color(0xFFDCE5FB);
  static const Color lightOnPrimaryContainer = Color(0xFF0E2A6B);
  static const Color lightSecondary = Color(0xFF18786A);
  static const Color lightOnSecondary = Color(0xFFFFFFFF);
  static const Color lightSecondaryContainer = Color(0xFFD2F0EA);
  static const Color lightOnSecondaryContainer = Color(0xFF063C35);
  static const Color lightBackground = Color(0xFFF6F7FB);
  static const Color lightSurface = Color(0xFFFFFFFF);
  static const Color lightSurfaceMuted = Color(0xFFEEF1F6);
  static const Color lightOutline = Color(0xFFC9CFDA);
  static const Color lightBorderSubtle = Color(0xFFE3E7EE);
  static const Color lightTextPrimary = Color(0xFF1A1D24);
  static const Color lightTextSecondary = Color(0xFF5B6372);
  static const Color lightTextDisabled = Color(0xFF9AA1AE);
  static const Color lightSuccess = Color(0xFF1E874B);
  static const Color lightSuccessContainer = Color(0xFFDDF3E6);
  static const Color lightOnSuccessContainer = Color(0xFF14532D);
  static const Color lightWarning = Color(0xFF9A5B00);
  static const Color lightWarningContainer = Color(0xFFFFF1D6);
  static const Color lightOnWarningContainer = Color(0xFF5C3700);
  static const Color lightError = Color(0xFFC62828);
  static const Color lightErrorContainer = Color(0xFFFDE7E7);
  static const Color lightOnErrorContainer = Color(0xFF7A1616);

  // ---------- Dark ----------
  static const Color darkPrimary = Color(0xFF8EA8F5);
  static const Color darkOnPrimary = Color(0xFF0E2A6B);
  static const Color darkPrimaryContainer = Color(0xFF253A73);
  static const Color darkOnPrimaryContainer = Color(0xFFDCE5FB);
  static const Color darkSecondary = Color(0xFF6FD1C0);
  static const Color darkOnSecondary = Color(0xFF063C35);
  static const Color darkSecondaryContainer = Color(0xFF16473F);
  static const Color darkOnSecondaryContainer = Color(0xFFD2F0EA);
  static const Color darkBackground = Color(0xFF0F1218);
  static const Color darkSurface = Color(0xFF171B23);
  static const Color darkSurfaceMuted = Color(0xFF212734);
  static const Color darkOutline = Color(0xFF3A4252);
  static const Color darkBorderSubtle = Color(0xFF2A303C);
  static const Color darkTextPrimary = Color(0xFFE6E9EF);
  static const Color darkTextSecondary = Color(0xFFA3AAB8);
  static const Color darkTextDisabled = Color(0xFF6B7383);
  static const Color darkSuccess = Color(0xFF6BD49A);
  static const Color darkSuccessContainer = Color(0xFF183A28);
  static const Color darkOnSuccessContainer = Color(0xFF6BD49A);
  static const Color darkWarning = Color(0xFFF2B65A);
  static const Color darkWarningContainer = Color(0xFF3D2E10);
  static const Color darkOnWarningContainer = Color(0xFFF2B65A);
  static const Color darkError = Color(0xFFF28B82);
  static const Color darkErrorContainer = Color(0xFF4A1C1C);
  static const Color darkOnErrorContainer = Color(0xFFF28B82);

  /// Delapan warna habit yang disimpan sebagai `color_value` (Tahap 2 §7).
  static const List<Color> habitSwatches = <Color>[
    Color(0xFF2D5BD7),
    Color(0xFF18786A),
    Color(0xFF7B4BC4),
    Color(0xFFC2410C),
    Color(0xFFB4235A),
    Color(0xFF0E7490),
    Color(0xFF4D7C0F),
    Color(0xFF5B6372),
  ];
}

/// Token warna tambahan yang tidak ada di [ColorScheme] Material 3.
@immutable
class AppColors extends ThemeExtension<AppColors> {
  const AppColors({
    required this.background,
    required this.surfaceMuted,
    required this.borderSubtle,
    required this.textSecondary,
    required this.textDisabled,
    required this.success,
    required this.successContainer,
    required this.onSuccessContainer,
    required this.warning,
    required this.warningContainer,
    required this.onWarningContainer,
  });

  final Color background;
  final Color surfaceMuted;
  final Color borderSubtle;
  final Color textSecondary;
  final Color textDisabled;
  final Color success;
  final Color successContainer;
  final Color onSuccessContainer;
  final Color warning;
  final Color warningContainer;
  final Color onWarningContainer;

  static const AppColors light = AppColors(
    background: AppPalette.lightBackground,
    surfaceMuted: AppPalette.lightSurfaceMuted,
    borderSubtle: AppPalette.lightBorderSubtle,
    textSecondary: AppPalette.lightTextSecondary,
    textDisabled: AppPalette.lightTextDisabled,
    success: AppPalette.lightSuccess,
    successContainer: AppPalette.lightSuccessContainer,
    onSuccessContainer: AppPalette.lightOnSuccessContainer,
    warning: AppPalette.lightWarning,
    warningContainer: AppPalette.lightWarningContainer,
    onWarningContainer: AppPalette.lightOnWarningContainer,
  );

  static const AppColors dark = AppColors(
    background: AppPalette.darkBackground,
    surfaceMuted: AppPalette.darkSurfaceMuted,
    borderSubtle: AppPalette.darkBorderSubtle,
    textSecondary: AppPalette.darkTextSecondary,
    textDisabled: AppPalette.darkTextDisabled,
    success: AppPalette.darkSuccess,
    successContainer: AppPalette.darkSuccessContainer,
    onSuccessContainer: AppPalette.darkOnSuccessContainer,
    warning: AppPalette.darkWarning,
    warningContainer: AppPalette.darkWarningContainer,
    onWarningContainer: AppPalette.darkOnWarningContainer,
  );

  @override
  AppColors copyWith({
    Color? background,
    Color? surfaceMuted,
    Color? borderSubtle,
    Color? textSecondary,
    Color? textDisabled,
    Color? success,
    Color? successContainer,
    Color? onSuccessContainer,
    Color? warning,
    Color? warningContainer,
    Color? onWarningContainer,
  }) {
    return AppColors(
      background: background ?? this.background,
      surfaceMuted: surfaceMuted ?? this.surfaceMuted,
      borderSubtle: borderSubtle ?? this.borderSubtle,
      textSecondary: textSecondary ?? this.textSecondary,
      textDisabled: textDisabled ?? this.textDisabled,
      success: success ?? this.success,
      successContainer: successContainer ?? this.successContainer,
      onSuccessContainer: onSuccessContainer ?? this.onSuccessContainer,
      warning: warning ?? this.warning,
      warningContainer: warningContainer ?? this.warningContainer,
      onWarningContainer: onWarningContainer ?? this.onWarningContainer,
    );
  }

  @override
  AppColors lerp(ThemeExtension<AppColors>? other, double t) {
    if (other is! AppColors) {
      return this;
    }
    return AppColors(
      background: Color.lerp(background, other.background, t)!,
      surfaceMuted: Color.lerp(surfaceMuted, other.surfaceMuted, t)!,
      borderSubtle: Color.lerp(borderSubtle, other.borderSubtle, t)!,
      textSecondary: Color.lerp(textSecondary, other.textSecondary, t)!,
      textDisabled: Color.lerp(textDisabled, other.textDisabled, t)!,
      success: Color.lerp(success, other.success, t)!,
      successContainer:
          Color.lerp(successContainer, other.successContainer, t)!,
      onSuccessContainer:
          Color.lerp(onSuccessContainer, other.onSuccessContainer, t)!,
      warning: Color.lerp(warning, other.warning, t)!,
      warningContainer:
          Color.lerp(warningContainer, other.warningContainer, t)!,
      onWarningContainer:
          Color.lerp(onWarningContainer, other.onWarningContainer, t)!,
    );
  }
}

/// Akses singkat ke token warna dari widget.
extension AppColorsContext on BuildContext {
  AppColors get appColors =>
      Theme.of(this).extension<AppColors>() ?? AppColors.light;

  ColorScheme get colorScheme => Theme.of(this).colorScheme;
}
