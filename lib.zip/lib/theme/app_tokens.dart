import 'package:flutter/widgets.dart';

/// Skala spacing grid 4 pt (Tahap 3 §2.3).
abstract final class AppSpacing {
  static const double xs = 4;
  static const double sm = 8;
  static const double md = 12;
  static const double lg = 16;
  static const double xl = 24;
  static const double xxl = 32;
  static const double xxxl = 48;

  /// Jarak kiri/kanan layar.
  static const double gutter = 16;

  /// Lebar konten maksimum pada layar lebar/Web.
  static const double maxContentWidth = 720;

  static const double sectionGap = 24;
  static const double cardGap = 12;
}

/// Radius sudut (Tahap 3 §2.3).
abstract final class AppRadius {
  static const double sm = 8;
  static const double md = 12;
  static const double lg = 16;
  static const double xl = 24;

  static const BorderRadius smAll = BorderRadius.all(Radius.circular(sm));
  static const BorderRadius mdAll = BorderRadius.all(Radius.circular(md));
  static const BorderRadius lgAll = BorderRadius.all(Radius.circular(lg));
  static const BorderRadius xlAll = BorderRadius.all(Radius.circular(xl));
}

/// Ukuran yang dipakai berulang.
abstract final class AppSizes {
  /// Target sentuh minimum (NFR-017).
  static const double minTouchTarget = 48;
  static const double buttonHeight = 52;
  static const double compactButtonHeight = 44;
  static const double iconSize = 24;
  static const double smallIconSize = 20;
}

/// Durasi animasi (Tahap 3 §2.4).
abstract final class AppDurations {
  static const Duration micro = Duration(milliseconds: 150);
  static const Duration medium = Duration(milliseconds: 250);
  static const Duration page = Duration(milliseconds: 300);

  /// Indikator loading untuk data lokal hanya muncul setelah jeda ini.
  static const Duration loadingDelay = Duration(milliseconds: 300);
}
