import 'package:flutter/foundation.dart';
import 'package:flutter/services.dart';
import 'package:flutter/widgets.dart';
import 'package:flutter_timezone/flutter_timezone.dart';
import 'package:intl/date_symbol_data_local.dart';
import 'package:intl/intl.dart';
import 'package:timezone/data/latest_all.dart' as tzdata;
import 'package:timezone/timezone.dart' as tz;

import 'core/config/supabase_bootstrap.dart';
import 'core/notifications/notification_service.dart';
import 'core/storage/hive_local_box.dart';
import 'core/storage/local_database.dart';

/// Layanan yang dibuka sebelum `runApp` dan disuntik ke ProviderScope.
class AppServices {
  const AppServices({required this.database, required this.notifications});

  final LocalDatabase database;
  final NotificationService notifications;
}

/// Inisialisasi sebelum `runApp` (Tahap 2 §4).
///
/// - 4A: lokal Indonesia dan lisensi font.
/// - 4B: Supabase (bila `env.json` terisi).
/// - 4C: Hive, zona waktu perangkat, notifikasi lokal.
Future<AppServices> bootstrap() async {
  WidgetsFlutterBinding.ensureInitialized();

  Intl.defaultLocale = 'id_ID';
  await initializeDateFormatting('id_ID');
  LicenseRegistry.addLicense(_fontLicense);

  await _initTimezone();
  await SupabaseBootstrap.initialize();

  LocalDatabase database;
  try {
    database = await openHiveDatabase();
  } catch (error) {
    // Sangat jarang (penyimpanan penuh/rusak). Aplikasi tetap terbuka dengan
    // data di memori; data akan ditarik ulang dari server.
    debugPrint('Hive gagal dibuka, memakai memori: $error');
    database = LocalDatabase.inMemory();
  }

  final NotificationService notifications =
      kIsWeb ? NoopNotificationService() : LocalNotificationService();
  await notifications.initialize();

  return AppServices(database: database, notifications: notifications);
}

/// Zona lokal untuk `zonedSchedule`. Fallback ke Asia/Jakarta.
Future<void> _initTimezone() async {
  tzdata.initializeTimeZones();
  String name = 'Asia/Jakarta';
  if (!kIsWeb) {
    try {
      final TimezoneInfo info = await FlutterTimezone.getLocalTimezone();
      name = info.identifier;
    } catch (error) {
      debugPrint('Zona waktu perangkat tidak terbaca: $error');
    }
  }
  try {
    tz.setLocalLocation(tz.getLocation(name));
  } catch (_) {
    tz.setLocalLocation(tz.getLocation('Asia/Jakarta'));
  }
}

Stream<LicenseEntry> _fontLicense() async* {
  final String text = await rootBundle.loadString('assets/fonts/OFL.txt');
  yield LicenseEntryWithLineBreaks(const <String>['Plus Jakarta Sans'], text);
}
