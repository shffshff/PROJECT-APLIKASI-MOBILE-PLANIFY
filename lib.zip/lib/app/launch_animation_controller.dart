import 'package:flutter_riverpod/flutter_riverpod.dart';

/// An intro belongs to an app launch, not every authentication state change.
final NotifierProvider<LaunchAnimationController, bool>
launchAnimationCompletedProvider =
    NotifierProvider<LaunchAnimationController, bool>(
      LaunchAnimationController.new,
    );

class LaunchAnimationController extends Notifier<bool> {
  @override
  bool build() => false;

  void complete() {
    if (!state) {
      state = true;
    }
  }
}
