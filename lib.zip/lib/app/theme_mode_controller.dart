import 'dart:async';

import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../features/profile/data/preferences_repository.dart';

/// Mode tema aktif (FR-044). Disimpan di perangkat (`device_settings`)
/// sehingga langsung berlaku saat aplikasi dibuka — juga sebelum masuk —
/// dan disinkronkan ke `user_preferences.theme_mode` saat sudah masuk.
class ThemeModeController extends Notifier<ThemeMode> {
  @override
  ThemeMode build() => ref.read(preferencesRepositoryProvider).deviceTheme();

  void setMode(ThemeMode mode) {
    state = mode;
    unawaited(ref.read(preferencesRepositoryProvider).save(themeMode: mode));
  }

  /// Dipakai setelah sinkron menarik preferensi dari perangkat lain.
  void applyRemote(ThemeMode mode) {
    if (state != mode) {
      state = mode;
      unawaited(ref.read(preferencesRepositoryProvider).setDeviceTheme(mode));
    }
  }
}

final NotifierProvider<ThemeModeController, ThemeMode> themeModeProvider =
    NotifierProvider<ThemeModeController, ThemeMode>(ThemeModeController.new);
