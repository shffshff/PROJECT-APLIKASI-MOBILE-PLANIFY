import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:go_router/go_router.dart';

/// C-23 — Scaffold dengan bottom navigation lima tab (Tahap 3 §3.1).
///
/// Aturan tombol back (Tahap 3 §3.4):
/// - halaman detail di dalam tab di-pop oleh go_router sebelum sampai ke sini;
/// - di root tab selain Home → pindah ke Home;
/// - di Home → snackbar "Tekan sekali lagi untuk keluar", lalu keluar bila
///   ditekan lagi dalam 2 detik.
class MainShell extends StatefulWidget {
  const MainShell({super.key, required this.navigationShell});

  final StatefulNavigationShell navigationShell;

  /// Urutan tab tidak boleh diubah: Home, Planner, Focus, AI Assistant, Profile.
  static const List<NavigationDestination> destinations =
      <NavigationDestination>[
    NavigationDestination(
      icon: Icon(Icons.home_outlined),
      selectedIcon: Icon(Icons.home_rounded),
      label: 'Home',
    ),
    NavigationDestination(
      icon: Icon(Icons.event_note_outlined),
      selectedIcon: Icon(Icons.event_note_rounded),
      label: 'Planner',
    ),
    NavigationDestination(
      icon: Icon(Icons.timer_outlined),
      selectedIcon: Icon(Icons.timer_rounded),
      label: 'Focus',
    ),
    NavigationDestination(
      icon: Icon(Icons.auto_awesome_outlined),
      selectedIcon: Icon(Icons.auto_awesome_rounded),
      label: 'AI Assistant',
    ),
    NavigationDestination(
      icon: Icon(Icons.person_outline_rounded),
      selectedIcon: Icon(Icons.person_rounded),
      label: 'Profile',
    ),
  ];

  static const Duration exitWindow = Duration(seconds: 2);

  @override
  State<MainShell> createState() => _MainShellState();
}

class _MainShellState extends State<MainShell> {
  DateTime? _lastBackPressedAt;

  void _onDestinationSelected(int index) {
    // Mengetuk tab yang sedang aktif mengembalikan tab ke root-nya.
    widget.navigationShell.goBranch(
      index,
      initialLocation: index == widget.navigationShell.currentIndex,
    );
  }

  void _handleBack(bool didPop, Object? result) {
    if (didPop) {
      return;
    }
    if (widget.navigationShell.currentIndex != 0) {
      widget.navigationShell.goBranch(0);
      return;
    }
    final DateTime now = DateTime.now();
    final DateTime? last = _lastBackPressedAt;
    if (last != null && now.difference(last) < MainShell.exitWindow) {
      SystemNavigator.pop();
      return;
    }
    _lastBackPressedAt = now;
    ScaffoldMessenger.of(context)
      ..hideCurrentSnackBar()
      ..showSnackBar(
        const SnackBar(
          content: Text('Tekan sekali lagi untuk keluar'),
          duration: MainShell.exitWindow,
        ),
      );
  }

  @override
  Widget build(BuildContext context) {
    return PopScope<Object?>(
      canPop: false,
      onPopInvokedWithResult: _handleBack,
      child: Scaffold(
        body: widget.navigationShell,
        bottomNavigationBar: NavigationBar(
          selectedIndex: widget.navigationShell.currentIndex,
          onDestinationSelected: _onDestinationSelected,
          destinations: MainShell.destinations,
        ),
      ),
    );
  }
}
