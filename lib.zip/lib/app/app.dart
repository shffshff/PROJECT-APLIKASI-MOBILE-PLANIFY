import 'dart:async';

import 'package:flutter/material.dart';
import 'package:flutter_localizations/flutter_localizations.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:go_router/go_router.dart';

import '../core/notifications/notification_service.dart';
import '../features/auth/application/session_controller.dart';
import '../features/auth/application/session_state.dart';
import '../features/auth/presentation/app_lifecycle_lock_observer.dart';
import '../theme/app_theme.dart';
import 'router/app_router.dart';
import 'router/routes.dart';
import 'sync/sync_controller.dart';
import 'theme_mode_controller.dart';

/// Widget akar aplikasi: tema, lokalisasi Indonesia, router, sinkronisasi,
/// dan perutean ketukan notifikasi.
class PlanifyApp extends ConsumerStatefulWidget {
  const PlanifyApp({super.key});

  static const Locale indonesian = Locale('id', 'ID');

  @override
  ConsumerState<PlanifyApp> createState() => _PlanifyAppState();
}

class _PlanifyAppState extends ConsumerState<PlanifyApp> {
  StreamSubscription<String>? _taps;

  /// Payload yang menunggu sesi siap (cold start dari notifikasi, Tahap 2
  /// §5.2 "pending deep link").
  String? _pendingPayload;

  @override
  void initState() {
    super.initState();
    final NotificationService notifications =
        ref.read(notificationServiceProvider);
    _taps = notifications.taps.listen(_handlePayload);
    unawaited(notifications.takeLaunchPayload().then((String? p) {
      if (p != null) {
        _handlePayload(p);
      }
    }));
  }

  @override
  void dispose() {
    _taps?.cancel();
    super.dispose();
  }

  bool get _sessionActive {
    final SessionState s = ref.read(sessionControllerProvider);
    return s.isAuthenticated && !s.isLocked;
  }

  void _handlePayload(String payload) {
    if (!mounted) {
      return;
    }
    if (!_sessionActive) {
      _pendingPayload = payload;
      return;
    }
    final GoRouter router = ref.read(appRouterProvider);
    if (payload.startsWith('task:')) {
      router.go(AppRoutes.planner);
      router.push(AppRoutes.taskDetail(payload.substring(5)));
    } else if (payload == 'focus') {
      router.go(AppRoutes.focus);
    }
  }

  @override
  Widget build(BuildContext context) {
    final GoRouter router = ref.watch(appRouterProvider);
    final ThemeMode themeMode = ref.watch(themeModeProvider);

    // Menjaga SyncController hidup tanpa membangun ulang seluruh aplikasi.
    ref.listen<SyncState>(syncControllerProvider, (_, _) {});
    ref.listen<SessionState>(sessionControllerProvider,
        (SessionState? prev, SessionState next) {
      final String? pending = _pendingPayload;
      if (pending != null && next.isAuthenticated && !next.isLocked) {
        _pendingPayload = null;
        // Tunggu redirect auth/lock selesai lebih dulu.
        WidgetsBinding.instance
            .addPostFrameCallback((_) => _handlePayload(pending));
      }
    });

    return MaterialApp.router(
      title: 'PLANIFY',
      debugShowCheckedModeBanner: false,
      theme: AppTheme.light(),
      darkTheme: AppTheme.dark(),
      themeMode: themeMode,
      routerConfig: router,
      builder: (BuildContext context, Widget? child) =>
          AppLifecycleLockObserver(child: child ?? const SizedBox.shrink()),
      locale: PlanifyApp.indonesian,
      supportedLocales: const <Locale>[
        PlanifyApp.indonesian,
        Locale('en', 'US'),
      ],
      localizationsDelegates: GlobalMaterialLocalizations.delegates,
    );
  }
}
