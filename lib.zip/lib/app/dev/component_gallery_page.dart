import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../../core/error/app_failure.dart';
import '../../core/widgets/app_button.dart';
import '../../core/widgets/app_progress.dart';
import '../../core/widgets/app_text_field.dart';
import '../../core/widgets/confirm_dialog.dart';
import '../../core/widgets/empty_state.dart';
import '../../core/widgets/error_state.dart';
import '../../core/widgets/loading_indicator.dart';
import '../../core/widgets/page_container.dart';
import '../../core/widgets/password_field.dart';
import '../../core/widgets/priority_badge.dart';
import '../../core/widgets/quick_action_tile.dart';
import '../../core/widgets/section_header.dart';
import '../../core/widgets/settings_tile.dart';
import '../../core/widgets/status_banner.dart';
import '../../core/widgets/sync_status_indicator.dart';
import '../../features/planner/domain/task_priority.dart';
import '../../theme/app_colors.dart';
import '../../theme/app_theme.dart';
import '../../theme/app_tokens.dart';
import '../theme_mode_controller.dart';

/// Galeri design system (hanya mode debug) untuk membandingkan komponen
/// dengan mockup Tahap 3 di light dan dark mode.
class ComponentGalleryPage extends ConsumerStatefulWidget {
  const ComponentGalleryPage({super.key});

  @override
  ConsumerState<ComponentGalleryPage> createState() =>
      _ComponentGalleryPageState();
}

class _ComponentGalleryPageState extends ConsumerState<ComponentGalleryPage> {
  final GlobalKey<FormState> _formKey = GlobalKey<FormState>();
  bool _loading = false;
  bool _toggle = true;
  String _dialogResult = 'Belum dipilih';

  Future<void> _simulateLoading() async {
    setState(() => _loading = true);
    await Future<void>.delayed(const Duration(seconds: 2));
    if (mounted) {
      setState(() => _loading = false);
    }
  }

  Future<void> _openDialog() async {
    final ConfirmResult result = await showConfirmDialog(
      context,
      title: 'Hapus tugas ini?',
      message: 'Pengingatnya juga akan dibatalkan.',
      confirmLabel: 'Hapus',
      isDestructive: true,
    );
    if (mounted) {
      setState(() => _dialogResult = result.name);
    }
  }

  void _toggleTheme() {
    final ThemeMode current = ref.read(themeModeProvider);
    final Brightness platform = MediaQuery.platformBrightnessOf(context);
    final bool isDark = current == ThemeMode.dark ||
        (current == ThemeMode.system && platform == Brightness.dark);
    ref
        .read(themeModeProvider.notifier)
        .setMode(isDark ? ThemeMode.light : ThemeMode.dark);
  }

  @override
  Widget build(BuildContext context) {
    final ThemeData theme = Theme.of(context);
    final ColorScheme scheme = theme.colorScheme;
    final AppColors colors = context.appColors;
    const SizedBox gap = SizedBox(height: AppSpacing.md);
    const SizedBox sectionGap = SizedBox(height: AppSpacing.sectionGap);

    final List<(String, Color)> swatches = <(String, Color)>[
      ('primary', scheme.primary),
      ('primaryContainer', scheme.primaryContainer),
      ('secondary', scheme.secondary),
      ('secondaryContainer', scheme.secondaryContainer),
      ('background', colors.background),
      ('surface', scheme.surface),
      ('surfaceMuted', colors.surfaceMuted),
      ('outline', scheme.outline),
      ('success', colors.success),
      ('warning', colors.warning),
      ('error', scheme.error),
      ('textSecondary', colors.textSecondary),
    ];

    return Scaffold(
      appBar: AppBar(
        title: const Text('Galeri komponen'),
        actions: <Widget>[
          IconButton(
            tooltip: 'Ganti tema terang/gelap',
            icon: const Icon(Icons.contrast_rounded),
            onPressed: _toggleTheme,
          ),
        ],
      ),
      body: SafeArea(
        child: ListView(
          padding: const EdgeInsets.only(bottom: AppSpacing.xxxl),
          children: <Widget>[
            PageContainer(
              child: Form(
                key: _formKey,
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.stretch,
                  children: <Widget>[
                    const SectionHeader(title: 'Warna'),
                    gap,
                    Wrap(
                      spacing: AppSpacing.sm,
                      runSpacing: AppSpacing.sm,
                      children: <Widget>[
                        for (final (String name, Color color) in swatches)
                          _Swatch(name: name, color: color),
                      ],
                    ),
                    sectionGap,
                    const SectionHeader(title: 'Tipografi'),
                    gap,
                    Text('18:42', style: AppTypography.timerDisplay),
                    Text('Rp 2.350.000', style: theme.textTheme.displaySmall),
                    Text('Selamat pagi, Nadia',
                        style: theme.textTheme.headlineSmall),
                    Text('Judul AppBar', style: theme.textTheme.titleLarge),
                    Text('Judul kartu tugas',
                        style: theme.textTheme.titleMedium),
                    Text('Isi utama 16/24', style: theme.textTheme.bodyLarge),
                    Text('Isi sekunder 14/20',
                        style: theme.textTheme.bodyMedium),
                    Text('Caption 12/16', style: theme.textTheme.bodySmall),
                    sectionGap,
                    const SectionHeader(title: 'Tombol'),
                    gap,
                    AppButton(
                      label: 'Simpan',
                      expand: true,
                      isLoading: _loading,
                      onPressed: _simulateLoading,
                    ),
                    gap,
                    Wrap(
                      spacing: AppSpacing.sm,
                      runSpacing: AppSpacing.sm,
                      children: <Widget>[
                        AppButton(
                          label: 'Mulai fokus',
                          variant: AppButtonVariant.tonal,
                          onPressed: () {},
                        ),
                        AppButton(
                          label: 'Reset',
                          icon: Icons.refresh_rounded,
                          variant: AppButtonVariant.outline,
                          onPressed: () {},
                        ),
                        AppButton(
                          label: 'Lihat semua',
                          variant: AppButtonVariant.text,
                          onPressed: () {},
                        ),
                        AppButton(
                          label: 'Hapus',
                          variant: AppButtonVariant.destructive,
                          onPressed: _openDialog,
                        ),
                        const AppButton(label: 'Nonaktif', onPressed: null),
                      ],
                    ),
                    gap,
                    Text('Hasil dialog: $_dialogResult',
                        style: theme.textTheme.bodySmall),
                    sectionGap,
                    const SectionHeader(title: 'Input'),
                    gap,
                    AppTextField(
                      label: 'Judul',
                      isRequired: true,
                      maxLength: 100,
                      showCounterFrom: 80,
                      textInputAction: TextInputAction.next,
                      validator: (String? value) =>
                          (value == null || value.trim().isEmpty)
                              ? 'Judul wajib diisi'
                              : null,
                    ),
                    gap,
                    const AppTextField(
                      label: 'Deskripsi',
                      maxLength: 500,
                      showCounterFrom: 0,
                      minLines: 3,
                      maxLines: 6,
                    ),
                    gap,
                    const PasswordField(isRequired: true),
                    gap,
                    AppButton(
                      label: 'Validasi form',
                      variant: AppButtonVariant.outline,
                      onPressed: () => _formKey.currentState?.validate(),
                    ),
                    sectionGap,
                    const SectionHeader(title: 'Badge & status'),
                    gap,
                    const Wrap(
                      spacing: AppSpacing.sm,
                      children: <Widget>[
                        PriorityBadge(priority: TaskPriority.high),
                        PriorityBadge(priority: TaskPriority.medium),
                        PriorityBadge(priority: TaskPriority.low),
                      ],
                    ),
                    gap,
                    const Wrap(
                      spacing: AppSpacing.sm,
                      children: <Widget>[
                        SyncStatusIndicator(state: SyncIndicatorState.synced),
                        SyncStatusIndicator(
                          state: SyncIndicatorState.pending,
                          count: 3,
                        ),
                        SyncStatusIndicator(
                          state: SyncIndicatorState.failed,
                          count: 1,
                        ),
                        SyncStatusIndicator(state: SyncIndicatorState.offline),
                      ],
                    ),
                    gap,
                    const StatusBanner(
                      type: StatusBannerType.warning,
                      title: 'Sesi kamu berakhir.',
                      message: 'Silakan masuk kembali. Perubahan yang belum '
                          'tersinkron tetap aman di perangkat.',
                    ),
                    gap,
                    StatusBanner(
                      type: StatusBannerType.info,
                      message: 'Izin notifikasi akan diminta saat kamu '
                          'menyimpan tugas ini.',
                      actionLabel: 'Pelajari',
                      onAction: () {},
                    ),
                    gap,
                    const StatusBanner(
                      type: StatusBannerType.success,
                      message: 'Semua kegiatan muat dalam waktu tersedia.',
                    ),
                    gap,
                    const StatusBanner(
                      type: StatusBannerType.error,
                      title: 'Rantai rusak pada blok #2.',
                      message: 'Hash tidak cocok setelah data diubah.',
                    ),
                    gap,
                    const StatusBanner(
                      type: StatusBannerType.offline,
                      message: 'Sedang offline — perubahan akan disinkron.',
                    ),
                    sectionGap,
                    const SectionHeader(title: 'Progres'),
                    gap,
                    Row(
                      children: <Widget>[
                        AppProgressRing(
                          value: 3 / 7,
                          semanticsLabel: '3 dari 7 tugas selesai',
                          center: Text(
                            '43%',
                            style: theme.textTheme.titleLarge!.copyWith(
                              fontFeatures: AppTypography.tabularFigures,
                            ),
                          ),
                        ),
                        const SizedBox(width: AppSpacing.lg),
                        const Expanded(
                          child: AppLinearProgress(
                            value: 0.5,
                            semanticsLabel: 'Progres kebiasaan',
                          ),
                        ),
                      ],
                    ),
                    gap,
                    const WeeklyBars(
                      values: <double>[0.75, 0.5, 0, 0, 0, 0, 0],
                      labels: <String>[
                        'Sen',
                        'Sel',
                        'Rab',
                        'Kam',
                        'Jum',
                        'Sab',
                        'Min',
                      ],
                      semanticsLabel:
                          'Minggu ini: Senin 75 persen, Selasa 50 persen',
                    ),
                    sectionGap,
                    const SectionHeader(title: 'Akses cepat & menu'),
                    gap,
                    GridView.count(
                      crossAxisCount: 4,
                      shrinkWrap: true,
                      physics: const NeverScrollableScrollPhysics(),
                      mainAxisSpacing: AppSpacing.sm,
                      crossAxisSpacing: AppSpacing.sm,
                      childAspectRatio: 0.85,
                      children: <Widget>[
                        QuickActionTile(
                          icon: Icons.local_fire_department_rounded,
                          label: 'Kebiasaan',
                          iconColor: scheme.secondary,
                          iconBackground: scheme.secondaryContainer,
                          onTap: () {},
                        ),
                        QuickActionTile(
                          icon: Icons.place_rounded,
                          label: 'Tempat',
                          onTap: () {},
                        ),
                        QuickActionTile(
                          icon: Icons.currency_exchange_rounded,
                          label: 'Kurs',
                          onTap: () {},
                        ),
                        QuickActionTile(
                          icon: Icons.schedule_rounded,
                          label: 'Zona waktu',
                          onTap: () {},
                        ),
                      ],
                    ),
                    gap,
                    Card(
                      child: Column(
                        children: <Widget>[
                          SettingsTile.navigation(
                            icon: Icons.link_rounded,
                            title: 'Hash-Chain Demo',
                            onTap: () {},
                          ),
                          const Divider(),
                          SettingsTile.toggle(
                            icon: Icons.fingerprint_rounded,
                            title: 'Login biometrik',
                            subtitle: 'Kunci lokal dengan sidik jari/wajah',
                            value: _toggle,
                            onChanged: (bool value) =>
                                setState(() => _toggle = value),
                          ),
                          const Divider(),
                          SettingsTile.toggle(
                            icon: Icons.sensors_rounded,
                            title: 'Focus Otomatis',
                            value: false,
                            enabled: false,
                            disabledReason:
                                'Sensor gerak tidak tersedia di perangkat ini',
                            onChanged: (bool value) {},
                          ),
                        ],
                      ),
                    ),
                    sectionGap,
                    const SectionHeader(title: 'Empty, error, loading'),
                    Card(
                      child: EmptyState(
                        icon: Icons.event_note_rounded,
                        title: 'Belum ada tugas',
                        message: 'Mulai harimu dengan menambah tugas pertama.',
                        primaryActionLabel: 'Tambah tugas',
                        onPrimaryAction: () {},
                        secondaryActionLabel: 'Minta usulan jadwal AI',
                        onSecondaryAction: () {},
                      ),
                    ),
                    gap,
                    Card(
                      child: ErrorState(
                        failure: const AppFailure(AppFailureKind.network),
                        compact: true,
                        onRetry: () {},
                      ),
                    ),
                    gap,
                    const Card(
                      child: Padding(
                        padding: EdgeInsets.all(AppSpacing.lg),
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: <Widget>[
                            SkeletonBox(width: 160, height: 20),
                            SizedBox(height: AppSpacing.sm),
                            SkeletonBox(height: 14),
                            SizedBox(height: AppSpacing.sm),
                            SkeletonBox(width: 220, height: 14),
                            SizedBox(height: AppSpacing.lg),
                            Center(
                              child: LoadingIndicator(label: 'Memuat kurs…'),
                            ),
                          ],
                        ),
                      ),
                    ),
                  ],
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}

class _Swatch extends StatelessWidget {
  const _Swatch({required this.name, required this.color});

  final String name;
  final Color color;

  @override
  Widget build(BuildContext context) {
    return SizedBox(
      width: 104,
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: <Widget>[
          Container(
            height: 44,
            decoration: BoxDecoration(
              color: color,
              borderRadius: AppRadius.smAll,
              border: Border.all(color: context.appColors.borderSubtle),
            ),
          ),
          const SizedBox(height: AppSpacing.xs),
          Text(
            name,
            style: Theme.of(context).textTheme.labelSmall,
            overflow: TextOverflow.ellipsis,
          ),
        ],
      ),
    );
  }
}
