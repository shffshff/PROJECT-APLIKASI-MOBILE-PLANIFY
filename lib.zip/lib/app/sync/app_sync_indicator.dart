import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../../core/widgets/sync_status_indicator.dart';
import '../../core/utils/app_date_format.dart';
import 'sync_controller.dart';

/// Indikator sinkron di AppBar (FR-051, C-15). Ketuk = sinkron sekarang.
class AppSyncIndicator extends ConsumerWidget {
  const AppSyncIndicator({super.key});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final SyncState sync = ref.watch(syncControllerProvider);
    final (SyncIndicatorState indicator, int count) = switch (sync.phase) {
      SyncPhase.offline => (SyncIndicatorState.offline, sync.pending),
      SyncPhase.error => (SyncIndicatorState.failed, sync.failed),
      _ when sync.failed > 0 => (SyncIndicatorState.failed, sync.failed),
      _ when sync.pending > 0 || sync.phase == SyncPhase.notConfigured =>
        (SyncIndicatorState.pending, sync.pending),
      _ => (SyncIndicatorState.synced, 0),
    };
    return SyncStatusIndicator(
      state: indicator,
      count: count,
      onTap: () => _onTap(context, ref, sync),
    );
  }

  Future<void> _onTap(
    BuildContext context,
    WidgetRef ref,
    SyncState sync,
  ) async {
    final ScaffoldMessengerState messenger = ScaffoldMessenger.of(context);
    if (sync.phase == SyncPhase.notConfigured) {
      messenger.showSnackBar(
        const SnackBar(
          content: Text(
            'Data tersimpan di perangkat. Sinkron aktif setelah aplikasi '
            'dihubungkan ke Supabase.',
          ),
        ),
      );
      return;
    }
    final SyncController controller = ref.read(syncControllerProvider.notifier);
    if (sync.failed > 0) {
      await controller.retryFailed();
    } else {
      await controller.syncNow();
    }
    final SyncState after = ref.read(syncControllerProvider);
    final DateTime? last = after.lastSyncAt;
    final String text = switch (after.phase) {
      SyncPhase.offline =>
        'Sedang offline. Perubahan tersimpan dan dikirim saat online.',
      SyncPhase.error =>
        'Sebagian data ditolak server. Ketuk lagi untuk mencoba ulang.',
      _ when after.pending > 0 =>
        '${after.pending} perubahan masih menunggu dikirim.',
      _ => last == null
          ? 'Data sudah tersinkron.'
          : 'Tersinkron ${AppDateFormat.time(last.toLocal())}.',
    };
    messenger.showSnackBar(SnackBar(content: Text(text)));
  }
}
