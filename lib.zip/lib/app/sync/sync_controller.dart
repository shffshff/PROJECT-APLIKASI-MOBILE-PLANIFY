import 'dart:async';

import 'package:flutter/foundation.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../../core/network/connectivity_source.dart';
import '../../core/storage/local_database.dart';
import '../../core/sync/local_change_signal.dart';
import '../../core/sync/remote_gateway.dart';
import '../../core/sync/sync_engine.dart';
import '../../core/sync/sync_entity.dart';
import '../../features/auth/application/session_controller.dart';
import '../../features/auth/application/session_state.dart';
import '../../features/focus/domain/focus_session.dart';
import '../../features/habit/domain/habit.dart';
import '../../features/planner/data/task_repository.dart';
import '../../features/planner/domain/task.dart';
import '../../features/feedback/data/feedback_repository.dart';
import '../../features/profile/data/preferences_repository.dart';
import '../../features/reminder/reminder_scheduler.dart';
import '../theme_mode_controller.dart';

/// Urutan tabel sesuai ketergantungan FK (Tahap 2 §10.2 langkah 4).
const List<SyncTableSpec> kSyncTables = <SyncTableSpec>[
  UserPreferences.spec,
  Task.spec,
  Habit.spec,
  HabitLog.spec,
  FocusSession.spec,
];

final Provider<SyncEngine?> syncEngineProvider = Provider<SyncEngine?>((Ref ref) {
  final RemoteGateway? remote = ref.watch(remoteGatewayProvider);
  if (remote == null) {
    return null;
  }
  return SyncEngine(
    database: ref.watch(localDatabaseProvider),
    remote: remote,
    tables: kSyncTables,
  );
});

enum SyncPhase { notConfigured, idle, syncing, offline, error }

@immutable
class SyncState {
  const SyncState({
    this.phase = SyncPhase.idle,
    this.pending = 0,
    this.failed = 0,
    this.conflicts = 0,
    this.lastSyncAt,
  });

  final SyncPhase phase;
  final int pending;
  final int failed;

  /// Versi lokal yang kalah konflik dan disimpan untuk ditinjau.
  final int conflicts;
  final DateTime? lastSyncAt;

  SyncState copyWith({
    SyncPhase? phase,
    int? pending,
    int? failed,
    int? conflicts,
    DateTime? lastSyncAt,
  }) {
    return SyncState(
      phase: phase ?? this.phase,
      pending: pending ?? this.pending,
      failed: failed ?? this.failed,
      conflicts: conflicts ?? this.conflicts,
      lastSyncAt: lastSyncAt ?? this.lastSyncAt,
    );
  }
}

/// Mengatur kapan sinkron berjalan (Tahap 2 §10.2 langkah 2):
/// setelah sesi siap, saat jaringan kembali, beberapa detik setelah
/// perubahan lokal, berkala selama aplikasi terbuka, dan manual.
///
/// Juga menjaga data antar-akun: bila akun yang masuk berbeda dari akun
/// terakhir di perangkat ini, data lokal akun sebelumnya dihapus dulu.
class SyncController extends Notifier<SyncState> {
  static const Duration debounce = Duration(seconds: 3);

  /// ASUMSI 4C (Tahap 2 menandai interval [PERLU DIKONFIRMASI]).
  static const Duration periodic = Duration(minutes: 5);
  static const String _lastUserKey = 'last_active_user_id';

  Timer? _debounce;
  Timer? _periodic;
  StreamSubscription<void>? _localSub;
  StreamSubscription<bool>? _netSub;
  bool _online = true;

  LocalDatabase get _db => ref.read(localDatabaseProvider);
  SyncEngine? get _engine => ref.read(syncEngineProvider);

  @override
  SyncState build() {
    ref.onDispose(() {
      _debounce?.cancel();
      _periodic?.cancel();
      _localSub?.cancel();
      _netSub?.cancel();
    });

    _localSub = ref.read(localChangeSignalProvider).stream.listen((_) {
      _refreshCounts();
      schedule();
    });

    final ConnectivitySource net = ref.read(connectivityProvider);
    _netSub = net.onlineChanges.listen((bool online) {
      _online = online;
      if (online) {
        unawaited(syncNow());
      } else if (ref.mounted) {
        state = state.copyWith(phase: SyncPhase.offline);
      }
    });

    ref.listen<SessionState>(
      sessionControllerProvider,
      (SessionState? previous, SessionState next) =>
          unawaited(_onSession(previous, next)),
      fireImmediately: true,
    );

    final SyncEngine? engine = _engine;
    return _counts(SyncState(
      phase: engine == null ? SyncPhase.notConfigured : SyncPhase.idle,
      lastSyncAt: engine?.lastSyncAt,
    ));
  }

  bool get _canSync {
    final SessionState session = ref.read(sessionControllerProvider);
    return _engine != null && session.isAuthenticated && !session.isLocked;
  }

  Future<void> _onSession(SessionState? previous, SessionState next) async {
    final bool wasActive =
        previous != null && previous.isAuthenticated && !previous.isLocked;
    final bool isActive = next.isAuthenticated && !next.isLocked;
    if (isActive && !wasActive) {
      await _guardAccount(next.user!.id);
      _periodic?.cancel();
      _periodic = Timer.periodic(periodic, (_) => unawaited(syncNow()));
      await ref
          .read(reminderSchedulerProvider)
          .reconcile(ref.read(taskRepositoryProvider).all());
      final UserPreferences? prefs =
          await ref.read(preferencesRepositoryProvider).pullInitial();
      if (prefs != null && ref.mounted) {
        ref.read(themeModeProvider.notifier).applyRemote(prefs.themeMode);
      }
      await syncNow();
    } else if (!isActive) {
      _periodic?.cancel();
      _debounce?.cancel();
    }
  }

  /// Data akun lain di perangkat ini dihapus sebelum data akun baru dipakai
  /// (Tahap 2 §5.1: logout membersihkan box).
  Future<void> _guardAccount(String userId) async {
    final String? last = _db.deviceSettings.getRaw(_lastUserKey);
    if (last != null && last != userId) {
      await ref.read(reminderSchedulerProvider).cancelAll();
      await _db.clearUserData();
    }
    await _db.deviceSettings.putRaw(_lastUserKey, userId);
    _refreshCounts();
  }

  SyncState _counts(SyncState base) {
    final Map<SyncStatus, int> counts =
        countSyncStatus(_db, kSyncTables);
    return base.copyWith(
      pending: counts[SyncStatus.pending],
      failed: counts[SyncStatus.failed],
      conflicts: _db.syncConflicts.keys.length,
    );
  }

  void _refreshCounts() {
    if (ref.mounted) {
      state = _counts(state);
    }
  }

  /// Menjadwalkan sinkron setelah jeda (menggabungkan banyak perubahan).
  void schedule() {
    if (!_canSync) {
      return;
    }
    _debounce?.cancel();
    _debounce = Timer(debounce, () => unawaited(syncNow()));
  }

  /// Menjalankan sinkron sekarang. Aman dipanggil berkali-kali (mutex).
  Future<SyncReport?> syncNow() async {
    final SyncEngine? engine = _engine;
    if (engine == null) {
      _refreshCounts();
      return null;
    }
    if (!_canSync) {
      return null;
    }
    if (!_online && !await ref.read(connectivityProvider).isOnline()) {
      if (ref.mounted) {
        state = _counts(state.copyWith(phase: SyncPhase.offline));
      }
      return null;
    }
    if (ref.mounted) {
      state = state.copyWith(phase: SyncPhase.syncing);
    }
    final SyncReport? report = await engine.run();
    if (!ref.mounted) {
      return report;
    }
    if (report == null) {
      return null; // putaran lain sedang berjalan
    }
    if (report.changedTables.contains(UserPreferences.spec.table)) {
      final UserPreferences? prefs =
          ref.read(preferencesRepositoryProvider).current();
      if (prefs != null) {
        ref.read(themeModeProvider.notifier).applyRemote(prefs.themeMode);
      }
    }
    if (report.completed) {
      await ref.read(feedbackRepositoryProvider).flush();
    }
    if (report.changedTables.contains(Task.spec.table)) {
      await ref
          .read(reminderSchedulerProvider)
          .reconcile(ref.read(taskRepositoryProvider).all());
    }
    final SyncPhase phase = switch (report.stoppedBy) {
      null => SyncPhase.idle,
      RemoteErrorKind.transient => SyncPhase.offline,
      RemoteErrorKind.unauthorized => SyncPhase.error,
      RemoteErrorKind.rejected => SyncPhase.error,
    };
    state = _counts(state.copyWith(
      phase: phase,
      lastSyncAt: engine.lastSyncAt,
    ));
    return report;
  }

  Future<void> retryFailed() async {
    final SyncEngine? engine = _engine;
    if (engine == null) {
      return;
    }
    await engine.retryFailed();
    _refreshCounts();
    await syncNow();
  }
}

final NotifierProvider<SyncController, SyncState> syncControllerProvider =
    NotifierProvider<SyncController, SyncState>(SyncController.new);
