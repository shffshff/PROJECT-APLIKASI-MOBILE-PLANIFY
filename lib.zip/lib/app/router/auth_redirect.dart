import '../../features/auth/application/session_state.dart';
import 'routes.dart';

/// Guard autentikasi (FR-047) sebagai fungsi murni agar mudah diuji.
///
/// Mengembalikan path tujuan bila [uri] harus dialihkan, atau `null` bila
/// boleh dibuka.
///
/// Aturan:
/// 1. Sebelum sesi siap → tahan di `/splash`.
/// 2. Belum masuk → hanya rute publik; selain itu ke `/login`. Rute
///    `/reset-password` tidak dapat dibuka tanpa mode pemulihan.
/// 3. Mode pemulihan (tautan email) → paksa ke `/reset-password`.
/// 4. Sudah masuk tetapi terkunci biometrik → paksa ke `/lock`.
/// 5. Sudah masuk → halaman auth/splash dialihkan ke `/home`.
///
/// Tautan dalam (deep link) autentikasi dari email tiba sebagai path `/`
/// (skema + host tanpa path); itu ditangani seperti membuka aplikasi biasa.
String? resolveAuthRedirect(SessionState session, Uri uri) {
  final String path = uri.path.isEmpty ? '/' : uri.path;

  if (!session.isReady) {
    return path == AppRoutes.splash ? null : AppRoutes.splash;
  }

  switch (session.phase) {
    case SessionPhase.initializing:
      return null; // tidak tercapai: ditangani di atas.

    case SessionPhase.unauthenticated:
      final bool isPublic = AppRoutes.publicRoutes.contains(path) &&
          path != AppRoutes.resetPassword &&
          path != AppRoutes.splash;
      return isPublic ? null : AppRoutes.login;

    case SessionPhase.passwordRecovery:
      return path == AppRoutes.resetPassword ? null : AppRoutes.resetPassword;

    case SessionPhase.authenticated:
      if (session.isLocked) {
        return path == AppRoutes.lock ? null : AppRoutes.lock;
      }
      const Set<String> authOnly = <String>{
        '/',
        AppRoutes.splash,
        AppRoutes.login,
        AppRoutes.register,
        AppRoutes.forgotPassword,
        AppRoutes.resetPassword,
        AppRoutes.lock,
      };
      return authOnly.contains(path) ? AppRoutes.home : null;
  }
}
