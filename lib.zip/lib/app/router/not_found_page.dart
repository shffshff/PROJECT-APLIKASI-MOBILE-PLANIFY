import 'package:flutter/material.dart';
import 'package:go_router/go_router.dart';

import '../../core/widgets/empty_state.dart';
import 'routes.dart';

/// Ditampilkan bila path tidak dikenal (misalnya deep link lama).
class NotFoundPage extends StatelessWidget {
  const NotFoundPage({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: SafeArea(
        child: Center(
          child: EmptyState(
            icon: Icons.explore_off_rounded,
            title: 'Halaman tidak ditemukan',
            message: 'Tautan ini mungkin sudah tidak berlaku.',
            primaryActionLabel: 'Kembali ke Home',
            onPrimaryAction: () => context.go(AppRoutes.home),
          ),
        ),
      ),
    );
  }
}
