/// Konstanta path rute (Tahap 2 §5.2, diperbarui oleh K-UI-01 Tahap 3:
/// fitur pendukung menjadi rute root di atas shell agar dapat dibuka dari tab
/// mana pun). Rute yang belum diimplementasikan tetap dicatat di sini agar
/// nama path konsisten di sub-tahap berikutnya.
abstract final class AppRoutes {
  // Lima tab utama (bottom navigation).
  static const String home = '/home';
  static const String planner = '/planner';
  static const String focus = '/focus';
  static const String ai = '/ai';
  static const String profile = '/profile';

  // Autentikasi — Tahap 4B.
  static const String splash = '/splash';
  static const String login = '/login';
  static const String register = '/register';
  static const String forgotPassword = '/forgot-password';
  static const String resetPassword = '/reset-password';
  static const String lock = '/lock';
  static const String about = '/about';

  // Planner (di dalam tab Planner) — Tahap 4C.
  static const String taskNew = '/planner/task/new';
  static String taskDetail(String id) => '/planner/task/$id';
  static String taskEdit(String id) => '/planner/task/$id/edit';

  // Focus (di dalam tab Focus) — Tahap 4D.
  static const String focusHistory = '/focus/history';

  // AI (di dalam tab AI) — Tahap 4E.
  static const String aiReview = '/ai/review';

  // Profile (di dalam tab Profile) — Tahap 4F.
  static const String profileSettings = '/profile/settings';
  static const String profileSync = '/profile/sync';
  static const String feedback = '/profile/feedback';

  // Fitur pendukung (rute root) — Tahap 4C–4F.
  static const String habits = '/habits';
  static const String habitNew = '/habits/new';
  static String habitDetail(String id) => '/habits/$id';
  static String habitEdit(String id) => '/habits/$id/edit';
  static const String places = '/tools/places';
  static const String currency = '/tools/currency';
  static const String timezone = '/tools/timezone';
  static const String focusGame = '/focus-game';
  static const String hashChain = '/hash-chain';

  // Hanya mode debug: galeri komponen design system.
  static const String componentGallery = '/dev/components';

  /// Rute yang boleh dibuka tanpa login (FR-047). Dipakai guard Tahap 4B.
  static const Set<String> publicRoutes = <String>{
    splash,
    login,
    register,
    forgotPassword,
    resetPassword,
    about,
  };
}
