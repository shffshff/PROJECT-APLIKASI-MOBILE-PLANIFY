import 'package:flutter/foundation.dart';
import 'package:flutter/widgets.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:go_router/go_router.dart';

import '../../features/ai_assistant/presentation/ai_assistant_page.dart';
import '../../features/ai_assistant/presentation/ai_review_page.dart';
import '../../features/currency/presentation/currency_page.dart';
import '../../features/feedback/presentation/feedback_page.dart';
import '../../features/hash_chain/presentation/hash_chain_page.dart';
import '../../features/navigator/presentation/places_page.dart';
import '../../features/profile/presentation/about_page.dart';
import '../../features/profile/presentation/settings_page.dart';
import '../../features/profile/presentation/sync_status_page.dart';
import '../../features/timezone_converter/presentation/timezone_page.dart';
import '../../features/auth/application/session_controller.dart';
import '../../features/auth/application/session_state.dart';
import '../../features/auth/presentation/forgot_password_page.dart';
import '../../features/auth/presentation/lock_page.dart';
import '../../features/auth/presentation/login_page.dart';
import '../../features/auth/presentation/register_page.dart';
import '../../features/auth/presentation/reset_password_page.dart';
import '../../features/auth/presentation/splash_page.dart';
import '../../features/balance_game/presentation/balance_game_page.dart';
import '../../features/focus/presentation/focus_history_page.dart';
import '../../features/focus/presentation/focus_page.dart';
import '../../features/habit/presentation/habit_detail_page.dart';
import '../../features/habit/presentation/habit_form_page.dart';
import '../../features/habit/presentation/habits_page.dart';
import '../../features/home/presentation/home_page.dart';
import '../../features/planner/presentation/planner_page.dart';
import '../../features/planner/presentation/task_detail_page.dart';
import '../../features/planner/presentation/task_form_page.dart';
import '../../features/profile/presentation/profile_page.dart';
import '../dev/component_gallery_page.dart';
import '../launch_animation_controller.dart';
import '../shell/main_shell.dart';
import 'auth_redirect.dart';
import 'not_found_page.dart';
import 'routes.dart';

/// Router aplikasi. Dibuat sebagai provider agar setiap test mendapat instance
/// baru dan guard autentikasi (FR-047) dapat membaca status sesi.
final Provider<GoRouter> appRouterProvider = Provider<GoRouter>((Ref ref) {
  // Router dievaluasi ulang setiap status sesi berubah (login, logout,
  // kunci biometrik, mode pemulihan password).
  final ValueNotifier<int> sessionTick = ValueNotifier<int>(0);
  ref.listen<SessionState>(
    sessionControllerProvider,
    (SessionState? previous, SessionState next) => sessionTick.value++,
  );
  ref.onDispose(sessionTick.dispose);

  ref.listen<bool>(
    launchAnimationCompletedProvider,
    (bool? previous, bool next) => sessionTick.value++,
  );

  final GoRouter router = GoRouter(
    navigatorKey: GlobalKey<NavigatorState>(debugLabel: 'root'),
    initialLocation: AppRoutes.splash,
    debugLogDiagnostics: kDebugMode,
    refreshListenable: sessionTick,
    redirect: (BuildContext context, GoRouterState state) {
      if (!ref.read(launchAnimationCompletedProvider)) {
        return state.uri.path == AppRoutes.splash ? null : AppRoutes.splash;
      }
      return resolveAuthRedirect(
        ref.read(sessionControllerProvider),
        state.uri,
      );
    },
    routes: <RouteBase>[
      GoRoute(
        path: AppRoutes.splash,
        builder: (BuildContext context, GoRouterState state) =>
            const SplashPage(),
      ),
      GoRoute(
        path: AppRoutes.login,
        builder: (BuildContext context, GoRouterState state) =>
            const LoginPage(),
      ),
      GoRoute(
        path: AppRoutes.register,
        builder: (BuildContext context, GoRouterState state) =>
            const RegisterPage(),
      ),
      GoRoute(
        path: AppRoutes.forgotPassword,
        builder: (BuildContext context, GoRouterState state) =>
            const ForgotPasswordPage(),
      ),
      GoRoute(
        path: AppRoutes.resetPassword,
        builder: (BuildContext context, GoRouterState state) =>
            const ResetPasswordPage(),
      ),
      GoRoute(
        path: AppRoutes.lock,
        builder: (BuildContext context, GoRouterState state) =>
            const LockPage(),
      ),
      StatefulShellRoute.indexedStack(
        builder:
            (
              BuildContext context,
              GoRouterState state,
              StatefulNavigationShell navigationShell,
            ) {
              return MainShell(navigationShell: navigationShell);
            },
        branches: <StatefulShellBranch>[
          StatefulShellBranch(
            routes: <RouteBase>[
              GoRoute(
                path: AppRoutes.home,
                builder: (BuildContext context, GoRouterState state) =>
                    const HomePage(),
              ),
            ],
          ),
          StatefulShellBranch(
            routes: <RouteBase>[
              GoRoute(
                path: AppRoutes.planner,
                builder: (BuildContext context, GoRouterState state) =>
                    const PlannerPage(),
                routes: <RouteBase>[
                  GoRoute(
                    path: 'task/new',
                    builder: (BuildContext context, GoRouterState state) =>
                        TaskFormPage(
                          initialDate: DateTime.tryParse(
                            state.uri.queryParameters['date'] ?? '',
                          ),
                        ),
                  ),
                  GoRoute(
                    path: 'task/:id',
                    builder: (BuildContext context, GoRouterState state) =>
                        TaskDetailPage(taskId: state.pathParameters['id']!),
                    routes: <RouteBase>[
                      GoRoute(
                        path: 'edit',
                        builder: (BuildContext context, GoRouterState state) =>
                            TaskFormPage(taskId: state.pathParameters['id']),
                      ),
                    ],
                  ),
                ],
              ),
            ],
          ),
          StatefulShellBranch(
            routes: <RouteBase>[
              GoRoute(
                path: AppRoutes.focus,
                builder: (BuildContext context, GoRouterState state) =>
                    const FocusPage(),
                routes: <RouteBase>[
                  GoRoute(
                    path: 'history',
                    builder: (BuildContext context, GoRouterState state) =>
                        const FocusHistoryPage(),
                  ),
                ],
              ),
            ],
          ),
          StatefulShellBranch(
            routes: <RouteBase>[
              GoRoute(
                path: AppRoutes.ai,
                builder: (BuildContext context, GoRouterState state) =>
                    const AiAssistantPage(),
                routes: <RouteBase>[
                  GoRoute(
                    path: 'review',
                    builder: (BuildContext context, GoRouterState state) =>
                        const AiReviewPage(),
                  ),
                ],
              ),
            ],
          ),
          StatefulShellBranch(
            routes: <RouteBase>[
              GoRoute(
                path: AppRoutes.profile,
                builder: (BuildContext context, GoRouterState state) =>
                    const ProfilePage(),
                routes: <RouteBase>[
                  GoRoute(
                    path: 'settings',
                    builder: (BuildContext context, GoRouterState state) =>
                        const SettingsPage(),
                  ),
                  GoRoute(
                    path: 'sync',
                    builder: (BuildContext context, GoRouterState state) =>
                        const SyncStatusPage(),
                  ),
                  GoRoute(
                    path: 'feedback',
                    builder: (BuildContext context, GoRouterState state) =>
                        const FeedbackPage(),
                  ),
                ],
              ),
            ],
          ),
        ],
      ),
      // Fitur pendukung sebagai rute root di atas shell (K-UI-01).
      GoRoute(
        path: AppRoutes.habits,
        builder: (BuildContext context, GoRouterState state) =>
            const HabitsPage(),
        routes: <RouteBase>[
          GoRoute(
            path: 'new',
            builder: (BuildContext context, GoRouterState state) =>
                const HabitFormPage(),
          ),
          GoRoute(
            path: ':id',
            builder: (BuildContext context, GoRouterState state) =>
                HabitDetailPage(habitId: state.pathParameters['id']!),
            routes: <RouteBase>[
              GoRoute(
                path: 'edit',
                builder: (BuildContext context, GoRouterState state) =>
                    HabitFormPage(habitId: state.pathParameters['id']),
              ),
            ],
          ),
        ],
      ),
      GoRoute(
        path: AppRoutes.focusGame,
        builder: (BuildContext context, GoRouterState state) =>
            const BalanceGamePage(),
      ),
      GoRoute(
        path: AppRoutes.places,
        builder: (BuildContext context, GoRouterState state) =>
            const PlacesPage(),
      ),
      GoRoute(
        path: AppRoutes.currency,
        builder: (BuildContext context, GoRouterState state) =>
            const CurrencyPage(),
      ),
      GoRoute(
        path: AppRoutes.timezone,
        builder: (BuildContext context, GoRouterState state) =>
            const TimezonePage(),
      ),
      GoRoute(
        path: AppRoutes.hashChain,
        builder: (BuildContext context, GoRouterState state) =>
            const HashChainPage(),
      ),
      GoRoute(
        path: AppRoutes.about,
        builder: (BuildContext context, GoRouterState state) =>
            const AboutPage(),
      ),
      if (kDebugMode)
        GoRoute(
          path: AppRoutes.componentGallery,
          builder: (BuildContext context, GoRouterState state) =>
              const ComponentGalleryPage(),
        ),
    ],
    errorBuilder: (BuildContext context, GoRouterState state) =>
        const NotFoundPage(),
  );
  ref.onDispose(router.dispose);
  return router;
});
