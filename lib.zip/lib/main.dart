import 'package:flutter/widgets.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

import 'app/app.dart';
import 'bootstrap.dart';
import 'core/network/connectivity_source.dart';
import 'core/notifications/notification_service.dart';
import 'core/sensors/motion_source.dart';
import 'core/storage/local_database.dart';

Future<void> main() async {
  final AppServices services = await bootstrap();
  runApp(
    ProviderScope(
      overrides: [
        localDatabaseProvider.overrideWithValue(services.database),
        notificationServiceProvider.overrideWithValue(services.notifications),
        connectivityProvider.overrideWithValue(ConnectivityPlusSource()),
        motionSourceProvider.overrideWithValue(const SensorsPlusMotionSource()),
      ],
      child: const PlanifyApp(),
    ),
  );
}
