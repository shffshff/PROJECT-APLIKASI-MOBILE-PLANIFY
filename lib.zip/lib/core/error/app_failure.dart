/// Jenis kegagalan yang dipetakan dari error data/service (Tahap 2 §5.1).
enum AppFailureKind { network, unauthorized, validation, notFound, external, unknown }

/// Kegagalan yang aman ditampilkan ke pengguna.
///
/// [debugDetail] hanya untuk log debug dan tidak pernah ditampilkan di UI
/// (Tahap 2 §15.1).
class AppFailure implements Exception {
  const AppFailure(
    this.kind, {
    this.message,
    this.customTitle,
    this.debugDetail,
  });

  final AppFailureKind kind;

  /// Pesan khusus yang menggantikan pesan default.
  final String? message;

  /// Judul khusus yang menggantikan judul default.
  final String? customTitle;

  final Object? debugDetail;

  /// Membungkus error apa pun menjadi [AppFailure].
  factory AppFailure.from(Object error) {
    if (error is AppFailure) {
      return error;
    }
    return AppFailure(AppFailureKind.unknown, debugDetail: error);
  }

  String get title =>
      customTitle ??
      switch (kind) {
        AppFailureKind.network => 'Tidak dapat terhubung',
        AppFailureKind.unauthorized => 'Sesi berakhir',
        AppFailureKind.validation => 'Data belum valid',
        AppFailureKind.notFound => 'Data tidak ditemukan',
        AppFailureKind.external => 'Layanan sedang bermasalah',
        AppFailureKind.unknown => 'Terjadi kesalahan',
      };

  String get userMessage =>
      message ??
      switch (kind) {
        AppFailureKind.network =>
          'Periksa koneksi internet, lalu coba lagi.',
        AppFailureKind.unauthorized => 'Silakan masuk kembali.',
        AppFailureKind.validation => 'Periksa kembali isian kamu.',
        AppFailureKind.notFound =>
          'Data mungkin sudah dihapus atau dipindahkan.',
        AppFailureKind.external =>
          'Layanan eksternal tidak merespons. Coba beberapa saat lagi.',
        AppFailureKind.unknown => 'Coba lagi beberapa saat lagi.',
      };

  @override
  String toString() => 'AppFailure($kind)';
}
