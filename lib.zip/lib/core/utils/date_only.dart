import 'package:uuid/uuid.dart';

/// Utilitas tanggal "tanpa jam" (Tahap 2 §6.3): disimpan sebagai
/// `yyyy-MM-dd` agar tidak bergeser karena zona waktu.
abstract final class DateOnly {
  static DateTime of(DateTime value) =>
      DateTime(value.year, value.month, value.day);

  static String format(DateTime value) {
    final String y = value.year.toString().padLeft(4, '0');
    final String m = value.month.toString().padLeft(2, '0');
    final String d = value.day.toString().padLeft(2, '0');
    return '$y-$m-$d';
  }

  /// Mengurai `yyyy-MM-dd` sebagai tanggal lokal. Melempar
  /// [FormatException] bila format salah.
  static DateTime parse(String text) {
    final List<String> parts = text.split('T').first.split('-');
    if (parts.length != 3) {
      throw FormatException('Tanggal tidak valid: $text');
    }
    return DateTime(
      int.parse(parts[0]),
      int.parse(parts[1]),
      int.parse(parts[2]),
    );
  }

  static bool isSameDay(DateTime a, DateTime b) =>
      a.year == b.year && a.month == b.month && a.day == b.day;

  /// Senin = 1 … Minggu = 7 (sama dengan `DateTime.weekday`).
  static int weekday(DateTime value) => value.weekday;

  /// Senin pada minggu yang memuat [value].
  static DateTime startOfWeek(DateTime value) =>
      of(value).subtract(Duration(days: value.weekday - 1));

  static DateTime addDays(DateTime value, int days) =>
      DateTime(value.year, value.month, value.day + days);
}

/// Menit sejak 00:00 ⇄ `HH:mm:ss` (kolom `time` PostgreSQL).
abstract final class TimeOfDayMinutes {
  static String toSql(int minutes) {
    final String h = (minutes ~/ 60).toString().padLeft(2, '0');
    final String m = (minutes % 60).toString().padLeft(2, '0');
    return '$h:$m:00';
  }

  static int? fromSql(Object? value) {
    if (value is! String || value.isEmpty) {
      return null;
    }
    final List<String> parts = value.split(':');
    if (parts.length < 2) {
      return null;
    }
    final int? h = int.tryParse(parts[0]);
    final int? m = int.tryParse(parts[1]);
    if (h == null || m == null) {
      return null;
    }
    return h * 60 + m;
  }

  static String label(int minutes) {
    final String h = (minutes ~/ 60).toString().padLeft(2, '0');
    final String m = (minutes % 60).toString().padLeft(2, '0');
    return '$h:$m';
  }
}

/// Pembuat UUID v4 di klien (Tahap 2 §6.1).
abstract final class Ids {
  static final Uuid _uuid = Uuid();

  static String newId() => _uuid.v4();
}

/// Membaca timestamp ISO dari JSON/Supabase; `null` bila kosong atau salah.
DateTime? parseTimestamp(Object? value) {
  if (value is! String || value.isEmpty) {
    return null;
  }
  return DateTime.tryParse(value);
}
