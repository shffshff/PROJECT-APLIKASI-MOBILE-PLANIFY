import 'package:intl/intl.dart';

/// Format tanggal dan waktu Indonesia (Tahap 3 §2.6).
///
/// Butuh `initializeDateFormatting('id_ID')` yang dipanggil di `bootstrap()`.
abstract final class AppDateFormat {
  static const String locale = 'id_ID';

  /// Contoh: "Selasa, 20 Oktober 2026".
  static String fullDate(DateTime date) =>
      DateFormat('EEEE, d MMMM y', locale).format(date);

  /// Contoh: "Sel, 20 Okt".
  static String shortDate(DateTime date) =>
      DateFormat('EEE, d MMM', locale).format(date);

  /// Contoh: "14:30" (format 24 jam).
  static String time(DateTime date) => DateFormat('HH:mm', locale).format(date);

  /// Sapaan sesuai jam lokal.
  static String greeting(DateTime now) {
    final int hour = now.hour;
    if (hour >= 4 && hour < 11) {
      return 'Selamat pagi';
    }
    if (hour >= 11 && hour < 15) {
      return 'Selamat siang';
    }
    if (hour >= 15 && hour < 18) {
      return 'Selamat sore';
    }
    return 'Selamat malam';
  }
}
