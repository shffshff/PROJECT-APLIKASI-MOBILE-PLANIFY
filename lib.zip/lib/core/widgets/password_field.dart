import 'package:flutter/material.dart';

import 'app_text_field.dart';

/// C-03 — input password dengan tombol tampilkan/sembunyikan.
class PasswordField extends StatefulWidget {
  const PasswordField({
    super.key,
    this.label = 'Password',
    this.controller,
    this.validator,
    this.helperText,
    this.textInputAction,
    this.onFieldSubmitted,
    this.autofillHints = const <String>[AutofillHints.password],
    this.isRequired = false,
    this.enabled = true,
    this.focusNode,
  });

  final String label;
  final TextEditingController? controller;
  final FormFieldValidator<String>? validator;
  final String? helperText;
  final TextInputAction? textInputAction;
  final ValueChanged<String>? onFieldSubmitted;
  final Iterable<String> autofillHints;
  final bool isRequired;
  final bool enabled;
  final FocusNode? focusNode;

  @override
  State<PasswordField> createState() => _PasswordFieldState();
}

class _PasswordFieldState extends State<PasswordField> {
  bool _obscured = true;

  @override
  Widget build(BuildContext context) {
    return AppTextField(
      label: widget.label,
      controller: widget.controller,
      validator: widget.validator,
      helperText: widget.helperText,
      isRequired: widget.isRequired,
      enabled: widget.enabled,
      focusNode: widget.focusNode,
      obscureText: _obscured,
      keyboardType: TextInputType.visiblePassword,
      textInputAction: widget.textInputAction,
      onFieldSubmitted: widget.onFieldSubmitted,
      autofillHints: widget.autofillHints,
      prefixIcon: const Icon(Icons.lock_outline_rounded),
      suffixIcon: IconButton(
        tooltip: _obscured ? 'Tampilkan password' : 'Sembunyikan password',
        icon: Icon(
          _obscured
              ? Icons.visibility_outlined
              : Icons.visibility_off_outlined,
        ),
        onPressed: () => setState(() => _obscured = !_obscured),
      ),
    );
  }
}
