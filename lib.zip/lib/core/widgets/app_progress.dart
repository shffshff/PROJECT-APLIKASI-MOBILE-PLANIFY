import 'dart:math' as math;

import 'package:flutter/material.dart';

import '../../theme/app_tokens.dart';

/// C-08 — ring progres (progres tugas di Home, dasar ring timer Focus).
class AppProgressRing extends StatelessWidget {
  const AppProgressRing({
    super.key,
    required this.value,
    required this.semanticsLabel,
    this.size = 84,
    this.strokeWidth = 9,
    this.color,
    this.trackColor,
    this.center,
  });

  /// Nilai 0.0–1.0. Nilai di luar rentang dipotong.
  final double value;
  final String semanticsLabel;
  final double size;
  final double strokeWidth;
  final Color? color;
  final Color? trackColor;
  final Widget? center;

  @override
  Widget build(BuildContext context) {
    final ColorScheme scheme = Theme.of(context).colorScheme;
    final double clamped = value.clamp(0.0, 1.0);

    return Semantics(
      label: semanticsLabel,
      value: '${(clamped * 100).round()} persen',
      excludeSemantics: true,
      child: SizedBox.square(
        dimension: size,
        child: CustomPaint(
          painter: _RingPainter(
            value: clamped,
            strokeWidth: strokeWidth,
            color: color ?? scheme.primary,
            trackColor: trackColor ?? scheme.primaryContainer,
          ),
          child: Center(child: center),
        ),
      ),
    );
  }
}

class _RingPainter extends CustomPainter {
  _RingPainter({
    required this.value,
    required this.strokeWidth,
    required this.color,
    required this.trackColor,
  });

  final double value;
  final double strokeWidth;
  final Color color;
  final Color trackColor;

  @override
  void paint(Canvas canvas, Size size) {
    final Rect rect = (Offset.zero & size).deflate(strokeWidth / 2);
    final Paint track = Paint()
      ..color = trackColor
      ..style = PaintingStyle.stroke
      ..strokeWidth = strokeWidth;
    canvas.drawArc(rect, 0, math.pi * 2, false, track);

    if (value <= 0) {
      return;
    }
    final Paint progress = Paint()
      ..color = color
      ..style = PaintingStyle.stroke
      ..strokeCap = StrokeCap.round
      ..strokeWidth = strokeWidth;
    canvas.drawArc(rect, -math.pi / 2, math.pi * 2 * value, false, progress);
  }

  @override
  bool shouldRepaint(covariant _RingPainter oldDelegate) {
    return oldDelegate.value != value ||
        oldDelegate.strokeWidth != strokeWidth ||
        oldDelegate.color != color ||
        oldDelegate.trackColor != trackColor;
  }
}

/// C-08 — bar progres linear (habit, kalibrasi game).
class AppLinearProgress extends StatelessWidget {
  const AppLinearProgress({
    super.key,
    required this.value,
    required this.semanticsLabel,
    this.height = 8,
    this.color,
    this.trackColor,
  });

  final double value;
  final String semanticsLabel;
  final double height;
  final Color? color;
  final Color? trackColor;

  @override
  Widget build(BuildContext context) {
    final ColorScheme scheme = Theme.of(context).colorScheme;
    final double clamped = value.clamp(0.0, 1.0);
    return LinearProgressIndicator(
      value: clamped,
      minHeight: height,
      borderRadius: BorderRadius.circular(height / 2),
      color: color ?? scheme.primary,
      backgroundColor: trackColor ?? scheme.primaryContainer,
      semanticsLabel: semanticsLabel,
      semanticsValue: '${(clamped * 100).round()} persen',
    );
  }
}

/// C-08 — grafik batang tujuh hari (ringkasan mingguan habit dan fokus).
class WeeklyBars extends StatelessWidget {
  const WeeklyBars({
    super.key,
    required this.values,
    required this.semanticsLabel,
    this.labels,
    this.height = 64,
    this.color,
    this.trackColor,
  });

  /// Tujuh nilai 0.0–1.0, Senin sampai Minggu. Nilai lebih/kurang dari tujuh
  /// dipotong atau diisi 0.
  final List<double> values;
  final String semanticsLabel;
  final List<String>? labels;
  final double height;
  final Color? color;
  final Color? trackColor;

  @override
  Widget build(BuildContext context) {
    final ThemeData theme = Theme.of(context);
    final Color barColor = color ?? theme.colorScheme.secondary;
    final Color emptyColor = trackColor ?? theme.colorScheme.secondaryContainer;
    final List<String>? dayLabels = labels;
    final List<double> days = List<double>.generate(
      7,
      (int i) => i < values.length ? values[i].clamp(0.0, 1.0) : 0.0,
    );

    return Semantics(
      label: semanticsLabel,
      excludeSemantics: true,
      child: Column(
        mainAxisSize: MainAxisSize.min,
        children: <Widget>[
          SizedBox(
            height: height,
            child: Row(
              crossAxisAlignment: CrossAxisAlignment.end,
              children: <Widget>[
                for (int i = 0; i < days.length; i++) ...<Widget>[
                  if (i > 0) const SizedBox(width: AppSpacing.xs),
                  Expanded(
                    child: FractionallySizedBox(
                      heightFactor: math.max(days[i], 0.06),
                      child: DecoratedBox(
                        decoration: BoxDecoration(
                          color: days[i] > 0 ? barColor : emptyColor,
                          borderRadius: BorderRadius.circular(3),
                        ),
                      ),
                    ),
                  ),
                ],
              ],
            ),
          ),
          if (dayLabels != null) ...<Widget>[
            const SizedBox(height: AppSpacing.xs),
            Row(
              children: <Widget>[
                for (final String label in dayLabels)
                  Expanded(
                    child: Text(
                      label,
                      textAlign: TextAlign.center,
                      style: theme.textTheme.labelSmall,
                    ),
                  ),
              ],
            ),
          ],
        ],
      ),
    );
  }
}
