import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../../theme/app_tokens.dart';
import '../error/app_failure.dart';
import 'error_state.dart';
import 'loading_indicator.dart';

/// C-22 — merender [AsyncValue] menjadi loading, error, empty, atau konten
/// (Tahap 2 §5.1). Spinner muncul setelah [AppDurations.loadingDelay] agar
/// data Hive yang cepat tidak berkedip.
class AsyncView<T> extends StatelessWidget {
  const AsyncView({
    super.key,
    required this.value,
    required this.builder,
    this.isEmpty,
    this.empty,
    this.loading,
    this.onRetry,
  });

  final AsyncValue<T> value;
  final Widget Function(BuildContext context, T data) builder;
  final bool Function(T data)? isEmpty;
  final Widget? empty;
  final Widget? loading;
  final VoidCallback? onRetry;

  @override
  Widget build(BuildContext context) {
    return value.when(
      data: (T data) {
        final Widget? emptyWidget = empty;
        final bool Function(T data)? emptyCheck = isEmpty;
        if (emptyWidget != null && emptyCheck != null && emptyCheck(data)) {
          return emptyWidget;
        }
        return builder(context, data);
      },
      error: (Object error, StackTrace stackTrace) => Center(
        child: ErrorState(failure: AppFailure.from(error), onRetry: onRetry),
      ),
      loading: () =>
          loading ??
          const Center(
            child: LoadingIndicator(delay: AppDurations.loadingDelay),
          ),
    );
  }
}
