import 'package:flutter/material.dart';

import '../../theme/app_colors.dart';

/// C-20 — baris menu/pengaturan.
///
/// Gunakan [SettingsTile.navigation] untuk baris yang membuka layar lain dan
/// [SettingsTile.toggle] untuk switch. Jika fitur tidak didukung perangkat,
/// set `enabled: false` dan isi [disabledReason] (Tahap 3 S-52).
class SettingsTile extends StatelessWidget {
  const SettingsTile.navigation({
    super.key,
    required this.icon,
    required this.title,
    this.subtitle,
    this.trailingText,
    required VoidCallback this.onTap,
    this.iconColor,
    this.enabled = true,
    this.disabledReason,
  })  : value = null,
        onChanged = null;

  const SettingsTile.toggle({
    super.key,
    required this.icon,
    required this.title,
    this.subtitle,
    required bool this.value,
    required ValueChanged<bool> this.onChanged,
    this.iconColor,
    this.enabled = true,
    this.disabledReason,
  })  : onTap = null,
        trailingText = null;

  final IconData icon;
  final String title;
  final String? subtitle;
  final String? trailingText;
  final VoidCallback? onTap;
  final bool? value;
  final ValueChanged<bool>? onChanged;
  final Color? iconColor;
  final bool enabled;
  final String? disabledReason;

  @override
  Widget build(BuildContext context) {
    final AppColors colors = context.appColors;
    final String? effectiveSubtitle =
        !enabled && disabledReason != null ? disabledReason : subtitle;
    final Widget leading = Icon(icon, color: iconColor);
    final Widget? subtitleWidget =
        effectiveSubtitle == null ? null : Text(effectiveSubtitle);

    final bool? switchValue = value;
    if (switchValue != null) {
      return SwitchListTile(
        secondary: leading,
        title: Text(title),
        subtitle: subtitleWidget,
        value: switchValue,
        onChanged: enabled ? onChanged : null,
      );
    }

    final String? trailing = trailingText;
    return ListTile(
      enabled: enabled,
      leading: leading,
      title: Text(title),
      subtitle: subtitleWidget,
      onTap: onTap,
      trailing: Row(
        mainAxisSize: MainAxisSize.min,
        children: <Widget>[
          if (trailing != null)
            Text(
              trailing,
              style: Theme.of(context)
                  .textTheme
                  .bodyMedium!
                  .copyWith(color: colors.textSecondary),
            ),
          Icon(Icons.chevron_right_rounded, color: colors.textDisabled),
        ],
      ),
    );
  }
}
