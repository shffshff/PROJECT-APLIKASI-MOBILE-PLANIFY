import 'package:flutter/widgets.dart';

import '../../theme/app_tokens.dart';

/// Membatasi lebar konten ke 720 dp dan memberi gutter 16 dp
/// (Tahap 3 §2.3 dan §8: dukungan layar lebar/Web).
class PageContainer extends StatelessWidget {
  const PageContainer({
    super.key,
    required this.child,
    this.padding = const EdgeInsets.symmetric(horizontal: AppSpacing.gutter),
  });

  final Widget child;
  final EdgeInsetsGeometry padding;

  @override
  Widget build(BuildContext context) {
    return Align(
      alignment: Alignment.topCenter,
      child: ConstrainedBox(
        constraints:
            const BoxConstraints(maxWidth: AppSpacing.maxContentWidth),
        child: Padding(padding: padding, child: child),
      ),
    );
  }
}
