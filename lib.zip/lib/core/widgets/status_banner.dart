import 'package:flutter/material.dart';

import '../../theme/app_colors.dart';
import '../../theme/app_tokens.dart';

enum StatusBannerType { info, success, warning, error, offline }

/// C-16 — banner kontekstual di atas konten (sesi berakhir, offline, cache,
/// DST, dsb). Selalu memakai ikon + teks, tidak hanya warna.
class StatusBanner extends StatelessWidget {
  const StatusBanner({
    super.key,
    required this.type,
    required this.message,
    this.title,
    this.actionLabel,
    this.onAction,
  });

  final StatusBannerType type;
  final String message;
  final String? title;
  final String? actionLabel;
  final VoidCallback? onAction;

  @override
  Widget build(BuildContext context) {
    final ThemeData theme = Theme.of(context);
    final ColorScheme scheme = theme.colorScheme;
    final AppColors colors = context.appColors;

    final (Color background, Color foreground, Color iconColor, IconData icon) =
        switch (type) {
      StatusBannerType.info => (
          scheme.primaryContainer,
          scheme.onPrimaryContainer,
          scheme.onPrimaryContainer,
          Icons.info_outline_rounded,
        ),
      StatusBannerType.success => (
          colors.successContainer,
          colors.onSuccessContainer,
          colors.success,
          Icons.check_circle_outline_rounded,
        ),
      StatusBannerType.warning => (
          colors.warningContainer,
          colors.onWarningContainer,
          colors.warning,
          Icons.warning_amber_rounded,
        ),
      StatusBannerType.error => (
          scheme.errorContainer,
          scheme.onErrorContainer,
          scheme.error,
          Icons.error_outline_rounded,
        ),
      StatusBannerType.offline => (
          colors.surfaceMuted,
          scheme.onSurface,
          colors.textSecondary,
          Icons.cloud_off_rounded,
        ),
    };

    final String? heading = title;
    final String? action = actionLabel;
    final TextStyle body =
        theme.textTheme.bodyMedium!.copyWith(color: foreground);

    return Semantics(
      container: true,
      liveRegion: true,
      child: DecoratedBox(
        decoration: BoxDecoration(
          color: background,
          borderRadius: AppRadius.mdAll,
        ),
        child: Padding(
          padding: const EdgeInsets.fromLTRB(14, 12, 14, 12),
          child: Row(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: <Widget>[
              Icon(icon, size: AppSizes.smallIconSize, color: iconColor),
              const SizedBox(width: AppSpacing.md),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  mainAxisSize: MainAxisSize.min,
                  children: <Widget>[
                    Text.rich(
                      TextSpan(
                        children: <InlineSpan>[
                          if (heading != null)
                            TextSpan(
                              text: '$heading ',
                              style: const TextStyle(
                                fontWeight: FontWeight.w700,
                              ),
                            ),
                          TextSpan(text: message),
                        ],
                      ),
                      style: body,
                    ),
                    if (action != null)
                      Padding(
                        padding: const EdgeInsets.only(top: AppSpacing.xs),
                        child: TextButton(
                          onPressed: onAction,
                          style: TextButton.styleFrom(
                            foregroundColor: foreground,
                            padding: EdgeInsets.zero,
                            minimumSize: const Size(48, 40),
                            textStyle: theme.textTheme.labelLarge!.copyWith(
                              decoration: TextDecoration.underline,
                            ),
                          ),
                          child: Text(action),
                        ),
                      ),
                  ],
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
