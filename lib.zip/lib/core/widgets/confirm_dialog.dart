import 'package:flutter/material.dart';

import '../../theme/app_tokens.dart';

/// Hasil dari [showConfirmDialog].
enum ConfirmResult { cancel, confirm, extra }

/// C-13 — menampilkan dialog konfirmasi dan mengembalikan pilihan pengguna.
///
/// Menutup dialog lewat barrier atau tombol back dianggap [ConfirmResult.cancel].
/// [extraActionLabel] dipakai untuk dialog tiga tombol, misalnya
/// "Sinkronkan dulu" pada dialog logout.
Future<ConfirmResult> showConfirmDialog(
  BuildContext context, {
  required String title,
  required String message,
  required String confirmLabel,
  String cancelLabel = 'Batal',
  bool isDestructive = false,
  String? extraActionLabel,
}) async {
  final ConfirmResult? result = await showDialog<ConfirmResult>(
    context: context,
    builder: (BuildContext dialogContext) => ConfirmDialog(
      title: title,
      message: message,
      confirmLabel: confirmLabel,
      cancelLabel: cancelLabel,
      isDestructive: isDestructive,
      extraActionLabel: extraActionLabel,
    ),
  );
  return result ?? ConfirmResult.cancel;
}

class ConfirmDialog extends StatelessWidget {
  const ConfirmDialog({
    super.key,
    required this.title,
    required this.message,
    required this.confirmLabel,
    this.cancelLabel = 'Batal',
    this.isDestructive = false,
    this.extraActionLabel,
  });

  final String title;
  final String message;
  final String confirmLabel;
  final String cancelLabel;
  final bool isDestructive;
  final String? extraActionLabel;

  @override
  Widget build(BuildContext context) {
    final ColorScheme scheme = Theme.of(context).colorScheme;
    final String? extra = extraActionLabel;
    const Size compact = Size(64, AppSizes.compactButtonHeight);

    return AlertDialog(
      title: Text(title),
      content: Text(message),
      actionsOverflowDirection: VerticalDirection.up,
      actions: <Widget>[
        TextButton(
          onPressed: () => Navigator.of(context).pop(ConfirmResult.cancel),
          child: Text(cancelLabel),
        ),
        if (extra != null)
          TextButton(
            onPressed: () => Navigator.of(context).pop(ConfirmResult.extra),
            child: Text(extra),
          ),
        FilledButton(
          onPressed: () => Navigator.of(context).pop(ConfirmResult.confirm),
          style: isDestructive
              ? FilledButton.styleFrom(
                  minimumSize: compact,
                  backgroundColor: scheme.error,
                  foregroundColor: scheme.onError,
                )
              : FilledButton.styleFrom(minimumSize: compact),
          child: Text(confirmLabel),
        ),
      ],
    );
  }
}
