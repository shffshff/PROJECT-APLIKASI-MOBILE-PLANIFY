import 'package:flutter/material.dart';

import '../../theme/app_colors.dart';
import '../../theme/app_tokens.dart';
import 'app_button.dart';

/// C-10 — empty state: ikon dalam lingkaran tonal, judul, pesan, dan aksi
/// lanjutan. Setiap empty state sebaiknya punya aksi (Tahap 3 §8).
class EmptyState extends StatelessWidget {
  const EmptyState({
    super.key,
    required this.icon,
    required this.title,
    this.message,
    this.primaryActionLabel,
    this.onPrimaryAction,
    this.secondaryActionLabel,
    this.onSecondaryAction,
  });

  final IconData icon;
  final String title;
  final String? message;
  final String? primaryActionLabel;
  final VoidCallback? onPrimaryAction;
  final String? secondaryActionLabel;
  final VoidCallback? onSecondaryAction;

  @override
  Widget build(BuildContext context) {
    final ThemeData theme = Theme.of(context);
    final String? body = message;
    final String? primary = primaryActionLabel;
    final String? secondary = secondaryActionLabel;

    return Padding(
      padding: const EdgeInsets.symmetric(
        horizontal: AppSpacing.xl,
        vertical: AppSpacing.xxl,
      ),
      child: Column(
        mainAxisSize: MainAxisSize.min,
        children: <Widget>[
          ExcludeSemantics(
            child: Container(
              width: 96,
              height: 96,
              decoration: BoxDecoration(
                color: theme.colorScheme.primaryContainer,
                shape: BoxShape.circle,
              ),
              alignment: Alignment.center,
              child: Icon(
                icon,
                size: 48,
                color: theme.colorScheme.onPrimaryContainer,
              ),
            ),
          ),
          const SizedBox(height: AppSpacing.lg),
          Text(
            title,
            textAlign: TextAlign.center,
            style: theme.textTheme.titleMedium!.copyWith(
              fontWeight: FontWeight.w700,
            ),
          ),
          if (body != null) ...<Widget>[
            const SizedBox(height: AppSpacing.sm),
            Text(
              body,
              textAlign: TextAlign.center,
              style: theme.textTheme.bodyMedium!.copyWith(
                color: context.appColors.textSecondary,
              ),
            ),
          ],
          if (primary != null) ...<Widget>[
            const SizedBox(height: AppSpacing.xl),
            AppButton(label: primary, onPressed: onPrimaryAction),
          ],
          if (secondary != null) ...<Widget>[
            const SizedBox(height: AppSpacing.sm),
            AppButton(
              label: secondary,
              onPressed: onSecondaryAction,
              variant: AppButtonVariant.text,
            ),
          ],
        ],
      ),
    );
  }
}
