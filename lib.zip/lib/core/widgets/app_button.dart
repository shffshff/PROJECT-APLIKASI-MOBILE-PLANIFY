import 'package:flutter/material.dart';

import '../../theme/app_tokens.dart';

enum AppButtonVariant { primary, tonal, outline, text, destructive }

/// C-01 — tombol standar PLANIFY.
///
/// Saat [isLoading] bernilai `true`, label diganti spinner, tombol tidak
/// menerima tap (mencegah double submission), dan lebarnya tidak berubah.
class AppButton extends StatelessWidget {
  const AppButton({
    super.key,
    required this.label,
    required this.onPressed,
    this.variant = AppButtonVariant.primary,
    this.icon,
    this.isLoading = false,
    this.expand = false,
  });

  final String label;
  final VoidCallback? onPressed;
  final AppButtonVariant variant;
  final IconData? icon;
  final bool isLoading;
  final bool expand;

  @override
  Widget build(BuildContext context) {
    final ColorScheme scheme = Theme.of(context).colorScheme;
    final VoidCallback? effectiveOnPressed = isLoading ? null : onPressed;

    final (Color background, Color foreground) = switch (variant) {
      AppButtonVariant.primary => (scheme.primary, scheme.onPrimary),
      AppButtonVariant.tonal => (
          scheme.primaryContainer,
          scheme.onPrimaryContainer,
        ),
      AppButtonVariant.destructive => (scheme.error, scheme.onError),
      AppButtonVariant.outline => (Colors.transparent, scheme.onSurface),
      AppButtonVariant.text => (Colors.transparent, scheme.primary),
    };

    // Saat loading, warna tetap seperti tombol aktif agar tidak tampak "rusak".
    final ButtonStyle? loadingStyle = isLoading
        ? ButtonStyle(
            backgroundColor: WidgetStatePropertyAll<Color>(background),
            foregroundColor: WidgetStatePropertyAll<Color>(foreground),
          )
        : null;

    final Widget content = isLoading
        ? Semantics(
            label: '$label, sedang diproses',
            child: SizedBox(
              width: 22,
              height: 22,
              child: CircularProgressIndicator(
                strokeWidth: 2.4,
                color: foreground,
              ),
            ),
          )
        : _LabelWithIcon(label: label, icon: icon);

    final Widget button = switch (variant) {
      AppButtonVariant.primary => FilledButton(
          onPressed: effectiveOnPressed,
          style: loadingStyle,
          child: content,
        ),
      AppButtonVariant.tonal => FilledButton.tonal(
          onPressed: effectiveOnPressed,
          style: loadingStyle,
          child: content,
        ),
      AppButtonVariant.destructive => FilledButton(
          onPressed: effectiveOnPressed,
          // loadingStyle didahulukan agar warna tetap merah saat loading.
          style: (loadingStyle ?? const ButtonStyle()).merge(
            FilledButton.styleFrom(
              backgroundColor: scheme.error,
              foregroundColor: scheme.onError,
            ),
          ),
          child: content,
        ),
      AppButtonVariant.outline => OutlinedButton(
          onPressed: effectiveOnPressed,
          style: loadingStyle,
          child: content,
        ),
      AppButtonVariant.text => TextButton(
          onPressed: effectiveOnPressed,
          style: loadingStyle,
          child: content,
        ),
    };

    if (!expand) {
      return button;
    }
    return SizedBox(
      width: double.infinity,
      height: variant == AppButtonVariant.text
          ? AppSizes.compactButtonHeight
          : AppSizes.buttonHeight,
      child: button,
    );
  }
}

class _LabelWithIcon extends StatelessWidget {
  const _LabelWithIcon({required this.label, this.icon});

  final String label;
  final IconData? icon;

  @override
  Widget build(BuildContext context) {
    final IconData? iconData = icon;
    if (iconData == null) {
      return Text(label, overflow: TextOverflow.ellipsis);
    }
    return Row(
      mainAxisSize: MainAxisSize.min,
      children: <Widget>[
        Icon(iconData, size: AppSizes.smallIconSize),
        const SizedBox(width: AppSpacing.sm),
        Flexible(child: Text(label, overflow: TextOverflow.ellipsis)),
      ],
    );
  }
}
