import 'package:flutter/material.dart';

import '../../theme/app_tokens.dart';
import 'empty_state.dart';
import 'page_container.dart';

/// Halaman sementara untuk tab yang isinya dikerjakan pada sub-tahap
/// berikutnya. Widget ini dihapus setelah semua tab terimplementasi.
class StagePlaceholderPage extends StatelessWidget {
  const StagePlaceholderPage({
    super.key,
    required this.title,
    required this.icon,
    required this.stage,
    required this.message,
    this.header,
    this.footer = const <Widget>[],
    this.actions = const <Widget>[],
  });

  final String title;
  final IconData icon;

  /// Contoh: "Tahap 4C".
  final String stage;
  final String message;
  final Widget? header;
  final List<Widget> footer;
  final List<Widget> actions;

  @override
  Widget build(BuildContext context) {
    final Widget? top = header;
    return Scaffold(
      appBar: AppBar(
        title: Text(
          title,
          style: Theme.of(context).textTheme.headlineSmall,
        ),
        actions: <Widget>[
          ...actions,
          const SizedBox(width: AppSpacing.sm),
        ],
      ),
      body: SafeArea(
        child: ListView(
          padding: const EdgeInsets.only(bottom: AppSpacing.xxl),
          children: <Widget>[
            PageContainer(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.stretch,
                children: <Widget>[
                  ?top,
                  EmptyState(
                    icon: icon,
                    title: 'Diimplementasikan pada $stage',
                    message: message,
                  ),
                  ...footer,
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}
