import 'package:flutter/material.dart';

import '../../theme/app_colors.dart';
import '../../theme/app_tokens.dart';
import '../error/app_failure.dart';
import 'app_button.dart';

/// C-11 — pesan error ramah pengguna dengan tombol "Coba lagi".
///
/// Tidak pernah menampilkan detail teknis (kode HTTP, stack trace, token).
class ErrorState extends StatelessWidget {
  const ErrorState({
    super.key,
    required this.failure,
    this.onRetry,
    this.compact = false,
  });

  final AppFailure failure;
  final VoidCallback? onRetry;

  /// `true` untuk tampilan di dalam kartu, `false` untuk layar penuh.
  final bool compact;

  IconData get _icon => switch (failure.kind) {
        AppFailureKind.network => Icons.cloud_off_rounded,
        AppFailureKind.unauthorized => Icons.lock_outline_rounded,
        AppFailureKind.notFound => Icons.search_off_rounded,
        _ => Icons.error_outline_rounded,
      };

  @override
  Widget build(BuildContext context) {
    final ThemeData theme = Theme.of(context);
    final ColorScheme scheme = theme.colorScheme;
    final double circle = compact ? 56 : 96;

    return Semantics(
      liveRegion: true,
      container: true,
      child: Padding(
        padding: EdgeInsets.all(compact ? AppSpacing.lg : AppSpacing.xl),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: <Widget>[
            ExcludeSemantics(
              child: Container(
                width: circle,
                height: circle,
                decoration: BoxDecoration(
                  color: scheme.errorContainer,
                  shape: BoxShape.circle,
                ),
                alignment: Alignment.center,
                child: Icon(
                  _icon,
                  size: compact ? 28 : 44,
                  color: scheme.onErrorContainer,
                ),
              ),
            ),
            const SizedBox(height: AppSpacing.md),
            Text(
              failure.title,
              textAlign: TextAlign.center,
              style: theme.textTheme.titleMedium!.copyWith(
                fontWeight: FontWeight.w700,
              ),
            ),
            const SizedBox(height: AppSpacing.xs),
            Text(
              failure.userMessage,
              textAlign: TextAlign.center,
              style: theme.textTheme.bodyMedium!.copyWith(
                color: context.appColors.textSecondary,
              ),
            ),
            if (onRetry != null) ...<Widget>[
              const SizedBox(height: AppSpacing.lg),
              AppButton(
                label: 'Coba lagi',
                icon: Icons.refresh_rounded,
                variant: AppButtonVariant.tonal,
                onPressed: onRetry,
              ),
            ],
          ],
        ),
      ),
    );
  }
}
