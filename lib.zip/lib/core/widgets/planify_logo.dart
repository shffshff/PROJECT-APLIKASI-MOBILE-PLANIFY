import 'package:flutter/material.dart';

/// Shared brand assets. Keep the original white checkmark in the PNG.
abstract final class PlanifyBrand {
  static const String logoAsset = 'assets/branding/planify-logo.png';
  static const String markAsset = 'assets/branding/planify-mark.png';
  static const Color purple = Color(0xFF4F3DE0);
  static const Color lightCanvas = Color(0xFFF8F7FF);
  static const Color darkCanvas = Color(0xFF141222);
}

class PlanifyLogo extends StatelessWidget {
  const PlanifyLogo({super.key, this.width = 240});

  final double width;

  @override
  Widget build(BuildContext context) {
    final bool dark = Theme.of(context).brightness == Brightness.dark;
    return Semantics(
      label: 'PLANIFY',
      image: true,
      child: DecoratedBox(
        decoration: BoxDecoration(
          color: dark ? PlanifyBrand.lightCanvas : Colors.transparent,
          borderRadius: BorderRadius.circular(20),
        ),
        child: Padding(
          padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
          child: Image.asset(
            PlanifyBrand.logoAsset,
            width: width,
            height: width * 731 / 2149,
            fit: BoxFit.contain,
            excludeFromSemantics: true,
            filterQuality: FilterQuality.high,
          ),
        ),
      ),
    );
  }
}
