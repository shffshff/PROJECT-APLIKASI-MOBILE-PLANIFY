import 'package:flutter/material.dart';
import 'package:flutter/services.dart';

import '../../theme/app_colors.dart';
import '../../theme/app_theme.dart';

/// C-02 — input berlabel dengan error, helper, dan penghitung karakter.
///
/// Label tampil di atas field (sesuai mockup Tahap 3). Validasi berjalan saat
/// field kehilangan fokus dan saat form disubmit, bukan saat huruf pertama
/// diketik (Tahap 3 §8).
class AppTextField extends StatefulWidget {
  const AppTextField({
    super.key,
    required this.label,
    this.controller,
    this.initialValue,
    this.validator,
    this.hintText,
    this.helperText,
    this.isRequired = false,
    this.maxLength,
    this.showCounterFrom,
    this.keyboardType,
    this.textInputAction,
    this.textCapitalization = TextCapitalization.none,
    this.onChanged,
    this.onFieldSubmitted,
    this.minLines,
    this.maxLines = 1,
    this.obscureText = false,
    this.prefixIcon,
    this.suffixIcon,
    this.autofillHints,
    this.inputFormatters,
    this.enabled = true,
    this.autofocus = false,
    this.focusNode,
  });

  final String label;
  final TextEditingController? controller;
  final String? initialValue;
  final FormFieldValidator<String>? validator;
  final String? hintText;
  final String? helperText;
  final bool isRequired;
  final int? maxLength;

  /// Penghitung karakter baru muncul setelah panjang teks mencapai nilai ini.
  final int? showCounterFrom;
  final TextInputType? keyboardType;
  final TextInputAction? textInputAction;
  final TextCapitalization textCapitalization;
  final ValueChanged<String>? onChanged;
  final ValueChanged<String>? onFieldSubmitted;
  final int? minLines;
  final int maxLines;
  final bool obscureText;
  final Widget? prefixIcon;
  final Widget? suffixIcon;
  final Iterable<String>? autofillHints;
  final List<TextInputFormatter>? inputFormatters;
  final bool enabled;
  final bool autofocus;
  final FocusNode? focusNode;

  @override
  State<AppTextField> createState() => _AppTextFieldState();
}

class _AppTextFieldState extends State<AppTextField> {
  final GlobalKey<FormFieldState<String>> _fieldKey =
      GlobalKey<FormFieldState<String>>();
  FocusNode? _ownedFocusNode;
  bool _hasBeenFocused = false;

  FocusNode get _focusNode =>
      widget.focusNode ?? (_ownedFocusNode ??= FocusNode());

  @override
  void initState() {
    super.initState();
    _focusNode.addListener(_handleFocusChange);
  }

  @override
  void didUpdateWidget(covariant AppTextField oldWidget) {
    super.didUpdateWidget(oldWidget);
    if (oldWidget.focusNode != widget.focusNode) {
      (oldWidget.focusNode ?? _ownedFocusNode)
          ?.removeListener(_handleFocusChange);
      _focusNode.addListener(_handleFocusChange);
    }
  }

  @override
  void dispose() {
    _focusNode.removeListener(_handleFocusChange);
    _ownedFocusNode?.dispose();
    super.dispose();
  }

  void _handleFocusChange() {
    if (_focusNode.hasFocus) {
      _hasBeenFocused = true;
      return;
    }
    if (_hasBeenFocused) {
      _fieldKey.currentState?.validate();
    }
  }

  Widget? _buildCounter(
    BuildContext context, {
    required int currentLength,
    required int? maxLength,
    required bool isFocused,
  }) {
    if (maxLength == null) {
      return null;
    }
    if (currentLength < (widget.showCounterFrom ?? 0)) {
      return null;
    }
    return Text(
      '$currentLength/$maxLength',
      semanticsLabel: '$currentLength dari $maxLength karakter',
      style: Theme.of(context).textTheme.bodySmall!.copyWith(
            color: context.appColors.textSecondary,
            fontFeatures: AppTypography.tabularFigures,
          ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final ThemeData theme = Theme.of(context);
    final bool obscure = widget.obscureText;

    return Column(
      crossAxisAlignment: CrossAxisAlignment.stretch,
      mainAxisSize: MainAxisSize.min,
      children: <Widget>[
        ExcludeSemantics(
          child: Text.rich(
            TextSpan(
              text: widget.label,
              children: <InlineSpan>[
                if (widget.isRequired)
                  TextSpan(
                    text: ' *',
                    style: TextStyle(color: theme.colorScheme.error),
                  ),
              ],
            ),
            style: theme.textTheme.labelLarge,
          ),
        ),
        const SizedBox(height: 6),
        Semantics(
          label: widget.isRequired ? '${widget.label}, wajib' : widget.label,
          child: TextFormField(
            key: _fieldKey,
            controller: widget.controller,
            initialValue:
                widget.controller == null ? widget.initialValue : null,
            focusNode: _focusNode,
            validator: widget.validator,
            enabled: widget.enabled,
            autofocus: widget.autofocus,
            obscureText: obscure,
            enableSuggestions: !obscure,
            autocorrect: !obscure,
            keyboardType: widget.keyboardType,
            textInputAction: widget.textInputAction,
            textCapitalization: widget.textCapitalization,
            inputFormatters: widget.inputFormatters,
            autofillHints: widget.autofillHints,
            maxLength: widget.maxLength,
            buildCounter: _buildCounter,
            minLines: obscure ? null : widget.minLines,
            maxLines: obscure ? 1 : widget.maxLines,
            onChanged: widget.onChanged,
            onFieldSubmitted: widget.onFieldSubmitted,
            style: theme.textTheme.bodyLarge,
            decoration: InputDecoration(
              hintText: widget.hintText,
              helperText: widget.helperText,
              helperMaxLines: 2,
              errorMaxLines: 2,
              prefixIcon: widget.prefixIcon,
              suffixIcon: widget.suffixIcon,
            ),
          ),
        ),
      ],
    );
  }
}
