import 'package:flutter/material.dart';

import '../../theme/app_colors.dart';
import '../../theme/app_tokens.dart';

/// Status yang ditampilkan [SyncStatusIndicator]. Nilainya akan diisi oleh
/// `syncStatusProvider` pada Tahap 4C (Tahap 2 §5.1).
enum SyncIndicatorState { synced, pending, failed, offline }

/// C-15 — ikon status sinkron di AppBar tab utama.
class SyncStatusIndicator extends StatelessWidget {
  const SyncStatusIndicator({
    super.key,
    required this.state,
    this.count = 0,
    this.onTap,
  });

  final SyncIndicatorState state;

  /// Jumlah perubahan menunggu/gagal (ditampilkan jika > 0).
  final int count;
  final VoidCallback? onTap;

  @override
  Widget build(BuildContext context) {
    final ColorScheme scheme = Theme.of(context).colorScheme;
    final AppColors colors = context.appColors;

    final (IconData icon, Color foreground, Color background, String label) =
        switch (state) {
      SyncIndicatorState.synced => (
          Icons.cloud_done_rounded,
          colors.success,
          colors.successContainer,
          'Status sinkron: semua data tersinkron',
        ),
      SyncIndicatorState.pending => (
          Icons.cloud_upload_rounded,
          colors.onWarningContainer,
          colors.warningContainer,
          'Status sinkron: $count perubahan menunggu',
        ),
      SyncIndicatorState.failed => (
          Icons.sync_problem_rounded,
          scheme.onErrorContainer,
          scheme.errorContainer,
          'Status sinkron: $count perubahan gagal',
        ),
      SyncIndicatorState.offline => (
          Icons.cloud_off_rounded,
          colors.textSecondary,
          colors.surfaceMuted,
          'Status sinkron: offline',
        ),
    };

    final bool showCount = count > 0 &&
        (state == SyncIndicatorState.pending ||
            state == SyncIndicatorState.failed);

    return Semantics(
      button: onTap != null,
      label: label,
      excludeSemantics: true,
      child: Tooltip(
        message: label,
        child: Material(
          color: background,
          shape: const StadiumBorder(),
          clipBehavior: Clip.antiAlias,
          child: InkWell(
            onTap: onTap,
            child: ConstrainedBox(
              constraints: const BoxConstraints(
                minWidth: AppSizes.minTouchTarget,
                minHeight: 40,
              ),
              child: Padding(
                padding: const EdgeInsets.symmetric(horizontal: 10),
                child: Row(
                  mainAxisSize: MainAxisSize.min,
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: <Widget>[
                    Icon(icon, size: AppSizes.smallIconSize, color: foreground),
                    if (showCount) ...<Widget>[
                      const SizedBox(width: AppSpacing.xs),
                      Text(
                        '$count',
                        style: Theme.of(context)
                            .textTheme
                            .labelMedium!
                            .copyWith(
                              color: foreground,
                              fontWeight: FontWeight.w700,
                            ),
                      ),
                    ],
                  ],
                ),
              ),
            ),
          ),
        ),
      ),
    );
  }
}
