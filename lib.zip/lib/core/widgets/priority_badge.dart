import 'package:flutter/material.dart';

import '../../features/planner/domain/task_priority.dart';
import '../../theme/app_colors.dart';
import '../../theme/app_tokens.dart';

/// C-06 — label prioritas berwarna, selalu disertai teks.
class PriorityBadge extends StatelessWidget {
  const PriorityBadge({super.key, required this.priority});

  final TaskPriority priority;

  @override
  Widget build(BuildContext context) {
    final ColorScheme scheme = Theme.of(context).colorScheme;
    final AppColors colors = context.appColors;

    final (Color foreground, Color background) = switch (priority) {
      TaskPriority.high => (scheme.error, scheme.errorContainer),
      TaskPriority.medium => (colors.warning, colors.warningContainer),
      TaskPriority.low => (colors.textSecondary, colors.surfaceMuted),
    };

    return Semantics(
      label: 'Prioritas ${priority.label}',
      excludeSemantics: true,
      child: DecoratedBox(
        decoration: BoxDecoration(
          color: background,
          borderRadius: AppRadius.smAll,
        ),
        child: Padding(
          padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 2),
          child: Text(
            priority.label,
            style: Theme.of(context)
                .textTheme
                .labelMedium!
                .copyWith(color: foreground),
          ),
        ),
      ),
    );
  }
}
