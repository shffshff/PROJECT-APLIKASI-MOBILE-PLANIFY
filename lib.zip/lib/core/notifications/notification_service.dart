import 'dart:async';

import 'package:flutter/foundation.dart';
import 'package:flutter_local_notifications/flutter_local_notifications.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:timezone/timezone.dart' as tz;

/// Kanal notifikasi Android.
enum NotificationChannel {
  reminders('planify_reminders', 'Pengingat tugas',
      'Pengingat sebelum tenggat tugas'),
  focus('planify_focus', 'Sesi fokus', 'Pemberitahuan saat sesi Pomodoro selesai');

  const NotificationChannel(this.id, this.title, this.description);

  final String id;
  final String title;
  final String description;
}

/// ID tetap untuk notifikasi Pomodoro (Tahap 2 §11.6). ID pengingat tugas
/// berada di rentang lain (lihat ReminderScheduler.idFor).
const int kPomodoroNotificationId = 1;

/// Abstraksi notifikasi lokal agar logika pengingat bisa diuji.
abstract interface class NotificationService {
  Future<void> initialize();

  /// Izin notifikasi sudah diberikan.
  Future<bool> areEnabled();

  /// Meminta izin (Android 13+). `true` bila diizinkan.
  Future<bool> requestPermission();

  Future<void> schedule({
    required int id,
    required String title,
    required String body,
    required DateTime at,
    required NotificationChannel channel,
    String? payload,
  });

  Future<void> cancel(int id);

  Future<Set<int>> pendingIds();

  /// Payload notifikasi yang diketuk saat aplikasi berjalan.
  Stream<String> get taps;

  /// Payload notifikasi yang membuka aplikasi dari keadaan mati (cold start).
  Future<String?> takeLaunchPayload();

  bool get isSupported;
}

/// Implementasi `flutter_local_notifications` 22.x.
///
/// Mode alarm (K-15): memakai `exactAllowWhileIdle` bila sistem mengizinkan
/// alarm exact, selain itu `inexactAllowWhileIdle` (bisa terlambat beberapa
/// menit saat Doze). Lihat docs/BACKEND_SETUP.md bagian Android.
class LocalNotificationService implements NotificationService {
  LocalNotificationService([FlutterLocalNotificationsPlugin? plugin])
      : _plugin = plugin ?? FlutterLocalNotificationsPlugin();

  final FlutterLocalNotificationsPlugin _plugin;
  final StreamController<String> _taps = StreamController<String>.broadcast();
  bool _initialized = false;
  bool? _exactAllowed;

  AndroidFlutterLocalNotificationsPlugin? get _android =>
      _plugin.resolvePlatformSpecificImplementation<
          AndroidFlutterLocalNotificationsPlugin>();

  @override
  bool get isSupported => !kIsWeb;

  @override
  Stream<String> get taps => _taps.stream;

  @override
  Future<void> initialize() async {
    if (_initialized || kIsWeb) {
      return;
    }
    const InitializationSettings settings = InitializationSettings(
      android: AndroidInitializationSettings('@mipmap/ic_launcher'),
      iOS: DarwinInitializationSettings(
        requestAlertPermission: false,
        requestBadgePermission: false,
        requestSoundPermission: false,
      ),
    );
    try {
      await _plugin.initialize(
        settings: settings,
        onDidReceiveNotificationResponse: (NotificationResponse response) {
          final String? payload = response.payload;
          if (payload != null && payload.isNotEmpty) {
            _taps.add(payload);
          }
        },
      );
      _initialized = true;
    } catch (error) {
      debugPrint('Notifikasi gagal diinisialisasi: $error');
    }
  }

  @override
  Future<bool> areEnabled() async {
    if (!_initialized) {
      return false;
    }
    try {
      return await _android?.areNotificationsEnabled() ?? true;
    } catch (error) {
      debugPrint('Cek izin notifikasi gagal: $error');
      return false;
    }
  }

  @override
  Future<bool> requestPermission() async {
    if (!_initialized) {
      return false;
    }
    try {
      final AndroidFlutterLocalNotificationsPlugin? android = _android;
      if (android != null) {
        return await android.requestNotificationsPermission() ?? false;
      }
      return true;
    } catch (error) {
      debugPrint('Permintaan izin notifikasi gagal: $error');
      return false;
    }
  }

  Future<AndroidScheduleMode> _scheduleMode() async {
    if (_exactAllowed == null) {
      try {
        _exactAllowed = await _android?.canScheduleExactNotifications() ?? false;
      } catch (_) {
        _exactAllowed = false;
      }
    }
    return _exactAllowed!
        ? AndroidScheduleMode.exactAllowWhileIdle
        : AndroidScheduleMode.inexactAllowWhileIdle;
  }

  @override
  Future<void> schedule({
    required int id,
    required String title,
    required String body,
    required DateTime at,
    required NotificationChannel channel,
    String? payload,
  }) async {
    if (!_initialized) {
      return;
    }
    final NotificationDetails details = NotificationDetails(
      android: AndroidNotificationDetails(
        channel.id,
        channel.title,
        channelDescription: channel.description,
        importance: Importance.high,
        priority: Priority.high,
      ),
      iOS: const DarwinNotificationDetails(),
    );
    await _plugin.zonedSchedule(
      id: id,
      title: title,
      body: body,
      scheduledDate: tz.TZDateTime.from(at, tz.local),
      notificationDetails: details,
      androidScheduleMode: await _scheduleMode(),
      payload: payload,
    );
  }

  @override
  Future<void> cancel(int id) async {
    if (!_initialized) {
      return;
    }
    await _plugin.cancel(id: id);
  }

  @override
  Future<Set<int>> pendingIds() async {
    if (!_initialized) {
      return <int>{};
    }
    final List<PendingNotificationRequest> pending =
        await _plugin.pendingNotificationRequests();
    return pending.map((PendingNotificationRequest p) => p.id).toSet();
  }

  @override
  Future<String?> takeLaunchPayload() async {
    if (!_initialized) {
      return null;
    }
    try {
      final NotificationAppLaunchDetails? details =
          await _plugin.getNotificationAppLaunchDetails();
      if (details?.didNotificationLaunchApp ?? false) {
        return details?.notificationResponse?.payload;
      }
    } catch (error) {
      debugPrint('Detail peluncuran notifikasi gagal dibaca: $error');
    }
    return null;
  }
}

/// Dipakai di Web dan test: tidak melakukan apa-apa.
class NoopNotificationService implements NotificationService {
  NoopNotificationService({this.enabled = false});

  bool enabled;
  final Map<int, DateTime> scheduled = <int, DateTime>{};
  final StreamController<String> _taps = StreamController<String>.broadcast();

  void simulateTap(String payload) => _taps.add(payload);

  @override
  bool get isSupported => false;

  @override
  Future<void> initialize() async {}

  @override
  Future<bool> areEnabled() async => enabled;

  @override
  Future<bool> requestPermission() async => enabled;

  @override
  Future<void> schedule({
    required int id,
    required String title,
    required String body,
    required DateTime at,
    required NotificationChannel channel,
    String? payload,
  }) async {
    scheduled[id] = at;
  }

  @override
  Future<void> cancel(int id) async {
    scheduled.remove(id);
  }

  @override
  Future<Set<int>> pendingIds() async => scheduled.keys.toSet();

  @override
  Stream<String> get taps => _taps.stream;

  @override
  Future<String?> takeLaunchPayload() async => null;
}

/// Diisi di `main.dart`. Bawaan: no-op (test, Web).
final Provider<NotificationService> notificationServiceProvider =
    Provider<NotificationService>((Ref ref) => NoopNotificationService());

/// Status izin notifikasi; di-refresh dengan `ref.invalidate`.
final FutureProvider<bool> notificationPermissionProvider =
    FutureProvider<bool>(
  (Ref ref) => ref.read(notificationServiceProvider).areEnabled(),
);
