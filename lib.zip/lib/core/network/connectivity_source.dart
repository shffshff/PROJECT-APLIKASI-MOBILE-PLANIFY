import 'package:connectivity_plus/connectivity_plus.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

/// Status antarmuka jaringan. Catatan: "online" di sini hanya berarti ada
/// antarmuka jaringan, bukan jaminan internet (Tahap 2 §14); kegagalan
/// request tetap ditangani SyncEngine.
abstract interface class ConnectivitySource {
  Future<bool> isOnline();

  Stream<bool> get onlineChanges;
}

class ConnectivityPlusSource implements ConnectivitySource {
  ConnectivityPlusSource([Connectivity? connectivity])
      : _connectivity = connectivity ?? Connectivity();

  final Connectivity _connectivity;

  static bool _online(List<ConnectivityResult> results) =>
      results.any((ConnectivityResult r) => r != ConnectivityResult.none);

  @override
  Future<bool> isOnline() async {
    try {
      return _online(await _connectivity.checkConnectivity());
    } catch (_) {
      return true; // tidak diketahui → biarkan request yang memutuskan
    }
  }

  @override
  Stream<bool> get onlineChanges =>
      _connectivity.onConnectivityChanged.map(_online).distinct();
}

/// Bawaan untuk test: selalu online, tidak ada perubahan.
class AlwaysOnlineConnectivity implements ConnectivitySource {
  const AlwaysOnlineConnectivity();

  @override
  Future<bool> isOnline() async => true;

  @override
  Stream<bool> get onlineChanges => const Stream<bool>.empty();
}

/// Diisi di `main.dart` dengan [ConnectivityPlusSource].
final Provider<ConnectivitySource> connectivityProvider =
    Provider<ConnectivitySource>((Ref ref) => const AlwaysOnlineConnectivity());
