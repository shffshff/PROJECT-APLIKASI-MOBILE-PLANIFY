import 'package:supabase_flutter/supabase_flutter.dart';

import 'secure_key_value_store.dart';

/// Penyimpanan sesi Supabase di penyimpanan terenkripsi.
///
/// Bawaan `supabase_flutter` menyimpan sesi (access + refresh token) di
/// SharedPreferences biasa. Karena sesi adalah kredensial, aplikasi ini
/// menggantinya dengan Keystore/Keychain lewat `flutter_secure_storage`.
class SecureLocalStorage extends LocalStorage {
  SecureLocalStorage(this._store);

  final SecureKeyValueStore _store;

  @override
  Future<void> initialize() async {}

  @override
  Future<bool> hasAccessToken() async {
    final String? value = await _store.read(SecureKeys.supabaseSession);
    return value != null && value.isNotEmpty;
  }

  @override
  Future<String?> accessToken() => _store.read(SecureKeys.supabaseSession);

  @override
  Future<void> persistSession(String persistSessionString) =>
      _store.write(SecureKeys.supabaseSession, persistSessionString);

  @override
  Future<void> removePersistedSession() =>
      _store.delete(SecureKeys.supabaseSession);
}
