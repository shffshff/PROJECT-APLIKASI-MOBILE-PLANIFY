import 'package:flutter_riverpod/flutter_riverpod.dart';

import 'local_box.dart';

/// Nama box Hive (Tahap 2 §6.2). Terpusat agar tidak ada salah ketik.
abstract final class BoxNames {
  static const String tasks = 'tasks';
  static const String habits = 'habits';
  static const String habitLogs = 'habit_logs';
  static const String focusSessions = 'focus_sessions';
  static const String deviceSettings = 'device_settings';
  static const String timerState = 'timer_state';
  static const String reminderMap = 'reminder_map';
  static const String gameScores = 'game_scores';
  static const String syncMeta = 'sync_meta';
  static const String syncConflicts = 'sync_conflicts';
  static const String achievements = 'achievements';
  static const String currencyCache = 'currency_cache';
  static const String feedbackOutbox = 'feedback_outbox';
  static const String preferences = 'preferences';

  static const List<String> all = <String>[
    tasks,
    habits,
    habitLogs,
    focusSessions,
    deviceSettings,
    timerState,
    reminderMap,
    gameScores,
    syncMeta,
    syncConflicts,
    achievements,
    currencyCache,
    feedbackOutbox,
    preferences,
  ];

  /// Box berisi data milik akun. Dikosongkan saat keluar manual atau saat
  /// akun lain masuk di perangkat yang sama (Tahap 2 §5.1/§15).
  static const List<String> userData = <String>[
    tasks,
    habits,
    habitLogs,
    focusSessions,
    timerState,
    reminderMap,
    syncMeta,
    syncConflicts,
    achievements,
    feedbackOutbox,
    preferences,
  ];
}

/// Kumpulan box yang sudah dibuka.
class LocalDatabase {
  LocalDatabase(Map<String, LocalBox> boxes) : _boxes = boxes;

  /// Database di memori (test dan fallback bila Hive gagal dibuka).
  factory LocalDatabase.inMemory() => LocalDatabase(<String, LocalBox>{
        for (final String name in BoxNames.all) name: MemoryLocalBox(name),
      });

  final Map<String, LocalBox> _boxes;

  LocalBox box(String name) {
    final LocalBox? box = _boxes[name];
    if (box == null) {
      throw StateError('Box "$name" belum dibuka.');
    }
    return box;
  }

  LocalBox get tasks => box(BoxNames.tasks);
  LocalBox get habits => box(BoxNames.habits);
  LocalBox get habitLogs => box(BoxNames.habitLogs);
  LocalBox get focusSessions => box(BoxNames.focusSessions);
  LocalBox get deviceSettings => box(BoxNames.deviceSettings);
  LocalBox get timerState => box(BoxNames.timerState);
  LocalBox get reminderMap => box(BoxNames.reminderMap);
  LocalBox get gameScores => box(BoxNames.gameScores);
  LocalBox get syncMeta => box(BoxNames.syncMeta);
  LocalBox get syncConflicts => box(BoxNames.syncConflicts);
  LocalBox get achievements => box(BoxNames.achievements);
  LocalBox get currencyCache => box(BoxNames.currencyCache);
  LocalBox get feedbackOutbox => box(BoxNames.feedbackOutbox);
  LocalBox get preferences => box(BoxNames.preferences);

  /// Menghapus seluruh data akun di perangkat ini.
  Future<void> clearUserData() async {
    for (final String name in BoxNames.userData) {
      await box(name).clear();
    }
  }
}

/// Diisi di `main.dart` lewat `overrideWithValue` setelah Hive dibuka.
/// Nilai bawaan (memori) hanya dipakai bila tidak ada override, misalnya
/// pada test komponen.
final Provider<LocalDatabase> localDatabaseProvider =
    Provider<LocalDatabase>((Ref ref) => LocalDatabase.inMemory());
