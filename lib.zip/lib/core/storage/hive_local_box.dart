import 'package:flutter/foundation.dart';
import 'package:hive_ce_flutter/hive_flutter.dart';

import 'local_box.dart';
import 'local_database.dart';

/// [LocalBox] di atas `Box<String>` Hive.
class HiveLocalBox implements LocalBox {
  HiveLocalBox(this._box);

  final Box<String> _box;

  @override
  String get name => _box.name;

  @override
  Iterable<String> get keys => _box.keys.map((dynamic k) => k.toString());

  @override
  String? getRaw(String key) => _box.get(key);

  @override
  Future<void> putRaw(String key, String value) => _box.put(key, value);

  @override
  Future<void> delete(String key) => _box.delete(key);

  @override
  Future<void> clear() async {
    await _box.clear();
  }

  @override
  Stream<void> get changes => _box.watch().map((BoxEvent _) {});
}

/// Membuka seluruh box. Bila satu box rusak (mis. file korup), box itu
/// dihapus lalu dibuat ulang; data inti dapat ditarik ulang dari server.
Future<LocalDatabase> openHiveDatabase() async {
  await Hive.initFlutter();
  final Map<String, LocalBox> boxes = <String, LocalBox>{};
  for (final String name in BoxNames.all) {
    Box<String> box;
    try {
      box = await Hive.openBox<String>(name);
    } catch (error) {
      debugPrint('Box $name gagal dibuka, dibuat ulang: $error');
      await Hive.deleteBoxFromDisk(name);
      box = await Hive.openBox<String>(name);
    }
    boxes[name] = HiveLocalBox(box);
  }
  return LocalDatabase(boxes);
}
