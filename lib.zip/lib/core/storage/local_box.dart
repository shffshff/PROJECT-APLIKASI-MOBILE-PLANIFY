import 'dart:async';
import 'dart:convert';

/// Penyimpanan lokal kunci → JSON string. Abstraksi tipis di atas Hive
/// (`Box<String>`) supaya repository bisa diuji tanpa file sistem.
///
/// Keputusan 4C: record disimpan sebagai JSON, bukan lewat adapter
/// `@HiveType` hasil build_runner (Tahap 2 §6.3). Alasannya: tidak ada
/// langkah generator yang bisa gagal/terlupa, dan evolusi skema cukup dengan
/// membaca field baru secara nullable. Aturan "nomor field tidak dipakai
/// ulang" berganti menjadi "nama key JSON tidak dipakai ulang".
abstract interface class LocalBox {
  String get name;

  Iterable<String> get keys;

  String? getRaw(String key);

  Future<void> putRaw(String key, String value);

  Future<void> delete(String key);

  Future<void> clear();

  /// Memancarkan setiap kali isi box berubah.
  Stream<void> get changes;
}

extension LocalBoxJson on LocalBox {
  Map<String, dynamic>? getJson(String key) {
    final String? raw = getRaw(key);
    if (raw == null) {
      return null;
    }
    try {
      final Object? decoded = jsonDecode(raw);
      return decoded is Map<String, dynamic> ? decoded : null;
    } on FormatException {
      return null;
    }
  }

  Future<void> putJson(String key, Map<String, dynamic> value) =>
      putRaw(key, jsonEncode(value));

  List<Map<String, dynamic>> allJson() {
    final List<Map<String, dynamic>> out = <Map<String, dynamic>>[];
    for (final String key in keys.toList()) {
      final Map<String, dynamic>? json = getJson(key);
      if (json != null) {
        out.add(json);
      }
    }
    return out;
  }
}

/// Implementasi di memori untuk test.
class MemoryLocalBox implements LocalBox {
  MemoryLocalBox(this.name);

  @override
  final String name;

  final Map<String, String> _data = <String, String>{};
  final StreamController<void> _changes = StreamController<void>.broadcast();

  @override
  Iterable<String> get keys => _data.keys;

  @override
  String? getRaw(String key) => _data[key];

  @override
  Future<void> putRaw(String key, String value) async {
    _data[key] = value;
    _changes.add(null);
  }

  @override
  Future<void> delete(String key) async {
    _data.remove(key);
    _changes.add(null);
  }

  @override
  Future<void> clear() async {
    _data.clear();
    _changes.add(null);
  }

  @override
  Stream<void> get changes => _changes.stream;
}
