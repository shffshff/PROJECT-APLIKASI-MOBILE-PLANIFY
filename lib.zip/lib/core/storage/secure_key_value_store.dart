import 'package:flutter_secure_storage/flutter_secure_storage.dart';

/// Penyimpanan kunci-nilai terenkripsi yang kecil. Dipisah sebagai antarmuka
/// agar test tidak membutuhkan platform channel.
abstract interface class SecureKeyValueStore {
  Future<String?> read(String key);
  Future<void> write(String key, String value);
  Future<void> delete(String key);
}

/// Implementasi nyata: Android Keystore (EncryptedSharedPreferences) / iOS
/// Keychain / WebCrypto di Web.
class FlutterSecureKeyValueStore implements SecureKeyValueStore {
  FlutterSecureKeyValueStore([FlutterSecureStorage? storage])
      : _storage = storage ?? const FlutterSecureStorage();

  final FlutterSecureStorage _storage;

  @override
  Future<String?> read(String key) => _storage.read(key: key);

  @override
  Future<void> write(String key, String value) =>
      _storage.write(key: key, value: value);

  @override
  Future<void> delete(String key) => _storage.delete(key: key);
}

/// Implementasi di memori untuk test.
class InMemoryKeyValueStore implements SecureKeyValueStore {
  InMemoryKeyValueStore([Map<String, String>? initial])
      : values = <String, String>{...?initial};

  final Map<String, String> values;

  @override
  Future<String?> read(String key) async => values[key];

  @override
  Future<void> write(String key, String value) async {
    values[key] = value;
  }

  @override
  Future<void> delete(String key) async {
    values.remove(key);
  }
}

/// Nama kunci penyimpanan aman.
abstract final class SecureKeys {
  /// JSON sesi Supabase.
  static const String supabaseSession = 'planify.supabase.session';

  /// ID pengguna yang mengaktifkan kunci biometrik di perangkat ini.
  static const String biometricOwner = 'planify.biometric.owner';

  /// Email pengguna yang mengaktifkan login biometrik (untuk tampilan pada halaman login).
  static const String biometricEmail = 'planify.biometric.email';

  /// Refresh token terenkripsi untuk memulihkan sesi autentikasi via biometrik setelah logout.
  static const String biometricToken = 'planify.biometric.token';

  /// Kredensial autentikasi terenkripsi (Android Keystore / iOS Keychain)
  /// yang dilindungi oleh verifikasi biometrik lokal untuk login kembali setelah logout.
  static const String biometricSecret = 'planify.biometric.secret';
}
