import 'package:flutter/foundation.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:sensors_plus/sensors_plus.dart';

/// Satu sampel sensor 3 sumbu.
@immutable
class MotionSample {
  const MotionSample(this.x, this.y, this.z);

  final double x;
  final double y;
  final double z;
}

/// Sumber accelerometer (m/s², termasuk gravitasi) dan gyroscope (rad/s).
/// Diabstraksi supaya logika sensor bisa diuji dengan sampel sintetis.
abstract interface class MotionSource {
  /// `false` di platform yang jelas tidak didukung (Web).
  bool get isPlatformSupported;

  Stream<MotionSample> accelerometer();

  Stream<MotionSample> gyroscope();
}

/// Implementasi `sensors_plus`. Laju sampling "normal" (bukan maksimum)
/// demi baterai (NFR-018). Bila sensor tidak ada, stream bisa error atau
/// tidak pernah mengirim event; pemanggil wajib memasang `onError` dan
/// batas waktu (Tahap 2 §12.1).
class SensorsPlusMotionSource implements MotionSource {
  const SensorsPlusMotionSource();

  @override
  bool get isPlatformSupported => !kIsWeb;

  @override
  Stream<MotionSample> accelerometer() =>
      accelerometerEventStream(samplingPeriod: SensorInterval.normalInterval)
          .map((AccelerometerEvent e) => MotionSample(e.x, e.y, e.z));

  @override
  Stream<MotionSample> gyroscope() =>
      gyroscopeEventStream(samplingPeriod: SensorInterval.gameInterval)
          .map((GyroscopeEvent e) => MotionSample(e.x, e.y, e.z));
}

/// Bawaan untuk test/Web: tidak ada sensor.
class NoMotionSource implements MotionSource {
  const NoMotionSource();

  @override
  bool get isPlatformSupported => false;

  @override
  Stream<MotionSample> accelerometer() => const Stream<MotionSample>.empty();

  @override
  Stream<MotionSample> gyroscope() => const Stream<MotionSample>.empty();
}

/// Diisi di `main.dart` dengan [SensorsPlusMotionSource].
final Provider<MotionSource> motionSourceProvider =
    Provider<MotionSource>((Ref ref) => const NoMotionSource());
