import 'dart:convert';

import 'package:flutter/foundation.dart';

import '../storage/local_box.dart';
import '../storage/local_database.dart';
import '../utils/date_only.dart';
import 'remote_gateway.dart';
import 'sync_entity.dart';

/// Ringkasan satu putaran sinkron.
@immutable
class SyncReport {
  const SyncReport({
    this.pushed = 0,
    this.pulled = 0,
    this.conflicts = 0,
    this.failed = 0,
    this.stoppedBy,
    this.changedTables = const <String>{},
  });

  final int pushed;
  final int pulled;
  final int conflicts;
  final int failed;

  /// Diisi bila putaran berhenti di tengah (jaringan/sesi).
  final RemoteErrorKind? stoppedBy;

  /// Tabel yang isinya berubah karena pull (untuk menjadwal ulang pengingat).
  final Set<String> changedTables;

  bool get completed => stoppedBy == null;
}

/// Hasil lokal yang kalah konflik (Tahap 2 §6.2 `sync_conflicts`).
@immutable
class SyncConflict {
  const SyncConflict({
    required this.table,
    required this.recordKey,
    required this.localJson,
    required this.serverVersion,
    required this.detectedAt,
  });

  final String table;
  final String recordKey;
  final String localJson;
  final int? serverVersion;
  final DateTime detectedAt;

  Map<String, dynamic> toJson() => <String, dynamic>{
        'table': table,
        'record_key': recordKey,
        'local_json': localJson,
        'server_version': serverVersion,
        'detected_at': detectedAt.toUtc().toIso8601String(),
      };
}

/// Mesin sinkronisasi: optimistic versioning + server-wins + simpan versi
/// lokal yang kalah (Tahap 2 §10). Tidak berjalan di background.
class SyncEngine {
  SyncEngine({
    required this.database,
    required this.remote,
    required this.tables,
    DateTime Function()? clock,
  }) : _clock = clock ?? DateTime.now;

  final LocalDatabase database;
  final RemoteGateway remote;

  /// Urutan push sesuai ketergantungan FK: tasks → habits → habit_logs →
  /// focus_sessions.
  final List<SyncTableSpec> tables;
  final DateTime Function() _clock;

  static const int pageSize = 500;

  /// Menutup celah antara `now()` transaksi dan waktu commit (§10.2 langkah 5).
  static const Duration pullMargin = Duration(seconds: 5);

  bool _running = false;
  bool get isRunning => _running;

  LocalBox get _meta => database.syncMeta;

  /// Menjalankan satu putaran. Mengembalikan `null` bila putaran lain masih
  /// berjalan (mutex).
  Future<SyncReport?> run() async {
    if (_running) {
      return null;
    }
    _running = true;
    int pushed = 0;
    int pulled = 0;
    int conflicts = 0;
    int failed = 0;
    final Set<String> changed = <String>{};
    try {
      for (final SyncTableSpec table in tables) {
        final _TableResult r = await _push(table);
        pushed += r.pushed;
        conflicts += r.conflicts;
        failed += r.failed;
        if (r.conflicts > 0) {
          changed.add(table.table);
        }
      }
      for (final SyncTableSpec table in tables) {
        final _TableResult r = await _pull(table);
        pulled += r.pulled;
        conflicts += r.conflicts;
        if (r.pulled > 0) {
          changed.add(table.table);
        }
      }
      await _meta.putRaw('lastSyncAt', _clock().toUtc().toIso8601String());
      return SyncReport(
        pushed: pushed,
        pulled: pulled,
        conflicts: conflicts,
        failed: failed,
        changedTables: changed,
      );
    } on RemoteError catch (error) {
      debugPrint('Sinkron berhenti: $error');
      return SyncReport(
        pushed: pushed,
        pulled: pulled,
        conflicts: conflicts,
        failed: failed,
        stoppedBy: error.kind,
        changedTables: changed,
      );
    } finally {
      _running = false;
    }
  }

  // ---- Push ---------------------------------------------------------------

  Future<_TableResult> _push(SyncTableSpec binding) async {
    final LocalBox box = database.box(binding.boxName);
    int pushed = 0;
    int conflicts = 0;
    int failed = 0;

    for (final String key in box.keys.toList()) {
      final Map<String, dynamic>? json = box.getJson(key);
      if (json == null || SyncStatus.parse(json['sync_status']) != SyncStatus.pending) {
        continue;
      }
      final SyncInfo info = SyncInfo.fromJson(json);
      final Map<String, dynamic> row = _payload(json);
      final Map<String, Object> pk = binding.pkOf(json);

      try {
        Map<String, dynamic>? server;
        if (info.serverVersion == null) {
          server = await remote.insertIgnore(
            binding.table,
            row,
            onConflict: binding.onConflict,
          );
          if (server == null) {
            // Sudah ada (mis. retry setelah respons hilang, atau log habit
            // yang sama dari perangkat lain).
            final Map<String, dynamic>? existing =
                await remote.fetch(binding.table, pk);
            if (existing == null) {
              await _markFailed(box, key, json, 'not_found');
              failed++;
              continue;
            }
            if (sameContent(row, existing)) {
              server = existing;
            } else {
              await _conflict(binding, box, key, json, existing);
              conflicts++;
              continue;
            }
          }
        } else {
          server = await remote.updateIfVersion(
            binding.table,
            pk,
            info.serverVersion!,
            _withoutCreatedAt(row),
          );
          if (server == null) {
            final Map<String, dynamic>? existing =
                await remote.fetch(binding.table, pk);
            if (existing == null) {
              await _markFailed(box, key, json, 'not_found_or_denied');
              failed++;
              continue;
            }
            await _conflict(binding, box, key, json, existing);
            conflicts++;
            continue;
          }
        }
        // Baca ulang: bila pengguna mengubah record selama request berjalan,
        // biarkan tetap pending agar ikut putaran berikutnya.
        final Map<String, dynamic>? latest = box.getJson(key);
        if (latest != null && jsonEncode(latest) != jsonEncode(json)) {
          await box.putJson(key, <String, dynamic>{
            ...latest,
            'version': server['version'],
          });
        } else {
          await _writeServer(box, key, server);
        }
        pushed++;
      } on RemoteError catch (error) {
        if (error.kind == RemoteErrorKind.rejected) {
          await _markFailed(box, key, json, error.code);
          failed++;
          continue;
        }
        rethrow; // transient / unauthorized → hentikan putaran.
      }
    }
    return _TableResult(pushed: pushed, conflicts: conflicts, failed: failed);
  }

  /// Kolom yang dikirim ke server: tanpa metadata lokal, `version`, dan
  /// `updated_at` (diisi trigger).
  static Map<String, dynamic> _payload(Map<String, dynamic> json) {
    final Map<String, dynamic> row = Map<String, dynamic>.of(json)
      ..remove('version')
      ..remove('updated_at')
      ..remove('sync_status')
      ..remove('sync_error');
    return row;
  }

  static Map<String, dynamic> _withoutCreatedAt(Map<String, dynamic> row) =>
      Map<String, dynamic>.of(row)..remove('created_at');

  Future<void> _writeServer(
    LocalBox box,
    String key,
    Map<String, dynamic> server,
  ) =>
      box.putJson(key, <String, dynamic>{
        ...server,
        'sync_status': SyncStatus.synced.name,
        'sync_error': null,
      });

  Future<void> _markFailed(
    LocalBox box,
    String key,
    Map<String, dynamic> json,
    String code,
  ) =>
      box.putJson(key, <String, dynamic>{
        ...json,
        'sync_status': SyncStatus.failed.name,
        'sync_error': code,
      });

  Future<void> _conflict(
    SyncTableSpec binding,
    LocalBox box,
    String key,
    Map<String, dynamic> localJson,
    Map<String, dynamic> server,
  ) async {
    final Object? version = server['version'];
    final SyncConflict conflict = SyncConflict(
      table: binding.table,
      recordKey: key,
      localJson: jsonEncode(localJson),
      serverVersion: version is num ? version.toInt() : null,
      detectedAt: _clock(),
    );
    await database.syncConflicts.putJson(
      '${binding.table}:$key:${_clock().microsecondsSinceEpoch}',
      conflict.toJson(),
    );
    await _writeServer(box, key, server);
  }

  // ---- Pull ---------------------------------------------------------------

  Future<_TableResult> _pull(SyncTableSpec binding) async {
    final LocalBox box = database.box(binding.boxName);
    final String cursorKey = 'lastPulledAt:${binding.table}';
    final DateTime? cursor = parseTimestamp(_meta.getRaw(cursorKey));
    final DateTime? since = cursor?.subtract(pullMargin);

    DateTime? maxSeen = cursor;
    int applied = 0;
    int conflicts = 0;
    int offset = 0;

    while (true) {
      final List<Map<String, dynamic>> rows = await remote.pullSince(
        binding.table,
        since,
        offset: offset,
        limit: pageSize,
      );
      for (final Map<String, dynamic> row in rows) {
        final String key = binding.keyOf(row);
        final _Apply result = await _applyRemote(binding, box, key, row);
        if (result == _Apply.applied) {
          applied++;
        } else if (result == _Apply.conflict) {
          applied++;
          conflicts++;
        }
        final DateTime updated = readUpdatedAt(row);
        if (maxSeen == null || updated.isAfter(maxSeen)) {
          maxSeen = updated;
        }
      }
      if (rows.length < pageSize) {
        break;
      }
      offset += pageSize;
    }

    if (maxSeen != null) {
      await _meta.putRaw(cursorKey, maxSeen.toUtc().toIso8601String());
    }
    return _TableResult(pulled: applied, conflicts: conflicts);
  }

  Future<_Apply> _applyRemote(
    SyncTableSpec binding,
    LocalBox box,
    String key,
    Map<String, dynamic> row,
  ) async {
    final Map<String, dynamic>? local = box.getJson(key);
    final Object? v = row['version'];
    final int serverVersion = v is num ? v.toInt() : 0;

    if (local == null) {
      await _writeServer(box, key, row);
      return _Apply.applied;
    }
    final SyncInfo info = SyncInfo.fromJson(local);
    final int known = info.serverVersion ?? 0;
    if (serverVersion <= known) {
      return _Apply.skipped; // data yang terambil ulang karena margin
    }
    if (info.status == SyncStatus.pending) {
      await _conflict(binding, box, key, local, row);
      return _Apply.conflict;
    }
    await _writeServer(box, key, row);
    return _Apply.applied;
  }

  /// Membandingkan isi baris tanpa memedulikan format timestamp/angka.
  @visibleForTesting
  static bool sameContent(
    Map<String, dynamic> local,
    Map<String, dynamic> server,
  ) {
    for (final MapEntry<String, dynamic> e in local.entries) {
      if (e.key == 'created_at') {
        continue;
      }
      if (!_sameValue(e.value, server[e.key])) {
        return false;
      }
    }
    return true;
  }

  static bool _sameValue(Object? a, Object? b) {
    if (a == null || b == null) {
      return a == b;
    }
    if (a is num && b is num) {
      return a == b;
    }
    if (a is List && b is List) {
      return jsonEncode(a) == jsonEncode(b);
    }
    final String sa = a.toString();
    final String sb = b.toString();
    if (sa == sb) {
      return true;
    }
    final DateTime? da = sa.contains('T') ? DateTime.tryParse(sa) : null;
    final DateTime? db = sb.contains('T') ? DateTime.tryParse(sb) : null;
    if (da != null && db != null) {
      return da.isAtSameMomentAs(db);
    }
    // '14:00' vs '14:00:00'
    if (sa.length == 5 && sb.startsWith(sa) && sb.length == 8) {
      return true;
    }
    if (sb.length == 5 && sa.startsWith(sb) && sa.length == 8) {
      return true;
    }
    return false;
  }

  /// Jumlah record per status di semua tabel (untuk indikator sinkron).
  Map<SyncStatus, int> countByStatus() => countSyncStatus(database, tables);

  /// Mengembalikan record `failed` menjadi `pending` (tombol "Coba lagi").
  Future<int> retryFailed() async {
    int n = 0;
    for (final SyncTableSpec binding in tables) {
      final LocalBox box = database.box(binding.boxName);
      for (final String key in box.keys.toList()) {
        final Map<String, dynamic>? json = box.getJson(key);
        if (json != null &&
            SyncStatus.parse(json['sync_status']) == SyncStatus.failed) {
          await box.putJson(key, <String, dynamic>{
            ...json,
            'sync_status': SyncStatus.pending.name,
            'sync_error': null,
          });
          n++;
        }
      }
    }
    return n;
  }

  DateTime? get lastSyncAt => parseTimestamp(_meta.getRaw('lastSyncAt'));
}

/// Menghitung record per status sinkron tanpa membutuhkan server.
Map<SyncStatus, int> countSyncStatus(
  LocalDatabase database,
  List<SyncTableSpec> tables,
) {
  final Map<SyncStatus, int> counts = <SyncStatus, int>{
    for (final SyncStatus s in SyncStatus.values) s: 0,
  };
  for (final SyncTableSpec spec in tables) {
    final LocalBox box = database.box(spec.boxName);
    for (final String key in box.keys) {
      final Map<String, dynamic>? json = box.getJson(key);
      if (json != null) {
        final SyncStatus s = SyncStatus.parse(json['sync_status']);
        counts[s] = counts[s]! + 1;
      }
    }
  }
  return counts;
}

enum _Apply { applied, conflict, skipped }

class _TableResult {
  const _TableResult({
    this.pushed = 0,
    this.pulled = 0,
    this.conflicts = 0,
    this.failed = 0,
  });

  final int pushed;
  final int pulled;
  final int conflicts;
  final int failed;
}
