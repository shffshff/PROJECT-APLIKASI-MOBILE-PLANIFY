import 'package:flutter/foundation.dart';

import '../storage/local_box.dart';
import '../utils/date_only.dart';

/// Status sinkronisasi per record (Tahap 2 §6.1).
enum SyncStatus {
  synced,
  pending,

  /// Ditolak server (validasi/RLS). Tidak dicoba ulang otomatis.
  failed;

  static SyncStatus parse(Object? value) => SyncStatus.values.firstWhere(
        (SyncStatus s) => s.name == value,
        orElse: () => SyncStatus.synced,
      );
}

/// Metadata sinkronisasi yang hanya ada di perangkat.
@immutable
class SyncInfo {
  const SyncInfo({
    this.serverVersion,
    this.status = SyncStatus.pending,
    this.error,
  });

  /// Versi terakhir yang diketahui dari server; `null` = belum pernah sinkron.
  final int? serverVersion;
  final SyncStatus status;

  /// Kode error singkat (bukan pesan teknis mentah).
  final String? error;

  static SyncInfo fromJson(Map<String, dynamic> json) {
    final Object? version = json['version'];
    return SyncInfo(
      serverVersion: version is num ? version.toInt() : null,
      status: SyncStatus.parse(json['sync_status']),
      error: json['sync_error'] as String?,
    );
  }

  Map<String, dynamic> toJson() => <String, dynamic>{
        'version': serverVersion,
        'sync_status': status.name,
        'sync_error': error,
      };

  @override
  bool operator ==(Object other) =>
      other is SyncInfo &&
      other.serverVersion == serverVersion &&
      other.status == status &&
      other.error == error;

  @override
  int get hashCode => Object.hash(serverVersion, status, error);
}

/// Entitas yang disinkronkan. `toRow()` berisi kolom server tanpa `version`
/// dan `updated_at` (keduanya diisi trigger `tg_touch_row` di server).
abstract interface class SyncEntity<T> {
  /// Key di box Hive (UUID, atau komposit untuk habit_logs).
  String get localKey;
  SyncInfo get syncInfo;
  DateTime get updatedAt;
  DateTime? get deletedAt;

  Map<String, dynamic> toRow();

  T withSync(SyncInfo info, {DateTime? updatedAt});
}

/// Tabel server yang disinkronkan beserta box lokalnya.
class SyncTableSpec {
  const SyncTableSpec({
    required this.table,
    required this.boxName,
    required this.pkColumns,
  });

  final String table;
  final String boxName;

  /// Kolom primary key di server (filter UPDATE/SELECT dan `on conflict`).
  final List<String> pkColumns;

  String get onConflict => pkColumns.join(',');

  Map<String, Object> pkOf(Map<String, dynamic> row) => <String, Object>{
        for (final String c in pkColumns) c: row[c] as Object,
      };

  /// Key box dari baris: kolom PK digabung dengan `|`
  /// (habit_logs → `"$habitId|yyyy-MM-dd"`, Tahap 2 §6.2).
  String keyOf(Map<String, dynamic> row) =>
      pkColumns.map((String c) => row[c].toString()).join('|');
}

/// Akses box untuk satu jenis entitas.
class EntityStore<T extends SyncEntity<T>> {
  EntityStore(this.box, this.spec, this.fromJson, {DateTime Function()? clock})
      : _clock = clock ?? DateTime.now;

  final LocalBox box;
  final SyncTableSpec spec;

  /// Membaca JSON lokal maupun baris server (`sync_status` kosong = synced).
  final T Function(Map<String, dynamic> json) fromJson;
  final DateTime Function() _clock;

  static Map<String, dynamic> toLocalJson<T extends SyncEntity<T>>(T e) =>
      <String, dynamic>{
        ...e.toRow(),
        'updated_at': e.updatedAt.toUtc().toIso8601String(),
        ...e.syncInfo.toJson(),
      };

  T? _decode(Map<String, dynamic>? json) {
    if (json == null) {
      return null;
    }
    try {
      return fromJson(json);
    } catch (error) {
      debugPrint('Record ${spec.table} rusak diabaikan: $error');
      return null;
    }
  }

  T? get(String key) => _decode(box.getJson(key));

  /// Semua record, termasuk tombstone bila [includeDeleted].
  List<T> all({bool includeDeleted = false}) {
    final List<T> out = <T>[];
    for (final String key in box.keys.toList()) {
      final T? e = get(key);
      if (e != null && (includeDeleted || e.deletedAt == null)) {
        out.add(e);
      }
    }
    return out;
  }

  /// Daftar yang diperbarui setiap box berubah (Tahap 2 §5.1: `watch()`).
  Stream<List<T>> watch() async* {
    yield all();
    await for (final _ in box.changes) {
      yield all();
    }
  }

  Iterable<T> withStatus(SyncStatus status) => all(includeDeleted: true)
      .where((T e) => e.syncInfo.status == status);

  /// Menulis perubahan lokal: status `pending`, `updated_at` = sekarang.
  Future<T> saveLocal(T entity) async {
    final T marked = entity.withSync(
      SyncInfo(serverVersion: entity.syncInfo.serverVersion),
      updatedAt: _clock().toUtc(),
    );
    await box.putJson(marked.localKey, toLocalJson(marked));
    return marked;
  }

  /// Menulis apa adanya (hasil dari server atau penandaan status).
  Future<void> put(T entity) =>
      box.putJson(entity.localKey, toLocalJson(entity));

  /// Penanda waktu UTC sekarang (dipakai repository untuk created_at dll).
  DateTime nowUtc() => _clock().toUtc();
}

/// Membaca `updated_at` dari baris server/lokal; fallback ke epoch.
DateTime readUpdatedAt(Map<String, dynamic> json) =>
    parseTimestamp(json['updated_at'])?.toUtc() ??
    DateTime.fromMillisecondsSinceEpoch(0, isUtc: true);
