import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:supabase_flutter/supabase_flutter.dart';

import '../config/supabase_bootstrap.dart';

/// Operasi tabel yang dibutuhkan SyncEngine (Tahap 2 §10.2). Diabstraksi
/// agar engine dapat diuji dengan server palsu.
abstract interface class RemoteGateway {
  /// `INSERT ... ON CONFLICT DO NOTHING RETURNING *`. `null` bila baris
  /// dengan PK yang sama sudah ada.
  Future<Map<String, dynamic>?> insertIgnore(
    String table,
    Map<String, dynamic> row, {
    required String onConflict,
  });

  Future<Map<String, dynamic>?> fetch(String table, Map<String, Object> pk);

  /// `UPDATE ... WHERE pk AND version = expected RETURNING *`. `null` bila
  /// tidak ada baris yang cocok (versi sudah berubah / tidak ada / RLS).
  Future<Map<String, dynamic>?> updateIfVersion(
    String table,
    Map<String, Object> pk,
    int expectedVersion,
    Map<String, dynamic> row,
  );

  /// Baris dengan `updated_at > since`, urut naik, per halaman.
  Future<List<Map<String, dynamic>>> pullSince(
    String table,
    DateTime? since, {
    required int offset,
    required int limit,
  });
}

/// Klasifikasi error dari server.
enum RemoteErrorKind {
  /// Jaringan putus / timeout / 5xx: coba lagi nanti.
  transient,

  /// Token tidak valid: hentikan sinkron.
  unauthorized,

  /// Ditolak (validasi, RLS, constraint): tandai `failed`.
  rejected,
}

class RemoteError implements Exception {
  const RemoteError(this.kind, this.code);

  final RemoteErrorKind kind;
  final String code;

  @override
  String toString() => 'RemoteError($kind, $code)';
}

/// Implementasi PostgREST (supabase_flutter). RLS di server membatasi baris
/// ke milik pengguna; klien tetap mengirim `user_id` miliknya.
class SupabaseRemoteGateway implements RemoteGateway {
  SupabaseRemoteGateway(this._client);

  final SupabaseClient _client;

  static const Duration _timeout = Duration(seconds: 20);

  Future<R> _guard<R>(Future<R> Function() body) async {
    try {
      return await body().timeout(_timeout);
    } on PostgrestException catch (error) {
      throw _classify(error);
    } on AuthException catch (error) {
      throw RemoteError(RemoteErrorKind.unauthorized, error.code ?? 'auth');
    } on RemoteError {
      rethrow;
    } catch (error) {
      // SocketException, ClientException, TimeoutException, dsb.
      throw RemoteError(RemoteErrorKind.transient, error.runtimeType.toString());
    }
  }

  static RemoteError _classify(PostgrestException error) {
    final String code = error.code ?? 'unknown';
    if (code == 'PGRST301' || code == 'PGRST302' || code == '401') {
      return RemoteError(RemoteErrorKind.unauthorized, code);
    }
    // Kode kelas 08 (koneksi), 53/57 (sumber daya/shutdown), 5xx HTTP.
    if (code.startsWith('08') ||
        code.startsWith('53') ||
        code.startsWith('57') ||
        code.startsWith('5')) {
      return RemoteError(RemoteErrorKind.transient, code);
    }
    return RemoteError(RemoteErrorKind.rejected, code);
  }

  @override
  Future<Map<String, dynamic>?> insertIgnore(
    String table,
    Map<String, dynamic> row, {
    required String onConflict,
  }) {
    return _guard(() async {
      final List<Map<String, dynamic>> rows = await _client
          .from(table)
          .upsert(row, onConflict: onConflict, ignoreDuplicates: true)
          .select();
      return rows.isEmpty ? null : rows.first;
    });
  }

  @override
  Future<Map<String, dynamic>?> fetch(String table, Map<String, Object> pk) {
    return _guard(() async {
      var query = _client.from(table).select();
      for (final MapEntry<String, Object> e in pk.entries) {
        query = query.eq(e.key, e.value);
      }
      return query.maybeSingle();
    });
  }

  @override
  Future<Map<String, dynamic>?> updateIfVersion(
    String table,
    Map<String, Object> pk,
    int expectedVersion,
    Map<String, dynamic> row,
  ) {
    return _guard(() async {
      var query = _client.from(table).update(row);
      for (final MapEntry<String, Object> e in pk.entries) {
        query = query.eq(e.key, e.value);
      }
      final List<Map<String, dynamic>> rows =
          await query.eq('version', expectedVersion).select();
      return rows.isEmpty ? null : rows.first;
    });
  }

  @override
  Future<List<Map<String, dynamic>>> pullSince(
    String table,
    DateTime? since, {
    required int offset,
    required int limit,
  }) {
    return _guard(() async {
      var query = _client.from(table).select();
      if (since != null) {
        query = query.gt('updated_at', since.toUtc().toIso8601String());
      }
      return query
          .order('updated_at', ascending: true)
          .range(offset, offset + limit - 1);
    });
  }
}

/// Gateway server; `null` bila Supabase belum dikonfigurasi (data tetap
/// tersimpan lokal dan disinkronkan setelah konfigurasi ada).
final Provider<RemoteGateway?> remoteGatewayProvider =
    Provider<RemoteGateway?>((Ref ref) {
  if (!SupabaseBootstrap.isInitialized) {
    return null;
  }
  return SupabaseRemoteGateway(SupabaseBootstrap.client);
});
