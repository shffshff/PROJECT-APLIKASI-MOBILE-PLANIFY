import 'dart:async';

import 'package:flutter_riverpod/flutter_riverpod.dart';

/// Sinyal "ada perubahan lokal yang perlu disinkronkan". Repository memanggil
/// [notify]; SyncController mendengarkan dan menjalankan sinkron setelah
/// jeda (debounce) beberapa detik (Tahap 2 §10.2 langkah 2).
class LocalChangeSignal {
  final StreamController<void> _controller =
      StreamController<void>.broadcast();

  Stream<void> get stream => _controller.stream;

  void notify() => _controller.add(null);

  Future<void> dispose() => _controller.close();
}

final Provider<LocalChangeSignal> localChangeSignalProvider =
    Provider<LocalChangeSignal>((Ref ref) {
  final LocalChangeSignal signal = LocalChangeSignal();
  ref.onDispose(signal.dispose);
  return signal;
});
