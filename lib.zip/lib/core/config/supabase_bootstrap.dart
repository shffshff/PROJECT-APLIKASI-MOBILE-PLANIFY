import 'package:flutter/foundation.dart';
import 'package:supabase_flutter/supabase_flutter.dart';

import '../storage/secure_key_value_store.dart';
import '../storage/secure_local_storage.dart';
import 'env.dart';

/// Inisialisasi Supabase sekali saat aplikasi mulai.
abstract final class SupabaseBootstrap {
  static bool _initialized = false;

  /// `true` bila Supabase terkonfigurasi dan berhasil diinisialisasi.
  static bool get isInitialized => _initialized;

  static SupabaseClient get client => Supabase.instance.client;

  /// Mengembalikan `true` bila siap dipakai. Tidak melempar: kegagalan
  /// membuat aplikasi tetap terbuka dengan pesan "belum dikonfigurasi".
  static Future<bool> initialize() async {
    if (_initialized) {
      return true;
    }
    if (!Env.isSupabaseConfigured) {
      debugPrint('Supabase belum dikonfigurasi (SUPABASE_URL/ANON_KEY kosong).');
      return false;
    }
    try {
      await Supabase.initialize(
        url: Env.supabaseUrl,
        anonKey: Env.supabaseAnonKey,
        authOptions: FlutterAuthClientOptions(
          authFlowType: AuthFlowType.pkce,
          localStorage: SecureLocalStorage(FlutterSecureKeyValueStore()),
        ),
      );
      _initialized = true;
    } catch (error) {
      debugPrint('Supabase.initialize gagal: $error');
    }
    return _initialized;
  }
}
