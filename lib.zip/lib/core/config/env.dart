/// Konfigurasi yang dibaca saat build melalui `--dart-define` atau
/// `--dart-define-from-file=env.json` (lihat docs/SETUP.md).
///
/// Hanya nilai PUBLIK yang boleh ada di sini: URL proyek Supabase dan
/// publishable/anon key yang dilindungi Row Level Security (NFR-002).
/// Secret seperti `service_role` atau API key LLM TIDAK BOLEH dimasukkan ke
/// aplikasi; tempatnya di Supabase secrets untuk Edge Function.
abstract final class Env {
  static const String supabaseUrl = String.fromEnvironment('SUPABASE_URL');
  static const String supabaseAnonKey =
      String.fromEnvironment('SUPABASE_ANON_KEY');

  /// `true` jika kedua nilai Supabase sudah diisi saat build.
  static bool get isSupabaseConfigured =>
      supabaseUrl.isNotEmpty && supabaseAnonKey.isNotEmpty;
}
