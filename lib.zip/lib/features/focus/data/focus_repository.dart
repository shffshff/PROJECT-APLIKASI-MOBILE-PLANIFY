import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../../../core/error/app_failure.dart';
import '../../../core/storage/local_box.dart';
import '../../../core/storage/local_database.dart';
import '../../../core/sync/local_change_signal.dart';
import '../../../core/sync/sync_entity.dart';
import '../../../core/utils/date_only.dart';
import '../../hash_chain/data/achievement_repository.dart';
import '../../planner/data/task_repository.dart';
import '../domain/focus_session.dart';
import '../domain/pomodoro_engine.dart';

/// Riwayat sesi fokus (append-only) + pengaturan & status timer lokal.
class FocusRepository {
  FocusRepository({
    required EntityStore<FocusSession> sessions,
    required LocalBox timerBox,
    required LocalBox settingsBox,
    required LocalChangeSignal signal,
    required String? Function() userId,
    Future<void> Function(Map<String, dynamic> data)? onAchievement,
  })  : _onAchievement = onAchievement,
        _sessions = sessions,
        _timerBox = timerBox,
        _settingsBox = settingsBox,
        _signal = signal,
        _userId = userId;

  final EntityStore<FocusSession> _sessions;
  final LocalBox _timerBox;
  final LocalBox _settingsBox;
  final LocalChangeSignal _signal;
  final String? Function() _userId;
  final Future<void> Function(Map<String, dynamic> data)? _onAchievement;

  static const String _timerKey = 'current';
  static const String _settingsKey = 'pomodoro';

  Stream<List<FocusSession>> watchSessions() => _sessions.watch();

  TimerState loadTimer() => TimerState.fromJson(_timerBox.getJson(_timerKey));

  Future<void> saveTimer(TimerState state) =>
      _timerBox.putJson(_timerKey, state.toJson());

  PomodoroSettings loadSettings() =>
      PomodoroSettings.fromJson(_settingsBox.getJson(_settingsKey));

  Future<void> saveSettings(PomodoroSettings settings) =>
      _settingsBox.putJson(_settingsKey, settings.toJson());

  Future<FocusSession> record(CompletedRun run) async {
    final String? user = _userId();
    if (user == null) {
      throw const AppFailure(AppFailureKind.unauthorized);
    }
    final DateTime now = _sessions.nowUtc();
    final FocusSession saved = await _sessions.saveLocal(
      FocusSession(
        id: Ids.newId(),
        userId: user,
        taskId: run.taskId,
        mode: run.mode,
        plannedSeconds: run.plannedSeconds,
        actualSeconds: run.actualSeconds,
        startedAt: run.startedAt,
        endedAt: run.endedAt,
        status: run.status,
        createdAt: now,
        updatedAt: now,
      ),
    );
    _signal.notify();
    if (saved.isCompletedFocus) {
      await _onAchievement?.call(<String, dynamic>{
        'type': 'focus_completed',
        'sessionId': saved.id,
        'minutes': saved.actualSeconds ~/ 60,
      });
    }
    return saved;
  }
}

final Provider<EntityStore<FocusSession>> focusSessionStoreProvider =
    Provider<EntityStore<FocusSession>>(
  (Ref ref) => EntityStore<FocusSession>(
    ref.watch(localDatabaseProvider).focusSessions,
    FocusSession.spec,
    FocusSession.fromJson,
  ),
);

final Provider<FocusRepository> focusRepositoryProvider =
    Provider<FocusRepository>((Ref ref) {
  final LocalDatabase db = ref.watch(localDatabaseProvider);
  return FocusRepository(
    sessions: ref.watch(focusSessionStoreProvider),
    timerBox: db.timerState,
    settingsBox: db.deviceSettings,
    signal: ref.watch(localChangeSignalProvider),
    userId: () => ref.read(currentUserIdProvider),
    onAchievement: ref.watch(achievementRepositoryProvider).record,
  );
});

final StreamProvider<List<FocusSession>> focusSessionsProvider =
    StreamProvider<List<FocusSession>>(
  (Ref ref) => ref.watch(focusRepositoryProvider).watchSessions(),
);

/// Statistik hari ini dan minggu ini.
final Provider<FocusStats> focusStatsProvider = Provider<FocusStats>((Ref ref) {
  final List<FocusSession> sessions =
      ref.watch(focusSessionsProvider).value ?? const <FocusSession>[];
  return FocusStats.of(sessions, DateTime.now());
});
