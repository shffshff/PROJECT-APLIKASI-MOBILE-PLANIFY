import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:intl/intl.dart';

import '../../../core/sync/sync_entity.dart';
import '../../../core/utils/app_date_format.dart';
import '../../../core/widgets/app_progress.dart';
import '../../../core/widgets/async_view.dart';
import '../../../core/widgets/empty_state.dart';
import '../../../core/widgets/page_container.dart';
import '../../../theme/app_colors.dart';
import '../../../theme/app_tokens.dart';
import '../../planner/data/task_repository.dart';
import '../../planner/domain/task.dart';
import '../data/focus_repository.dart';
import '../domain/focus_session.dart';

/// Riwayat & statistik fokus (FR-024).
class FocusHistoryPage extends ConsumerWidget {
  const FocusHistoryPage({super.key});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final AsyncValue<List<FocusSession>> sessions =
        ref.watch(focusSessionsProvider);
    final FocusStats stats = ref.watch(focusStatsProvider);
    final Map<String, String> titles = <String, String>{
      for (final Task t in ref.watch(tasksProvider).value ?? const <Task>[])
        t.id: t.title,
    };
    final ThemeData theme = Theme.of(context);
    final int maxDay = stats.weekMinutes.fold(0, (int a, int b) => a > b ? a : b);

    return Scaffold(
      appBar: AppBar(title: const Text('Riwayat fokus')),
      body: SafeArea(
        child: AsyncView<List<FocusSession>>(
          value: sessions,
          isEmpty: (List<FocusSession> l) => l.isEmpty,
          empty: const EmptyState(
            icon: Icons.timer_outlined,
            title: 'Belum ada sesi fokus',
            message: 'Selesaikan satu sesi Pomodoro untuk melihat riwayatmu.',
          ),
          builder: (BuildContext context, List<FocusSession> all) {
            final List<FocusSession> sorted = List<FocusSession>.of(all)
              ..sort((FocusSession a, FocusSession b) =>
                  b.startedAt.compareTo(a.startedAt));
            return ListView(
              padding: const EdgeInsets.only(bottom: AppSpacing.xxl),
              children: <Widget>[
                PageContainer(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.stretch,
                    children: <Widget>[
                      const SizedBox(height: AppSpacing.lg),
                      Card(
                        margin: EdgeInsets.zero,
                        child: Padding(
                          padding: const EdgeInsets.all(AppSpacing.lg),
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: <Widget>[
                              Text(
                                'Minggu ini: ${stats.weekTotal} menit',
                                style: theme.textTheme.titleMedium,
                              ),
                              Text(
                                'Hari ini: ${stats.todaySessions} sesi · '
                                '${stats.todayMinutes} menit',
                                style: theme.textTheme.bodyMedium!.copyWith(
                                  color: context.appColors.textSecondary,
                                ),
                              ),
                              const SizedBox(height: AppSpacing.lg),
                              WeeklyBars(
                                values: <double>[
                                  for (final int m in stats.weekMinutes)
                                    maxDay == 0 ? 0 : m / maxDay,
                                ],
                                labels: const <String>[
                                  'Sen',
                                  'Sel',
                                  'Rab',
                                  'Kam',
                                  'Jum',
                                  'Sab',
                                  'Min',
                                ],
                                semanticsLabel:
                                    'Menit fokus Senin sampai Minggu: '
                                    '${stats.weekMinutes.join(', ')}',
                              ),
                            ],
                          ),
                        ),
                      ),
                      const SizedBox(height: AppSpacing.lg),
                      for (final FocusSession s in sorted.take(100))
                        _SessionTile(
                          session: s,
                          taskTitle: s.taskId == null ? null : titles[s.taskId],
                        ),
                    ],
                  ),
                ),
              ],
            );
          },
        ),
      ),
    );
  }
}

class _SessionTile extends StatelessWidget {
  const _SessionTile({required this.session, this.taskTitle});

  final FocusSession session;
  final String? taskTitle;

  @override
  Widget build(BuildContext context) {
    final DateTime start = session.startedAt.toLocal();
    final bool done = session.status == FocusSessionStatus.completed;
    final String minutes = '${(session.actualSeconds / 60).round()} menit';
    final String? title = taskTitle;
    return ListTile(
      contentPadding: EdgeInsets.zero,
      leading: Icon(
        session.mode == PomodoroMode.focus
            ? Icons.timer_rounded
            : Icons.coffee_rounded,
      ),
      title: Text(
        '${session.mode.label} · $minutes'
        '${done ? '' : ' · dibatalkan'}',
      ),
      subtitle: Text(
        '${DateFormat('EEE, d MMM', 'id_ID').format(start)} '
        '${AppDateFormat.time(start)}'
        '${title == null ? '' : ' · $title'}',
        maxLines: 1,
        overflow: TextOverflow.ellipsis,
      ),
      trailing: session.syncInfo.status == SyncStatus.synced
          ? null
          : const Tooltip(
              message: 'Belum sinkron',
              child: Icon(Icons.cloud_upload_outlined, size: 18),
            ),
    );
  }
}
