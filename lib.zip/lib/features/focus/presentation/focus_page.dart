import 'dart:async';

import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:go_router/go_router.dart';

import '../../../app/router/routes.dart';
import '../../../core/storage/local_box.dart';
import '../../../core/storage/local_database.dart';
import '../../../core/widgets/app_button.dart';
import '../../../core/widgets/app_progress.dart';
import '../../../core/widgets/page_container.dart';
import '../../../core/widgets/section_header.dart';
import '../../../core/widgets/settings_tile.dart';
import '../../../core/widgets/status_banner.dart';
import '../../../theme/app_colors.dart';
import '../../../theme/app_theme.dart';
import '../../../theme/app_tokens.dart';
import '../../auto_focus/presentation/auto_focus_controller.dart';
import '../../habit/data/habit_repository.dart';
import '../../planner/data/task_repository.dart';
import '../../planner/domain/task.dart';
import '../data/focus_repository.dart';
import '../domain/focus_session.dart';
import '../domain/pomodoro_engine.dart';
import 'pomodoro_controller.dart';
import 'widgets/pomodoro_settings_sheet.dart';

String formatClock(int seconds) {
  final int s = seconds < 0 ? 0 : seconds;
  final String m = (s ~/ 60).toString().padLeft(2, '0');
  final String r = (s % 60).toString().padLeft(2, '0');
  return '$m:$r';
}

/// S-30 Focus / Pomodoro (FR-022–024) + kartu Focus Otomatis (FR-036),
/// Habit Tracker, dan Balance Focus Game.
class FocusPage extends ConsumerStatefulWidget {
  const FocusPage({super.key});

  @override
  ConsumerState<FocusPage> createState() => _FocusPageState();
}

class _FocusPageState extends ConsumerState<FocusPage> {
  late final AppLifecycleListener _lifecycle;
  late final AutoFocusController _autoFocus;
  ValueListenable<bool>? _tickerMode;
  bool _foreground = true;

  @override
  void initState() {
    super.initState();
    _autoFocus = ref.read(autoFocusControllerProvider.notifier);
    _lifecycle = AppLifecycleListener(
      onStateChange: (AppLifecycleState s) {
        _foreground = s == AppLifecycleState.resumed;
        if (_foreground) {
          ref.read(pomodoroControllerProvider.notifier).refresh();
        }
        _updateSensorGate();
      },
    );
  }

  @override
  void didChangeDependencies() {
    super.didChangeDependencies();
    // Tab yang tidak aktif di StatefulShellRoute dimatikan TickerMode-nya;
    // dipakai untuk mengetahui apakah halaman Focus sedang tampil.
    final ValueListenable<bool> notifier = TickerMode.getNotifier(context);
    if (!identical(notifier, _tickerMode)) {
      _tickerMode?.removeListener(_updateSensorGate);
      _tickerMode = notifier..addListener(_updateSensorGate);
    }
    _updateSensorGate();
  }

  @override
  void dispose() {
    _lifecycle.dispose();
    _tickerMode?.removeListener(_updateSensorGate);
    // Halaman hilang → sensor wajib berhenti (NFR-018). Ditunda karena
    // provider tidak boleh diubah selagi pohon widget dibongkar.
    final AutoFocusController auto = _autoFocus;
    scheduleMicrotask(() => auto.setPageActive(false));
    super.dispose();
  }

  void _updateSensorGate() {
    if (!mounted) {
      return;
    }
    final bool isCurrent = ModalRoute.of(context)?.isCurrent ?? true;
    final bool visible = (_tickerMode?.value ?? true) && isCurrent;
    final bool active = visible && _foreground;
    // Ditunda agar tidak mengubah provider di tengah build.
    scheduleMicrotask(() {
      if (mounted) {
        _autoFocus.setPageActive(active);
      }
    });
  }

  @override
  Widget build(BuildContext context) {
    // Dipanggil ulang saat rute di atasnya muncul/hilang (isCurrent).
    ModalRoute.of(context);
    _updateSensorGate();

    final PomodoroView view = ref.watch(pomodoroControllerProvider);
    final FocusStats stats = ref.watch(focusStatsProvider);
    final AutoFocusState auto = ref.watch(autoFocusControllerProvider);
    final ThemeData theme = Theme.of(context);

    ref.listen<PomodoroView>(pomodoroControllerProvider,
        (PomodoroView? prev, PomodoroView next) {
      final PomodoroMode? finished = next.justFinished;
      if (finished != null && prev?.justFinished == null) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
            content: Text(
              finished == PomodoroMode.focus
                  ? 'Sesi fokus selesai. Saatnya ${next.timer.mode.label.toLowerCase()}.'
                  : 'Istirahat selesai. Siap fokus lagi?',
            ),
          ),
        );
        ref.read(pomodoroControllerProvider.notifier).dismissFinished();
      }
    });

    return Scaffold(
      appBar: AppBar(
        title: Text('Focus', style: theme.textTheme.headlineSmall),
        actions: <Widget>[
          IconButton(
            tooltip: 'Riwayat fokus',
            icon: const Icon(Icons.history_rounded),
            onPressed: () => context.push(AppRoutes.focusHistory),
          ),
          IconButton(
            tooltip: 'Atur durasi',
            icon: const Icon(Icons.tune_rounded),
            onPressed: view.timer.isIdle
                ? () => showPomodoroSettingsSheet(context, ref, view.settings)
                : null,
          ),
          const SizedBox(width: AppSpacing.sm),
        ],
      ),
      body: SafeArea(
        child: ListView(
          padding: const EdgeInsets.only(bottom: AppSpacing.xxl),
          children: <Widget>[
            PageContainer(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.stretch,
                children: <Widget>[
                  const SizedBox(height: AppSpacing.sm),
                  if (auto.isPrompting) ...<Widget>[
                    _AutoFocusPrompt(
                      until: auto.promptUntil!,
                      minutes: view.settings.focusMinutes,
                    ),
                    const SizedBox(height: AppSpacing.lg),
                  ],
                  _ModeSelector(view: view),
                  const SizedBox(height: AppSpacing.xl),
                  _TimerDial(view: view),
                  const SizedBox(height: AppSpacing.lg),
                  _TaskPicker(view: view),
                  const SizedBox(height: AppSpacing.lg),
                  _Controls(view: view),
                  const SizedBox(height: AppSpacing.sectionGap),
                  Card(
                    margin: EdgeInsets.zero,
                    child: ListTile(
                      leading: const Icon(Icons.insights_rounded),
                      title: Text(
                        'Hari ini: ${stats.todaySessions} sesi · '
                        '${stats.todayMinutes} menit',
                      ),
                      subtitle: Text('Minggu ini: ${stats.weekTotal} menit'),
                      trailing: const Icon(Icons.chevron_right_rounded),
                      onTap: () => context.push(AppRoutes.focusHistory),
                    ),
                  ),
                  const SizedBox(height: AppSpacing.sectionGap),
                  const SectionHeader(title: 'Fitur fokus'),
                  const SizedBox(height: AppSpacing.sm),
                  _AutoFocusCard(state: auto),
                  const SizedBox(height: AppSpacing.cardGap),
                  const _HabitCard(),
                  const SizedBox(height: AppSpacing.cardGap),
                  const _GameCard(),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}

class _ModeSelector extends ConsumerWidget {
  const _ModeSelector({required this.view});

  final PomodoroView view;

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final PomodoroSettings s = view.settings;
    return SegmentedButton<PomodoroMode>(
      showSelectedIcon: false,
      segments: <ButtonSegment<PomodoroMode>>[
        ButtonSegment<PomodoroMode>(
          value: PomodoroMode.focus,
          label: Text('Fokus ${s.focusMinutes}'),
        ),
        ButtonSegment<PomodoroMode>(
          value: PomodoroMode.shortBreak,
          label: Text('Istirahat ${s.shortBreakMinutes}'),
        ),
        ButtonSegment<PomodoroMode>(
          value: PomodoroMode.longBreak,
          label: Text('Istirahat ${s.longBreakMinutes}'),
        ),
      ],
      selected: <PomodoroMode>{view.timer.mode},
      onSelectionChanged: view.timer.isIdle
          ? (Set<PomodoroMode> m) =>
              ref.read(pomodoroControllerProvider.notifier).selectMode(m.first)
          : null,
    );
  }
}

class _TimerDial extends StatelessWidget {
  const _TimerDial({required this.view});

  final PomodoroView view;

  @override
  Widget build(BuildContext context) {
    final ThemeData theme = Theme.of(context);
    final TimerState t = view.timer;
    final String status = switch (t.status) {
      TimerStatus.idle => 'Siap',
      TimerStatus.running =>
        t.mode == PomodoroMode.focus ? 'Fokus berjalan' : 'Sedang istirahat',
      TimerStatus.paused => 'Dijeda',
    };
    final String clock = formatClock(view.remainingSeconds);
    return Center(
      child: AppProgressRing(
        value: t.isIdle ? 0 : view.progress,
        size: 240,
        strokeWidth: 12,
        color: t.mode == PomodoroMode.focus
            ? theme.colorScheme.primary
            : theme.colorScheme.tertiary,
        semanticsLabel: '$status, sisa $clock',
        center: Column(
          mainAxisSize: MainAxisSize.min,
          children: <Widget>[
            Text(
              clock,
              style: AppTypography.timerDisplay.copyWith(
                color: theme.colorScheme.onSurface,
              ),
            ),
            Text(status, style: theme.textTheme.titleSmall),
            if (t.mode == PomodoroMode.focus)
              Text(
                'Sesi ${view.cycleIndex} dari '
                '${view.settings.sessionsBeforeLongBreak}',
                style: theme.textTheme.bodySmall!.copyWith(
                  color: context.appColors.textSecondary,
                ),
              ),
          ],
        ),
      ),
    );
  }
}

class _TaskPicker extends ConsumerWidget {
  const _TaskPicker({required this.view});

  final PomodoroView view;

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    if (view.timer.mode != PomodoroMode.focus) {
      return const SizedBox.shrink();
    }
    final List<Task> open = (ref.watch(tasksProvider).value ?? const <Task>[])
        .where((Task t) => !t.isCompleted)
        .toList()
      ..sort((Task a, Task b) => a.dueMoment.compareTo(b.dueMoment));
    final String? selectedId = view.timer.taskId;
    final bool known = open.any((Task t) => t.id == selectedId);

    return DropdownButtonFormField<String?>(
      key: ValueKey<String?>('task-${known ? selectedId : null}'),
      initialValue: known ? selectedId : null,
      isExpanded: true,
      decoration: const InputDecoration(
        labelText: 'Kerjakan (opsional)',
        prefixIcon: Icon(Icons.task_alt_rounded),
      ),
      items: <DropdownMenuItem<String?>>[
        const DropdownMenuItem<String?>(
          value: null,
          child: Text('Tanpa tugas tertentu'),
        ),
        for (final Task t in open.take(20))
          DropdownMenuItem<String?>(
            value: t.id,
            child: Text(t.title, overflow: TextOverflow.ellipsis),
          ),
      ],
      onChanged: (String? id) =>
          ref.read(pomodoroControllerProvider.notifier).setTask(id),
    );
  }
}

class _Controls extends ConsumerWidget {
  const _Controls({required this.view});

  final PomodoroView view;

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final PomodoroController c = ref.read(pomodoroControllerProvider.notifier);
    final TimerState t = view.timer;
    return Row(
      children: <Widget>[
        Expanded(
          child: AppButton(
            label: switch (t.status) {
              TimerStatus.idle => 'Mulai',
              TimerStatus.running => 'Jeda',
              TimerStatus.paused => 'Lanjut',
            },
            icon: t.isRunning ? Icons.pause_rounded : Icons.play_arrow_rounded,
            expand: true,
            onPressed: switch (t.status) {
              TimerStatus.idle => () => c.start(taskId: t.taskId),
              TimerStatus.running => c.pause,
              TimerStatus.paused => c.resume,
            },
          ),
        ),
        const SizedBox(width: AppSpacing.md),
        Expanded(
          child: AppButton(
            label: t.isIdle ? 'Lewati' : 'Reset',
            icon: t.isIdle ? Icons.skip_next_rounded : Icons.replay_rounded,
            variant: AppButtonVariant.outline,
            expand: true,
            onPressed: t.isIdle ? c.skip : c.reset,
          ),
        ),
      ],
    );
  }
}

class _AutoFocusPrompt extends ConsumerStatefulWidget {
  const _AutoFocusPrompt({required this.until, required this.minutes});

  final DateTime until;
  final int minutes;

  @override
  ConsumerState<_AutoFocusPrompt> createState() => _AutoFocusPromptState();
}

class _AutoFocusPromptState extends ConsumerState<_AutoFocusPrompt> {
  Timer? _timer;

  @override
  void initState() {
    super.initState();
    _timer = Timer.periodic(const Duration(seconds: 1), (_) {
      if (mounted) {
        setState(() {});
      }
    });
  }

  @override
  void dispose() {
    _timer?.cancel();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final ThemeData theme = Theme.of(context);
    final int left =
        widget.until.difference(DateTime.now()).inSeconds.clamp(0, 999);
    final AutoFocusController c =
        ref.read(autoFocusControllerProvider.notifier);
    return Semantics(
      liveRegion: true,
      container: true,
      child: Card(
        margin: EdgeInsets.zero,
        color: theme.colorScheme.primaryContainer,
        child: Padding(
          padding: const EdgeInsets.all(AppSpacing.lg),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.stretch,
            children: <Widget>[
              Text(
                'Ponsel terdeteksi telungkup',
                style: theme.textTheme.titleMedium,
              ),
              const SizedBox(height: AppSpacing.xs),
              Text(
                'Mulai sesi fokus ${widget.minutes} menit sekarang? Deteksi '
                'sensor bisa keliru, jadi sesi baru dimulai jika kamu setuju.',
              ),
              const SizedBox(height: AppSpacing.xs),
              Text(
                'Ditutup otomatis dalam $left dtk',
                style: theme.textTheme.bodySmall,
              ),
              const SizedBox(height: AppSpacing.md),
              Row(
                children: <Widget>[
                  Expanded(
                    child: AppButton(
                      label: 'Tidak sekarang',
                      variant: AppButtonVariant.outline,
                      expand: true,
                      onPressed: c.decline,
                    ),
                  ),
                  const SizedBox(width: AppSpacing.md),
                  Expanded(
                    child: AppButton(
                      label: 'Mulai fokus',
                      expand: true,
                      onPressed: c.accept,
                    ),
                  ),
                ],
              ),
            ],
          ),
        ),
      ),
    );
  }
}

class _AutoFocusCard extends ConsumerWidget {
  const _AutoFocusCard({required this.state});

  final AutoFocusState state;

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final bool idle = ref.watch(
      pomodoroControllerProvider.select((PomodoroView v) => v.timer.isIdle),
    );
    final String subtitle = switch (state.availability) {
      SensorAvailability.unsupported =>
        'Tidak didukung di platform ini.',
      SensorAvailability.unavailable =>
        'Accelerometer tidak terdeteksi di perangkat ini.',
      _ when !state.enabled =>
        'Telungkupkan ponsel saat timer siap untuk ditawari sesi fokus.',
      _ when !idle => 'Aktif · sensor dijeda selama sesi berjalan.',
      _ when state.listening => 'Aktif · menunggu ponsel ditelungkupkan.',
      _ => 'Aktif · sensor hanya dibaca saat halaman ini terbuka.',
    };
    final bool supported =
        state.availability != SensorAvailability.unsupported &&
            state.availability != SensorAvailability.unavailable;
    return Card(
      margin: EdgeInsets.zero,
      child: Column(
        children: <Widget>[
          SettingsTile.toggle(
            icon: Icons.screen_rotation_alt_rounded,
            title: 'Focus Otomatis',
            subtitle: subtitle,
            value: state.enabled,
            enabled: supported || state.enabled,
            disabledReason: subtitle,
            onChanged: (bool v) =>
                ref.read(autoFocusControllerProvider.notifier).setEnabled(v),
          ),
          if (state.enabled && supported)
            Padding(
              padding: const EdgeInsets.fromLTRB(
                AppSpacing.lg,
                0,
                AppSpacing.lg,
                AppSpacing.md,
              ),
              child: Text(
                'Getar singkat memberi tahu saat tawaran muncul. Data sensor '
                'tidak disimpan.',
                style: Theme.of(context).textTheme.bodySmall!.copyWith(
                      color: context.appColors.textSecondary,
                    ),
              ),
            ),
        ],
      ),
    );
  }
}

class _HabitCard extends ConsumerWidget {
  const _HabitCard();

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final List<HabitProgress> list =
        ref.watch(habitProgressProvider).value ?? const <HabitProgress>[];
    final List<HabitProgress> today =
        list.where((HabitProgress p) => p.isTargetToday).toList();
    final int done = today.where((HabitProgress p) => p.doneToday).length;
    return Card(
      margin: EdgeInsets.zero,
      child: SettingsTile.navigation(
        icon: Icons.repeat_rounded,
        title: 'Habit Tracker',
        subtitle: list.isEmpty
            ? 'Bangun kebiasaan kecil setiap hari'
            : '$done/${today.length} hari ini',
        onTap: () => context.push(AppRoutes.habits),
      ),
    );
  }
}

class _GameCard extends ConsumerWidget {
  const _GameCard();

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final LocalBox scores = ref.watch(localDatabaseProvider).gameScores;
    final Object? best = scores.getJson('best')?['score'];
    return Card(
      margin: EdgeInsets.zero,
      child: SettingsTile.navigation(
        icon: Icons.sports_esports_outlined,
        title: 'Balance Focus Game',
        subtitle: 'Latih keseimbangan & konsentrasi',
        trailingText: best is num ? 'Terbaik ${best.toInt()}' : null,
        onTap: () => context.push(AppRoutes.focusGame),
      ),
    );
  }
}

/// Banner kecil untuk dipakai halaman lain bila timer berjalan.
class RunningTimerBanner extends ConsumerWidget {
  const RunningTimerBanner({super.key});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final PomodoroView v = ref.watch(pomodoroControllerProvider);
    if (v.timer.isIdle) {
      return const SizedBox.shrink();
    }
    return StatusBanner(
      type: StatusBannerType.info,
      title: v.timer.mode.label,
      message: 'tersisa ${formatClock(v.remainingSeconds)}.',
      actionLabel: 'Buka Focus',
      onAction: () => context.go(AppRoutes.focus),
    );
  }
}
