import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../../../../theme/app_tokens.dart';
import '../../domain/pomodoro_engine.dart';
import '../pomodoro_controller.dart';

/// Pengaturan durasi Pomodoro (hanya saat timer idle).
Future<void> showPomodoroSettingsSheet(
  BuildContext context,
  WidgetRef ref,
  PomodoroSettings current,
) async {
  final PomodoroSettings? next = await showModalBottomSheet<PomodoroSettings>(
    context: context,
    showDragHandle: true,
    isScrollControlled: true,
    builder: (BuildContext context) => _SettingsSheet(initial: current),
  );
  if (next != null) {
    await ref.read(pomodoroControllerProvider.notifier).updateSettings(next);
  }
}

class _SettingsSheet extends StatefulWidget {
  const _SettingsSheet({required this.initial});

  final PomodoroSettings initial;

  @override
  State<_SettingsSheet> createState() => _SettingsSheetState();
}

class _SettingsSheetState extends State<_SettingsSheet> {
  late PomodoroSettings _s = widget.initial;

  Widget _stepper(
    String label,
    int value,
    String unit,
    ValueChanged<int> onChanged, {
    int min = PomodoroSettings.minMinutes,
    int max = PomodoroSettings.maxMinutes,
    int step = 1,
  }) {
    return ListTile(
      contentPadding: EdgeInsets.zero,
      title: Text(label),
      subtitle: Text('$value $unit'),
      trailing: Row(
        mainAxisSize: MainAxisSize.min,
        children: <Widget>[
          IconButton(
            tooltip: 'Kurangi $label',
            onPressed: value > min ? () => onChanged(value - step) : null,
            icon: const Icon(Icons.remove_circle_outline_rounded),
          ),
          IconButton(
            tooltip: 'Tambah $label',
            onPressed: value < max ? () => onChanged(value + step) : null,
            icon: const Icon(Icons.add_circle_outline_rounded),
          ),
        ],
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return SafeArea(
      child: Padding(
        padding: const EdgeInsets.fromLTRB(
          AppSpacing.lg,
          0,
          AppSpacing.lg,
          AppSpacing.lg,
        ),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: <Widget>[
            Text('Durasi Pomodoro',
                style: Theme.of(context).textTheme.titleLarge),
            const SizedBox(height: AppSpacing.sm),
            _stepper('Fokus', _s.focusMinutes, 'menit', (int v) {
              setState(() => _s = _s.copyWith(focusMinutes: v));
            }, step: 5, min: 5),
            _stepper('Istirahat pendek', _s.shortBreakMinutes, 'menit',
                (int v) {
              setState(() => _s = _s.copyWith(shortBreakMinutes: v));
            }),
            _stepper('Istirahat panjang', _s.longBreakMinutes, 'menit',
                (int v) {
              setState(() => _s = _s.copyWith(longBreakMinutes: v));
            }, step: 5, min: 5),
            _stepper(
              'Istirahat panjang setiap',
              _s.sessionsBeforeLongBreak,
              'sesi fokus',
              (int v) {
                setState(() => _s = _s.copyWith(sessionsBeforeLongBreak: v));
              },
              min: 2,
              max: 8,
            ),
            const SizedBox(height: AppSpacing.md),
            Row(
              children: <Widget>[
                Expanded(
                  child: OutlinedButton(
                    onPressed: () =>
                        setState(() => _s = const PomodoroSettings()),
                    child: const Text('Kembalikan 25/5/15'),
                  ),
                ),
                const SizedBox(width: AppSpacing.md),
                Expanded(
                  child: FilledButton(
                    onPressed: () => Navigator.of(context).pop(_s),
                    child: const Text('Simpan'),
                  ),
                ),
              ],
            ),
          ],
        ),
      ),
    );
  }
}
