import 'dart:async';

import 'package:flutter/foundation.dart';
import 'package:flutter/services.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../../../core/notifications/notification_service.dart';
import '../../auth/application/auth_providers.dart';
import '../data/focus_repository.dart';
import '../domain/focus_session.dart';
import '../domain/pomodoro_engine.dart';

/// Tampilan timer untuk UI.
@immutable
class PomodoroView {
  const PomodoroView({
    required this.timer,
    required this.settings,
    required this.remainingSeconds,
    this.justFinished,
  });

  final TimerState timer;
  final PomodoroSettings settings;
  final int remainingSeconds;

  /// Diisi sesaat setelah sesi berakhir (untuk banner/umpan balik).
  final PomodoroMode? justFinished;

  double get progress {
    final int planned = timer.plannedSeconds;
    return planned == 0 ? 0 : 1 - remainingSeconds / planned;
  }

  /// "Sesi 3 dari 4" (urutan sesi fokus dalam siklus).
  int get cycleIndex =>
      (timer.completedFocusCount % settings.sessionsBeforeLongBreak) + 1;

  PomodoroView copyWith({
    TimerState? timer,
    PomodoroSettings? settings,
    int? remainingSeconds,
    PomodoroMode? justFinished,
    bool clearJustFinished = false,
  }) {
    return PomodoroView(
      timer: timer ?? this.timer,
      settings: settings ?? this.settings,
      remainingSeconds: remainingSeconds ?? this.remainingSeconds,
      justFinished:
          clearJustFinished ? null : (justFinished ?? this.justFinished),
    );
  }
}

/// Timer Pomodoro (keep-alive: tidak berhenti saat pindah tab, FR-023).
///
/// Waktu dihitung dari jam dinding dan status disimpan di Hive setiap
/// transisi, sehingga tetap benar setelah background atau ditutup paksa.
/// Notifikasi "sesi selesai" dijadwalkan saat timer mulai/lanjut dan
/// dibatalkan saat jeda/reset.
class PomodoroController extends Notifier<PomodoroView> {
  late final FocusRepository _repo = ref.read(focusRepositoryProvider);
  late final NotificationService _notifications =
      ref.read(notificationServiceProvider);
  Timer? _ticker;

  DateTime _now() => ref.read(clockProvider)();

  @override
  PomodoroView build() {
    ref.onDispose(() => _ticker?.cancel());
    final PomodoroSettings settings = _repo.loadSettings();
    TimerState timer = _repo.loadTimer();
    final DateTime now = _now();

    if (PomodoroEngine.isFinished(timer, now)) {
      // Selesai saat aplikasi tertutup: catat dengan waktu berakhir teoretis.
      final (TimerState next, CompletedRun run) =
          PomodoroEngine.complete(timer, now, settings);
      timer = next;
      unawaited(_record(run));
      unawaited(_repo.saveTimer(timer));
    }
    if (timer.isRunning) {
      _startTicker();
    }
    return PomodoroView(
      timer: timer,
      settings: settings,
      remainingSeconds: timer.remainingSeconds(now),
    );
  }

  Future<void> _record(CompletedRun run) async {
    try {
      await _repo.record(run);
    } catch (error) {
      debugPrint('Sesi fokus gagal dicatat: $error');
    }
  }

  void _startTicker() {
    _ticker?.cancel();
    _ticker = Timer.periodic(const Duration(seconds: 1), (_) => _tick());
  }

  void _stopTicker() {
    _ticker?.cancel();
    _ticker = null;
  }

  void _tick() {
    final DateTime now = _now();
    if (PomodoroEngine.isFinished(state.timer, now)) {
      unawaited(_finish());
      return;
    }
    state = state.copyWith(remainingSeconds: state.timer.remainingSeconds(now));
  }

  /// Dipanggil saat aplikasi kembali aktif agar tampilan langsung benar.
  void refresh() {
    if (state.timer.isRunning) {
      _tick();
    }
  }

  Future<void> _apply(TimerState next, {bool notify = true}) async {
    state = state.copyWith(
      timer: next,
      remainingSeconds: next.remainingSeconds(_now()),
      clearJustFinished: true,
    );
    await _repo.saveTimer(next);
    if (next.isRunning) {
      _startTicker();
      if (notify) {
        await _scheduleEndNotification(next);
      }
    } else {
      _stopTicker();
      await _notifications.cancel(kPomodoroNotificationId);
    }
  }

  Future<void> _scheduleEndNotification(TimerState timer) async {
    final DateTime? endsAt = timer.endsAt;
    if (endsAt == null) {
      return;
    }
    try {
      await _notifications.cancel(kPomodoroNotificationId);
      if (!await _notifications.areEnabled()) {
        return;
      }
      await _notifications.schedule(
        id: kPomodoroNotificationId,
        title: timer.mode == PomodoroMode.focus
            ? 'Sesi fokus selesai'
            : 'Waktu istirahat habis',
        body: timer.mode == PomodoroMode.focus
            ? 'Kerja bagus! Saatnya istirahat sejenak.'
            : 'Siap lanjut fokus?',
        at: endsAt.toLocal(),
        channel: NotificationChannel.focus,
        payload: 'focus',
      );
    } catch (error) {
      debugPrint('Notifikasi Pomodoro gagal dijadwalkan: $error');
    }
  }

  // ---- Aksi pengguna ------------------------------------------------------

  void selectMode(PomodoroMode mode) {
    unawaited(_apply(
      PomodoroEngine.selectMode(state.timer, mode, state.settings),
    ));
  }

  Future<void> start({String? taskId}) async {
    if (!state.timer.isIdle) {
      return;
    }
    // Minta izin notifikasi sekali agar akhir sesi tetap terasa saat di
    // background. Penolakan tidak menghalangi timer.
    if (_notifications.isSupported && !await _notifications.areEnabled()) {
      await _notifications.requestPermission();
    }
    await _apply(PomodoroEngine.start(state.timer, _now(), taskId: taskId));
  }

  Future<void> pause() => _apply(PomodoroEngine.pause(state.timer, _now()));

  Future<void> resume() => _apply(PomodoroEngine.resume(state.timer, _now()));

  Future<void> reset() async {
    final (TimerState next, CompletedRun? cancelled) =
        PomodoroEngine.reset(state.timer, _now(), state.settings);
    if (cancelled != null) {
      await _record(cancelled);
    }
    await _apply(next);
  }

  /// Melewati sesi berjalan tanpa mencatatnya sebagai selesai.
  Future<void> skip() async {
    final PomodoroMode current = state.timer.mode;
    await reset();
    selectMode(
      current == PomodoroMode.focus
          ? PomodoroMode.shortBreak
          : PomodoroMode.focus,
    );
  }

  void setTask(String? taskId) {
    unawaited(_apply(
      taskId == null
          ? state.timer.copyWith(clearTaskId: true)
          : state.timer.copyWith(taskId: taskId),
      notify: false,
    ));
  }

  Future<void> updateSettings(PomodoroSettings settings) async {
    await _repo.saveSettings(settings);
    state = state.copyWith(settings: settings);
    if (state.timer.isIdle) {
      await _apply(
        state.timer.copyWith(plannedSeconds: settings.secondsFor(state.timer.mode)),
      );
    }
  }

  Future<void> _finish() async {
    final (TimerState next, CompletedRun run) =
        PomodoroEngine.complete(state.timer, _now(), state.settings);
    _stopTicker();
    await _record(run);
    await _repo.saveTimer(next);
    // Notifikasi terjadwal untuk saat ini tidak perlu lagi karena pengguna
    // sedang melihat aplikasi.
    await _notifications.cancel(kPomodoroNotificationId);
    unawaited(HapticFeedback.mediumImpact().catchError((Object _) {}));
    state = PomodoroView(
      timer: next,
      settings: state.settings,
      remainingSeconds: next.remainingSeconds(_now()),
      justFinished: run.mode,
    );
  }

  void dismissFinished() {
    state = state.copyWith(clearJustFinished: true);
  }
}

final NotifierProvider<PomodoroController, PomodoroView>
    pomodoroControllerProvider =
    NotifierProvider<PomodoroController, PomodoroView>(PomodoroController.new);
