import 'package:flutter/foundation.dart';

import '../../../core/sync/sync_entity.dart';
import '../../../core/utils/date_only.dart';

/// Mode Pomodoro (check `focus_sessions.mode`).
enum PomodoroMode {
  focus('focus', 'Fokus'),
  shortBreak('short_break', 'Istirahat pendek'),
  longBreak('long_break', 'Istirahat panjang');

  const PomodoroMode(this.sql, this.label);

  final String sql;
  final String label;

  static PomodoroMode parse(Object? value) => PomodoroMode.values.firstWhere(
        (PomodoroMode m) => m.sql == value || m.name == value,
        orElse: () => PomodoroMode.focus,
      );
}

enum FocusSessionStatus {
  completed,
  cancelled;

  static FocusSessionStatus parse(Object? value) =>
      value == 'cancelled' ? cancelled : completed;
}

/// Riwayat satu sesi (tabel `public.focus_sessions`, append-only).
@immutable
class FocusSession implements SyncEntity<FocusSession> {
  const FocusSession({
    required this.id,
    required this.userId,
    required this.mode,
    required this.plannedSeconds,
    required this.actualSeconds,
    required this.startedAt,
    required this.status,
    required this.createdAt,
    required this.updatedAt,
    this.taskId,
    this.endedAt,
    this.deletedAt,
    this.syncInfo = const SyncInfo(),
  });

  static const SyncTableSpec spec = SyncTableSpec(
    table: 'focus_sessions',
    boxName: 'focus_sessions',
    pkColumns: <String>['id'],
  );

  final String id;
  final String userId;
  final String? taskId;
  final PomodoroMode mode;
  final int plannedSeconds;
  final int actualSeconds;
  final DateTime startedAt;
  final DateTime? endedAt;
  final FocusSessionStatus status;
  final DateTime createdAt;
  @override
  final DateTime updatedAt;
  @override
  final DateTime? deletedAt;
  @override
  final SyncInfo syncInfo;

  @override
  String get localKey => id;

  bool get isCompletedFocus =>
      mode == PomodoroMode.focus && status == FocusSessionStatus.completed;

  static FocusSession fromJson(Map<String, dynamic> json) {
    final Object? planned = json['planned_seconds'];
    final Object? actual = json['actual_seconds'];
    return FocusSession(
      id: json['id'] as String,
      userId: json['user_id'] as String,
      taskId: json['task_id'] as String?,
      mode: PomodoroMode.parse(json['mode']),
      plannedSeconds: planned is num ? planned.toInt() : 0,
      actualSeconds: actual is num ? actual.toInt() : 0,
      startedAt: parseTimestamp(json['started_at'])?.toUtc() ??
          readUpdatedAt(json),
      endedAt: parseTimestamp(json['ended_at'])?.toUtc(),
      status: FocusSessionStatus.parse(json['status']),
      createdAt:
          parseTimestamp(json['created_at'])?.toUtc() ?? readUpdatedAt(json),
      updatedAt: readUpdatedAt(json),
      deletedAt: parseTimestamp(json['deleted_at'])?.toUtc(),
      syncInfo: SyncInfo.fromJson(json),
    );
  }

  @override
  Map<String, dynamic> toRow() => <String, dynamic>{
        'id': id,
        'user_id': userId,
        'task_id': taskId,
        'mode': mode.sql,
        'planned_seconds': plannedSeconds,
        'actual_seconds': actualSeconds,
        'started_at': startedAt.toUtc().toIso8601String(),
        'ended_at': endedAt?.toUtc().toIso8601String(),
        'status': status.name,
        'created_at': createdAt.toUtc().toIso8601String(),
        'deleted_at': deletedAt?.toUtc().toIso8601String(),
      };

  @override
  FocusSession withSync(SyncInfo info, {DateTime? updatedAt}) => FocusSession(
        id: id,
        userId: userId,
        taskId: taskId,
        mode: mode,
        plannedSeconds: plannedSeconds,
        actualSeconds: actualSeconds,
        startedAt: startedAt,
        endedAt: endedAt,
        status: status,
        createdAt: createdAt,
        updatedAt: updatedAt ?? this.updatedAt,
        deletedAt: deletedAt,
        syncInfo: info,
      );
}

/// Statistik fokus (FR-024).
@immutable
class FocusStats {
  const FocusStats({
    required this.todaySessions,
    required this.todayMinutes,
    required this.weekMinutes,
  });

  final int todaySessions;
  final int todayMinutes;

  /// Menit fokus Senin…Minggu minggu ini (7 nilai).
  final List<int> weekMinutes;

  int get weekTotal => weekMinutes.fold(0, (int a, int b) => a + b);

  static FocusStats of(Iterable<FocusSession> sessions, DateTime now) {
    final DateTime weekStart = DateOnly.startOfWeek(now);
    final List<int> week = List<int>.filled(7, 0);
    int todaySessions = 0;
    int todaySeconds = 0;
    for (final FocusSession s in sessions) {
      if (!s.isCompletedFocus || s.deletedAt != null) {
        continue;
      }
      final DateTime local = s.startedAt.toLocal();
      if (DateOnly.isSameDay(local, now)) {
        todaySessions++;
        todaySeconds += s.actualSeconds;
      }
      final int index = DateOnly.of(local).difference(weekStart).inDays;
      if (index >= 0 && index < 7) {
        week[index] += s.actualSeconds ~/ 60;
      }
    }
    return FocusStats(
      todaySessions: todaySessions,
      todayMinutes: todaySeconds ~/ 60,
      weekMinutes: week,
    );
  }
}
