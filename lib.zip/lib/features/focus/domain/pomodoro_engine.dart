import 'package:flutter/foundation.dart';

import '../../../core/utils/date_only.dart';
import 'focus_session.dart';

enum TimerStatus { idle, running, paused }

/// Durasi Pomodoro yang dapat diatur (prompt implementasi final §D; Tahap 1
/// default 25/5/15 dengan istirahat panjang setiap 4 sesi fokus).
@immutable
class PomodoroSettings {
  const PomodoroSettings({
    this.focusMinutes = 25,
    this.shortBreakMinutes = 5,
    this.longBreakMinutes = 15,
    this.sessionsBeforeLongBreak = 4,
  });

  static const int minMinutes = 1;
  static const int maxMinutes = 120;

  final int focusMinutes;
  final int shortBreakMinutes;
  final int longBreakMinutes;
  final int sessionsBeforeLongBreak;

  int secondsFor(PomodoroMode mode) => switch (mode) {
        PomodoroMode.focus => focusMinutes * 60,
        PomodoroMode.shortBreak => shortBreakMinutes * 60,
        PomodoroMode.longBreak => longBreakMinutes * 60,
      };

  int minutesFor(PomodoroMode mode) => secondsFor(mode) ~/ 60;

  PomodoroSettings copyWith({
    int? focusMinutes,
    int? shortBreakMinutes,
    int? longBreakMinutes,
    int? sessionsBeforeLongBreak,
  }) {
    int clamp(int v) => v.clamp(minMinutes, maxMinutes);
    return PomodoroSettings(
      focusMinutes: clamp(focusMinutes ?? this.focusMinutes),
      shortBreakMinutes: clamp(shortBreakMinutes ?? this.shortBreakMinutes),
      longBreakMinutes: clamp(longBreakMinutes ?? this.longBreakMinutes),
      sessionsBeforeLongBreak:
          (sessionsBeforeLongBreak ?? this.sessionsBeforeLongBreak).clamp(2, 8),
    );
  }

  Map<String, dynamic> toJson() => <String, dynamic>{
        'focus': focusMinutes,
        'short': shortBreakMinutes,
        'long': longBreakMinutes,
        'cycle': sessionsBeforeLongBreak,
      };

  static PomodoroSettings fromJson(Map<String, dynamic>? json) {
    if (json == null) {
      return const PomodoroSettings();
    }
    int read(String k, int d) {
      final Object? v = json[k];
      return v is num ? v.toInt() : d;
    }

    return const PomodoroSettings().copyWith(
      focusMinutes: read('focus', 25),
      shortBreakMinutes: read('short', 5),
      longBreakMinutes: read('long', 15),
      sessionsBeforeLongBreak: read('cycle', 4),
    );
  }

  @override
  bool operator ==(Object other) =>
      other is PomodoroSettings &&
      other.focusMinutes == focusMinutes &&
      other.shortBreakMinutes == shortBreakMinutes &&
      other.longBreakMinutes == longBreakMinutes &&
      other.sessionsBeforeLongBreak == sessionsBeforeLongBreak;

  @override
  int get hashCode => Object.hash(
        focusMinutes,
        shortBreakMinutes,
        longBreakMinutes,
        sessionsBeforeLongBreak,
      );
}

/// Status timer yang disimpan di box `timer_state` (Tahap 2 §6.2). Waktu
/// dihitung dari jam dinding, bukan dari jumlah tick, sehingga tetap akurat
/// setelah aplikasi di background atau ditutup paksa (FR-023, NFR-012).
@immutable
class TimerState {
  const TimerState({
    this.mode = PomodoroMode.focus,
    this.status = TimerStatus.idle,
    this.plannedSeconds = 25 * 60,
    this.startedAt,
    this.pausedAt,
    this.accumulatedPausedSeconds = 0,
    this.completedFocusCount = 0,
    this.taskId,
    this.cycleDate,
  });

  final PomodoroMode mode;
  final TimerStatus status;
  final int plannedSeconds;

  /// Saat sesi pertama kali dimulai (UTC).
  final DateTime? startedAt;
  final DateTime? pausedAt;
  final int accumulatedPausedSeconds;

  /// Jumlah sesi fokus selesai dalam siklus saat ini (reset tiap hari).
  final int completedFocusCount;

  /// Tugas yang sedang dikerjakan (opsional, `focus_sessions.task_id`).
  final String? taskId;

  /// Tanggal siklus (yyyy-MM-dd) untuk mereset hitungan setiap hari.
  final String? cycleDate;

  bool get isRunning => status == TimerStatus.running;
  bool get isIdle => status == TimerStatus.idle;

  int elapsedSeconds(DateTime now) {
    final DateTime? start = startedAt;
    if (start == null) {
      return 0;
    }
    final DateTime until =
        status == TimerStatus.paused ? (pausedAt ?? now) : now;
    final int elapsed =
        until.difference(start).inSeconds - accumulatedPausedSeconds;
    return elapsed.clamp(0, plannedSeconds);
  }

  int remainingSeconds(DateTime now) =>
      isIdle ? plannedSeconds : plannedSeconds - elapsedSeconds(now);

  /// Saat timer berakhir bila terus berjalan.
  DateTime? get endsAt {
    final DateTime? start = startedAt;
    if (start == null || status != TimerStatus.running) {
      return null;
    }
    return start.add(
      Duration(seconds: plannedSeconds + accumulatedPausedSeconds),
    );
  }

  TimerState copyWith({
    PomodoroMode? mode,
    TimerStatus? status,
    int? plannedSeconds,
    DateTime? startedAt,
    bool clearStartedAt = false,
    DateTime? pausedAt,
    bool clearPausedAt = false,
    int? accumulatedPausedSeconds,
    int? completedFocusCount,
    String? taskId,
    bool clearTaskId = false,
    String? cycleDate,
  }) {
    return TimerState(
      mode: mode ?? this.mode,
      status: status ?? this.status,
      plannedSeconds: plannedSeconds ?? this.plannedSeconds,
      startedAt: clearStartedAt ? null : (startedAt ?? this.startedAt),
      pausedAt: clearPausedAt ? null : (pausedAt ?? this.pausedAt),
      accumulatedPausedSeconds:
          accumulatedPausedSeconds ?? this.accumulatedPausedSeconds,
      completedFocusCount: completedFocusCount ?? this.completedFocusCount,
      taskId: clearTaskId ? null : (taskId ?? this.taskId),
      cycleDate: cycleDate ?? this.cycleDate,
    );
  }

  Map<String, dynamic> toJson() => <String, dynamic>{
        'mode': mode.sql,
        'status': status.name,
        'planned_seconds': plannedSeconds,
        'started_at': startedAt?.toUtc().toIso8601String(),
        'paused_at': pausedAt?.toUtc().toIso8601String(),
        'paused_seconds': accumulatedPausedSeconds,
        'completed_focus': completedFocusCount,
        'task_id': taskId,
        'cycle_date': cycleDate,
      };

  static TimerState fromJson(Map<String, dynamic>? json) {
    if (json == null) {
      return const TimerState();
    }
    int read(String k, int d) {
      final Object? v = json[k];
      return v is num ? v.toInt() : d;
    }

    return TimerState(
      mode: PomodoroMode.parse(json['mode']),
      status: TimerStatus.values.firstWhere(
        (TimerStatus s) => s.name == json['status'],
        orElse: () => TimerStatus.idle,
      ),
      plannedSeconds: read('planned_seconds', 25 * 60),
      startedAt: parseTimestamp(json['started_at'])?.toUtc(),
      pausedAt: parseTimestamp(json['paused_at'])?.toUtc(),
      accumulatedPausedSeconds: read('paused_seconds', 0),
      completedFocusCount: read('completed_focus', 0),
      taskId: json['task_id'] as String?,
      cycleDate: json['cycle_date'] as String?,
    );
  }

  @override
  bool operator ==(Object other) =>
      other is TimerState && _jsonEq(other.toJson(), toJson());

  @override
  int get hashCode => Object.hashAll(toJson().values);
}

bool _jsonEq(Map<String, dynamic> a, Map<String, dynamic> b) {
  if (a.length != b.length) {
    return false;
  }
  for (final String k in a.keys) {
    if (a[k] != b[k]) {
      return false;
    }
  }
  return true;
}

/// Hasil penyelesaian sesi.
@immutable
class CompletedRun {
  const CompletedRun({
    required this.mode,
    required this.plannedSeconds,
    required this.actualSeconds,
    required this.startedAt,
    required this.endedAt,
    required this.status,
    this.taskId,
  });

  final PomodoroMode mode;
  final int plannedSeconds;
  final int actualSeconds;
  final DateTime startedAt;
  final DateTime endedAt;
  final FocusSessionStatus status;
  final String? taskId;
}

/// Logika Pomodoro murni (Tahap 2 §4: `pomodoro_engine.dart`).
abstract final class PomodoroEngine {
  /// Sesi fokus yang dibatalkan baru dicatat bila sudah berjalan selama ini.
  static const int minCancelledSecondsToRecord = 60;

  static TimerState _rollCycle(TimerState s, DateTime now) {
    final String today = DateOnly.format(now.toLocal());
    if (s.cycleDate == today) {
      return s;
    }
    return s.copyWith(completedFocusCount: 0, cycleDate: today);
  }

  /// Memilih mode saat idle; durasi mengikuti [settings].
  static TimerState selectMode(
    TimerState s,
    PomodoroMode mode,
    PomodoroSettings settings,
  ) {
    if (!s.isIdle) {
      return s;
    }
    return s.copyWith(mode: mode, plannedSeconds: settings.secondsFor(mode));
  }

  static TimerState start(TimerState s, DateTime now, {String? taskId}) {
    if (!s.isIdle) {
      return s;
    }
    return _rollCycle(s, now).copyWith(
      status: TimerStatus.running,
      startedAt: now.toUtc(),
      clearPausedAt: true,
      accumulatedPausedSeconds: 0,
      taskId: taskId,
    );
  }

  static TimerState pause(TimerState s, DateTime now) {
    if (s.status != TimerStatus.running) {
      return s;
    }
    return s.copyWith(status: TimerStatus.paused, pausedAt: now.toUtc());
  }

  static TimerState resume(TimerState s, DateTime now) {
    final DateTime? pausedAt = s.pausedAt;
    if (s.status != TimerStatus.paused || pausedAt == null) {
      return s;
    }
    final int paused = now.toUtc().difference(pausedAt).inSeconds;
    return s.copyWith(
      status: TimerStatus.running,
      clearPausedAt: true,
      accumulatedPausedSeconds: s.accumulatedPausedSeconds + paused,
    );
  }

  static bool isFinished(TimerState s, DateTime now) =>
      s.isRunning && s.remainingSeconds(now) <= 0;

  /// Reset ke idle. Mengembalikan catatan "dibatalkan" bila sesi fokus sudah
  /// berjalan cukup lama, agar tetap tercatat jujur (bukan "selesai").
  static (TimerState, CompletedRun?) reset(
    TimerState s,
    DateTime now,
    PomodoroSettings settings,
  ) {
    CompletedRun? cancelled;
    final DateTime? start = s.startedAt;
    final int elapsed = s.elapsedSeconds(now);
    if (!s.isIdle &&
        start != null &&
        s.mode == PomodoroMode.focus &&
        elapsed >= minCancelledSecondsToRecord) {
      cancelled = CompletedRun(
        mode: s.mode,
        plannedSeconds: s.plannedSeconds,
        actualSeconds: elapsed,
        startedAt: start,
        endedAt: now.toUtc(),
        status: FocusSessionStatus.cancelled,
        taskId: s.taskId,
      );
    }
    final TimerState idle = s.copyWith(
      status: TimerStatus.idle,
      plannedSeconds: settings.secondsFor(s.mode),
      clearStartedAt: true,
      clearPausedAt: true,
      accumulatedPausedSeconds: 0,
    );
    return (idle, cancelled);
  }

  /// Mode berikutnya: setiap N sesi fokus → istirahat panjang.
  static PomodoroMode nextMode(
    PomodoroMode finished,
    int completedFocusCount,
    PomodoroSettings settings,
  ) {
    if (finished != PomodoroMode.focus) {
      return PomodoroMode.focus;
    }
    return completedFocusCount % settings.sessionsBeforeLongBreak == 0
        ? PomodoroMode.longBreak
        : PomodoroMode.shortBreak;
  }

  /// Menyelesaikan sesi yang waktunya habis. `endedAt` = waktu berakhir
  /// teoretis (bukan saat aplikasi dibuka lagi) agar riwayat akurat.
  static (TimerState, CompletedRun) complete(
    TimerState s,
    DateTime now,
    PomodoroSettings settings,
  ) {
    final DateTime start = s.startedAt ?? now.toUtc();
    final DateTime ended = s.endsAt ?? now.toUtc();
    final int count = s.mode == PomodoroMode.focus
        ? s.completedFocusCount + 1
        : s.completedFocusCount;
    final PomodoroMode next = nextMode(s.mode, count, settings);
    final CompletedRun run = CompletedRun(
      mode: s.mode,
      plannedSeconds: s.plannedSeconds,
      actualSeconds: s.plannedSeconds,
      startedAt: start,
      endedAt: ended,
      status: FocusSessionStatus.completed,
      taskId: s.taskId,
    );
    final TimerState idle = TimerState(
      mode: next,
      plannedSeconds: settings.secondsFor(next),
      completedFocusCount:
          next == PomodoroMode.focus && s.mode == PomodoroMode.longBreak
              ? 0
              : count,
      taskId: s.taskId,
      cycleDate: s.cycleDate,
    );
    return (idle, run);
  }
}
