import 'package:flutter/foundation.dart';

import '../../planner/domain/task_priority.dart';

/// Kegiatan yang ingin dijadwalkan (kontrak §11.2 Tahap 2).
@immutable
class ScheduleActivity {
  const ScheduleActivity({
    required this.ref,
    required this.title,
    required this.durationMinutes,
    this.priority = TaskPriority.medium,
    this.deadline,
    this.taskId,
  });

  /// ID lokal kegiatan di permintaan ini (bukan ID tugas, bukan ID pengguna).
  final String ref;
  final String title;
  final int durationMinutes;
  final TaskPriority priority;

  /// Tenggat (waktu lokal). `null` = tanpa tenggat.
  final DateTime? deadline;

  /// Diisi bila kegiatan diambil dari tugas Planner yang sudah ada. TIDAK
  /// dikirim ke server.
  final String? taskId;

  ScheduleActivity copyWith({
    String? title,
    int? durationMinutes,
    TaskPriority? priority,
    DateTime? deadline,
    bool clearDeadline = false,
  }) {
    return ScheduleActivity(
      ref: ref,
      title: title ?? this.title,
      durationMinutes: durationMinutes ?? this.durationMinutes,
      priority: priority ?? this.priority,
      deadline: clearDeadline ? null : (deadline ?? this.deadline),
      taskId: taskId,
    );
  }
}

/// Rentang waktu kosong (waktu lokal).
@immutable
class TimeWindow {
  const TimeWindow({required this.start, required this.end});

  final DateTime start;
  final DateTime end;

  int get minutes => end.difference(start).inMinutes;

  bool contains(DateTime s, DateTime e) => !s.isBefore(start) && !e.isAfter(end);
}

@immutable
class ScheduleRequest {
  const ScheduleRequest({
    required this.timezone,
    required this.activities,
    required this.windows,
  });

  /// Nama zona IANA perangkat, mis. `Asia/Jakarta`.
  final String timezone;
  final List<ScheduleActivity> activities;
  final List<TimeWindow> windows;

  /// Body untuk Edge Function. Hanya judul, durasi, prioritas, tenggat, dan
  /// jendela waktu — tanpa email/ID pengguna (Tahap 2 §15, NFR-007).
  Map<String, dynamic> toJson() => <String, dynamic>{
        'timezone': timezone,
        'activities': <Map<String, dynamic>>[
          for (final ScheduleActivity a in activities)
            <String, dynamic>{
              'ref': a.ref,
              'title': a.title,
              'duration_minutes': a.durationMinutes,
              'priority': a.priority.value,
              'deadline': a.deadline == null ? null : isoWithOffset(a.deadline!),
            },
        ],
        'available_windows': <Map<String, dynamic>>[
          for (final TimeWindow w in windows)
            <String, dynamic>{
              'start': isoWithOffset(w.start),
              'end': isoWithOffset(w.end),
            },
        ],
      };
}

enum SuggestionSource {
  /// Dari Edge Function + LLM.
  llm,

  /// `RuleBasedScheduler` di perangkat — BUKAN AI.
  ruleBased;

  String get label => switch (this) {
        SuggestionSource.llm => 'Dihasilkan AI',
        SuggestionSource.ruleBased => 'Berbasis aturan (bukan AI)',
      };
}

@immutable
class ScheduledItem {
  const ScheduledItem({
    required this.ref,
    required this.title,
    required this.start,
    required this.end,
  });

  final String ref;
  final String title;
  final DateTime start;
  final DateTime end;

  int get minutes => end.difference(start).inMinutes;
}

@immutable
class ScheduleSuggestion {
  const ScheduleSuggestion({
    required this.source,
    required this.items,
    this.unscheduled = const <String>[],
    this.note,
  });

  final SuggestionSource source;
  final List<ScheduledItem> items;

  /// `ref` kegiatan yang tidak muat.
  final List<String> unscheduled;
  final String? note;

  /// Membaca respons sukses Edge Function. Melempar [FormatException] bila
  /// bentuknya salah.
  static ScheduleSuggestion fromJson(Map<String, dynamic> json) {
    final Object? items = json['items'];
    if (items is! List) {
      throw const FormatException('items tidak ada');
    }
    return ScheduleSuggestion(
      source: SuggestionSource.llm,
      items: <ScheduledItem>[
        for (final Object? raw in items)
          if (raw is Map)
            ScheduledItem(
              ref: raw['ref'] as String,
              title: raw['title'] as String,
              start: DateTime.parse(raw['start'] as String).toLocal(),
              end: DateTime.parse(raw['end'] as String).toLocal(),
            ),
      ],
      unscheduled: <String>[
        for (final Object? r in (json['unscheduled'] as List?) ?? <Object?>[])
          if (r is String) r else if (r is Map && r['ref'] is String) r['ref'] as String,
      ],
      note: json['note'] as String?,
    );
  }
}

/// ISO-8601 dengan offset lokal, mis. `2026-10-21T13:00:00+07:00`.
String isoWithOffset(DateTime local) {
  final DateTime t = local.toLocal();
  String two(int n) => n.toString().padLeft(2, '0');
  final Duration off = t.timeZoneOffset;
  final String sign = off.isNegative ? '-' : '+';
  final int mins = off.inMinutes.abs();
  return '${t.year.toString().padLeft(4, '0')}-${two(t.month)}-${two(t.day)}'
      'T${two(t.hour)}:${two(t.minute)}:${two(t.second)}'
      '$sign${two(mins ~/ 60)}:${two(mins % 60)}';
}
