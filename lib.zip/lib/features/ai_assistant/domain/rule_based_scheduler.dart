import 'schedule_models.dart';

/// Penyusun jadwal cadangan berbasis ATURAN (FR-031). **Bukan LLM/AI.**
///
/// 1. Urutkan: tenggat terdekat → prioritas tertinggi → durasi terpendek.
/// 2. Isi slot paling awal yang muat (greedy earliest-fit) di jendela waktu,
///    tanpa melewati tenggat dan tanpa tumpang tindih.
/// 3. Yang tidak muat → `unscheduled`.
abstract final class RuleBasedScheduler {
  /// Jeda antar-kegiatan (menit) supaya jadwal tidak terlalu rapat.
  static const int gapMinutes = 0;

  static ScheduleSuggestion schedule(
    ScheduleRequest request, {
    required DateTime now,
  }) {
    final List<ScheduleActivity> ordered =
        List<ScheduleActivity>.of(request.activities)
          ..sort((ScheduleActivity a, ScheduleActivity b) {
            final DateTime far = DateTime(9999);
            final int byDeadline =
                (a.deadline ?? far).compareTo(b.deadline ?? far);
            if (byDeadline != 0) {
              return byDeadline;
            }
            final int byPriority = b.priority.value.compareTo(a.priority.value);
            if (byPriority != 0) {
              return byPriority;
            }
            return a.durationMinutes.compareTo(b.durationMinutes);
          });

    // Slot kosong, dimulai tidak lebih awal dari sekarang (dibulatkan ke
    // 5 menit berikutnya).
    final DateTime earliest = _roundUp(now);
    final List<TimeWindow> free = <TimeWindow>[
      for (final TimeWindow w in List<TimeWindow>.of(request.windows)
        ..sort((TimeWindow a, TimeWindow b) => a.start.compareTo(b.start)))
        if (w.end.isAfter(earliest))
          TimeWindow(
            start: w.start.isBefore(earliest) ? earliest : w.start,
            end: w.end,
          ),
    ];

    final List<ScheduledItem> items = <ScheduledItem>[];
    final List<String> unscheduled = <String>[];

    for (final ScheduleActivity a in ordered) {
      final Duration need = Duration(minutes: a.durationMinutes);
      int? slotIndex;
      for (int i = 0; i < free.length; i++) {
        final DateTime start = free[i].start;
        final DateTime end = start.add(need);
        final bool fits = !end.isAfter(free[i].end);
        final bool beforeDeadline =
            a.deadline == null || !end.isAfter(a.deadline!);
        if (fits && beforeDeadline) {
          slotIndex = i;
          break;
        }
      }
      if (slotIndex == null) {
        unscheduled.add(a.ref);
        continue;
      }
      final TimeWindow slot = free[slotIndex];
      final DateTime end = slot.start.add(need);
      items.add(ScheduledItem(
        ref: a.ref,
        title: a.title.trim(),
        start: slot.start,
        end: end,
      ));
      final DateTime nextStart = end.add(const Duration(minutes: gapMinutes));
      if (nextStart.isBefore(slot.end)) {
        free[slotIndex] = TimeWindow(start: nextStart, end: slot.end);
      } else {
        free.removeAt(slotIndex);
      }
    }

    items.sort((ScheduledItem a, ScheduledItem b) => a.start.compareTo(b.start));
    return ScheduleSuggestion(
      source: SuggestionSource.ruleBased,
      items: items,
      unscheduled: unscheduled,
      note: 'Disusun dengan aturan sederhana: tenggat terdekat dan prioritas '
          'tertinggi ditempatkan lebih awal.',
    );
  }

  static DateTime _roundUp(DateTime t) {
    final int extra = (5 - t.minute % 5) % 5;
    final DateTime base = DateTime(t.year, t.month, t.day, t.hour, t.minute);
    return (extra == 0 && t.second == 0 && t.millisecond == 0)
        ? base
        : base.add(Duration(minutes: extra == 0 ? 5 : extra));
  }
}
