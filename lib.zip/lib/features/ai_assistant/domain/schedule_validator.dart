import 'schedule_models.dart';

/// Batas permintaan (Tahap 2 §11.2, angka usulan `[PERLU DIKONFIRMASI]`).
/// Batas yang sama diterapkan di Edge Function.
abstract final class ScheduleLimits {
  static const int maxActivities = 20;
  static const int minDuration = 5;
  static const int maxDuration = 480;
  static const int maxTitle = 100;
  static const int maxWindows = 14;
  static const Duration horizon = Duration(days: 7);
}

abstract final class ScheduleValidator {
  /// Pesan error pertama untuk ditampilkan, atau `null` bila valid.
  static String? validateRequest(ScheduleRequest r, {required DateTime now}) {
    if (r.activities.isEmpty) {
      return 'Tambahkan minimal satu kegiatan.';
    }
    if (r.activities.length > ScheduleLimits.maxActivities) {
      return 'Maksimal ${ScheduleLimits.maxActivities} kegiatan sekali susun.';
    }
    for (final ScheduleActivity a in r.activities) {
      final String title = a.title.trim();
      if (title.isEmpty) {
        return 'Setiap kegiatan perlu judul.';
      }
      if (title.length > ScheduleLimits.maxTitle) {
        return 'Judul "${title.substring(0, 20)}…" terlalu panjang '
            '(maks ${ScheduleLimits.maxTitle} karakter).';
      }
      if (a.durationMinutes < ScheduleLimits.minDuration ||
          a.durationMinutes > ScheduleLimits.maxDuration) {
        return 'Durasi "$title" harus ${ScheduleLimits.minDuration}–'
            '${ScheduleLimits.maxDuration} menit.';
      }
    }
    if (r.windows.isEmpty) {
      return 'Tambahkan minimal satu waktu tersedia.';
    }
    if (r.windows.length > ScheduleLimits.maxWindows) {
      return 'Maksimal ${ScheduleLimits.maxWindows} rentang waktu.';
    }
    final DateTime limit = now.add(ScheduleLimits.horizon);
    for (final TimeWindow w in r.windows) {
      if (!w.end.isAfter(w.start)) {
        return 'Jam selesai harus setelah jam mulai.';
      }
      if (!w.end.isAfter(now)) {
        return 'Ada waktu tersedia yang sudah lewat.';
      }
      if (w.start.isAfter(limit)) {
        return 'Waktu tersedia maksimal 7 hari ke depan.';
      }
    }
    return null;
  }

  /// Memeriksa usulan (dari LLM atau aturan) terhadap permintaan:
  /// di dalam jendela, tidak tumpang tindih, durasi sama, `ref` dikenal,
  /// tidak melewati tenggat, tidak di masa lalu. Mengembalikan alasan gagal
  /// atau `null` bila lolos.
  static String? checkSuggestion(
    ScheduleRequest r,
    ScheduleSuggestion s, {
    required DateTime now,
  }) {
    final Map<String, ScheduleActivity> byRef = <String, ScheduleActivity>{
      for (final ScheduleActivity a in r.activities) a.ref: a,
    };
    final Set<String> seen = <String>{};
    for (final ScheduledItem item in s.items) {
      final ScheduleActivity? a = byRef[item.ref];
      if (a == null) {
        return 'ref tidak dikenal: ${item.ref}';
      }
      if (!seen.add(item.ref)) {
        return 'kegiatan ganda: ${item.ref}';
      }
      if (item.minutes != a.durationMinutes) {
        return 'durasi berbeda: ${item.ref}';
      }
      if (!r.windows.any((TimeWindow w) => w.contains(item.start, item.end))) {
        return 'di luar waktu tersedia: ${item.ref}';
      }
      final DateTime? deadline = a.deadline;
      if (deadline != null && item.end.isAfter(deadline)) {
        return 'melewati tenggat: ${item.ref}';
      }
      if (item.start.isBefore(now.subtract(const Duration(minutes: 1)))) {
        return 'di masa lalu: ${item.ref}';
      }
    }
    final List<ScheduledItem> sorted = List<ScheduledItem>.of(s.items)
      ..sort((ScheduledItem a, ScheduledItem b) => a.start.compareTo(b.start));
    for (int i = 1; i < sorted.length; i++) {
      if (sorted[i].start.isBefore(sorted[i - 1].end)) {
        return 'tumpang tindih: ${sorted[i - 1].ref} & ${sorted[i].ref}';
      }
    }
    return null;
  }
}
