import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:go_router/go_router.dart';
import 'package:intl/intl.dart';

import '../../../app/router/routes.dart';
import '../../../core/utils/app_date_format.dart';
import '../../../core/utils/date_only.dart';
import '../../../core/widgets/app_button.dart';
import '../../../core/widgets/empty_state.dart';
import '../../../core/widgets/page_container.dart';
import '../../../core/widgets/priority_badge.dart';
import '../../../core/widgets/status_banner.dart';
import '../../../theme/app_colors.dart';
import '../../../theme/app_tokens.dart';
import '../../planner/data/task_repository.dart';
import '../../planner/domain/task.dart';
import '../data/ai_repository.dart';
import '../domain/schedule_models.dart';
import 'ai_controller.dart';

/// S-41 Tinjau usulan (FR-032): tidak ada yang berubah sampai pengguna
/// menekan Simpan.
class AiReviewPage extends ConsumerWidget {
  const AiReviewPage({super.key});

  Future<void> _save(BuildContext context, WidgetRef ref) async {
    final ScaffoldMessengerState messenger = ScaffoldMessenger.of(context);
    final ApplyResult r =
        await ref.read(aiControllerProvider.notifier).applyApproved();
    messenger.showSnackBar(
      SnackBar(
        content: Text(
          '${r.created + r.updated} kegiatan disimpan ke Planner'
          '${r.updated > 0 ? ' (${r.updated} tugas lama diperbarui)' : ''}'
          '${r.skipped > 0 ? '; ${r.skipped} dilewati' : ''}.',
        ),
      ),
    );
    if (context.mounted) {
      context.go(AppRoutes.planner);
    }
  }

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final AiState state = ref.watch(aiControllerProvider);
    final SuggestionResult? result = state.result;
    final ThemeData theme = Theme.of(context);

    if (result == null) {
      return Scaffold(
        appBar: AppBar(title: const Text('Tinjau usulan')),
        body: EmptyState(
          icon: Icons.auto_awesome_outlined,
          title: 'Belum ada usulan',
          message: 'Susun usulan dari halaman AI Assistant.',
          primaryActionLabel: 'Kembali',
          onPrimaryAction: () => context.go(AppRoutes.ai),
        ),
      );
    }

    final ScheduleSuggestion s = result.suggestion;
    final List<Task> tasks =
        ref.watch(tasksProvider).value ?? const <Task>[];
    final Map<String, ScheduleActivity> byRef = <String, ScheduleActivity>{
      for (final ScheduleActivity a in state.activities) a.ref: a,
    };
    final Map<String, List<ScheduledItem>> byDay =
        <String, List<ScheduledItem>>{};
    for (final ScheduledItem i in s.items) {
      byDay.putIfAbsent(DateOnly.format(i.start), () => <ScheduledItem>[]).add(i);
    }
    final int count = s.items
        .where((ScheduledItem i) => state.approved.contains(i.ref))
        .length;

    return Scaffold(
      appBar: AppBar(title: const Text('Tinjau usulan')),
      body: SafeArea(
        child: ListView(
          padding: const EdgeInsets.only(bottom: AppSpacing.xxl),
          children: <Widget>[
            PageContainer(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.stretch,
                children: <Widget>[
                  const SizedBox(height: AppSpacing.lg),
                  StatusBanner(
                    type: s.source == SuggestionSource.llm
                        ? StatusBannerType.info
                        : StatusBannerType.warning,
                    title: s.source.label,
                    message: '— periksa sebelum menyimpan. Tidak ada yang '
                        'berubah sampai kamu menekan Simpan.',
                  ),
                  if (result.fallbackReason != null) ...<Widget>[
                    const SizedBox(height: AppSpacing.sm),
                    StatusBanner(
                      type: StatusBannerType.offline,
                      message: '${result.fallbackReason!.userReason} Usulan '
                          'ini disusun dengan aturan, bukan AI.',
                      actionLabel: 'Coba AI lagi',
                      onAction: () async {
                        await ref.read(aiControllerProvider.notifier).submit();
                      },
                    ),
                  ],
                  if (s.note != null) ...<Widget>[
                    const SizedBox(height: AppSpacing.md),
                    Text(
                      'Catatan: ${s.note}',
                      style: theme.textTheme.bodyMedium!.copyWith(
                        color: context.appColors.textSecondary,
                      ),
                    ),
                  ],
                  for (final MapEntry<String, List<ScheduledItem>> day
                      in byDay.entries) ...<Widget>[
                    const SizedBox(height: AppSpacing.lg),
                    Text(
                      DateFormat('EEEE, d MMM', 'id_ID')
                          .format(DateOnly.parse(day.key))
                          .toUpperCase(),
                      style: theme.textTheme.labelMedium!.copyWith(
                        color: context.appColors.textSecondary,
                        letterSpacing: 0.8,
                      ),
                    ),
                    const SizedBox(height: AppSpacing.sm),
                    for (final ScheduledItem item in day.value)
                      _ItemTile(
                        item: item,
                        activity: byRef[item.ref],
                        conflict: conflictFor(
                          item,
                          tasks,
                          ignoreTaskId: byRef[item.ref]?.taskId,
                        ),
                        selected: state.approved.contains(item.ref),
                        onToggle: () => ref
                            .read(aiControllerProvider.notifier)
                            .toggleApproved(item.ref),
                      ),
                  ],
                  const SizedBox(height: AppSpacing.md),
                  if (s.unscheduled.isEmpty)
                    Text(
                      'Semua kegiatan muat dalam waktu tersedia.',
                      style: theme.textTheme.bodyMedium,
                    )
                  else
                    StatusBanner(
                      type: StatusBannerType.warning,
                      title: 'Tidak muat:',
                      message: s.unscheduled
                          .map((String r) => byRef[r]?.title ?? r)
                          .join(', '),
                    ),
                  const SizedBox(height: AppSpacing.xl),
                  Row(
                    children: <Widget>[
                      Expanded(
                        child: AppButton(
                          label: 'Tolak semua',
                          variant: AppButtonVariant.outline,
                          expand: true,
                          onPressed: () {
                            ref.read(aiControllerProvider.notifier).rejectAll();
                            context.canPop()
                                ? context.pop()
                                : context.go(AppRoutes.ai);
                          },
                        ),
                      ),
                      const SizedBox(width: AppSpacing.md),
                      Expanded(
                        child: AppButton(
                          label: 'Simpan $count ke Planner',
                          expand: true,
                          onPressed: count == 0 ? null : () => _save(context, ref),
                        ),
                      ),
                    ],
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}

class _ItemTile extends StatelessWidget {
  const _ItemTile({
    required this.item,
    required this.activity,
    required this.conflict,
    required this.selected,
    required this.onToggle,
  });

  final ScheduledItem item;
  final ScheduleActivity? activity;
  final Task? conflict;
  final bool selected;
  final VoidCallback onToggle;

  @override
  Widget build(BuildContext context) {
    final ThemeData theme = Theme.of(context);
    final Task? clash = conflict;
    final ScheduleActivity? a = activity;
    return Card(
      margin: const EdgeInsets.only(bottom: AppSpacing.sm),
      child: CheckboxListTile(
        value: selected,
        onChanged: (_) => onToggle(),
        controlAffinity: ListTileControlAffinity.leading,
        title: Text(item.title),
        subtitle: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: <Widget>[
            Text(
              '${AppDateFormat.time(item.start)} – ${AppDateFormat.time(item.end)}'
              ' · ${item.minutes} m'
              '${a?.taskId == null ? '' : ' · perbarui jadwal tugas yang ada'}',
            ),
            if (clash != null)
              Padding(
                padding: const EdgeInsets.only(top: 2),
                child: Row(
                  children: <Widget>[
                    Icon(Icons.warning_amber_rounded,
                        size: 16, color: context.appColors.warning),
                    const SizedBox(width: 4),
                    Expanded(
                      child: Text(
                        'Bentrok: ${clash.title} '
                        '${AppDateFormat.time(clash.dueMoment)}',
                        style: theme.textTheme.bodySmall!.copyWith(
                          color: context.appColors.onWarningContainer,
                        ),
                      ),
                    ),
                  ],
                ),
              ),
          ],
        ),
        secondary: a == null ? null : PriorityBadge(priority: a.priority),
      ),
    );
  }
}
