import 'package:flutter/material.dart';

import '../../../../core/utils/app_date_format.dart';
import '../../../../core/utils/date_only.dart';
import '../../../../theme/app_tokens.dart';
import '../../../planner/domain/task_priority.dart';
import '../../domain/schedule_models.dart';
import '../../domain/schedule_validator.dart';

/// Lembar ubah kegiatan (judul, durasi, prioritas, tenggat).
Future<ScheduleActivity?> showActivitySheet(
  BuildContext context,
  ScheduleActivity initial,
) {
  return showModalBottomSheet<ScheduleActivity>(
    context: context,
    isScrollControlled: true,
    showDragHandle: true,
    builder: (BuildContext context) => Padding(
      padding:
          EdgeInsets.only(bottom: MediaQuery.viewInsetsOf(context).bottom),
      child: _ActivitySheet(initial: initial),
    ),
  );
}

class _ActivitySheet extends StatefulWidget {
  const _ActivitySheet({required this.initial});

  final ScheduleActivity initial;

  @override
  State<_ActivitySheet> createState() => _ActivitySheetState();
}

class _ActivitySheetState extends State<_ActivitySheet> {
  late final TextEditingController _title =
      TextEditingController(text: widget.initial.title);
  late final TextEditingController _custom = TextEditingController(
    text: widget.initial.durationMinutes.toString(),
  );
  late int _duration = widget.initial.durationMinutes;
  late TaskPriority _priority = widget.initial.priority;
  late DateTime? _deadline = widget.initial.deadline;
  late bool _customDuration =
      !const <int>[30, 60, 90].contains(widget.initial.durationMinutes);
  String? _error;

  @override
  void dispose() {
    _title.dispose();
    _custom.dispose();
    super.dispose();
  }

  Future<void> _pickDeadline() async {
    final DateTime now = DateTime.now();
    final DateTime? date = await showDatePicker(
      context: context,
      initialDate: _deadline ?? now,
      firstDate: DateOnly.of(now),
      lastDate: DateOnly.addDays(now, 60),
      helpText: 'Tenggat kegiatan',
    );
    if (date == null || !mounted) {
      return;
    }
    final TimeOfDay? time = await showTimePicker(
      context: context,
      initialTime: const TimeOfDay(hour: 23, minute: 59),
      helpText: 'Jam tenggat',
    );
    final TimeOfDay t = time ?? const TimeOfDay(hour: 23, minute: 59);
    setState(() => _deadline =
        DateTime(date.year, date.month, date.day, t.hour, t.minute));
  }

  void _save() {
    final String title = _title.text.trim();
    final int duration =
        _customDuration ? (int.tryParse(_custom.text.trim()) ?? 0) : _duration;
    String? error;
    if (title.isEmpty) {
      error = 'Judul kegiatan wajib diisi.';
    } else if (title.length > ScheduleLimits.maxTitle) {
      error = 'Judul maksimal ${ScheduleLimits.maxTitle} karakter.';
    } else if (duration < ScheduleLimits.minDuration ||
        duration > ScheduleLimits.maxDuration) {
      error = 'Durasi ${ScheduleLimits.minDuration}–'
          '${ScheduleLimits.maxDuration} menit.';
    }
    if (error != null) {
      setState(() => _error = error);
      return;
    }
    Navigator.of(context).pop(
      widget.initial.copyWith(
        title: title,
        durationMinutes: duration,
        priority: _priority,
        deadline: _deadline,
        clearDeadline: _deadline == null,
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final ThemeData theme = Theme.of(context);
    final DateTime? deadline = _deadline;
    return SafeArea(
      child: SingleChildScrollView(
        padding: const EdgeInsets.fromLTRB(
          AppSpacing.lg,
          0,
          AppSpacing.lg,
          AppSpacing.lg,
        ),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.stretch,
          mainAxisSize: MainAxisSize.min,
          children: <Widget>[
            Text('Kegiatan', style: theme.textTheme.titleLarge),
            const SizedBox(height: AppSpacing.md),
            TextField(
              controller: _title,
              autofocus: widget.initial.title.isEmpty,
              maxLength: ScheduleLimits.maxTitle,
              textCapitalization: TextCapitalization.sentences,
              decoration: const InputDecoration(
                labelText: 'Judul kegiatan',
                counterText: '',
              ),
            ),
            const SizedBox(height: AppSpacing.md),
            Text('Durasi', style: theme.textTheme.labelLarge),
            const SizedBox(height: AppSpacing.sm),
            Wrap(
              spacing: AppSpacing.sm,
              children: <Widget>[
                for (final int m in const <int>[30, 60, 90])
                  ChoiceChip(
                    label: Text('${m}m'),
                    selected: !_customDuration && _duration == m,
                    onSelected: (_) => setState(() {
                      _customDuration = false;
                      _duration = m;
                    }),
                  ),
                ChoiceChip(
                  label: const Text('Lainnya'),
                  selected: _customDuration,
                  onSelected: (_) => setState(() => _customDuration = true),
                ),
              ],
            ),
            if (_customDuration) ...<Widget>[
              const SizedBox(height: AppSpacing.sm),
              TextField(
                controller: _custom,
                keyboardType: TextInputType.number,
                decoration: const InputDecoration(
                  labelText: 'Durasi (menit)',
                  suffixText: 'menit',
                ),
              ),
            ],
            const SizedBox(height: AppSpacing.md),
            Text('Prioritas', style: theme.textTheme.labelLarge),
            const SizedBox(height: AppSpacing.sm),
            SegmentedButton<TaskPriority>(
              segments: <ButtonSegment<TaskPriority>>[
                for (final TaskPriority p in TaskPriority.values)
                  ButtonSegment<TaskPriority>(value: p, label: Text(p.label)),
              ],
              selected: <TaskPriority>{_priority},
              onSelectionChanged: (Set<TaskPriority> s) =>
                  setState(() => _priority = s.first),
            ),
            const SizedBox(height: AppSpacing.md),
            ListTile(
              contentPadding: EdgeInsets.zero,
              leading: const Icon(Icons.flag_outlined),
              title: const Text('Tenggat'),
              subtitle: Text(
                deadline == null
                    ? 'Tanpa tenggat'
                    : '${AppDateFormat.shortDate(deadline)}, '
                        '${AppDateFormat.time(deadline)}',
              ),
              trailing: deadline == null
                  ? null
                  : IconButton(
                      tooltip: 'Hapus tenggat',
                      icon: const Icon(Icons.close_rounded),
                      onPressed: () => setState(() => _deadline = null),
                    ),
              onTap: _pickDeadline,
            ),
            if (_error != null)
              Text(
                _error!,
                style: theme.textTheme.bodySmall!
                    .copyWith(color: theme.colorScheme.error),
              ),
            const SizedBox(height: AppSpacing.md),
            FilledButton(onPressed: _save, child: const Text('Simpan kegiatan')),
          ],
        ),
      ),
    );
  }
}

/// Lembar ubah rentang waktu tersedia.
Future<TimeWindow?> showWindowSheet(BuildContext context, TimeWindow initial) {
  return showModalBottomSheet<TimeWindow>(
    context: context,
    showDragHandle: true,
    builder: (BuildContext context) => _WindowSheet(initial: initial),
  );
}

class _WindowSheet extends StatefulWidget {
  const _WindowSheet({required this.initial});

  final TimeWindow initial;

  @override
  State<_WindowSheet> createState() => _WindowSheetState();
}

class _WindowSheetState extends State<_WindowSheet> {
  late DateTime _day = DateOnly.of(widget.initial.start);
  late TimeOfDay _start = TimeOfDay.fromDateTime(widget.initial.start);
  late TimeOfDay _end = TimeOfDay.fromDateTime(widget.initial.end);
  String? _error;

  DateTime _at(TimeOfDay t) =>
      DateTime(_day.year, _day.month, _day.day, t.hour, t.minute);

  @override
  Widget build(BuildContext context) {
    final ThemeData theme = Theme.of(context);
    return SafeArea(
      child: Padding(
        padding: const EdgeInsets.fromLTRB(
          AppSpacing.lg,
          0,
          AppSpacing.lg,
          AppSpacing.lg,
        ),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: <Widget>[
            Text('Waktu tersedia', style: theme.textTheme.titleLarge),
            ListTile(
              contentPadding: EdgeInsets.zero,
              leading: const Icon(Icons.event_rounded),
              title: const Text('Tanggal'),
              subtitle: Text(AppDateFormat.shortDate(_day)),
              onTap: () async {
                final DateTime now = DateTime.now();
                final DateTime? d = await showDatePicker(
                  context: context,
                  initialDate: _day,
                  firstDate: DateOnly.of(now),
                  lastDate: DateOnly.addDays(now, 7),
                );
                if (d != null) {
                  setState(() => _day = DateOnly.of(d));
                }
              },
            ),
            Row(
              children: <Widget>[
                Expanded(
                  child: ListTile(
                    contentPadding: EdgeInsets.zero,
                    title: const Text('Mulai'),
                    subtitle: Text(_start.format(context)),
                    onTap: () async {
                      final TimeOfDay? t = await showTimePicker(
                        context: context,
                        initialTime: _start,
                      );
                      if (t != null) {
                        setState(() => _start = t);
                      }
                    },
                  ),
                ),
                Expanded(
                  child: ListTile(
                    contentPadding: EdgeInsets.zero,
                    title: const Text('Selesai'),
                    subtitle: Text(_end.format(context)),
                    onTap: () async {
                      final TimeOfDay? t = await showTimePicker(
                        context: context,
                        initialTime: _end,
                      );
                      if (t != null) {
                        setState(() => _end = t);
                      }
                    },
                  ),
                ),
              ],
            ),
            if (_error != null)
              Text(
                _error!,
                style: theme.textTheme.bodySmall!
                    .copyWith(color: theme.colorScheme.error),
              ),
            const SizedBox(height: AppSpacing.md),
            FilledButton(
              onPressed: () {
                final DateTime s = _at(_start);
                final DateTime e = _at(_end);
                if (!e.isAfter(s)) {
                  setState(() => _error = 'Jam selesai harus setelah jam mulai.');
                  return;
                }
                Navigator.of(context).pop(TimeWindow(start: s, end: e));
              },
              child: const Text('Simpan waktu'),
            ),
          ],
        ),
      ),
    );
  }
}
