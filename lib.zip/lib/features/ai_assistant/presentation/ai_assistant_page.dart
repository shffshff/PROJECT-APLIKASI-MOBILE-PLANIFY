import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:go_router/go_router.dart';

import '../../../app/router/routes.dart';
import '../../../core/utils/app_date_format.dart';
import '../../../core/widgets/app_button.dart';
import '../../../core/widgets/page_container.dart';
import '../../../core/widgets/priority_badge.dart';
import '../../../core/widgets/section_header.dart';
import '../../../core/widgets/status_banner.dart';
import '../../../theme/app_colors.dart';
import '../../../theme/app_tokens.dart';
import '../../planner/data/task_repository.dart';
import '../../planner/domain/task.dart';
import '../data/ai_repository.dart';
import '../domain/schedule_models.dart';
import 'ai_controller.dart';
import 'widgets/ai_editors.dart';

/// S-40 AI Assistant (FR-029–031): percakapan singkat + penyusun kegiatan.
class AiAssistantPage extends ConsumerWidget {
  const AiAssistantPage({super.key});

  Future<void> _editActivity(
    BuildContext context,
    WidgetRef ref,
    ScheduleActivity activity,
  ) async {
    final ScheduleActivity? edited = await showActivitySheet(context, activity);
    if (edited != null) {
      ref.read(aiControllerProvider.notifier).upsertActivity(edited);
    }
  }

  Future<void> _importFromPlanner(BuildContext context, WidgetRef ref) async {
    final List<Task> open = ref
        .read(taskRepositoryProvider)
        .all()
        .where((Task t) => !t.isCompleted && !t.isOverdue(DateTime.now()))
        .toList()
      ..sort((Task a, Task b) => a.dueMoment.compareTo(b.dueMoment));
    if (open.isEmpty) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Belum ada tugas aktif di Planner.')),
      );
      return;
    }
    final Set<String>? picked = await showModalBottomSheet<Set<String>>(
      context: context,
      showDragHandle: true,
      isScrollControlled: true,
      builder: (BuildContext context) => _TaskPickerSheet(tasks: open),
    );
    if (picked != null && picked.isNotEmpty) {
      ref
          .read(aiControllerProvider.notifier)
          .importTasks(open.where((Task t) => picked.contains(t.id)));
    }
  }

  Future<void> _submit(BuildContext context, WidgetRef ref) async {
    final bool ok = await ref.read(aiControllerProvider.notifier).submit();
    if (ok && context.mounted) {
      context.push(AppRoutes.aiReview);
    }
  }

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final AiState state = ref.watch(aiControllerProvider);
    final AiController c = ref.read(aiControllerProvider.notifier);
    final bool configured = ref.watch(aiRepositoryProvider).isConfigured;
    final ThemeData theme = Theme.of(context);
    final bool over = state.totalMinutes > state.availableMinutes;

    return Scaffold(
      appBar: AppBar(
        title: Text('AI Assistant', style: theme.textTheme.headlineSmall),
      ),
      body: SafeArea(
        child: ListView(
          padding: const EdgeInsets.only(bottom: AppSpacing.xxl),
          children: <Widget>[
            PageContainer(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.stretch,
                children: <Widget>[
                  const SizedBox(height: AppSpacing.sm),
                  for (final AiMessage m in state.messages)
                    _Bubble(
                      message: m,
                      onAction: m.action != null && state.result != null
                          ? () => context.push(AppRoutes.aiReview)
                          : null,
                    ),
                  if (!configured) ...<Widget>[
                    const SizedBox(height: AppSpacing.sm),
                    const StatusBanner(
                      type: StatusBannerType.info,
                      title: 'Mode berbasis aturan.',
                      message: 'Backend AI belum terhubung, jadi usulan '
                          'disusun dengan aturan sederhana di perangkat '
                          '(bukan AI).',
                    ),
                  ],
                  const SizedBox(height: AppSpacing.lg),
                  const SectionHeader(title: '1 · Kegiatan'),
                  const SizedBox(height: AppSpacing.sm),
                  for (final ScheduleActivity a in state.activities)
                    Card(
                      margin: const EdgeInsets.only(bottom: AppSpacing.sm),
                      child: ListTile(
                        title: Text(a.title),
                        subtitle: Text(
                          '${a.durationMinutes} menit · '
                          '${a.deadline == null ? 'tanpa tenggat' : '${AppDateFormat.shortDate(a.deadline!)} ${AppDateFormat.time(a.deadline!)}'}'
                          '${a.taskId == null ? '' : ' · dari Planner'}',
                        ),
                        leading: PriorityBadge(priority: a.priority),
                        trailing: IconButton(
                          tooltip: 'Hapus kegiatan ${a.title}',
                          icon: const Icon(Icons.close_rounded),
                          onPressed: () => c.removeActivity(a.ref),
                        ),
                        onTap: () => _editActivity(context, ref, a),
                      ),
                    ),
                  Wrap(
                    spacing: AppSpacing.sm,
                    children: <Widget>[
                      TextButton.icon(
                        onPressed: () =>
                            _editActivity(context, ref, c.newActivity()),
                        icon: const Icon(Icons.add_rounded),
                        label: const Text('Tambah kegiatan'),
                      ),
                      TextButton.icon(
                        onPressed: () => _importFromPlanner(context, ref),
                        icon: const Icon(Icons.playlist_add_rounded),
                        label: const Text('Ambil dari Planner'),
                      ),
                    ],
                  ),
                  const SizedBox(height: AppSpacing.lg),
                  const SectionHeader(title: '2 · Waktu tersedia'),
                  const SizedBox(height: AppSpacing.sm),
                  for (int i = 0; i < state.windows.length; i++)
                    Card(
                      margin: const EdgeInsets.only(bottom: AppSpacing.sm),
                      child: ListTile(
                        leading: const Icon(Icons.schedule_rounded),
                        title: Text(AppDateFormat.shortDate(state.windows[i].start)),
                        subtitle: Text(
                          '${AppDateFormat.time(state.windows[i].start)} – '
                          '${AppDateFormat.time(state.windows[i].end)}',
                        ),
                        trailing: state.windows.length > 1
                            ? IconButton(
                                tooltip: 'Hapus waktu',
                                icon: const Icon(Icons.close_rounded),
                                onPressed: () => c.removeWindow(i),
                              )
                            : null,
                        onTap: () async {
                          final TimeWindow? w =
                              await showWindowSheet(context, state.windows[i]);
                          if (w != null) {
                            c.setWindow(i, w);
                          }
                        },
                      ),
                    ),
                  Align(
                    alignment: Alignment.centerLeft,
                    child: TextButton.icon(
                      onPressed: c.addWindow,
                      icon: const Icon(Icons.add_rounded),
                      label: const Text('Tambah waktu'),
                    ),
                  ),
                  const SizedBox(height: AppSpacing.md),
                  Text(
                    'Total kegiatan: ${formatMinutes(state.totalMinutes)} dari '
                    '${formatMinutes(state.availableMinutes)} tersedia',
                    style: theme.textTheme.titleSmall!.copyWith(
                      color: over ? theme.colorScheme.error : null,
                    ),
                  ),
                  if (over)
                    Text(
                      'Sebagian kegiatan mungkin tidak muat.',
                      style: theme.textTheme.bodySmall,
                    ),
                  const SizedBox(height: AppSpacing.md),
                  if (state.error != null) ...<Widget>[
                    StatusBanner(
                      type: StatusBannerType.warning,
                      message: state.error!,
                    ),
                    const SizedBox(height: AppSpacing.md),
                  ],
                  Text(
                    configured
                        ? 'Judul, durasi, prioritas, dan tenggat dikirim ke '
                            'layanan AI untuk menyusun usulan. Email dan ID '
                            'akunmu tidak ikut terkirim.'
                        : 'Data kegiatan diproses di perangkat ini.',
                    style: theme.textTheme.bodySmall!.copyWith(
                      color: context.appColors.textSecondary,
                    ),
                  ),
                  const SizedBox(height: AppSpacing.md),
                  AppButton(
                    label: 'Susun usulan',
                    icon: Icons.auto_awesome_rounded,
                    expand: true,
                    isLoading: state.status == AiStatus.loading,
                    onPressed: () => _submit(context, ref),
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}

class _Bubble extends StatelessWidget {
  const _Bubble({required this.message, this.onAction});

  final AiMessage message;
  final VoidCallback? onAction;

  @override
  Widget build(BuildContext context) {
    final ThemeData theme = Theme.of(context);
    final ColorScheme scheme = theme.colorScheme;
    final bool user = message.fromUser;
    final String? action = message.action;
    return Align(
      alignment: user ? Alignment.centerRight : Alignment.centerLeft,
      child: ConstrainedBox(
        constraints: const BoxConstraints(maxWidth: 520),
        child: Container(
          margin: const EdgeInsets.only(bottom: AppSpacing.sm),
          padding: const EdgeInsets.all(AppSpacing.md),
          decoration: BoxDecoration(
            color: user ? scheme.primary : scheme.surfaceContainerHigh,
            borderRadius: BorderRadius.only(
              topLeft: const Radius.circular(AppRadius.lg),
              topRight: const Radius.circular(AppRadius.lg),
              bottomLeft: Radius.circular(user ? AppRadius.lg : 4),
              bottomRight: Radius.circular(user ? 4 : AppRadius.lg),
            ),
          ),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: <Widget>[
              Semantics(
                label: user ? 'Kamu' : 'Asisten',
                child: Text(
                  message.text,
                  style: theme.textTheme.bodyMedium!.copyWith(
                    color: user ? scheme.onPrimary : scheme.onSurface,
                  ),
                ),
              ),
              if (action != null && onAction != null)
                TextButton(onPressed: onAction, child: Text(action)),
            ],
          ),
        ),
      ),
    );
  }
}

class _TaskPickerSheet extends StatefulWidget {
  const _TaskPickerSheet({required this.tasks});

  final List<Task> tasks;

  @override
  State<_TaskPickerSheet> createState() => _TaskPickerSheetState();
}

class _TaskPickerSheetState extends State<_TaskPickerSheet> {
  final Set<String> _picked = <String>{};

  @override
  Widget build(BuildContext context) {
    return SafeArea(
      child: Column(
        mainAxisSize: MainAxisSize.min,
        crossAxisAlignment: CrossAxisAlignment.stretch,
        children: <Widget>[
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: AppSpacing.lg),
            child: Text(
              'Ambil dari Planner',
              style: Theme.of(context).textTheme.titleLarge,
            ),
          ),
          Flexible(
            child: ListView(
              shrinkWrap: true,
              children: <Widget>[
                for (final Task t in widget.tasks.take(30))
                  CheckboxListTile(
                    value: _picked.contains(t.id),
                    title: Text(t.title),
                    subtitle: Text(
                      'Tenggat ${AppDateFormat.shortDate(t.dueDate)}',
                    ),
                    onChanged: (bool? v) => setState(() {
                      v == true ? _picked.add(t.id) : _picked.remove(t.id);
                    }),
                  ),
              ],
            ),
          ),
          Padding(
            padding: const EdgeInsets.all(AppSpacing.lg),
            child: FilledButton(
              onPressed: () => Navigator.of(context).pop(_picked),
              child: Text('Tambahkan ${_picked.length} tugas'),
            ),
          ),
        ],
      ),
    );
  }
}
