import 'package:flutter/foundation.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:timezone/timezone.dart' as tz;

import '../../../core/utils/app_date_format.dart';
import '../../../core/utils/date_only.dart';
import '../../auth/application/auth_providers.dart';
import '../../planner/data/task_repository.dart';
import '../../planner/domain/task.dart';
import '../../planner/domain/task_validator.dart';
import '../data/ai_repository.dart';
import '../domain/schedule_models.dart';
import '../domain/schedule_validator.dart';

@immutable
class AiMessage {
  const AiMessage({required this.fromUser, required this.text, this.action});

  final bool fromUser;
  final String text;

  /// Label tombol (mis. "Tinjau usulan") bila pesan membawa hasil.
  final String? action;
}

enum AiStatus { editing, loading, reviewing }

@immutable
class AiState {
  const AiState({
    required this.activities,
    required this.windows,
    this.status = AiStatus.editing,
    this.result,
    this.approved = const <String>{},
    this.messages = const <AiMessage>[],
    this.error,
  });

  final List<ScheduleActivity> activities;
  final List<TimeWindow> windows;
  final AiStatus status;
  final SuggestionResult? result;

  /// `ref` yang dicentang pengguna di layar Tinjau.
  final Set<String> approved;
  final List<AiMessage> messages;
  final String? error;

  int get totalMinutes =>
      activities.fold(0, (int a, ScheduleActivity x) => a + x.durationMinutes);
  int get availableMinutes =>
      windows.fold(0, (int a, TimeWindow w) => a + w.minutes);

  AiState copyWith({
    List<ScheduleActivity>? activities,
    List<TimeWindow>? windows,
    AiStatus? status,
    SuggestionResult? result,
    bool clearResult = false,
    Set<String>? approved,
    List<AiMessage>? messages,
    String? error,
    bool clearError = false,
  }) {
    return AiState(
      activities: activities ?? this.activities,
      windows: windows ?? this.windows,
      status: status ?? this.status,
      result: clearResult ? null : (result ?? this.result),
      approved: approved ?? this.approved,
      messages: messages ?? this.messages,
      error: clearError ? null : (error ?? this.error),
    );
  }
}

/// Hasil menyimpan usulan ke Planner.
@immutable
class ApplyResult {
  const ApplyResult({required this.created, required this.updated, required this.skipped});

  final int created;
  final int updated;
  final int skipped;
}

/// Bentrok usulan dengan tugas yang sudah ada (jam tenggatnya jatuh di dalam
/// slot usulan).
Task? conflictFor(ScheduledItem item, Iterable<Task> tasks, {String? ignoreTaskId}) {
  for (final Task t in tasks) {
    if (t.isCompleted || t.isDeleted || t.dueTimeMinutes == null) {
      continue;
    }
    if (t.id == ignoreTaskId) {
      continue;
    }
    final DateTime due = t.dueMoment;
    if (!due.isBefore(item.start) && due.isBefore(item.end)) {
      return t;
    }
  }
  return null;
}

/// State AI Assistant (Tahap 2 §5.1: draf usulan hanya di memori).
/// Tidak ada yang masuk ke Planner sebelum pengguna menekan Simpan (FR-032).
class AiController extends Notifier<AiState> {
  int _seq = 0;

  DateTime _now() => ref.read(clockProvider)();

  String _nextRef() => 'a${++_seq}';

  @override
  AiState build() {
    final DateTime now = _now();
    return AiState(
      activities: const <ScheduleActivity>[],
      windows: <TimeWindow>[_defaultWindow(now)],
      messages: const <AiMessage>[
        AiMessage(
          fromUser: false,
          text: 'Halo! Ceritakan kegiatan yang ingin kamu kerjakan dan kapan '
              'kamu punya waktu luang. Aku akan menyusun usulan jadwal — kamu '
              'yang memutuskan apa yang masuk ke Planner.',
        ),
      ],
    );
  }

  /// Sisa hari ini (dibulatkan ke jam berikutnya) atau besok 09–12.
  static TimeWindow _defaultWindow(DateTime now) {
    final DateTime nextHour =
        DateTime(now.year, now.month, now.day, now.hour + 1);
    final DateTime endOfDay = DateTime(now.year, now.month, now.day, 21);
    if (nextHour.add(const Duration(hours: 1)).isBefore(endOfDay)) {
      final DateTime end = nextHour.add(const Duration(hours: 4));
      return TimeWindow(
        start: nextHour,
        end: end.isAfter(endOfDay) ? endOfDay : end,
      );
    }
    final DateTime tomorrow = DateOnly.addDays(now, 1);
    return TimeWindow(
      start: DateTime(tomorrow.year, tomorrow.month, tomorrow.day, 9),
      end: DateTime(tomorrow.year, tomorrow.month, tomorrow.day, 12),
    );
  }

  ScheduleActivity newActivity() => ScheduleActivity(
        ref: _nextRef(),
        title: '',
        durationMinutes: 60,
      );

  void upsertActivity(ScheduleActivity a) {
    final List<ScheduleActivity> list = List<ScheduleActivity>.of(state.activities);
    final int i = list.indexWhere((ScheduleActivity x) => x.ref == a.ref);
    if (i >= 0) {
      list[i] = a;
    } else {
      list.add(a);
    }
    state = state.copyWith(activities: list, clearError: true);
  }

  void removeActivity(String ref) => state = state.copyWith(
        activities: state.activities
            .where((ScheduleActivity a) => a.ref != ref)
            .toList(),
      );

  /// "Ambil dari Planner": tugas belum selesai menjadi kegiatan.
  void importTasks(Iterable<Task> tasks) {
    final Set<String> existing = state.activities
        .map((ScheduleActivity a) => a.taskId)
        .whereType<String>()
        .toSet();
    final List<ScheduleActivity> list = List<ScheduleActivity>.of(state.activities);
    for (final Task t in tasks) {
      if (existing.contains(t.id) || list.length >= ScheduleLimits.maxActivities) {
        continue;
      }
      list.add(ScheduleActivity(
        ref: _nextRef(),
        title: t.title,
        durationMinutes: 60,
        priority: t.priority,
        deadline: t.dueMoment,
        taskId: t.id,
      ));
    }
    state = state.copyWith(activities: list, clearError: true);
  }

  void setWindow(int index, TimeWindow w) {
    final List<TimeWindow> list = List<TimeWindow>.of(state.windows);
    if (index >= 0 && index < list.length) {
      list[index] = w;
    } else {
      list.add(w);
    }
    state = state.copyWith(windows: list, clearError: true);
  }

  void addWindow() {
    final TimeWindow last = state.windows.isEmpty
        ? _defaultWindow(_now())
        : state.windows.last;
    final DateTime next = DateOnly.addDays(last.start, 1);
    setWindow(
      -1,
      TimeWindow(
        start: DateTime(next.year, next.month, next.day, 9),
        end: DateTime(next.year, next.month, next.day, 12),
      ),
    );
  }

  void removeWindow(int index) {
    final List<TimeWindow> list = List<TimeWindow>.of(state.windows)
      ..removeAt(index);
    state = state.copyWith(windows: list);
  }

  static String _zoneName() {
    try {
      return tz.local.name;
    } catch (_) {
      return 'Asia/Jakarta';
    }
  }

  ScheduleRequest buildRequest() => ScheduleRequest(
        timezone: _zoneName(),
        activities: state.activities,
        windows: state.windows,
      );

  String _summary(ScheduleRequest r) {
    final int total = state.totalMinutes;
    return 'Susun ${r.activities.length} kegiatan '
        '(${formatMinutes(total)}) dalam ${r.windows.length} rentang waktu '
        '(${formatMinutes(state.availableMinutes)}).';
  }

  /// Menyusun usulan. `true` bila siap ditinjau.
  Future<bool> submit({bool forceRuleBased = false}) async {
    if (state.status == AiStatus.loading) {
      return false;
    }
    final ScheduleRequest request = buildRequest();
    final String? invalid =
        ScheduleValidator.validateRequest(request, now: _now());
    if (invalid != null) {
      state = state.copyWith(error: invalid);
      return false;
    }
    state = state.copyWith(
      status: AiStatus.loading,
      clearError: true,
      messages: <AiMessage>[
        ...state.messages,
        AiMessage(fromUser: true, text: _summary(request)),
      ],
    );
    final SuggestionResult result = await ref
        .read(aiRepositoryProvider)
        .suggest(request, forceRuleBased: forceRuleBased);
    if (!ref.mounted) {
      return false;
    }
    final List<Task> tasks = ref.read(taskRepositoryProvider).all();
    final Map<String, ScheduleActivity> byRef = <String, ScheduleActivity>{
      for (final ScheduleActivity a in request.activities) a.ref: a,
    };
    final Set<String> approved = <String>{
      for (final ScheduledItem i in result.suggestion.items)
        if (conflictFor(i, tasks, ignoreTaskId: byRef[i.ref]?.taskId) == null)
          i.ref,
    };
    final ScheduleSuggestion s = result.suggestion;
    final String head = result.fallbackReason == null
        ? 'Usulan dari AI siap.'
        : '${result.fallbackReason!.userReason} Aku memakai penyusun berbasis '
            'aturan (bukan AI) sebagai gantinya.';
    state = state.copyWith(
      status: AiStatus.reviewing,
      result: result,
      approved: approved,
      messages: <AiMessage>[
        ...state.messages,
        AiMessage(
          fromUser: false,
          text: '$head ${s.items.length} kegiatan terjadwal'
              '${s.unscheduled.isEmpty ? '' : ', ${s.unscheduled.length} tidak muat'}.',
          action: 'Tinjau usulan',
        ),
      ],
    );
    return true;
  }

  void toggleApproved(String ref) {
    final Set<String> set = Set<String>.of(state.approved);
    set.contains(ref) ? set.remove(ref) : set.add(ref);
    state = state.copyWith(approved: set);
  }

  /// Menolak semua: tidak ada yang disimpan (FR-032).
  void rejectAll() {
    state = state.copyWith(
      status: AiStatus.editing,
      clearResult: true,
      approved: const <String>{},
      messages: <AiMessage>[
        ...state.messages,
        const AiMessage(
          fromUser: false,
          text: 'Usulan ditolak. Tidak ada yang diubah di Planner.',
        ),
      ],
    );
  }

  /// Menyimpan item yang disetujui ke Planner.
  Future<ApplyResult> applyApproved() async {
    final SuggestionResult? result = state.result;
    if (result == null) {
      return const ApplyResult(created: 0, updated: 0, skipped: 0);
    }
    final TaskRepository repo = ref.read(taskRepositoryProvider);
    final Map<String, ScheduleActivity> byRef = <String, ScheduleActivity>{
      for (final ScheduleActivity a in state.activities) a.ref: a,
    };
    final TaskSource source = result.suggestion.source == SuggestionSource.llm
        ? TaskSource.aiLlm
        : TaskSource.ruleBased;
    final DateTime now = _now();
    int created = 0;
    int updated = 0;
    int skipped = 0;

    for (final ScheduledItem item in result.suggestion.items) {
      if (!state.approved.contains(item.ref)) {
        continue;
      }
      final ScheduleActivity? activity = byRef[item.ref];
      final int minutes = item.start.hour * 60 + item.start.minute;
      final String? dateError = TaskValidator.dueDate(
        item.start,
        now: now,
        isNew: true,
        dueTimeMinutes: minutes,
      );
      if (activity == null || dateError != null) {
        skipped++;
        continue;
      }
      final String slot =
          '${AppDateFormat.time(item.start)}–${AppDateFormat.time(item.end)}';
      final String? taskId = activity.taskId;
      final Task? existing = taskId == null ? null : repo.byId(taskId);
      if (existing != null) {
        await repo.update(
          existing,
          TaskDraft(
            title: existing.title,
            description: existing.description,
            dueDate: DateOnly.of(item.start),
            dueTimeMinutes: minutes,
            category: existing.category,
            priority: existing.priority,
            reminderAt: existing.reminderAt?.toLocal(),
            source: existing.source,
          ),
        );
        updated++;
      } else {
        await repo.create(TaskDraft(
          title: item.title,
          description: 'Dijadwalkan $slot (${source == TaskSource.aiLlm ? 'usulan AI' : 'usulan berbasis aturan'}).',
          dueDate: DateOnly.of(item.start),
          dueTimeMinutes: minutes,
          priority: activity.priority,
          source: source,
        ));
        created++;
      }
    }
    final int total = created + updated;
    state = state.copyWith(
      status: AiStatus.editing,
      clearResult: true,
      approved: const <String>{},
      activities: const <ScheduleActivity>[],
      messages: <AiMessage>[
        ...state.messages,
        AiMessage(
          fromUser: false,
          text: '$total kegiatan disimpan ke Planner'
              '${skipped == 0 ? '' : ' ($skipped dilewati karena waktunya sudah lewat)'}.',
        ),
      ],
    );
    return ApplyResult(created: created, updated: updated, skipped: skipped);
  }
}

/// Keep-alive: draf tidak hilang saat berpindah tab.
final NotifierProvider<AiController, AiState> aiControllerProvider =
    NotifierProvider<AiController, AiState>(AiController.new);

/// "3 j 15 m".
String formatMinutes(int minutes) {
  final int h = minutes ~/ 60;
  final int m = minutes % 60;
  if (h == 0) {
    return '$m m';
  }
  return m == 0 ? '$h j' : '$h j $m m';
}

