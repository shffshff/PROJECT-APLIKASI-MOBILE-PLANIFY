import 'dart:async';

import 'package:flutter/foundation.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:supabase_flutter/supabase_flutter.dart';

import '../../../core/config/supabase_bootstrap.dart';
import '../../../core/network/connectivity_source.dart';
import '../../auth/application/auth_providers.dart';
import '../domain/rule_based_scheduler.dart';
import '../domain/schedule_models.dart';
import '../domain/schedule_validator.dart';

/// Kode error kontrak `schedule-suggest` (Tahap 2 §11.2) + kondisi klien.
enum AiErrorCode {
  unavailable('AI_UNAVAILABLE'),
  invalidResponse('AI_INVALID_RESPONSE'),
  validation('VALIDATION'),
  rateLimited('RATE_LIMITED'),
  unauthorized('UNAUTHORIZED'),
  timeout('TIMEOUT'),
  offline('OFFLINE'),
  notConfigured('NOT_CONFIGURED');

  const AiErrorCode(this.wire);

  final String wire;

  static AiErrorCode parse(Object? v) => AiErrorCode.values.firstWhere(
        (AiErrorCode c) => c.wire == v,
        orElse: () => AiErrorCode.unavailable,
      );

  /// Alasan yang ditampilkan saat memakai fallback.
  String get userReason => switch (this) {
        AiErrorCode.unavailable => 'Layanan AI sedang tidak tersedia.',
        AiErrorCode.invalidResponse =>
          'Jawaban AI tidak lolos pemeriksaan jadwal.',
        AiErrorCode.validation => 'Permintaan ditolak karena datanya belum valid.',
        AiErrorCode.rateLimited =>
          'Batas permintaan AI tercapai. Coba lagi beberapa saat lagi.',
        AiErrorCode.unauthorized => 'Sesi tidak valid untuk memakai AI.',
        AiErrorCode.timeout => 'Layanan AI terlalu lama merespons.',
        AiErrorCode.offline => 'Perangkat sedang offline.',
        AiErrorCode.notConfigured =>
          'Backend AI belum dikonfigurasi di aplikasi ini.',
      };
}

class AiException implements Exception {
  const AiException(this.code);

  final AiErrorCode code;

  @override
  String toString() => 'AiException(${code.wire})';
}

/// Kontrak layanan AI. Implementasi nyata memanggil Supabase Edge Function;
/// secret LLM hanya ada di server (NFR-002).
abstract interface class AiScheduleService {
  Future<ScheduleSuggestion> suggest(ScheduleRequest request);
}

/// Memanggil Edge Function `schedule-suggest` dengan JWT pengguna.
class EdgeFunctionScheduleService implements AiScheduleService {
  EdgeFunctionScheduleService(this._client);

  final SupabaseClient _client;
  static const Duration timeout = Duration(seconds: 25);

  @override
  Future<ScheduleSuggestion> suggest(ScheduleRequest request) async {
    try {
      final FunctionResponse response = await _client.functions
          .invoke('schedule-suggest', body: request.toJson())
          .timeout(timeout);
      final Object? data = response.data;
      if (data is! Map<String, dynamic>) {
        throw const AiException(AiErrorCode.invalidResponse);
      }
      final Object? error = data['error'];
      if (error is Map) {
        throw AiException(AiErrorCode.parse(error['code']));
      }
      return ScheduleSuggestion.fromJson(data);
    } on AiException {
      rethrow;
    } on TimeoutException {
      throw const AiException(AiErrorCode.timeout);
    } on FunctionException catch (e) {
      final Object? details = e.details;
      if (details is Map && details['error'] is Map) {
        throw AiException(
          AiErrorCode.parse((details['error'] as Map)['code']),
        );
      }
      throw AiException(
        e.status == 401 ? AiErrorCode.unauthorized : AiErrorCode.unavailable,
      );
    } on FormatException {
      throw const AiException(AiErrorCode.invalidResponse);
    } catch (e) {
      debugPrint('schedule-suggest gagal: ${e.runtimeType}');
      throw const AiException(AiErrorCode.unavailable);
    }
  }
}

/// Hasil untuk UI: usulan + alasan bila memakai fallback.
@immutable
class SuggestionResult {
  const SuggestionResult({required this.suggestion, this.fallbackReason});

  final ScheduleSuggestion suggestion;

  /// Diisi bila AI tidak dipakai dan usulan berasal dari aturan.
  final AiErrorCode? fallbackReason;
}

/// AI dulu; bila gagal/offline/belum dikonfigurasi → `RuleBasedScheduler`.
/// Respons AI tetap diperiksa ulang di perangkat (pertahanan berlapis).
class AiRepository {
  AiRepository({
    required AiScheduleService? service,
    required ConnectivitySource connectivity,
    required DateTime Function() clock,
  })  : _service = service,
        _connectivity = connectivity,
        _clock = clock;

  final AiScheduleService? _service;
  final ConnectivitySource _connectivity;
  final DateTime Function() _clock;

  bool get isConfigured => _service != null;

  Future<SuggestionResult> suggest(
    ScheduleRequest request, {
    bool forceRuleBased = false,
  }) async {
    final DateTime now = _clock();
    if (forceRuleBased) {
      return SuggestionResult(
        suggestion: RuleBasedScheduler.schedule(request, now: now),
      );
    }
    final AiScheduleService? service = _service;
    AiErrorCode? reason;
    if (service == null) {
      reason = AiErrorCode.notConfigured;
    } else if (!await _connectivity.isOnline()) {
      reason = AiErrorCode.offline;
    } else {
      try {
        final ScheduleSuggestion s = await service.suggest(request);
        final String? problem =
            ScheduleValidator.checkSuggestion(request, s, now: now);
        if (problem == null) {
          return SuggestionResult(suggestion: s);
        }
        debugPrint('Usulan AI ditolak pemeriksaan lokal: $problem');
        reason = AiErrorCode.invalidResponse;
      } on AiException catch (e) {
        reason = e.code;
      }
    }
    return SuggestionResult(
      suggestion: RuleBasedScheduler.schedule(request, now: now),
      fallbackReason: reason,
    );
  }
}

final Provider<AiScheduleService?> aiScheduleServiceProvider =
    Provider<AiScheduleService?>((Ref ref) {
  if (!SupabaseBootstrap.isInitialized) {
    return null;
  }
  return EdgeFunctionScheduleService(SupabaseBootstrap.client);
});

final Provider<AiRepository> aiRepositoryProvider =
    Provider<AiRepository>((Ref ref) {
  return AiRepository(
    service: ref.watch(aiScheduleServiceProvider),
    connectivity: ref.watch(connectivityProvider),
    clock: ref.watch(clockProvider),
  );
});
