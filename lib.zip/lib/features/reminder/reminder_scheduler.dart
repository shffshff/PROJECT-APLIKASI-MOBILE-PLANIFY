import 'package:flutter/foundation.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../../core/notifications/notification_service.dart';
import '../../core/storage/local_box.dart';
import '../../core/storage/local_database.dart';
import '../../core/utils/app_date_format.dart';
import '../planner/domain/task.dart';

/// Jembatan Task ↔ notifikasi lokal (FR-017–021, Tahap 2 §11.6).
///
/// Aturan:
/// - Pengingat hanya dijadwalkan bila tugas aktif (tidak dihapus, belum
///   selesai) dan `reminderAt` di masa depan.
/// - Simpan/edit → jadwal lama dibatalkan dulu (ID sama), lalu dijadwalkan.
/// - Selesai/hapus → dibatalkan.
/// - [reconcile] mencocokkan semua tugas dengan jadwal tertunda (saat app
///   dibuka, setelah sinkron, dan setelah reboot via receiver plugin).
class ReminderScheduler {
  ReminderScheduler(
    this._notifications,
    this._map, {
    DateTime Function()? clock,
  }) : _clock = clock ?? DateTime.now;

  final NotificationService _notifications;

  /// taskId → id notifikasi (box `reminder_map`).
  final LocalBox _map;
  final DateTime Function() _clock;

  /// ID 31-bit stabil dari UUID (FNV-1a), di atas rentang ID tetap.
  static int idFor(String taskId) {
    int hash = 0x811c9dc5;
    for (final int unit in taskId.codeUnits) {
      hash ^= unit;
      hash = (hash * 0x01000193) & 0x7fffffff;
    }
    return 1000 + (hash % 0x7ffff000);
  }

  static bool isEligible(Task task, DateTime now) {
    final DateTime? at = task.reminderAt;
    return !task.isDeleted &&
        !task.isCompleted &&
        at != null &&
        at.isAfter(now);
  }

  /// Menjadwalkan atau membatalkan pengingat satu tugas.
  Future<void> syncTask(Task task) async {
    final int id = idFor(task.id);
    try {
      await _notifications.cancel(id);
      if (!isEligible(task, _clock())) {
        await _map.delete(task.id);
        return;
      }
      if (!await _notifications.areEnabled()) {
        // Tetap dicatat agar dijadwalkan saat izin diberikan (reconcile).
        await _map.putRaw(task.id, id.toString());
        return;
      }
      final DateTime local = task.reminderAt!.toLocal();
      final String when = task.dueTimeMinutes == null
          ? AppDateFormat.shortDate(task.dueDate)
          : '${AppDateFormat.shortDate(task.dueDate)}, '
              '${AppDateFormat.time(task.dueMoment)}';
      await _notifications.schedule(
        id: id,
        title: task.title,
        body: 'Tenggat $when',
        at: local,
        channel: NotificationChannel.reminders,
        payload: 'task:${task.id}',
      );
      await _map.putRaw(task.id, id.toString());
    } catch (error) {
      debugPrint('Pengingat ${task.id} gagal dijadwalkan: $error');
    }
  }

  Future<void> cancelTask(String taskId) async {
    await _notifications.cancel(idFor(taskId));
    await _map.delete(taskId);
  }

  /// Menyamakan seluruh jadwal dengan daftar tugas (FR-021).
  Future<void> reconcile(Iterable<Task> tasks) async {
    final Set<String> seen = <String>{};
    for (final Task task in tasks) {
      seen.add(task.id);
      await syncTask(task);
    }
    for (final String taskId in _map.keys.toList()) {
      if (!seen.contains(taskId)) {
        await cancelTask(taskId);
      }
    }
  }

  /// Dipakai saat keluar akun.
  Future<void> cancelAll() async {
    for (final String taskId in _map.keys.toList()) {
      await cancelTask(taskId);
    }
  }
}

final Provider<ReminderScheduler> reminderSchedulerProvider =
    Provider<ReminderScheduler>((Ref ref) {
  return ReminderScheduler(
    ref.watch(notificationServiceProvider),
    ref.watch(localDatabaseProvider).reminderMap,
  );
});
