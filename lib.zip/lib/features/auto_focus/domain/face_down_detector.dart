import 'dart:math' as math;

import 'package:flutter/foundation.dart';

/// Parameter deteksi (Tahap 2 §12.1). Nilai awal yang HARUS dikalibrasi
/// lewat eksperimen di perangkat nyata (K-10).
@immutable
class FaceDownConfig {
  const FaceDownConfig({
    this.alpha = 0.2,
    this.zThreshold = 8.0,
    this.xyTolerance = 2.5,
    this.magTolerance = 1.5,
    this.hold = const Duration(seconds: 3),
    this.cooldown = const Duration(minutes: 2),
  });

  static const double gravity = 9.81;

  final double alpha;
  final double zThreshold;
  final double xyTolerance;
  final double magTolerance;
  final Duration hold;
  final Duration cooldown;
}

/// Deteksi "ponsel diletakkan telungkup dan diam" dari accelerometer.
/// Logika murni: tidak menyentuh sensor ataupun jam sistem.
///
/// Sumbu Android: Z keluar dari layar. Layar menghadap ke bawah di meja →
/// z ≈ −9,8 m/s².
class FaceDownDetector {
  FaceDownDetector([this.config = const FaceDownConfig()]);

  final FaceDownConfig config;

  double? _fx;
  double? _fy;
  double? _fz;
  DateTime? _since;
  DateTime? _cooldownUntil;
  bool _fired = false;

  /// `true` bila kondisi telungkup sedang terpenuhi (setelah filter).
  bool get isFaceDown => _since != null;

  /// Memproses satu sampel. Mengembalikan `true` tepat sekali saat kondisi
  /// bertahan selama `hold` dan tidak sedang cooldown. Event berikutnya baru
  /// mungkin setelah ponsel diangkat lalu ditelungkupkan lagi.
  bool onSample(double x, double y, double z, DateTime now) {
    final double a = config.alpha;
    _fx = _fx == null ? x : a * x + (1 - a) * _fx!;
    _fy = _fy == null ? y : a * y + (1 - a) * _fy!;
    _fz = _fz == null ? z : a * z + (1 - a) * _fz!;

    final double fx = _fx!;
    final double fy = _fy!;
    final double fz = _fz!;
    final double xy = math.sqrt(fx * fx + fy * fy);
    final double magnitude = math.sqrt(fx * fx + fy * fy + fz * fz);

    final bool faceDown = fz < -config.zThreshold &&
        xy < config.xyTolerance &&
        (magnitude - FaceDownConfig.gravity).abs() < config.magTolerance;

    if (!faceDown) {
      _since = null;
      _fired = false;
      return false;
    }
    _since ??= now;
    if (_fired) {
      return false;
    }
    final DateTime? until = _cooldownUntil;
    if (until != null && now.isBefore(until)) {
      return false;
    }
    if (now.difference(_since!) >= config.hold) {
      _fired = true;
      return true;
    }
    return false;
  }

  /// Dipanggil setelah tawaran ditolak/kedaluwarsa.
  void startCooldown(DateTime now) {
    _cooldownUntil = now.add(config.cooldown);
  }

  bool inCooldown(DateTime now) {
    final DateTime? until = _cooldownUntil;
    return until != null && now.isBefore(until);
  }

  void reset() {
    _fx = null;
    _fy = null;
    _fz = null;
    _since = null;
    _fired = false;
  }
}
