import 'dart:async';

import 'package:flutter/foundation.dart';
import 'package:flutter/services.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../../../core/sensors/motion_source.dart';
import '../../../core/storage/local_box.dart';
import '../../../core/storage/local_database.dart';
import '../../auth/application/auth_providers.dart';
import '../../focus/domain/focus_session.dart';
import '../../focus/presentation/pomodoro_controller.dart';
import '../domain/face_down_detector.dart';

enum SensorAvailability { unknown, available, unavailable, unsupported }

@immutable
class AutoFocusState {
  const AutoFocusState({
    this.enabled = false,
    this.availability = SensorAvailability.unknown,
    this.listening = false,
    this.promptUntil,
  });

  /// Toggle pengguna (disimpan di `device_settings`).
  final bool enabled;
  final SensorAvailability availability;

  /// Listener accelerometer sedang aktif.
  final bool listening;

  /// Terisi saat tawaran "Mulai sesi fokus?" tampil; batas waktu tawaran.
  final DateTime? promptUntil;

  bool get isPrompting => promptUntil != null;

  AutoFocusState copyWith({
    bool? enabled,
    SensorAvailability? availability,
    bool? listening,
    DateTime? promptUntil,
    bool clearPrompt = false,
  }) {
    return AutoFocusState(
      enabled: enabled ?? this.enabled,
      availability: availability ?? this.availability,
      listening: listening ?? this.listening,
      promptUntil: clearPrompt ? null : (promptUntil ?? this.promptUntil),
    );
  }
}

/// Focus Mode Otomatis (FR-036).
///
/// Sensor hanya dibaca bila SEMUA syarat terpenuhi: toggle aktif, halaman
/// Focus sedang tampil di depan, aplikasi di foreground, dan timer idle
/// (Tahap 2 §12.1, mockup S-34). Sesi TIDAK pernah dimulai otomatis: deteksi
/// hanya memunculkan tawaran yang harus disetujui.
class AutoFocusController extends Notifier<AutoFocusState> {
  static const String _settingKey = 'auto_focus';
  static const Duration promptTimeout = Duration(seconds: 20);
  static const Duration availabilityTimeout = Duration(seconds: 3);

  late final MotionSource _source = ref.read(motionSourceProvider);
  late final LocalBox _settings = ref.read(localDatabaseProvider).deviceSettings;
  final FaceDownDetector _detector = FaceDownDetector();

  StreamSubscription<MotionSample>? _sub;
  Timer? _availabilityTimer;
  Timer? _promptTimer;
  bool _pageActive = false;
  bool _gotSample = false;

  DateTime _now() => ref.read(clockProvider)();

  @override
  AutoFocusState build() {
    ref.onDispose(_stop);
    ref.onDispose(() => _promptTimer?.cancel());
    // Timer berjalan → sensor dijeda; kembali idle → boleh lagi.
    ref.listen<bool>(
      pomodoroControllerProvider.select((PomodoroView v) => v.timer.isIdle),
      (bool? previous, bool next) => _evaluate(),
    );
    final bool enabled = _settings.getJson(_settingKey)?['enabled'] == true;
    return AutoFocusState(
      enabled: enabled,
      availability: _source.isPlatformSupported
          ? SensorAvailability.unknown
          : SensorAvailability.unsupported,
    );
  }

  Future<void> setEnabled(bool enabled) async {
    await _settings.putJson(_settingKey, <String, dynamic>{'enabled': enabled});
    state = state.copyWith(enabled: enabled);
    if (enabled && state.availability == SensorAvailability.unavailable) {
      // Beri kesempatan cek ulang.
      state = state.copyWith(availability: SensorAvailability.unknown);
    }
    _evaluate();
  }

  /// Dipanggil halaman Focus: tampil di depan + aplikasi foreground.
  void setPageActive(bool active) {
    if (!ref.mounted || _pageActive == active) {
      return;
    }
    _pageActive = active;
    _evaluate();
  }

  bool get _shouldListen {
    final bool idle = ref.read(pomodoroControllerProvider).timer.isIdle;
    return state.enabled &&
        _pageActive &&
        idle &&
        !state.isPrompting &&
        (state.availability == SensorAvailability.unknown ||
            state.availability == SensorAvailability.available);
  }

  void _evaluate() {
    if (_shouldListen) {
      _start();
    } else {
      _stop();
    }
  }

  void _start() {
    if (_sub != null) {
      return;
    }
    _detector.reset();
    _gotSample = false;
    _sub = _source.accelerometer().listen(
      _onSample,
      onError: (Object error) {
        debugPrint('Accelerometer error: $error');
        _markUnavailable();
      },
      cancelOnError: true,
    );
    state = state.copyWith(listening: true);
    if (state.availability == SensorAvailability.unknown) {
      _availabilityTimer?.cancel();
      _availabilityTimer = Timer(availabilityTimeout, () {
        if (!_gotSample) {
          _markUnavailable();
        }
      });
    }
  }

  void _stop() {
    _availabilityTimer?.cancel();
    _availabilityTimer = null;
    unawaited(_sub?.cancel());
    _sub = null;
    if (ref.mounted && state.listening) {
      state = state.copyWith(listening: false);
    }
  }

  void _markUnavailable() {
    _stop();
    if (ref.mounted) {
      state = state.copyWith(availability: SensorAvailability.unavailable);
    }
  }

  void _onSample(MotionSample s) {
    if (!_gotSample) {
      _gotSample = true;
      _availabilityTimer?.cancel();
      state = state.copyWith(availability: SensorAvailability.available);
    }
    if (_detector.onSample(s.x, s.y, s.z, _now())) {
      _offer();
    }
  }

  void _offer() {
    _stop();
    // Getar singkat; kegagalan platform (mis. di test) diabaikan.
    unawaited(HapticFeedback.vibrate().catchError((Object _) {}));
    final DateTime until = _now().add(promptTimeout);
    state = state.copyWith(promptUntil: until);
    _promptTimer?.cancel();
    _promptTimer = Timer(promptTimeout, decline);
  }

  /// Pengguna menyetujui: mulai sesi fokus.
  Future<void> accept() async {
    _promptTimer?.cancel();
    state = state.copyWith(clearPrompt: true);
    final PomodoroController pomodoro =
        ref.read(pomodoroControllerProvider.notifier);
    pomodoro.selectMode(PomodoroMode.focus);
    await pomodoro.start();
    _evaluate();
  }

  /// Ditolak atau kedaluwarsa → cooldown sebelum menawarkan lagi.
  void decline() {
    _promptTimer?.cancel();
    if (!ref.mounted) {
      return;
    }
    _detector.startCooldown(_now());
    state = state.copyWith(clearPrompt: true);
    _evaluate();
  }

  /// Hanya untuk test: menyuntik sampel tanpa sensor.
  @visibleForTesting
  void debugSample(MotionSample sample) => _onSample(sample);
}

final NotifierProvider<AutoFocusController, AutoFocusState>
    autoFocusControllerProvider =
    NotifierProvider<AutoFocusController, AutoFocusState>(
  AutoFocusController.new,
);
