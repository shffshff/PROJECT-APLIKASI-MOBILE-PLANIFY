import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:go_router/go_router.dart';

import '../../../app/router/routes.dart';
import '../../../app/sync/app_sync_indicator.dart';
import '../../../app/sync/sync_controller.dart';
import '../../../core/notifications/notification_service.dart';
import '../../../core/utils/app_date_format.dart';
import '../../../core/utils/date_only.dart';
import '../../../core/widgets/app_button.dart';
import '../../../core/widgets/app_progress.dart';
import '../../../core/widgets/empty_state.dart';
import '../../../core/widgets/page_container.dart';
import '../../../core/widgets/quick_action_tile.dart';
import '../../../core/widgets/section_header.dart';
import '../../../theme/app_colors.dart';
import '../../../theme/app_tokens.dart';
import '../../auth/application/session_controller.dart';
import '../../focus/data/focus_repository.dart';
import '../../focus/domain/focus_session.dart';
import '../../habit/data/habit_repository.dart';
import '../../planner/data/task_repository.dart';
import '../../planner/domain/task.dart';
import '../../planner/domain/task_filter.dart';
import '../../planner/presentation/planner_controller.dart';
import '../../planner/presentation/widgets/task_card.dart';

/// S-10 Home: ringkasan hari ini dari data lokal (FR-008/009).
class HomePage extends ConsumerWidget {
  const HomePage({super.key});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final DateTime now = DateTime.now();
    final ThemeData theme = Theme.of(context);
    final String? name =
        ref.watch(sessionControllerProvider.select((s) => s.user?.shortName));
    final List<Task> tasks = ref.watch(tasksProvider).value ?? const <Task>[];
    final DaySummary summary = DaySummary.of(tasks, now);
    final bool denied =
        ref.watch(notificationPermissionProvider).value == false;

    return Scaffold(
      appBar: AppBar(
        toolbarHeight: 72,
        title: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: <Widget>[
            Text(
              name == null
                  ? AppDateFormat.greeting(now)
                  : '${AppDateFormat.greeting(now)}, $name',
              style: theme.textTheme.headlineSmall,
              overflow: TextOverflow.ellipsis,
            ),
            Text(
              AppDateFormat.fullDate(now),
              style: theme.textTheme.bodyMedium!.copyWith(
                color: context.appColors.textSecondary,
              ),
            ),
          ],
        ),
        actions: const <Widget>[
          AppSyncIndicator(),
          SizedBox(width: AppSpacing.sm),
        ],
      ),
      body: SafeArea(
        child: RefreshIndicator(
          onRefresh: () => ref.read(syncControllerProvider.notifier).syncNow(),
          child: ListView(
            padding: const EdgeInsets.only(bottom: AppSpacing.xxl),
            children: <Widget>[
              PageContainer(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.stretch,
                  children: <Widget>[
                    const SizedBox(height: AppSpacing.sm),
                    _ProgressCard(summary: summary),
                    if (summary.next != null) ...<Widget>[
                      const SizedBox(height: AppSpacing.cardGap),
                      _NextTaskCard(task: summary.next!, now: now),
                    ],
                    const SizedBox(height: AppSpacing.sectionGap),
                    SectionHeader(
                      title: 'Prioritas hari ini',
                      actionLabel: 'Lihat semua',
                      onAction: () {
                        ref
                            .read(plannerViewProvider.notifier)
                            .selectDay(now);
                        context.go(AppRoutes.planner);
                      },
                    ),
                    const SizedBox(height: AppSpacing.sm),
                    if (summary.todayOpen.isEmpty)
                      Card(
                        margin: EdgeInsets.zero,
                        child: EmptyState(
                          icon: Icons.task_alt_rounded,
                          title: summary.total == 0
                              ? 'Belum ada tugas hari ini'
                              : 'Semua tugas hari ini selesai',
                          message: summary.total == 0
                              ? 'Tambahkan tugas agar harimu lebih terarah.'
                              : 'Kerja bagus! Nikmati sisa harimu.',
                          primaryActionLabel: 'Tambah tugas',
                          onPrimaryAction: () => context.push(
                            '${AppRoutes.taskNew}?date=${DateOnly.format(now)}',
                          ),
                        ),
                      )
                    else
                      for (final Task t in summary.todayOpen.take(3)) ...<Widget>[
                        TaskCard(
                          task: t,
                          now: now,
                          notificationsDenied: denied,
                          onTap: () => context.push(AppRoutes.taskDetail(t.id)),
                          onToggle: (bool v) =>
                              toggleTaskWithUndo(context, ref, t, v),
                        ),
                        const SizedBox(height: AppSpacing.cardGap),
                      ],
                    const SizedBox(height: AppSpacing.sectionGap),
                    const _HabitSummary(),
                    const SizedBox(height: AppSpacing.sectionGap),
                    const _FocusSummary(),
                    const SizedBox(height: AppSpacing.sectionGap),
                    const SectionHeader(title: 'Akses cepat'),
                    const SizedBox(height: AppSpacing.sm),
                    const _QuickActions(),
                  ],
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}

class _ProgressCard extends StatelessWidget {
  const _ProgressCard({required this.summary});

  final DaySummary summary;

  @override
  Widget build(BuildContext context) {
    final ThemeData theme = Theme.of(context);
    final AppColors colors = context.appColors;
    final int percent = (summary.progress * 100).round();
    final int remaining = summary.total - summary.completed;
    return Card(
      margin: EdgeInsets.zero,
      child: Padding(
        padding: const EdgeInsets.all(AppSpacing.lg),
        child: Row(
          children: <Widget>[
            AppProgressRing(
              value: summary.progress,
              size: 84,
              semanticsLabel:
                  '$percent persen, ${summary.completed} dari ${summary.total} '
                  'tugas hari ini selesai',
              center: Text('$percent%', style: theme.textTheme.titleLarge),
            ),
            const SizedBox(width: AppSpacing.lg),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: <Widget>[
                  Text(
                    '${summary.completed} dari ${summary.total} tugas selesai',
                    style: theme.textTheme.titleMedium,
                  ),
                  const SizedBox(height: 6),
                  if (summary.overdue > 0)
                    Row(
                      children: <Widget>[
                        Icon(Icons.schedule_rounded,
                            size: 16, color: theme.colorScheme.error),
                        const SizedBox(width: 4),
                        Text(
                          '${summary.overdue} terlambat',
                          style: theme.textTheme.bodyMedium!
                              .copyWith(color: theme.colorScheme.error),
                        ),
                      ],
                    ),
                  Text(
                    '$remaining tersisa hari ini',
                    style: theme.textTheme.bodyMedium!
                        .copyWith(color: colors.textSecondary),
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}

class _NextTaskCard extends StatelessWidget {
  const _NextTaskCard({required this.task, required this.now});

  final Task task;
  final DateTime now;

  String _relative() {
    final Duration d = task.dueMoment.difference(now);
    if (d.inMinutes < 1) {
      return 'SEBENTAR LAGI';
    }
    if (d.inMinutes < 60) {
      return '${d.inMinutes} MENIT LAGI';
    }
    if (d.inHours < 24) {
      return '${d.inHours} JAM LAGI';
    }
    return '${d.inDays} HARI LAGI';
  }

  @override
  Widget build(BuildContext context) {
    final ThemeData theme = Theme.of(context);
    final ColorScheme scheme = theme.colorScheme;
    return Card(
      margin: EdgeInsets.zero,
      color: scheme.primaryContainer,
      child: InkWell(
        onTap: () => context.push(AppRoutes.taskDetail(task.id)),
        child: Padding(
          padding: const EdgeInsets.all(AppSpacing.lg),
          child: Row(
            children: <Widget>[
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: <Widget>[
                    Text(
                      'BERIKUTNYA · ${_relative()}',
                      style: theme.textTheme.labelMedium!.copyWith(
                        color: scheme.onPrimaryContainer,
                        letterSpacing: 0.8,
                      ),
                    ),
                    const SizedBox(height: 4),
                    Text(
                      task.title,
                      style: theme.textTheme.titleMedium!
                          .copyWith(color: scheme.onPrimaryContainer),
                      maxLines: 2,
                      overflow: TextOverflow.ellipsis,
                    ),
                  ],
                ),
              ),
              Text(
                AppDateFormat.time(task.dueMoment),
                style: theme.textTheme.titleMedium!
                    .copyWith(color: scheme.onPrimaryContainer),
              ),
            ],
          ),
        ),
      ),
    );
  }
}

class _HabitSummary extends ConsumerWidget {
  const _HabitSummary();

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final List<HabitProgress> list =
        ref.watch(habitProgressProvider).value ?? const <HabitProgress>[];
    final List<HabitProgress> today =
        list.where((HabitProgress p) => p.isTargetToday).toList();
    final int done = today.where((HabitProgress p) => p.doneToday).length;
    final ThemeData theme = Theme.of(context);

    return Column(
      crossAxisAlignment: CrossAxisAlignment.stretch,
      children: <Widget>[
        SectionHeader(
          title: 'Kebiasaan',
          actionLabel: list.isEmpty ? 'Buat' : '$done/${today.length} hari ini',
          onAction: () => context.push(AppRoutes.habits),
        ),
        const SizedBox(height: AppSpacing.sm),
        if (list.isEmpty)
          Text(
            'Belum ada kebiasaan. Mulai dari yang kecil, misalnya "Minum air".',
            style: theme.textTheme.bodyMedium!
                .copyWith(color: context.appColors.textSecondary),
          )
        else
          Wrap(
            spacing: AppSpacing.sm,
            runSpacing: AppSpacing.sm,
            children: <Widget>[
              for (final HabitProgress p in today)
                Chip(
                  avatar: Icon(
                    p.doneToday
                        ? Icons.check_circle_rounded
                        : Icons.radio_button_unchecked_rounded,
                    size: 18,
                    color: Color(p.habit.colorValue),
                  ),
                  label: Text(p.habit.name),
                ),
            ],
          ),
      ],
    );
  }
}

class _FocusSummary extends ConsumerWidget {
  const _FocusSummary();

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final FocusStats stats = ref.watch(focusStatsProvider);
    final ThemeData theme = Theme.of(context);
    return Card(
      margin: EdgeInsets.zero,
      child: Padding(
        padding: const EdgeInsets.all(AppSpacing.lg),
        child: Row(
          children: <Widget>[
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: <Widget>[
                  Text(
                    '${stats.todaySessions} sesi · ${stats.todayMinutes} menit',
                    style: theme.textTheme.titleMedium,
                  ),
                  Text(
                    'Fokus hari ini',
                    style: theme.textTheme.bodyMedium!
                        .copyWith(color: context.appColors.textSecondary),
                  ),
                ],
              ),
            ),
            AppButton(
              label: 'Mulai fokus',
              icon: Icons.play_arrow_rounded,
              variant: AppButtonVariant.tonal,
              onPressed: () => context.go(AppRoutes.focus),
            ),
          ],
        ),
      ),
    );
  }
}

class _QuickActions extends StatelessWidget {
  const _QuickActions();

  @override
  Widget build(BuildContext context) {
    final List<(IconData, String, String)> items = <(IconData, String, String)>[
      (Icons.repeat_rounded, 'Kebiasaan', AppRoutes.habits),
      (Icons.place_outlined, 'Tempat', AppRoutes.places),
      (Icons.currency_exchange_rounded, 'Kurs', AppRoutes.currency),
      (Icons.public_rounded, 'Zona waktu', AppRoutes.timezone),
      (Icons.sports_esports_outlined, 'Balance game', AppRoutes.focusGame),
      (Icons.link_rounded, 'Hash-chain', AppRoutes.hashChain),
    ];
    return GridView.count(
      crossAxisCount: 3,
      shrinkWrap: true,
      physics: const NeverScrollableScrollPhysics(),
      mainAxisSpacing: AppSpacing.sm,
      crossAxisSpacing: AppSpacing.sm,
      childAspectRatio: 1.1,
      children: <Widget>[
        for (final (IconData icon, String label, String path) in items)
          QuickActionTile(
            icon: icon,
            label: label,
            onTap: () => context.push(path),
          ),
      ],
    );
  }
}
