import 'package:flutter/foundation.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../../../core/storage/local_box.dart';
import '../../../core/storage/local_database.dart';
import '../../../core/sync/remote_gateway.dart';
import '../../planner/data/task_repository.dart';

enum FeedbackCategory {
  kesan('Kesan'),
  saran('Saran'),
  bug('Bug'),
  lainnya('Lainnya');

  const FeedbackCategory(this.label);

  final String label;
}

abstract final class FeedbackValidator {
  static const int minLength = 10;
  static const int maxLength = 1000;

  static String? message(String? v) {
    final int n = v?.trim().length ?? 0;
    if (n == 0) {
      return 'Pesan wajib diisi.';
    }
    if (n < minLength) {
      return 'Minimal $minLength karakter.';
    }
    if (n > maxLength) {
      return 'Maksimal $maxLength karakter.';
    }
    return null;
  }
}

/// Kesan & saran (FR-046): disimpan di antrean lokal dulu lalu dikirim ke
/// tabel `feedback`. `id` dibuat di klien sehingga kirim ulang/ketuk ganda
/// tidak membuat baris dobel (`on conflict do nothing`).
class FeedbackRepository {
  FeedbackRepository(this._outbox, this._remote, this._userId);

  final LocalBox _outbox;
  final RemoteGateway? _remote;
  final String? Function() _userId;

  static const String appVersion = '0.1.0';

  int get pendingCount => _outbox.keys.length;

  /// Menyimpan ke antrean lalu mencoba mengirim. `true` bila sudah terkirim.
  Future<bool> submit({
    required String id,
    required FeedbackCategory category,
    required String message,
    int? rating,
  }) async {
    final String? user = _userId();
    if (user == null) {
      return false;
    }
    await _outbox.putJson(id, <String, dynamic>{
      'id': id,
      'user_id': user,
      'category': category.name,
      'rating': rating,
      'message': message.trim(),
      'app_version': appVersion,
      'created_at': DateTime.now().toUtc().toIso8601String(),
    });
    await flush();
    return _outbox.getRaw(id) == null;
  }

  /// Mengirim antrean. Gagal jaringan → tetap di antrean.
  Future<int> flush() async {
    final RemoteGateway? remote = _remote;
    if (remote == null) {
      return 0;
    }
    int sent = 0;
    for (final String key in _outbox.keys.toList()) {
      final Map<String, dynamic>? row = _outbox.getJson(key);
      if (row == null) {
        await _outbox.delete(key);
        continue;
      }
      try {
        await remote.insertIgnore('feedback', row, onConflict: 'id');
        await _outbox.delete(key);
        sent++;
      } on RemoteError catch (e) {
        if (e.kind == RemoteErrorKind.rejected) {
          debugPrint('Feedback ditolak server (${e.code}); dibuang.');
          await _outbox.delete(key);
        } else {
          break;
        }
      }
    }
    return sent;
  }
}

final Provider<FeedbackRepository> feedbackRepositoryProvider =
    Provider<FeedbackRepository>((Ref ref) {
  return FeedbackRepository(
    ref.watch(localDatabaseProvider).feedbackOutbox,
    ref.watch(remoteGatewayProvider),
    () => ref.read(currentUserIdProvider),
  );
});
