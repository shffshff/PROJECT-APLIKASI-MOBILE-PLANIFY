import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:go_router/go_router.dart';

import '../../../app/router/routes.dart';
import '../../../core/utils/date_only.dart';
import '../../../core/widgets/app_button.dart';
import '../../../core/widgets/app_text_field.dart';
import '../../../core/widgets/page_container.dart';
import '../../../theme/app_colors.dart';
import '../../../theme/app_tokens.dart';
import '../data/feedback_repository.dart';

/// S-54 Kesan & Saran (FR-046).
class FeedbackPage extends ConsumerStatefulWidget {
  const FeedbackPage({super.key});

  @override
  ConsumerState<FeedbackPage> createState() => _FeedbackPageState();
}

class _FeedbackPageState extends ConsumerState<FeedbackPage> {
  final GlobalKey<FormState> _formKey = GlobalKey<FormState>();
  final TextEditingController _message = TextEditingController();

  /// Satu ID per isian: ketuk ganda tidak membuat dua record.
  final String _id = Ids.newId();
  FeedbackCategory _category = FeedbackCategory.kesan;
  int? _rating;
  bool _sending = false;

  @override
  void dispose() {
    _message.dispose();
    super.dispose();
  }

  Future<void> _send() async {
    if (_sending || !(_formKey.currentState?.validate() ?? false)) {
      return;
    }
    setState(() => _sending = true);
    final ScaffoldMessengerState m = ScaffoldMessenger.of(context);
    final bool sent = await ref.read(feedbackRepositoryProvider).submit(
          id: _id,
          category: _category,
          message: _message.text,
          rating: _rating,
        );
    m.showSnackBar(
      SnackBar(
        content: Text(
          sent
              ? 'Terima kasih! Masukanmu sudah terkirim.'
              : 'Masukan disimpan dan akan dikirim otomatis saat online.',
        ),
      ),
    );
    if (mounted) {
      context.canPop() ? context.pop() : context.go(AppRoutes.profile);
    }
  }

  @override
  Widget build(BuildContext context) {
    final ThemeData theme = Theme.of(context);
    return Scaffold(
      appBar: AppBar(title: const Text('Kesan & Saran')),
      body: SafeArea(
        child: Form(
          key: _formKey,
          child: ListView(
            padding: const EdgeInsets.only(bottom: AppSpacing.xxl),
            children: <Widget>[
              PageContainer(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.stretch,
                  children: <Widget>[
                    const SizedBox(height: AppSpacing.lg),
                    Text(
                      'Masukanmu membantu pengembangan PLANIFY. Tidak ada data '
                      'tugas yang ikut terkirim.',
                      style: theme.textTheme.bodyMedium!.copyWith(
                        color: context.appColors.textSecondary,
                      ),
                    ),
                    const SizedBox(height: AppSpacing.lg),
                    Text('Kategori *', style: theme.textTheme.labelLarge),
                    const SizedBox(height: AppSpacing.sm),
                    Wrap(
                      spacing: AppSpacing.sm,
                      children: <Widget>[
                        for (final FeedbackCategory c in FeedbackCategory.values)
                          ChoiceChip(
                            label: Text(c.label),
                            selected: _category == c,
                            onSelected: (_) => setState(() => _category = c),
                          ),
                      ],
                    ),
                    const SizedBox(height: AppSpacing.lg),
                    Text('Penilaian (opsional)', style: theme.textTheme.labelLarge),
                    Row(
                      children: <Widget>[
                        for (int i = 1; i <= 5; i++)
                          IconButton(
                            tooltip: '$i bintang',
                            isSelected: (_rating ?? 0) >= i,
                            onPressed: () => setState(
                              () => _rating = _rating == i ? null : i,
                            ),
                            icon: Icon(
                              (_rating ?? 0) >= i
                                  ? Icons.star_rounded
                                  : Icons.star_outline_rounded,
                              color: context.appColors.warning,
                            ),
                          ),
                      ],
                    ),
                    const SizedBox(height: AppSpacing.md),
                    AppTextField(
                      label: 'Pesan',
                      controller: _message,
                      isRequired: true,
                      minLines: 4,
                      maxLines: 8,
                      maxLength: FeedbackValidator.maxLength,
                      showCounterFrom: 1,
                      helperText:
                          'Minimal ${FeedbackValidator.minLength} karakter',
                      validator: FeedbackValidator.message,
                      textCapitalization: TextCapitalization.sentences,
                    ),
                    const SizedBox(height: AppSpacing.md),
                    Text(
                      'Saat offline, masukan disimpan dan dikirim otomatis '
                      'begitu koneksi kembali.',
                      style: theme.textTheme.bodySmall,
                    ),
                    const SizedBox(height: AppSpacing.xl),
                    AppButton(
                      label: 'Kirim masukan',
                      icon: Icons.send_rounded,
                      expand: true,
                      isLoading: _sending,
                      onPressed: _send,
                    ),
                  ],
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
