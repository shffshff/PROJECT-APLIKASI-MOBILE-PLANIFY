import 'dart:math' as math;

import 'package:flutter/foundation.dart';

/// Tingkat sensitivitas kendali (mockup S-37: "Sensitivitas · Sedang").
enum BalanceSensitivity {
  low('Rendah', 0.9),
  medium('Sedang', 1.5),
  high('Tinggi', 2.3);

  const BalanceSensitivity(this.label, this.gain);

  final String label;
  final double gain;

  static BalanceSensitivity parse(Object? v) => BalanceSensitivity.values
      .firstWhere((BalanceSensitivity s) => s.name == v, orElse: () => medium);
}

/// Parameter game (Tahap 2 §12.2). Posisi dalam satuan arena: pusat (0,0),
/// tepi arena berjari-jari 1.
@immutable
class BalanceConfig {
  const BalanceConfig({
    this.duration = const Duration(seconds: 60),
    this.targetRadius = 0.32,
    this.ballRadius = 0.07,
    this.deadzone = 0.03,
    this.emaAlpha = 0.35,
    this.damping = 1.6,
    this.gain = 1.5,
  });

  final Duration duration;
  final double targetRadius;
  final double ballRadius;

  /// rad/s di bawah nilai ini dianggap nol (menekan noise/drift kecil).
  final double deadzone;
  final double emaAlpha;

  /// Peredaman kecepatan per detik.
  final double damping;
  final double gain;
}

enum BalanceStatus { playing, won, lost }

@immutable
class BalanceState {
  const BalanceState({
    this.x = 0,
    this.y = 0,
    this.vx = 0,
    this.vy = 0,
    this.wx = 0,
    this.wy = 0,
    this.elapsed = Duration.zero,
    this.secondsInTarget = 0,
    this.status = BalanceStatus.playing,
  });

  final double x;
  final double y;
  final double vx;
  final double vy;

  /// Kecepatan sudut tersaring (rad/s).
  final double wx;
  final double wy;
  final Duration elapsed;
  final double secondsInTarget;
  final BalanceStatus status;

  /// Skor = detik di zona target × 10 (bilangan bulat).
  int get score => (secondsInTarget * 10).floor();

  double get distance => math.sqrt(x * x + y * y);
}

/// Fisika bola: kendali KECEPATAN dari gyroscope (bukan integrasi sudut)
/// agar drift tidak menumpuk (Tahap 2 §12.2). Logika murni.
abstract final class BalancePhysics {
  static double _dead(double v, double zone) =>
      v.abs() < zone ? 0 : v - zone * v.sign;

  /// Satu langkah simulasi. [gx], [gy] = pembacaan gyroscope dikurangi bias.
  static BalanceState step(
    BalanceState s,
    double gx,
    double gy,
    double dtSeconds,
    BalanceConfig c,
  ) {
    if (s.status != BalanceStatus.playing || dtSeconds <= 0) {
      return s;
    }
    final double dt = math.min(dtSeconds, 0.1); // cegah lompatan saat jank
    final double a = c.emaAlpha;
    final double wx = a * gx + (1 - a) * s.wx;
    final double wy = a * gy + (1 - a) * s.wy;
    final double ux = _dead(wx, c.deadzone);
    final double uy = _dead(wy, c.deadzone);

    // Miring ke kanan (rotasi sumbu Y) → bola ke kanan; miring ke depan
    // (rotasi sumbu X) → bola ke bawah layar. Tanda dapat dibalik setelah
    // uji di perangkat (K-10).
    final double decay = math.max(0, 1 - c.damping * dt);
    final double vx = (s.vx + uy * c.gain * dt) * decay;
    final double vy = (s.vy + ux * c.gain * dt) * decay;
    final double x = s.x + vx * dt;
    final double y = s.y + vy * dt;

    final double dist = math.sqrt(x * x + y * y);
    final Duration elapsed =
        s.elapsed + Duration(microseconds: (dt * 1e6).round());
    final double inTarget =
        s.secondsInTarget + (dist <= c.targetRadius ? dt : 0);

    BalanceStatus status = BalanceStatus.playing;
    if (dist + c.ballRadius >= 1) {
      status = BalanceStatus.lost;
    } else if (elapsed >= c.duration) {
      status = BalanceStatus.won;
    }

    return BalanceState(
      x: x,
      y: y,
      vx: vx,
      vy: vy,
      wx: wx,
      wy: wy,
      elapsed: elapsed,
      secondsInTarget: inTarget,
      status: status,
    );
  }
}

/// Kalibrasi titik nol gyroscope (perangkat dipegang diam ±2 detik).
class GyroCalibrator {
  GyroCalibrator({this.maxStdDev = 0.12});

  /// Simpangan baku di atas ini = pengguna bergerak, kalibrasi diulang.
  final double maxStdDev;

  final List<double> _xs = <double>[];
  final List<double> _ys = <double>[];

  int get sampleCount => _xs.length;

  void add(double x, double y) {
    _xs.add(x);
    _ys.add(y);
  }

  void clear() {
    _xs.clear();
    _ys.clear();
  }

  static double _mean(List<double> v) =>
      v.isEmpty ? 0 : v.reduce((double a, double b) => a + b) / v.length;

  static double _std(List<double> v, double mean) {
    if (v.length < 2) {
      return 0;
    }
    final double sum = v.fold<double>(
      0,
      (double acc, double e) => acc + (e - mean) * (e - mean),
    );
    return math.sqrt(sum / (v.length - 1));
  }

  /// Bias (x, y) bila cukup stabil; `null` bila perlu diulang.
  (double, double)? result({int minSamples = 10}) {
    if (_xs.length < minSamples) {
      return null;
    }
    final double mx = _mean(_xs);
    final double my = _mean(_ys);
    if (_std(_xs, mx) > maxStdDev || _std(_ys, my) > maxStdDev) {
      return null;
    }
    return (mx, my);
  }
}
