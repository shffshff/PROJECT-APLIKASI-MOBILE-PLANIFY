import 'dart:async';

import 'package:flutter/material.dart';
import 'package:flutter/scheduler.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../../../core/sensors/motion_source.dart';
import '../../../core/storage/local_box.dart';
import '../../../core/storage/local_database.dart';
import '../../../core/widgets/app_button.dart';
import '../../../core/widgets/empty_state.dart';
import '../../../core/widgets/page_container.dart';
import '../../../theme/app_colors.dart';
import '../../../theme/app_theme.dart';
import '../../../theme/app_tokens.dart';
import '../domain/balance_physics.dart';

enum _Phase { checking, unsupported, intro, calibrating, playing, finished }

/// S-37 Balance Focus Game (FR-037/038). Gyroscope hanya didengarkan saat
/// kalibrasi dan bermain; dihentikan saat selesai, saat aplikasi ke
/// background, dan saat halaman ditinggalkan (NFR-018).
class BalanceGamePage extends ConsumerStatefulWidget {
  const BalanceGamePage({super.key});

  @override
  ConsumerState<BalanceGamePage> createState() => _BalanceGamePageState();
}

class _BalanceGamePageState extends ConsumerState<BalanceGamePage>
    with SingleTickerProviderStateMixin {
  static const String _bestKey = 'best';
  static const String _sensitivityKey = 'game_sensitivity';
  static const Duration _calibration = Duration(seconds: 2);

  late final Ticker _ticker = createTicker(_onTick);
  late final AppLifecycleListener _lifecycle;
  late final MotionSource _source = ref.read(motionSourceProvider);
  late final LocalBox _scores = ref.read(localDatabaseProvider).gameScores;
  late final LocalBox _settings =
      ref.read(localDatabaseProvider).deviceSettings;

  StreamSubscription<MotionSample>? _sub;
  Timer? _checkTimer;
  final GyroCalibrator _calibrator = GyroCalibrator();

  _Phase _phase = _Phase.checking;
  BalanceSensitivity _sensitivity = BalanceSensitivity.medium;
  BalanceState _game = const BalanceState();
  (double, double) _bias = (0, 0);
  MotionSample _latest = const MotionSample(0, 0, 0);
  Duration? _lastTick;
  DateTime? _calibrationStart;
  String? _message;
  int _best = 0;
  bool _newBest = false;

  BalanceConfig get _config => BalanceConfig(gain: _sensitivity.gain);

  @override
  void initState() {
    super.initState();
    final Object? best = _scores.getJson(_bestKey)?['score'];
    _best = best is num ? best.toInt() : 0;
    _sensitivity = BalanceSensitivity.parse(_settings.getRaw(_sensitivityKey));
    _lifecycle = AppLifecycleListener(onHide: _onHidden, onPause: _onHidden);
    _checkAvailability();
  }

  @override
  void dispose() {
    _lifecycle.dispose();
    _stopSensor();
    _ticker.dispose();
    _checkTimer?.cancel();
    super.dispose();
  }

  // ---- Sensor -------------------------------------------------------------

  void _checkAvailability() {
    if (!_source.isPlatformSupported) {
      setState(() => _phase = _Phase.unsupported);
      return;
    }
    bool got = false;
    _listen((MotionSample _) {
      if (!got) {
        got = true;
        _checkTimer?.cancel();
        _stopSensor();
        if (mounted) {
          setState(() => _phase = _Phase.intro);
        }
      }
    });
    _checkTimer = Timer(const Duration(seconds: 3), () {
      if (!got) {
        _stopSensor();
        if (mounted) {
          setState(() => _phase = _Phase.unsupported);
        }
      }
    });
  }

  void _listen(void Function(MotionSample) onData) {
    _stopSensor();
    _sub = _source.gyroscope().listen(
      onData,
      onError: (Object error) {
        _stopSensor();
        if (mounted) {
          setState(() => _phase = _Phase.unsupported);
        }
      },
      cancelOnError: true,
    );
  }

  void _stopSensor() {
    unawaited(_sub?.cancel());
    _sub = null;
    if (_ticker.isActive) {
      _ticker.stop();
    }
  }

  void _onHidden() {
    if (_phase == _Phase.playing || _phase == _Phase.calibrating) {
      _stopSensor();
      setState(() {
        _phase = _Phase.intro;
        _message = 'Permainan dihentikan karena aplikasi ditinggalkan.';
      });
    }
  }

  // ---- Alur permainan -------------------------------------------------------

  void _startCalibration() {
    _calibrator.clear();
    _calibrationStart = DateTime.now();
    setState(() {
      _phase = _Phase.calibrating;
      _message = null;
      _newBest = false;
    });
    _listen((MotionSample s) {
      _calibrator.add(s.x, s.y);
      if (DateTime.now().difference(_calibrationStart!) >= _calibration) {
        final (double, double)? bias = _calibrator.result();
        _stopSensor();
        if (bias == null) {
          setState(() {
            _phase = _Phase.intro;
            _message = 'Ponsel bergerak saat kalibrasi. Pegang diam lalu '
                'coba lagi.';
          });
        } else {
          _bias = bias;
          _startPlaying();
        }
      }
    });
  }

  void _startPlaying() {
    _game = const BalanceState();
    _lastTick = null;
    setState(() => _phase = _Phase.playing);
    _listen((MotionSample s) => _latest = s);
    _ticker.start();
  }

  void _onTick(Duration elapsed) {
    final Duration? last = _lastTick;
    _lastTick = elapsed;
    if (last == null) {
      return;
    }
    final double dt = (elapsed - last).inMicroseconds / 1e6;
    final BalanceState next = BalancePhysics.step(
      _game,
      _latest.x - _bias.$1,
      _latest.y - _bias.$2,
      dt,
      _config,
    );
    setState(() => _game = next);
    if (next.status != BalanceStatus.playing) {
      _finish();
    }
  }

  void _finish() {
    _stopSensor();
    final int score = _game.score;
    if (score > _best) {
      _best = score;
      _newBest = true;
      unawaited(_scores.putJson(_bestKey, <String, dynamic>{
        'score': score,
        'achieved_at': DateTime.now().toUtc().toIso8601String(),
      }));
    }
    setState(() => _phase = _Phase.finished);
  }

  Future<void> _setSensitivity(BalanceSensitivity s) async {
    setState(() => _sensitivity = s);
    await _settings.putRaw(_sensitivityKey, s.name);
  }

  // ---- UI -------------------------------------------------------------------

  @override
  Widget build(BuildContext context) {
    final ThemeData theme = Theme.of(context);
    return Scaffold(
      appBar: AppBar(title: const Text('Balance Focus Game')),
      body: SafeArea(
        child: switch (_phase) {
          _Phase.checking => const Center(child: CircularProgressIndicator()),
          _Phase.unsupported => const EmptyState(
              icon: Icons.screen_rotation_alt_rounded,
              title: 'Gyroscope tidak tersedia',
              message: 'Perangkat atau platform ini tidak menyediakan '
                  'gyroscope, jadi permainan tidak dapat dimainkan.',
            ),
          _ => ListView(
              padding: const EdgeInsets.only(bottom: AppSpacing.xxl),
              children: <Widget>[
                PageContainer(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.stretch,
                    children: <Widget>[
                      const SizedBox(height: AppSpacing.lg),
                      _Hud(
                        remaining: _config.duration - _game.elapsed,
                        score: _game.score,
                        inTarget: _phase == _Phase.playing &&
                            _game.distance <= _config.targetRadius,
                      ),
                      const SizedBox(height: AppSpacing.lg),
                      AspectRatio(
                        aspectRatio: 1,
                        child: CustomPaint(
                          painter: _ArenaPainter(
                            state: _game,
                            config: _config,
                            arena: theme.colorScheme.surfaceContainerHighest,
                            target: context.appColors.successContainer,
                            targetBorder: context.appColors.success,
                            ball: theme.colorScheme.primary,
                            edge: theme.colorScheme.error,
                          ),
                          child: Semantics(
                            label: _phase == _Phase.playing
                                ? 'Arena permainan. Skor ${_game.score}.'
                                : 'Arena permainan',
                          ),
                        ),
                      ),
                      const SizedBox(height: AppSpacing.lg),
                      ..._controls(theme),
                    ],
                  ),
                ),
              ],
            ),
        },
      ),
    );
  }

  List<Widget> _controls(ThemeData theme) {
    final String? message = _message;
    final TextStyle hint =
        theme.textTheme.bodyMedium!.copyWith(color: context.appColors.textSecondary);
    switch (_phase) {
      case _Phase.calibrating:
        return <Widget>[
          Text(
            'Kalibrasi… pegang ponsel diam dan mendatar selama 2 detik.',
            textAlign: TextAlign.center,
            style: theme.textTheme.titleSmall,
          ),
        ];
      case _Phase.playing:
        return <Widget>[
          Text(
            'Miringkan ponsel perlahan untuk menjaga bola di lingkaran hijau. '
            'Menyentuh tepi luar = kalah.',
            textAlign: TextAlign.center,
            style: hint,
          ),
          const SizedBox(height: AppSpacing.md),
          AppButton(
            label: 'Berhenti',
            variant: AppButtonVariant.outline,
            expand: true,
            onPressed: () {
              _stopSensor();
              setState(() => _phase = _Phase.intro);
            },
          ),
        ];
      case _Phase.finished:
        final bool won = _game.status == BalanceStatus.won;
        return <Widget>[
          Semantics(
            liveRegion: true,
            child: Text(
              won ? 'Kamu bertahan 60 detik!' : 'Bola menyentuh tepi.',
              textAlign: TextAlign.center,
              style: theme.textTheme.titleLarge,
            ),
          ),
          Text(
            'Skor ${_game.score}${_newBest ? ' · rekor baru!' : ''} · '
            'Terbaik $_best',
            textAlign: TextAlign.center,
            style: hint,
          ),
          const SizedBox(height: AppSpacing.lg),
          AppButton(
            label: 'Main lagi',
            icon: Icons.replay_rounded,
            expand: true,
            onPressed: _startCalibration,
          ),
        ];
      case _Phase.intro:
      case _Phase.checking:
      case _Phase.unsupported:
        return <Widget>[
          if (message != null) ...<Widget>[
            Text(message, textAlign: TextAlign.center, style: hint),
            const SizedBox(height: AppSpacing.md),
          ],
          Text('Sensitivitas', style: theme.textTheme.labelLarge),
          const SizedBox(height: AppSpacing.sm),
          SegmentedButton<BalanceSensitivity>(
            segments: <ButtonSegment<BalanceSensitivity>>[
              for (final BalanceSensitivity s in BalanceSensitivity.values)
                ButtonSegment<BalanceSensitivity>(
                  value: s,
                  label: Text(s.label),
                ),
            ],
            selected: <BalanceSensitivity>{_sensitivity},
            onSelectionChanged: (Set<BalanceSensitivity> s) =>
                _setSensitivity(s.first),
          ),
          const SizedBox(height: AppSpacing.lg),
          AppButton(
            label: 'Kalibrasi & mulai',
            icon: Icons.play_arrow_rounded,
            expand: true,
            onPressed: _startCalibration,
          ),
          const SizedBox(height: AppSpacing.sm),
          Text(
            'Terbaik $_best · Data gyroscope hanya dibaca selama permainan.',
            textAlign: TextAlign.center,
            style: hint,
          ),
        ];
    }
  }
}

class _Hud extends StatelessWidget {
  const _Hud({
    required this.remaining,
    required this.score,
    required this.inTarget,
  });

  final Duration remaining;
  final int score;
  final bool inTarget;

  @override
  Widget build(BuildContext context) {
    final ThemeData theme = Theme.of(context);
    final int secs = remaining.isNegative ? 0 : remaining.inSeconds;
    final TextStyle big = theme.textTheme.headlineMedium!
        .copyWith(fontFeatures: AppTypography.tabularFigures);
    return Row(
      children: <Widget>[
        Expanded(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: <Widget>[
              Text('SISA WAKTU', style: theme.textTheme.labelSmall),
              Text('00:${secs.toString().padLeft(2, '0')}', style: big),
            ],
          ),
        ),
        Column(
          crossAxisAlignment: CrossAxisAlignment.end,
          children: <Widget>[
            Text('SKOR', style: theme.textTheme.labelSmall),
            Text('$score', style: big),
            Text(
              inTarget ? 'Di zona target · +10/dtk' : ' ',
              style: theme.textTheme.bodySmall!
                  .copyWith(color: context.appColors.success),
            ),
          ],
        ),
      ],
    );
  }
}

class _ArenaPainter extends CustomPainter {
  _ArenaPainter({
    required this.state,
    required this.config,
    required this.arena,
    required this.target,
    required this.targetBorder,
    required this.ball,
    required this.edge,
  });

  final BalanceState state;
  final BalanceConfig config;
  final Color arena;
  final Color target;
  final Color targetBorder;
  final Color ball;
  final Color edge;

  @override
  void paint(Canvas canvas, Size size) {
    final double r = size.shortestSide / 2;
    final Offset c = Offset(size.width / 2, size.height / 2);
    canvas.drawCircle(c, r, Paint()..color = arena);
    canvas.drawCircle(
      c,
      r,
      Paint()
        ..color = edge.withValues(alpha: 0.5)
        ..style = PaintingStyle.stroke
        ..strokeWidth = 3,
    );
    canvas.drawCircle(c, r * config.targetRadius, Paint()..color = target);
    canvas.drawCircle(
      c,
      r * config.targetRadius,
      Paint()
        ..color = targetBorder
        ..style = PaintingStyle.stroke
        ..strokeWidth = 2,
    );
    canvas.drawCircle(
      c + Offset(state.x * r, state.y * r),
      r * config.ballRadius,
      Paint()..color = ball,
    );
  }

  @override
  bool shouldRepaint(_ArenaPainter old) =>
      old.state != state || old.ball != ball;
}
