import 'package:supabase_flutter/supabase_flutter.dart' as sb;

import '../../../core/error/app_failure.dart';
import '../domain/auth_event.dart';
import '../domain/auth_repository.dart';
import '../domain/auth_user.dart';
import 'supabase_auth_error_mapper.dart';

/// [AuthRepository] berbasis Supabase Auth (email + password, alur PKCE).
class SupabaseAuthRepository implements AuthRepository {
  SupabaseAuthRepository(this._auth, {sb.SupabaseClient? client})
      : _client = client;

  final sb.GoTrueClient _auth;

  /// Untuk memperbarui tabel `profiles` (opsional di test).
  final sb.SupabaseClient? _client;

  /// URL yang dibuka dari email (konfirmasi akun dan atur ulang password).
  /// WAJIB didaftarkan di Supabase Dashboard → Authentication → URL
  /// Configuration → Redirect URLs, dan di AndroidManifest (docs/AUTH_SETUP.md).
  static const String redirectUrl = 'id.planify.planify://auth-callback';

  @override
  bool get isConfigured => true;

  @override
  AuthUser? get currentUser => _toUser(_auth.currentUser);

  @override
  Stream<AuthEvent> get events =>
      _auth.onAuthStateChange.map((sb.AuthState state) {
        return AuthEvent(
          _mapEvent(state.event),
          user: _toUser(state.session?.user),
        );
      });

  @override
  Future<AuthUser> signInWithPassword({
    required String email,
    required String password,
  }) async {
    try {
      final sb.AuthResponse response = await _auth.signInWithPassword(
        email: email.trim(),
        password: password,
      );
      final AuthUser? user = _toUser(response.user ?? response.session?.user);
      if (user == null) {
        throw const AppFailure(AppFailureKind.unknown);
      }
      return user;
    } catch (error) {
      throw mapSupabaseAuthError(error);
    }
  }

  @override
  Future<SignUpOutcome> signUp({
    required String fullName,
    required String email,
    required String password,
  }) async {
    try {
      final sb.AuthResponse response = await _auth.signUp(
        email: email.trim(),
        password: password,
        // `display_name` dibaca trigger handle_new_user (Tahap 2 §7.3) untuk
        // mengisi tabel profiles. `full_name` disimpan juga untuk kompatibilitas.
        data: <String, dynamic>{
          'display_name': fullName.trim(),
          'full_name': fullName.trim(),
        },
        emailRedirectTo: redirectUrl,
      );
      // Tanpa sesi = konfirmasi email aktif. Untuk email yang sudah terdaftar,
      // Supabase (proteksi enumerasi) juga mengembalikan tanpa sesi sehingga
      // UI sengaja menampilkan pesan netral yang sama.
      return response.session != null
          ? SignUpOutcome.signedIn
          : SignUpOutcome.confirmationRequired;
    } catch (error) {
      throw mapSupabaseAuthError(error);
    }
  }

  @override
  Future<void> sendPasswordResetEmail(String email) async {
    try {
      await _auth.resetPasswordForEmail(email.trim(), redirectTo: redirectUrl);
    } catch (error) {
      throw mapSupabaseAuthError(error);
    }
  }

  @override
  Future<void> updatePassword(String newPassword) async {
    try {
      await _auth.updateUser(sb.UserAttributes(password: newPassword));
    } catch (error) {
      throw mapSupabaseAuthError(error);
    }
  }

  @override
  Future<AuthUser> updateDisplayName(String name) async {
    final String clean = name.trim();
    try {
      final sb.UserResponse res = await _auth.updateUser(
        sb.UserAttributes(
          data: <String, dynamic>{'display_name': clean, 'full_name': clean},
        ),
      );
      final AuthUser? user = _toUser(res.user);
      if (user == null) {
        throw const AppFailure(AppFailureKind.unknown);
      }
      final sb.SupabaseClient? client = _client;
      if (client != null) {
        // Trigger tg_touch_row menaikkan version; RLS: hanya baris sendiri.
        await client
            .from('profiles')
            .update(<String, dynamic>{'display_name': clean})
            .eq('id', user.id);
      }
      return user;
    } catch (error) {
      throw mapSupabaseAuthError(error);
    }
  }

  @override
  Future<void> signOut() async {
    try {
      await _auth.signOut(scope: sb.SignOutScope.local);
    } on sb.AuthRetryableFetchException {
      // Offline: sesi lokal sudah dibersihkan klien; token di server akan
      // kedaluwarsa sendiri. Tidak perlu menampilkan error ke pengguna.
    } catch (error) {
      throw mapSupabaseAuthError(error);
    }
  }

  @override
  String? get currentRefreshToken => _auth.currentSession?.refreshToken;

  @override
  Future<AuthUser> signInWithRefreshToken(String refreshToken) async {
    try {
      final sb.AuthResponse response = await _auth.setSession(refreshToken);
      final AuthUser? user = _toUser(response.user ?? response.session?.user);
      if (user == null) {
        throw const AppFailure(AppFailureKind.unauthorized);
      }
      return user;
    } catch (error) {
      throw mapSupabaseAuthError(error);
    }
  }

  static AuthEventType _mapEvent(sb.AuthChangeEvent event) {
    switch (event) {
      case sb.AuthChangeEvent.initialSession:
        return AuthEventType.initialSession;
      case sb.AuthChangeEvent.signedIn:
        return AuthEventType.signedIn;
      case sb.AuthChangeEvent.signedOut:
        return AuthEventType.signedOut;
      case sb.AuthChangeEvent.passwordRecovery:
        return AuthEventType.passwordRecovery;
      case sb.AuthChangeEvent.userUpdated:
        return AuthEventType.userUpdated;
      case sb.AuthChangeEvent.tokenRefreshed:
        return AuthEventType.tokenRefreshed;
      default:
        return AuthEventType.tokenRefreshed;
    }
  }

  static AuthUser? _toUser(sb.User? user) {
    if (user == null) {
      return null;
    }
    final Object? name =
        user.userMetadata?['display_name'] ?? user.userMetadata?['full_name'];
    return AuthUser(
      id: user.id,
      email: user.email ?? '',
      displayName: name is String ? name : null,
    );
  }
}
