import 'package:flutter/foundation.dart';
import 'package:local_auth/local_auth.dart';

/// Apakah perangkat dapat memverifikasi pengguna secara lokal.
enum BiometricAvailability {
  available,

  /// Perangkat tidak punya biometrik maupun kunci layar, atau tidak didukung
  /// (mis. beberapa emulator, Web).
  unavailable,
}

enum BiometricOutcome {
  success,

  /// Pengguna membatalkan atau sidik jari/wajah tidak cocok.
  cancelled,

  /// Terlalu banyak percobaan gagal; coba lagi nanti.
  lockedOut,

  /// Biometrik/kunci layar tidak tersedia atau belum diatur.
  unavailable,

  /// Kesalahan tak terduga dari perangkat.
  failed,
}

/// Verifikasi identitas LOKAL. Hasilnya hanya membuka kunci aplikasi; sesi
/// server tetap dikelola Supabase Auth (Tahap 1/2: biometrik bukan pengganti
/// sesi server).
abstract interface class BiometricAuthenticator {
  Future<BiometricAvailability> availability();

  Future<BiometricOutcome> authenticate({required String reason});
}

/// Implementasi `local_auth`.
///
/// Memakai `biometricOnly: false` sehingga PIN/pola/sandi perangkat dapat
/// menjadi cadangan bila biometrik gagal. Label UI karena itu menyebut
/// "biometrik atau kunci layar".
class LocalAuthBiometricAuthenticator implements BiometricAuthenticator {
  LocalAuthBiometricAuthenticator([LocalAuthentication? auth])
      : _auth = auth ?? LocalAuthentication();

  final LocalAuthentication _auth;

  @override
  Future<BiometricAvailability> availability() async {
    try {
      final bool supported = await _auth.isDeviceSupported();
      return supported
          ? BiometricAvailability.available
          : BiometricAvailability.unavailable;
    } catch (error) {
      debugPrint('Biometric availability check gagal: $error');
      return BiometricAvailability.unavailable;
    }
  }

  @override
  Future<BiometricOutcome> authenticate({required String reason}) async {
    try {
      final bool ok = await _auth.authenticate(
        localizedReason: reason,
        persistAcrossBackgrounding: true,
      );
      return ok ? BiometricOutcome.success : BiometricOutcome.cancelled;
    } on LocalAuthException catch (error) {
      return _mapCode(error.code.name);
    } catch (error) {
      debugPrint('Biometric authenticate gagal: $error');
      return BiometricOutcome.failed;
    }
  }

  /// Dipetakan lewat nama kode (bukan enum) agar tahan perubahan nama anggota
  /// `LocalAuthExceptionCode` antarversi.
  @visibleForTesting
  static BiometricOutcome mapCode(String codeName) => _mapCode(codeName);

  static BiometricOutcome _mapCode(String codeName) {
    final String name = codeName.toLowerCase();
    if (name.contains('cancel') || name.contains('timeout')) {
      return BiometricOutcome.cancelled;
    }
    if (name.contains('lockout')) {
      return BiometricOutcome.lockedOut;
    }
    if (name.contains('nobiometric') ||
        name.contains('nocredential') ||
        name.contains('notavailable') ||
        name.contains('notenrolled') ||
        name.contains('passcodenotset')) {
      return BiometricOutcome.unavailable;
    }
    return BiometricOutcome.failed;
  }
}
