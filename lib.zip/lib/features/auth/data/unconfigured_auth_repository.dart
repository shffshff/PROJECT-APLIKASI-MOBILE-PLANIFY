import '../../../core/error/app_failure.dart';
import '../domain/auth_event.dart';
import '../domain/auth_repository.dart';
import '../domain/auth_user.dart';

/// Dipakai bila `SUPABASE_URL` / `SUPABASE_ANON_KEY` belum diisi saat build
/// (atau inisialisasi Supabase gagal). Semua aksi gagal dengan pesan jelas,
/// tidak ada "mode masuk palsu".
class UnconfiguredAuthRepository implements AuthRepository {
  const UnconfiguredAuthRepository();

  static const AppFailure _failure = AppFailure(
    AppFailureKind.external,
    customTitle: 'Server belum terhubung',
    message: 'Aplikasi belum dikonfigurasi dengan proyek Supabase. '
        'Isi env.json lalu jalankan dengan --dart-define-from-file=env.json '
        '(lihat docs/SETUP_LENGKAP.md).',
  );

  @override
  bool get isConfigured => false;

  @override
  AuthUser? get currentUser => null;

  @override
  Stream<AuthEvent> get events => const Stream<AuthEvent>.empty();

  @override
  Future<AuthUser> signInWithPassword({
    required String email,
    required String password,
  }) =>
      Future<AuthUser>.error(_failure);

  @override
  Future<SignUpOutcome> signUp({
    required String fullName,
    required String email,
    required String password,
  }) =>
      Future<SignUpOutcome>.error(_failure);

  @override
  Future<void> sendPasswordResetEmail(String email) =>
      Future<void>.error(_failure);

  @override
  Future<void> updatePassword(String newPassword) =>
      Future<void>.error(_failure);

  @override
  Future<AuthUser> updateDisplayName(String name) =>
      Future<AuthUser>.error(_failure);

  @override
  Future<void> signOut() async {}

  @override
  String? get currentRefreshToken => null;

  @override
  Future<AuthUser> signInWithRefreshToken(String refreshToken) =>
      Future<AuthUser>.error(_failure);
}
