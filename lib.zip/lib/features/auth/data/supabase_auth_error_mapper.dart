import 'dart:async';

import 'package:supabase_flutter/supabase_flutter.dart';

import '../../../core/error/app_failure.dart';

/// Memetakan error Supabase Auth ke [AppFailure] berbahasa Indonesia.
///
/// Prinsip: tidak menyalahkan pengguna, selalu memberi langkah pemulihan, dan
/// tidak membocorkan detail teknis (detail hanya di `debugDetail`).
AppFailure mapSupabaseAuthError(Object error) {
  if (error is AppFailure) {
    return error;
  }

  if (error is AuthRetryableFetchException) {
    return AppFailure(AppFailureKind.network, debugDetail: error);
  }

  if (error is AuthWeakPasswordException) {
    return AppFailure(
      AppFailureKind.validation,
      customTitle: 'Password terlalu lemah',
      message: 'Gunakan minimal 8 karakter dengan kombinasi huruf dan angka.',
      debugDetail: error,
    );
  }

  if (error is AuthException) {
    return _fromAuthException(error);
  }

  if (error is TimeoutException || _looksLikeNetworkError(error)) {
    return AppFailure(AppFailureKind.network, debugDetail: error);
  }

  return AppFailure(AppFailureKind.unknown, debugDetail: error);
}

AppFailure _fromAuthException(AuthException error) {
  final String code = (error.code ?? '').toLowerCase();
  final String message = error.message.toLowerCase();
  final String status = error.statusCode ?? '';

  bool has(String text) => message.contains(text);

  if (code == 'invalid_credentials' || has('invalid login credentials')) {
    return AppFailure(
      AppFailureKind.unauthorized,
      customTitle: 'Belum bisa masuk',
      message: 'Email atau password belum cocok. Periksa lagi, atau atur '
          'ulang password lewat "Lupa password?".',
      debugDetail: error,
    );
  }
  if (code == 'email_not_confirmed' || has('email not confirmed')) {
    return AppFailure(
      AppFailureKind.unauthorized,
      customTitle: 'Email belum dikonfirmasi',
      message: 'Buka tautan konfirmasi yang dikirim ke emailmu '
          '(cek juga folder spam), lalu masuk kembali.',
      debugDetail: error,
    );
  }
  if (code == 'user_already_exists' ||
      code == 'email_exists' ||
      has('already registered')) {
    return AppFailure(
      AppFailureKind.validation,
      customTitle: 'Email sudah terdaftar',
      message: 'Coba masuk dengan email ini, atau atur ulang passwordnya.',
      debugDetail: error,
    );
  }
  if (code == 'weak_password') {
    return AppFailure(
      AppFailureKind.validation,
      customTitle: 'Password terlalu lemah',
      message: 'Gunakan minimal 8 karakter dengan kombinasi huruf dan angka.',
      debugDetail: error,
    );
  }
  if (code == 'same_password') {
    return AppFailure(
      AppFailureKind.validation,
      customTitle: 'Password sama dengan yang lama',
      message: 'Pilih password baru yang berbeda dari sebelumnya.',
      debugDetail: error,
    );
  }
  if (code == 'over_request_rate_limit' ||
      code == 'over_email_send_rate_limit' ||
      status == '429') {
    return AppFailure(
      AppFailureKind.external,
      customTitle: 'Terlalu banyak percobaan',
      message: 'Tunggu sekitar satu menit, lalu coba lagi.',
      debugDetail: error,
    );
  }
  if (code == 'signup_disabled') {
    return AppFailure(
      AppFailureKind.external,
      customTitle: 'Pendaftaran ditutup',
      message: 'Pendaftaran akun baru sedang tidak tersedia.',
      debugDetail: error,
    );
  }
  if (code == 'otp_expired' ||
      code == 'flow_state_expired' ||
      code == 'flow_state_not_found' ||
      has('expired')) {
    return AppFailure(
      AppFailureKind.unauthorized,
      customTitle: 'Tautan kedaluwarsa',
      message: 'Minta tautan baru lewat "Lupa password?", lalu buka '
          'tautannya segera.',
      debugDetail: error,
    );
  }
  if (code == 'session_not_found' ||
      code == 'refresh_token_not_found' ||
      code == 'refresh_token_already_used' ||
      status == '401') {
    return AppFailure(AppFailureKind.unauthorized, debugDetail: error);
  }
  if (status.startsWith('5')) {
    return AppFailure(AppFailureKind.external, debugDetail: error);
  }
  return AppFailure(AppFailureKind.unknown, debugDetail: error);
}

/// Error jaringan dari `dart:io`/`package:http` dikenali lewat nama tipe agar
/// file ini tetap dapat dikompilasi untuk Web (tanpa `dart:io`).
bool _looksLikeNetworkError(Object error) {
  final String type = error.runtimeType.toString();
  return type.contains('SocketException') ||
      type.contains('ClientException') ||
      type.contains('HandshakeException') ||
      type.contains('TlsException');
}
