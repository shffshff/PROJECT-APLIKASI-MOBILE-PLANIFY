import 'package:flutter/foundation.dart';

/// Pengguna yang sedang masuk. Hanya berisi data yang aman ditampilkan; token
/// sesi tidak pernah keluar dari lapisan data.
@immutable
class AuthUser {
  const AuthUser({required this.id, required this.email, this.displayName});

  /// UUID pengguna di Supabase Auth (`auth.users.id`).
  final String id;
  final String email;

  /// Nama dari `user_metadata.display_name`, bila ada.
  final String? displayName;

  /// Nama untuk sapaan: nama lengkap, atau bagian email sebelum `@`.
  String get shortName {
    final String? name = displayName?.trim();
    if (name != null && name.isNotEmpty) {
      return name.split(RegExp(r'\s+')).first;
    }
    final int at = email.indexOf('@');
    return at > 0 ? email.substring(0, at) : email;
  }

  @override
  bool operator ==(Object other) =>
      other is AuthUser &&
      other.id == id &&
      other.email == email &&
      other.displayName == displayName;

  @override
  int get hashCode => Object.hash(id, email, displayName);

  @override
  String toString() => 'AuthUser($id)';
}
