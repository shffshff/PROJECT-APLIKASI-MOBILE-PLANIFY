import 'package:flutter/foundation.dart';

import 'auth_user.dart';

/// Peristiwa autentikasi yang dipetakan dari backend (Supabase
/// `AuthChangeEvent`) agar lapisan atas tidak bergantung pada paket Supabase.
enum AuthEventType {
  /// Sesi awal saat aplikasi dibuka (ada atau tidak ada pengguna).
  initialSession,
  signedIn,
  signedOut,

  /// Pengguna membuka tautan "atur ulang password" dari email.
  passwordRecovery,
  userUpdated,
  tokenRefreshed,
}

@immutable
class AuthEvent {
  const AuthEvent(this.type, {this.user});

  final AuthEventType type;
  final AuthUser? user;
}

/// Hasil pendaftaran.
enum SignUpOutcome {
  /// Akun dibuat dan sesi langsung aktif (konfirmasi email dimatikan).
  signedIn,

  /// Akun dibuat, tetapi pengguna harus membuka tautan konfirmasi di email.
  confirmationRequired,
}
