/// Validator form autentikasi. Mengembalikan pesan error atau `null` bila valid.
///
/// Kebijakan password (ASUMSI Tahap 4B, selaraskan dengan pengaturan
/// Authentication → Password di dashboard Supabase): minimal 8 karakter,
/// mengandung huruf dan angka.
abstract final class AuthValidators {
  static const int minPasswordLength = 8;
  static const int minNameLength = 2;
  /// Sama dengan check `profiles.display_name` (1–50) di Tahap 2 §7.3.
  static const int maxNameLength = 50;

  static final RegExp _email =
      RegExp(r'^[^\s@]+@[^\s@]+\.[^\s@]{2,}$');
  static final RegExp _hasLetter = RegExp(r'[A-Za-z]');
  static final RegExp _hasDigit = RegExp(r'\d');

  static String? email(String? value) {
    final String text = value?.trim() ?? '';
    if (text.isEmpty) {
      return 'Email wajib diisi.';
    }
    if (!_email.hasMatch(text)) {
      return 'Format email belum benar. Contoh: nama@contoh.id';
    }
    return null;
  }

  /// Untuk login: cukup tidak kosong (aturan kekuatan hanya saat membuat).
  static String? passwordRequired(String? value) {
    if (value == null || value.isEmpty) {
      return 'Password wajib diisi.';
    }
    return null;
  }

  /// Untuk membuat/mengganti password.
  static String? newPassword(String? value) {
    if (value == null || value.isEmpty) {
      return 'Password wajib diisi.';
    }
    if (value.length < minPasswordLength ||
        !_hasLetter.hasMatch(value) ||
        !_hasDigit.hasMatch(value)) {
      return 'Minimal $minPasswordLength karakter, berisi huruf dan angka.';
    }
    return null;
  }

  /// Mengembalikan validator yang membandingkan dengan password asli.
  static FormFieldValidatorString confirmPassword(
    String Function() original,
  ) {
    return (String? value) {
      if (value == null || value.isEmpty) {
        return 'Ulangi password untuk memastikan tidak salah ketik.';
      }
      if (value != original()) {
        return 'Password belum sama. Periksa kembali.';
      }
      return null;
    };
  }

  static String? fullName(String? value) {
    final String text = value?.trim() ?? '';
    if (text.isEmpty) {
      return 'Nama wajib diisi.';
    }
    if (text.length < minNameLength) {
      return 'Nama minimal $minNameLength karakter.';
    }
    if (text.length > maxNameLength) {
      return 'Nama maksimal $maxNameLength karakter.';
    }
    return null;
  }
}

/// Alias agar file ini tidak perlu mengimpor `package:flutter/widgets.dart`.
typedef FormFieldValidatorString = String? Function(String? value);
