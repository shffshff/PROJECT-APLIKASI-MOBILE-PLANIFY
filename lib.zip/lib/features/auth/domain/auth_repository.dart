import 'auth_event.dart';
import 'auth_user.dart';

/// Kontrak autentikasi (Tahap 2: Supabase Auth). Semua kegagalan dilempar
/// sebagai `AppFailure` dengan pesan yang aman ditampilkan ke pengguna.
abstract interface class AuthRepository {
  /// `false` bila URL/anon key Supabase belum diisi saat build.
  bool get isConfigured;

  /// Pengguna dari sesi yang tersimpan, atau `null`.
  AuthUser? get currentUser;

  /// Aliran peristiwa autentikasi (broadcast).
  Stream<AuthEvent> get events;

  Future<AuthUser> signInWithPassword({
    required String email,
    required String password,
  });

  Future<SignUpOutcome> signUp({
    required String fullName,
    required String email,
    required String password,
  });

  /// Mengirim email atur ulang password. Backend sengaja tidak memberi tahu
  /// apakah email terdaftar (mencegah enumerasi akun).
  Future<void> sendPasswordResetEmail(String email);

  /// Mengganti password pengguna yang sesinya sedang dalam mode pemulihan.
  Future<void> updatePassword(String newPassword);

  /// Mengubah nama tampilan (metadata Auth + tabel `profiles`).
  Future<AuthUser> updateDisplayName(String name);

  /// Keluar dari perangkat ini. Sesi lokal selalu dihapus walau offline.
  Future<void> signOut();

  /// Refresh token dari sesi aktif saat ini, atau `null` bila belum masuk.
  String? get currentRefreshToken;

  /// Masuk kembali menggunakan refresh token yang tersimpan di penyimpanan aman.
  Future<AuthUser> signInWithRefreshToken(String refreshToken);
}
