import 'dart:async';

import 'package:flutter/foundation.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../../../core/storage/secure_key_value_store.dart';
import '../data/biometric_authenticator.dart';
import '../domain/auth_event.dart';
import '../domain/auth_repository.dart';
import '../domain/auth_user.dart';
import 'auth_providers.dart';
import 'session_state.dart';

/// Hasil mengaktifkan kunci biometrik.
enum BiometricEnableResult { enabled, cancelled, unavailable, lockedOut, failed }

/// Sumber kebenaran status sesi. Dibaca router (guard) dan seluruh UI.
///
/// Prinsip keamanan:
/// - Biometrik hanya membuka kunci APLIKASI di perangkat ini. Sesi server
///   (Supabase Auth) tetap sumber kebenaran; tanpa sesi, biometrik tidak bisa
///   dipakai untuk masuk.
/// - Penanda biometrik terikat pada ID pengguna (bukan sekadar boolean), jadi
///   tidak berlaku untuk akun lain yang masuk di perangkat yang sama.
class SessionController extends Notifier<SessionState> {
  late final AuthRepository _repository = ref.read(authRepositoryProvider);
  late final SecureKeyValueStore _store = ref.read(secureStoreProvider);
  late final BiometricAuthenticator _biometric =
      ref.read(biometricAuthenticatorProvider);

  StreamSubscription<AuthEvent>? _subscription;
  bool _initialized = false;
  bool _userInitiatedSignOut = false;
  String? _cachedSecret;

  bool get hasCachedSecret => _cachedSecret != null && _cachedSecret!.isNotEmpty;

  void setCachedSecret(String secret) {
    _cachedSecret = secret;
  }

  @override
  SessionState build() {
    _subscription = _repository.events.listen(_onEvent);
    ref.onDispose(() => _subscription?.cancel());
    // Ditunda satu microtask: `state` belum boleh diubah selagi build berjalan.
    unawaited(Future<void>.microtask(_initialize));
    return const SessionState();
  }

  Future<void> _initialize() async {
    final AuthUser? user = _repository.currentUser;
    if (user == null) {
      _initialized = true;
      if (ref.mounted && state.phase == SessionPhase.initializing) {
        state = state.copyWith(phase: SessionPhase.unauthenticated);
      }
      return;
    }
    final bool enabled = await _isBiometricEnabledFor(user.id);
    _initialized = true;
    if (!ref.mounted) {
      return;
    }
    // Peristiwa passwordRecovery yang tiba selama pembacaan tidak boleh
    // ditimpa kembali menjadi "authenticated".
    if (state.phase == SessionPhase.passwordRecovery) {
      state = state.copyWith(biometricEnabled: enabled);
      return;
    }
    // Pembukaan dingin (cold start) dengan sesi tersimpan: langsung ke Home.
    // Biometrik di PLANIFY hanya untuk login kembali setelah logout, bukan App Lock.
    state = SessionState(
      phase: SessionPhase.authenticated,
      user: user,
      biometricEnabled: enabled,
      isLocked: false,
    );
  }

  Future<void> _onEvent(AuthEvent event) async {
    if (!ref.mounted) {
      return;
    }
    switch (event.type) {
      case AuthEventType.initialSession:
        // Keadaan awal ditentukan _initialize() dari currentUser.
        break;
      case AuthEventType.signedIn:
        await _handleSignedIn(event.user);
      case AuthEventType.signedOut:
        _handleSignedOut();
      case AuthEventType.passwordRecovery:
        final AuthUser? recoveryUser = event.user ?? _repository.currentUser;
        state = state.copyWith(
          phase: SessionPhase.passwordRecovery,
          user: recoveryUser,
          isLocked: false,
        );
      case AuthEventType.userUpdated:
      case AuthEventType.tokenRefreshed:
        final AuthUser? updated = event.user;
        if (updated != null && state.isAuthenticated) {
          state = state.copyWith(user: updated);
        }
        if (state.biometricEnabled) {
          final String? token = _repository.currentRefreshToken;
          if (token != null && token.isNotEmpty) {
            unawaited(_store.write(SecureKeys.biometricToken, token));
          }
        }
    }
  }

  Future<void> _handleSignedIn(AuthUser? user) async {
    if (user == null || !_initialized) {
      return;
    }
    _userInitiatedSignOut = false;
    // Supabase dapat memancarkan signedIn lagi saat aplikasi kembali aktif;
    // jangan mereset kunci/halaman untuk pengguna yang sama.
    final bool sameUser = state.user?.id == user.id;
    if (sameUser &&
        (state.phase == SessionPhase.authenticated ||
            state.phase == SessionPhase.passwordRecovery)) {
      if (state.phase == SessionPhase.authenticated) {
        state = state.copyWith(user: user);
      }
      return;
    }
    final String? owner = await _store.read(SecureKeys.biometricOwner);
    if (owner != null && owner != user.id) {
      await _store.delete(SecureKeys.biometricOwner);
      await _store.delete(SecureKeys.biometricEmail);
      await _store.delete(SecureKeys.biometricSecret);
      await _store.delete(SecureKeys.biometricToken);
    } else if (owner == user.id) {
      if (_cachedSecret != null && _cachedSecret!.isNotEmpty) {
        unawaited(_store.write(SecureKeys.biometricSecret, _cachedSecret!));
      }
      if (_repository.currentRefreshToken != null) {
        unawaited(_store.write(
          SecureKeys.biometricToken,
          _repository.currentRefreshToken!,
        ));
      }
    }
    final bool enabled = await _isBiometricEnabledFor(user.id);
    if (!ref.mounted) {
      return;
    }
    // Baru saja memasukkan password → tidak perlu membuka kunci lagi.
    state = SessionState(
      phase: SessionPhase.authenticated,
      user: user,
      biometricEnabled: enabled,
    );
  }

  void _handleSignedOut() {
    final bool expired =
        !_userInitiatedSignOut && state.phase == SessionPhase.authenticated;
    _userInitiatedSignOut = false;
    state = SessionState(
      phase: SessionPhase.unauthenticated,
      sessionExpired: expired,
    );
  }

  Future<bool> _isBiometricEnabledFor(String userId) async {
    try {
      return await _store.read(SecureKeys.biometricOwner) == userId;
    } catch (error) {
      debugPrint('Gagal membaca penanda biometrik: $error');
      return false;
    }
  }

  // ---- Aksi dari UI -------------------------------------------------------

  /// Keluar manual. Sesi lokal dibersihkan. Penanda dan token biometrik
  /// tetap dipertahankan jika pengguna mengaktifkannya, sehingga dapat masuk
  /// kembali lewat biometrik di perangkat ini.
  Future<void> signOut() async {
    _userInitiatedSignOut = true;
    _cachedSecret = null;
    try {
      await _repository.signOut();
    } catch (_) {
      _userInitiatedSignOut = false;
      rethrow;
    } finally {
      if (ref.mounted && _repository.currentUser == null) {
        state = const SessionState(phase: SessionPhase.unauthenticated);
      }
    }
  }

  /// Dipanggil setelah password baru tersimpan pada alur atur ulang.
  void completeRecovery() {
    final AuthUser? user = state.user ?? _repository.currentUser;
    if (user == null) {
      state = const SessionState(phase: SessionPhase.unauthenticated);
      return;
    }
    state = SessionState(phase: SessionPhase.authenticated, user: user);
    unawaited(_refreshBiometricFlag(user.id));
  }

  Future<void> _refreshBiometricFlag(String userId) async {
    final bool enabled = await _isBiometricEnabledFor(userId);
    if (ref.mounted && state.user?.id == userId) {
      state = state.copyWith(biometricEnabled: enabled);
    }
  }

  /// Pengguna membatalkan alur atur ulang password.
  Future<void> cancelRecovery() => signOut();

  /// Membuka kunci aplikasi dengan biometrik/kunci layar.
  Future<BiometricOutcome> unlock({required String reason}) async {
    final BiometricOutcome outcome =
        await _biometric.authenticate(reason: reason);
    if (outcome == BiometricOutcome.success && ref.mounted) {
      state = state.copyWith(isLocked: false);
    }
    return outcome;
  }

  /// Mengaktifkan login biometrik untuk pengguna saat ini. Pengguna harus
  /// lolos verifikasi sekali agar pengaturan terbukti berfungsi.
  Future<BiometricEnableResult> enableBiometric({
    required String reason,
    String? password,
  }) async {
    final AuthUser? user = state.user;
    if (user == null || !state.isAuthenticated) {
      return BiometricEnableResult.failed;
    }
    if (await _biometric.availability() != BiometricAvailability.available) {
      return BiometricEnableResult.unavailable;
    }
    final String? effectiveSecret = password ?? _cachedSecret;
    final BiometricOutcome outcome =
        await _biometric.authenticate(reason: reason);
    switch (outcome) {
      case BiometricOutcome.success:
        await _store.write(SecureKeys.biometricOwner, user.id);
        if (user.email.isNotEmpty) {
          await _store.write(SecureKeys.biometricEmail, user.email);
        }
        if (effectiveSecret != null && effectiveSecret.isNotEmpty) {
          _cachedSecret = effectiveSecret;
          await _store.write(SecureKeys.biometricSecret, effectiveSecret);
        }
        final String? token = _repository.currentRefreshToken;
        if (token != null && token.isNotEmpty) {
          await _store.write(SecureKeys.biometricToken, token);
        }
        if (ref.mounted) {
          state = state.copyWith(biometricEnabled: true);
        }
        return BiometricEnableResult.enabled;
      case BiometricOutcome.cancelled:
        return BiometricEnableResult.cancelled;
      case BiometricOutcome.lockedOut:
        return BiometricEnableResult.lockedOut;
      case BiometricOutcome.unavailable:
        return BiometricEnableResult.unavailable;
      case BiometricOutcome.failed:
        return BiometricEnableResult.failed;
    }
  }

  Future<void> disableBiometric() async {
    _cachedSecret = null;
    await _store.delete(SecureKeys.biometricOwner);
    await _store.delete(SecureKeys.biometricEmail);
    await _store.delete(SecureKeys.biometricSecret);
    await _store.delete(SecureKeys.biometricToken);
    if (ref.mounted) {
      state = state.copyWith(biometricEnabled: false, isLocked: false);
    }
  }

  // ---- Siklus hidup aplikasi ---------------------------------------------

  /// Aplikasi masuk latar belakang.
  void onBackgrounded() {}

  /// Aplikasi kembali aktif. Sesuai arsitektur Planify, biometrik tidak
  /// digunakan sebagai App Lock saat kembali dari latar belakang.
  void onForegrounded() {}
}

final NotifierProvider<SessionController, SessionState>
    sessionControllerProvider =
    NotifierProvider<SessionController, SessionState>(SessionController.new);
