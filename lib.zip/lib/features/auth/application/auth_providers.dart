import 'package:flutter/foundation.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../../../core/config/supabase_bootstrap.dart';
import '../../../core/storage/secure_key_value_store.dart';
import '../data/biometric_authenticator.dart';
import '../data/supabase_auth_repository.dart';
import '../data/unconfigured_auth_repository.dart';
import '../domain/auth_repository.dart';

/// Repository autentikasi. Di test, timpa dengan fake lewat `overrides`.
final Provider<AuthRepository> authRepositoryProvider =
    Provider<AuthRepository>((Ref ref) {
  if (!SupabaseBootstrap.isInitialized) {
    return const UnconfiguredAuthRepository();
  }
  return SupabaseAuthRepository(
    SupabaseBootstrap.client.auth,
    client: SupabaseBootstrap.client,
  );
});

final Provider<SecureKeyValueStore> secureStoreProvider =
    Provider<SecureKeyValueStore>((Ref ref) => FlutterSecureKeyValueStore());

final Provider<BiometricAuthenticator> biometricAuthenticatorProvider =
    Provider<BiometricAuthenticator>(
  (Ref ref) => LocalAuthBiometricAuthenticator(),
);

/// Jam sistem; diganti di test agar logika kunci ulang bisa diuji.
final Provider<DateTime Function()> clockProvider =
    Provider<DateTime Function()>((Ref ref) => DateTime.now);

/// Berapa lama aplikasi boleh di latar belakang sebelum dikunci ulang.
/// ASUMSI Tahap 4B (belum ditetapkan di Tahap 1–3).
const Duration kRelockAfter = Duration(minutes: 1);

/// Ketersediaan biometrik/kunci layar di perangkat (untuk toggle di Profile).
final FutureProvider<BiometricAvailability> biometricAvailabilityProvider =
    FutureProvider.autoDispose<BiometricAvailability>(
  (Ref ref) => ref.read(biometricAuthenticatorProvider).availability(),
);

/// Informasi ketersediaan login biometrik di halaman login.
@immutable
class BiometricLoginInfo {
  const BiometricLoginInfo({
    required this.canLogin,
    this.email,
    this.ownerId,
  });

  final bool canLogin;
  final String? email;
  final String? ownerId;
}

final FutureProvider<BiometricLoginInfo> biometricLoginInfoProvider =
    FutureProvider.autoDispose<BiometricLoginInfo>((Ref ref) async {
  final BiometricAvailability availability =
      await ref.watch(biometricAuthenticatorProvider).availability();
  if (availability != BiometricAvailability.available) {
    return const BiometricLoginInfo(canLogin: false);
  }
  final SecureKeyValueStore store = ref.watch(secureStoreProvider);
  final String? ownerId = await store.read(SecureKeys.biometricOwner);
  final String? secret = await store.read(SecureKeys.biometricSecret);
  final String? token = await store.read(SecureKeys.biometricToken);
  final String? email = await store.read(SecureKeys.biometricEmail);

  final bool hasCredential = (secret != null && secret.isNotEmpty) ||
      (token != null && token.isNotEmpty);

  if (ownerId == null || ownerId.isEmpty || !hasCredential) {
    return const BiometricLoginInfo(canLogin: false);
  }
  return BiometricLoginInfo(
    canLogin: true,
    email: email,
    ownerId: ownerId,
  );
});
