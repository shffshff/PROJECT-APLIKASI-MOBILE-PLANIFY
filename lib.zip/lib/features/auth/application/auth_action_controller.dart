import 'dart:async';

import 'package:flutter/foundation.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../../../core/error/app_failure.dart';
import '../../../core/storage/secure_key_value_store.dart';
import '../data/biometric_authenticator.dart';
import '../domain/auth_event.dart';
import '../domain/auth_repository.dart';
import 'auth_providers.dart';
import 'session_controller.dart';

@immutable
class AuthActionState {
  const AuthActionState({this.isLoading = false, this.failure});

  final bool isLoading;
  final AppFailure? failure;
}

/// Aksi form autentikasi (masuk, daftar, lupa/atur ulang password).
///
/// Dibuat `autoDispose` sehingga status loading/error tidak terbawa antar
/// halaman. Setiap aksi mengembalikan hasil agar halaman dapat menampilkan
/// state sukses; perpindahan halaman akibat sesi dilakukan router.
class AuthActionController extends Notifier<AuthActionState> {
  late final AuthRepository _repository = ref.read(authRepositoryProvider);
  late final SecureKeyValueStore _store = ref.read(secureStoreProvider);
  late final BiometricAuthenticator _biometric =
      ref.read(biometricAuthenticatorProvider);

  @override
  AuthActionState build() => const AuthActionState();

  void clearError() {
    if (state.failure != null) {
      state = const AuthActionState();
    }
  }

  /// Menjalankan [action]; mencegah eksekusi ganda dan mengubah error menjadi
  /// [AppFailure]. Mengembalikan `null` bila gagal atau sedang berjalan.
  Future<T?> _run<T>(Future<T> Function() action) async {
    if (state.isLoading) {
      return null;
    }
    state = const AuthActionState(isLoading: true);
    try {
      final T result = await action();
      if (ref.mounted) {
        state = const AuthActionState();
      }
      return result;
    } catch (error) {
      final AppFailure failure = AppFailure.from(error);
      if (kDebugMode && failure.debugDetail != null) {
        debugPrint('Auth gagal (${failure.kind}): ${failure.debugDetail}');
      }
      if (ref.mounted) {
        state = AuthActionState(failure: failure);
      }
      return null;
    }
  }

  /// `true` bila berhasil. Router memindahkan pengguna lewat event sesi.
  Future<bool> signIn({required String email, required String password}) async {
    final String cleanEmail = email.trim();
    final Object? user = await _run<Object>(
      () => _repository.signInWithPassword(
        email: cleanEmail,
        password: password,
      ),
    );
    if (user != null) {
      ref.read(sessionControllerProvider.notifier).setCachedSecret(password);
    }
    return user != null;
  }

  /// Masuk menggunakan autentikasi biometrik lokal dan memulihkan sesi autentikasi.
  Future<bool> signInWithBiometric({
    String reason = 'Konfirmasi biometrik untuk masuk ke PLANIFY',
  }) async {
    if (state.isLoading) {
      return false;
    }
    state = const AuthActionState(isLoading: true);
    try {
      final String? owner = await _store.read(SecureKeys.biometricOwner);
      final String? email = await _store.read(SecureKeys.biometricEmail);
      final String? secret = await _store.read(SecureKeys.biometricSecret);
      final String? token = await _store.read(SecureKeys.biometricToken);

      final bool hasCredential = (secret != null && secret.isNotEmpty) ||
          (token != null && token.isNotEmpty);

      if (owner == null || owner.isEmpty || !hasCredential) {
        if (ref.mounted) {
          state = const AuthActionState(
            failure: AppFailure(
              AppFailureKind.unauthorized,
              customTitle: 'Biometrik belum siap',
              message:
                  'Kredensial biometrik tidak ditemukan. Silakan masuk menggunakan email dan password.',
            ),
          );
        }
        return false;
      }

      final BiometricOutcome outcome =
          await _biometric.authenticate(reason: reason);

      switch (outcome) {
        case BiometricOutcome.success:
          break; // Lanjutkan ke autentikasi Supabase
        case BiometricOutcome.cancelled:
          if (ref.mounted) {
            state = const AuthActionState();
          }
          return false;
        case BiometricOutcome.lockedOut:
          if (ref.mounted) {
            state = const AuthActionState(
              failure: AppFailure(
                AppFailureKind.external,
                customTitle: 'Terlalu banyak percobaan',
                message:
                    'Sensor biometrik terkunci sementara. Gunakan email dan password atau coba lagi nanti.',
              ),
            );
          }
          return false;
        case BiometricOutcome.unavailable:
          if (ref.mounted) {
            state = const AuthActionState(
              failure: AppFailure(
                AppFailureKind.external,
                customTitle: 'Biometrik tidak tersedia',
                message:
                    'Biometrik atau kunci layar belum tersedia di perangkat ini.',
              ),
            );
          }
          return false;
        case BiometricOutcome.failed:
          if (ref.mounted) {
            state = const AuthActionState(
              failure: AppFailure(
                AppFailureKind.external,
                customTitle: 'Verifikasi biometrik gagal',
                message:
                    'Sidik jari tidak dikenali. Coba lagi atau gunakan email dan password.',
              ),
            );
          }
          return false;
      }

      try {
        if (secret != null &&
            secret.isNotEmpty &&
            email != null &&
            email.isNotEmpty) {
          await _repository.signInWithPassword(
            email: email,
            password: secret,
          );
          ref.read(sessionControllerProvider.notifier).setCachedSecret(secret);
        } else if (token != null && token.isNotEmpty) {
          await _repository.signInWithRefreshToken(token);
        }
        if (ref.mounted) {
          state = const AuthActionState();
        }
        return true;
      } catch (authError) {
        final AppFailure failure = AppFailure.from(authError);
        // HANYA hapus kredensial jika error adalah unauthorized (mis. password telah diubah).
        // Jangan hapus jika kesalahan jaringan atau kendala sementara.
        if (failure.kind == AppFailureKind.unauthorized) {
          await _store.delete(SecureKeys.biometricSecret);
          await _store.delete(SecureKeys.biometricToken);
          ref.invalidate(biometricLoginInfoProvider);
        }
        rethrow;
      }
    } catch (error) {
      final AppFailure failure = AppFailure.from(error);
      if (kDebugMode && failure.debugDetail != null) {
        debugPrint('Biometric sign in gagal: ${failure.debugDetail}');
      }
      if (ref.mounted) {
        state = AuthActionState(failure: failure);
      }
      return false;
    }
  }

  Future<SignUpOutcome?> signUp({
    required String fullName,
    required String email,
    required String password,
  }) {
    return _run<SignUpOutcome>(
      () => _repository.signUp(
        fullName: fullName,
        email: email,
        password: password,
      ),
    );
  }

  Future<bool> sendPasswordReset(String email) async {
    final bool? ok = await _run<bool>(() async {
      await _repository.sendPasswordResetEmail(email);
      return true;
    });
    return ok ?? false;
  }

  /// Menyimpan password baru lalu menyelesaikan mode pemulihan.
  Future<bool> updatePassword(String newPassword) async {
    final bool? ok = await _run<bool>(() async {
      await _repository.updatePassword(newPassword);
      return true;
    });
    if (ok == true) {
      final SessionController sessionCtrl =
          ref.read(sessionControllerProvider.notifier);
      sessionCtrl.setCachedSecret(newPassword);
      if (ref.read(sessionControllerProvider).biometricEnabled) {
        unawaited(ref
            .read(secureStoreProvider)
            .write(SecureKeys.biometricSecret, newPassword));
      }
      sessionCtrl.completeRecovery();
    }
    return ok ?? false;
  }
}

final NotifierProvider<AuthActionController, AuthActionState>
    authActionProvider =
    NotifierProvider.autoDispose<AuthActionController, AuthActionState>(
  AuthActionController.new,
);
