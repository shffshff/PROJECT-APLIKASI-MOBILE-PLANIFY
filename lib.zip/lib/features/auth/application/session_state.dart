import 'package:flutter/foundation.dart';

import '../domain/auth_user.dart';

enum SessionPhase {
  /// Sesi tersimpan dan penanda biometrik sedang dibaca (Splash).
  initializing,
  unauthenticated,
  authenticated,

  /// Pengguna membuka tautan atur ulang password dari email.
  passwordRecovery,
}

/// Status sesi aplikasi yang dibaca oleh router (guard FR-047) dan UI.
@immutable
class SessionState {
  const SessionState({
    this.phase = SessionPhase.initializing,
    this.user,
    this.biometricEnabled = false,
    this.isLocked = false,
    this.sessionExpired = false,
  });

  final SessionPhase phase;
  final AuthUser? user;

  /// Kunci biometrik aktif untuk [user] di perangkat ini.
  final bool biometricEnabled;

  /// Aplikasi terkunci menunggu verifikasi biometrik. Hanya bermakna saat
  /// [phase] == authenticated.
  final bool isLocked;

  /// Sesi berakhir di server (bukan keluar manual); memunculkan banner di
  /// halaman Login.
  final bool sessionExpired;

  bool get isReady => phase != SessionPhase.initializing;
  bool get isAuthenticated => phase == SessionPhase.authenticated;

  SessionState copyWith({
    SessionPhase? phase,
    AuthUser? user,
    bool clearUser = false,
    bool? biometricEnabled,
    bool? isLocked,
    bool? sessionExpired,
  }) {
    return SessionState(
      phase: phase ?? this.phase,
      user: clearUser ? null : (user ?? this.user),
      biometricEnabled: biometricEnabled ?? this.biometricEnabled,
      isLocked: isLocked ?? this.isLocked,
      sessionExpired: sessionExpired ?? this.sessionExpired,
    );
  }

  @override
  bool operator ==(Object other) =>
      other is SessionState &&
      other.phase == phase &&
      other.user == user &&
      other.biometricEnabled == biometricEnabled &&
      other.isLocked == isLocked &&
      other.sessionExpired == sessionExpired;

  @override
  int get hashCode =>
      Object.hash(phase, user, biometricEnabled, isLocked, sessionExpired);

  @override
  String toString() =>
      'SessionState($phase, locked: $isLocked, biometric: $biometricEnabled)';
}
