import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:go_router/go_router.dart';

import '../../../app/router/routes.dart';
import '../../../core/widgets/app_button.dart';
import '../../../core/widgets/app_text_field.dart';
import '../../../core/widgets/password_field.dart';
import '../../../core/widgets/status_banner.dart';
import '../../../theme/app_colors.dart';
import '../../../theme/app_tokens.dart';
import '../application/auth_action_controller.dart';
import '../application/auth_providers.dart';
import '../application/session_controller.dart';
import '../application/session_state.dart';
import '../domain/auth_validators.dart';
import 'widgets/auth_failure_banner.dart';
import 'widgets/auth_layout.dart';

/// S-02 Login.
class LoginPage extends ConsumerStatefulWidget {
  const LoginPage({super.key});

  @override
  ConsumerState<LoginPage> createState() => _LoginPageState();
}

class _LoginPageState extends ConsumerState<LoginPage> {
  final GlobalKey<FormState> _formKey = GlobalKey<FormState>();
  final TextEditingController _email = TextEditingController();
  final TextEditingController _password = TextEditingController();
  final FocusNode _emailFocus = FocusNode();
  final FocusNode _passwordFocus = FocusNode();

  @override
  void dispose() {
    _email.dispose();
    _password.dispose();
    _emailFocus.dispose();
    _passwordFocus.dispose();
    super.dispose();
  }

  Future<void> _submit() async {
    if (ref.read(authActionProvider).isLoading) {
      return;
    }
    final bool valid = _formKey.currentState?.validate() ?? false;
    if (!valid) {
      // Fokus ke field pertama yang bermasalah.
      if (AuthValidators.email(_email.text) != null) {
        _emailFocus.requestFocus();
      } else {
        _passwordFocus.requestFocus();
      }
      return;
    }
    FocusManager.instance.primaryFocus?.unfocus();
    final bool ok = await ref.read(authActionProvider.notifier).signIn(
          email: _email.text,
          password: _password.text,
        );
    if (ok) {
      // Memberi tahu pengelola kata sandi bahwa kredensial valid.
      TextInput.finishAutofillContext();
    }
    // Perpindahan ke Home dilakukan router setelah event sesi diterima.
  }

  Future<void> _submitBiometric() async {
    if (ref.read(authActionProvider).isLoading) {
      return;
    }
    FocusManager.instance.primaryFocus?.unfocus();
    ref.read(authActionProvider.notifier).clearError();
    await ref.read(authActionProvider.notifier).signInWithBiometric();
  }

  @override
  Widget build(BuildContext context) {
    final AuthActionState action = ref.watch(authActionProvider);
    final SessionState session = ref.watch(sessionControllerProvider);
    final bool configured = ref.watch(authRepositoryProvider).isConfigured;
    final AsyncValue<BiometricLoginInfo> biometric =
        ref.watch(biometricLoginInfoProvider);
    final ThemeData theme = Theme.of(context);

    return AuthLayout(
      footer: Column(
        children: <Widget>[
          const AuthSecurityNote(),
          TextButton(
            onPressed: () => context.push(AppRoutes.about),
            child: const Text('Tentang aplikasi'),
          ),
        ],
      ),
      children: <Widget>[
        if (session.sessionExpired)
          const Padding(
            padding: EdgeInsets.only(bottom: AppSpacing.lg),
            child: StatusBanner(
              type: StatusBannerType.warning,
              title: 'Sesi kamu berakhir.',
              message: 'Silakan masuk kembali. Perubahan yang belum '
                  'tersinkron tetap aman di perangkat.',
            ),
          ),
        if (!configured)
          const Padding(
            padding: EdgeInsets.only(bottom: AppSpacing.lg),
            child: StatusBanner(
              type: StatusBannerType.warning,
              title: 'Server belum terhubung.',
              message: 'Isi SUPABASE_URL dan SUPABASE_ANON_KEY di env.json, '
                  'lalu jalankan dengan --dart-define-from-file=env.json.',
            ),
          ),
        const AuthHeader(
          title: 'Masuk ke PLANIFY',
          subtitle: 'Atur hari, jaga fokus.',
        ),
        AuthFailureBanner(failure: action.failure),
        Form(
          key: _formKey,
          child: AutofillGroup(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.stretch,
              children: <Widget>[
                AppTextField(
                  label: 'Email',
                  controller: _email,
                  focusNode: _emailFocus,
                  validator: AuthValidators.email,
                  keyboardType: TextInputType.emailAddress,
                  textInputAction: TextInputAction.next,
                  autofillHints: const <String>[AutofillHints.email],
                  prefixIcon: const Icon(Icons.mail_outline_rounded),
                  enabled: !action.isLoading,
                  onChanged: (_) =>
                      ref.read(authActionProvider.notifier).clearError(),
                ),
                const SizedBox(height: AppSpacing.lg),
                PasswordField(
                  controller: _password,
                  focusNode: _passwordFocus,
                  validator: AuthValidators.passwordRequired,
                  textInputAction: TextInputAction.done,
                  onFieldSubmitted: (_) => _submit(),
                  enabled: !action.isLoading,
                ),
                Align(
                  alignment: Alignment.centerRight,
                  child: TextButton(
                    onPressed: action.isLoading
                        ? null
                        : () => context.push(AppRoutes.forgotPassword),
                    child: const Text('Lupa password?'),
                  ),
                ),
                const SizedBox(height: AppSpacing.sm),
                AppButton(
                  label: 'Masuk',
                  expand: true,
                  isLoading: action.isLoading,
                  onPressed: _submit,
                ),
              ],
            ),
          ),
        ),
        if (biometric.value?.canLogin == true) ...[
          const SizedBox(height: AppSpacing.lg),
          Row(
            children: <Widget>[
              Expanded(
                child: Divider(
                  color: theme.colorScheme.outlineVariant,
                ),
              ),
              Padding(
                padding: const EdgeInsets.symmetric(horizontal: AppSpacing.md),
                child: Text(
                  'atau',
                  style: theme.textTheme.bodySmall?.copyWith(
                    color: context.appColors.textSecondary,
                  ),
                ),
              ),
              Expanded(
                child: Divider(
                  color: theme.colorScheme.outlineVariant,
                ),
              ),
            ],
          ),
          const SizedBox(height: AppSpacing.lg),
          AppButton(
            label: 'Masuk dengan Biometrik',
            icon: Icons.fingerprint_rounded,
            variant: AppButtonVariant.outline,
            expand: true,
            isLoading: action.isLoading,
            onPressed: action.isLoading ? null : _submitBiometric,
          ),
          if (biometric.value?.email != null &&
              biometric.value!.email!.isNotEmpty) ...[
            const SizedBox(height: AppSpacing.xs),
            Center(
              child: Text(
                'Akun tersimpan: ${biometric.value!.email}',
                style: theme.textTheme.bodySmall?.copyWith(
                  color: context.appColors.textSecondary,
                ),
              ),
            ),
          ],
        ],
        const SizedBox(height: AppSpacing.lg),
        Row(
          mainAxisAlignment: MainAxisAlignment.center,
          children: <Widget>[
            Text(
              'Belum punya akun?',
              style: theme.textTheme.bodyMedium!.copyWith(
                color: context.appColors.textSecondary,
              ),
            ),
            TextButton(
              onPressed: action.isLoading
                  ? null
                  : () => context.push(AppRoutes.register),
              child: const Text('Daftar'),
            ),
          ],
        ),
      ],
    );
  }
}
