import 'dart:ui' show lerpDouble;

import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../../../app/launch_animation_controller.dart';
import '../../../core/widgets/planify_logo.dart';

/// The router waits for both this intro and the stored authentication session.
class SplashPage extends ConsumerStatefulWidget {
  const SplashPage({super.key});

  static const Duration introDuration = Duration(milliseconds: 1400);

  @override
  ConsumerState<SplashPage> createState() => _SplashPageState();
}

class _SplashPageState extends ConsumerState<SplashPage>
    with SingleTickerProviderStateMixin {
  late final AnimationController _controller = AnimationController(
    vsync: this,
    duration: SplashPage.introDuration,
  )..addStatusListener(_onStatus);
  bool _started = false;

  void _onStatus(AnimationStatus status) {
    if (status == AnimationStatus.completed) {
      WidgetsBinding.instance.addPostFrameCallback((_) {
        if (mounted) {
          ref.read(launchAnimationCompletedProvider.notifier).complete();
        }
      });
    }
  }

  @override
  void didChangeDependencies() {
    super.didChangeDependencies();
    if (!_started) {
      _started = true;
      if (MediaQuery.disableAnimationsOf(context) ||
          ref.read(launchAnimationCompletedProvider)) {
        _controller.value = 1;
      } else {
        _controller.forward();
      }
    } else if (MediaQuery.disableAnimationsOf(context)) {
      _controller.value = 1;
    }
  }

  @override
  void dispose() {
    _controller.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final ThemeData theme = Theme.of(context);
    final bool dark = theme.brightness == Brightness.dark;
    final Color canvas = dark
        ? PlanifyBrand.darkCanvas
        : PlanifyBrand.lightCanvas;

    return Scaffold(
      backgroundColor: canvas,
      body: Stack(
        fit: StackFit.expand,
        children: <Widget>[
          ExcludeSemantics(
            child: DecoratedBox(
              decoration: BoxDecoration(
                gradient: RadialGradient(
                  center: const Alignment(0.75, -0.65),
                  radius: 1.1,
                  colors: <Color>[
                    PlanifyBrand.purple.withValues(alpha: dark ? 0.16 : 0.08),
                    canvas,
                  ],
                ),
              ),
            ),
          ),
          SafeArea(
            child: Center(
              child: SingleChildScrollView(
                padding: const EdgeInsets.all(32),
                child: ConstrainedBox(
                  constraints: const BoxConstraints(maxWidth: 360),
                  child: AnimatedBuilder(
                    animation: _controller,
                    builder: (BuildContext context, Widget? child) {
                      final double progress = _controller.value;
                      final double reveal = const Interval(
                        0,
                        0.65,
                        curve: Curves.easeOutCubic,
                      ).transform(progress);
                      final double detail = const Interval(
                        0.3,
                        0.9,
                        curve: Curves.easeOut,
                      ).transform(progress);
                      return Column(
                        mainAxisSize: MainAxisSize.min,
                        children: <Widget>[
                          Opacity(
                            opacity: reveal,
                            child: Transform.translate(
                              offset: Offset(0, lerpDouble(22, 0, reveal)!),
                              child: Transform.scale(
                                scale: lerpDouble(0.92, 1, reveal)!,
                                child: child,
                              ),
                            ),
                          ),
                          const SizedBox(height: 22),
                          Opacity(
                            opacity: detail,
                            child: Text(
                              'Atur hari, jaga fokus.',
                              textAlign: TextAlign.center,
                              style: theme.textTheme.titleMedium?.copyWith(
                                color: theme.colorScheme.onSurface,
                              ),
                            ),
                          ),
                          const SizedBox(height: 40),
                          Opacity(
                            opacity: detail,
                            child: SizedBox(
                              width: 88,
                              child: LinearProgressIndicator(
                                value: progress,
                                minHeight: 3,
                                borderRadius: BorderRadius.circular(8),
                                color: dark
                                    ? const Color(0xFFB6ADFF)
                                    : PlanifyBrand.purple,
                                backgroundColor: PlanifyBrand.purple.withValues(
                                  alpha: 0.12,
                                ),
                              ),
                            ),
                          ),
                          const SizedBox(height: 14),
                          Text(
                            'Menyiapkan PLANIFY…',
                            style: theme.textTheme.bodySmall?.copyWith(
                              color: theme.colorScheme.onSurfaceVariant,
                            ),
                          ),
                        ],
                      );
                    },
                    child: const PlanifyLogo(width: 280),
                  ),
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }
}
