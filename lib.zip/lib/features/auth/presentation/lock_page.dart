import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../../../core/widgets/app_button.dart';
import '../../../core/widgets/status_banner.dart';
import '../../../theme/app_colors.dart';
import '../../../theme/app_tokens.dart';
import '../application/session_controller.dart';
import '../application/session_state.dart';
import '../data/biometric_authenticator.dart';
import 'sign_out_flow.dart';
import 'widgets/auth_layout.dart';

/// S-06 Kunci aplikasi. Muncul saat aplikasi dibuka (atau kembali dari latar
/// belakang cukup lama) ketika kunci biometrik aktif.
///
/// Biometrik di sini hanya memverifikasi pemilik perangkat; sesi Supabase
/// yang sudah tersimpan tetap yang memberi akses ke data. Jalan keluar
/// "Masuk dengan password" mengakhiri sesi lokal dan membuka halaman Login.
class LockPage extends ConsumerStatefulWidget {
  const LockPage({super.key});

  @override
  ConsumerState<LockPage> createState() => _LockPageState();
}

class _LockPageState extends ConsumerState<LockPage> {
  bool _busy = false;
  BiometricOutcome? _lastFailure;

  @override
  void initState() {
    super.initState();
    // Langsung tawarkan verifikasi begitu halaman tampil.
    WidgetsBinding.instance.addPostFrameCallback((_) => _unlock());
  }

  Future<void> _unlock() async {
    if (_busy || !mounted) {
      return;
    }
    setState(() {
      _busy = true;
      _lastFailure = null;
    });
    final BiometricOutcome outcome = await ref
        .read(sessionControllerProvider.notifier)
        .unlock(reason: 'Buka PLANIFY');
    if (!mounted) {
      return;
    }
    setState(() {
      _busy = false;
      _lastFailure = outcome == BiometricOutcome.success ? null : outcome;
    });
    // Saat sukses, router memindahkan ke Home karena isLocked menjadi false.
  }

  Future<void> _usePassword() => confirmAndSignOut(
        context,
        ref,
        title: 'Masuk dengan password?',
        message: 'Kamu akan keluar dari perangkat ini, lalu masuk lagi '
            'dengan email dan password.',
        confirmLabel: 'Lanjut',
      );

  ({StatusBannerType type, String text})? _failureText() {
    switch (_lastFailure) {
      case null:
      case BiometricOutcome.success:
        return null;
      case BiometricOutcome.cancelled:
        return (
          type: StatusBannerType.info,
          text: 'Verifikasi dibatalkan. Ketuk tombol di bawah untuk '
              'mencoba lagi.',
        );
      case BiometricOutcome.lockedOut:
        return (
          type: StatusBannerType.warning,
          text: 'Terlalu banyak percobaan. Tunggu sebentar atau gunakan '
              'password.',
        );
      case BiometricOutcome.unavailable:
        return (
          type: StatusBannerType.warning,
          text: 'Biometrik atau kunci layar tidak tersedia di perangkat ini. '
              'Masuk dengan password.',
        );
      case BiometricOutcome.failed:
        return (
          type: StatusBannerType.error,
          text: 'Verifikasi belum berhasil. Coba lagi atau masuk dengan '
              'password.',
        );
    }
  }

  @override
  Widget build(BuildContext context) {
    final SessionState session = ref.watch(sessionControllerProvider);
    final ThemeData theme = Theme.of(context);
    final ({StatusBannerType type, String text})? failure = _failureText();

    return AuthLayout(
      children: <Widget>[
        const AuthHeader(title: 'PLANIFY terkunci'),
        Text(
          session.user?.email ?? '',
          textAlign: TextAlign.center,
          style: theme.textTheme.bodyMedium!.copyWith(
            color: context.appColors.textSecondary,
          ),
        ),
        const SizedBox(height: AppSpacing.xl),
        if (failure != null)
          Padding(
            padding: const EdgeInsets.only(bottom: AppSpacing.lg),
            child: StatusBanner(type: failure.type, message: failure.text),
          ),
        AppButton(
          label: 'Buka dengan biometrik',
          icon: Icons.fingerprint_rounded,
          expand: true,
          isLoading: _busy,
          onPressed: _unlock,
        ),
        const SizedBox(height: AppSpacing.sm),
        AppButton(
          label: 'Masuk dengan password',
          variant: AppButtonVariant.text,
          expand: true,
          onPressed: _busy ? null : _usePassword,
        ),
      ],
    );
  }
}
