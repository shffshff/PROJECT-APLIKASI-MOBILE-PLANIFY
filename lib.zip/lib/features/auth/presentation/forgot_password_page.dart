import 'dart:async';

import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:go_router/go_router.dart';

import '../../../app/router/routes.dart';
import '../../../core/widgets/app_button.dart';
import '../../../core/widgets/app_text_field.dart';
import '../../../theme/app_colors.dart';
import '../../../theme/app_tokens.dart';
import '../application/auth_action_controller.dart';
import '../domain/auth_validators.dart';
import 'widgets/auth_failure_banner.dart';
import 'widgets/auth_layout.dart';

/// S-04 Lupa password. Mengirim tautan atur ulang ke email.
///
/// Pesan sukses sengaja netral ("jika terdaftar") karena backend tidak
/// mengungkap apakah sebuah email punya akun. Tombol kirim ulang memiliki
/// jeda 60 detik agar tidak terkena batas laju email Supabase.
class ForgotPasswordPage extends ConsumerStatefulWidget {
  const ForgotPasswordPage({super.key});

  /// Jeda sebelum tautan boleh dikirim ulang.
  static const int resendSeconds = 60;

  @override
  ConsumerState<ForgotPasswordPage> createState() =>
      _ForgotPasswordPageState();
}

class _ForgotPasswordPageState extends ConsumerState<ForgotPasswordPage> {
  final GlobalKey<FormState> _formKey = GlobalKey<FormState>();
  final TextEditingController _email = TextEditingController();
  final FocusNode _emailFocus = FocusNode();

  Timer? _timer;
  String? _sentTo;
  int _secondsLeft = 0;

  @override
  void dispose() {
    _timer?.cancel();
    _email.dispose();
    _emailFocus.dispose();
    super.dispose();
  }

  void _startCooldown() {
    _timer?.cancel();
    setState(() => _secondsLeft = ForgotPasswordPage.resendSeconds);
    _timer = Timer.periodic(const Duration(seconds: 1), (Timer timer) {
      if (!mounted) {
        timer.cancel();
        return;
      }
      setState(() => _secondsLeft--);
      if (_secondsLeft <= 0) {
        timer.cancel();
      }
    });
  }

  Future<void> _submit() async {
    if (ref.read(authActionProvider).isLoading || _secondsLeft > 0) {
      return;
    }
    if (!(_formKey.currentState?.validate() ?? false)) {
      _emailFocus.requestFocus();
      return;
    }
    FocusManager.instance.primaryFocus?.unfocus();
    final String email = _email.text.trim();
    final bool ok =
        await ref.read(authActionProvider.notifier).sendPasswordReset(email);
    if (ok && mounted) {
      setState(() => _sentTo = email);
      _startCooldown();
    }
  }

  void _backToLogin() {
    if (context.canPop()) {
      context.pop();
    } else {
      context.go(AppRoutes.login);
    }
  }

  @override
  Widget build(BuildContext context) {
    final AuthActionState action = ref.watch(authActionProvider);
    final ThemeData theme = Theme.of(context);
    final String? sentTo = _sentTo;
    final bool coolingDown = _secondsLeft > 0;

    return AuthLayout(
      showBackButton: true,
      children: <Widget>[
        AuthHeader(
          title: sentTo == null ? 'Lupa password?' : 'Cek emailmu',
          subtitle: sentTo == null
              ? 'Masukkan email akunmu. Kami kirim tautan untuk membuat '
                  'password baru.'
              : null,
        ),
        if (sentTo != null) ...<Widget>[
          Semantics(
            liveRegion: true,
            child: Text(
              'Jika $sentTo terdaftar, tautan untuk membuat password baru '
              'sudah dikirim. Buka tautannya dari perangkat ini. Cek juga '
              'folder spam.',
              textAlign: TextAlign.center,
              style: theme.textTheme.bodyMedium!.copyWith(
                color: context.appColors.textSecondary,
              ),
            ),
          ),
          const SizedBox(height: AppSpacing.xl),
        ],
        AuthFailureBanner(failure: action.failure),
        Form(
          key: _formKey,
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.stretch,
            children: <Widget>[
              AppTextField(
                label: 'Email',
                controller: _email,
                focusNode: _emailFocus,
                validator: AuthValidators.email,
                keyboardType: TextInputType.emailAddress,
                textInputAction: TextInputAction.done,
                autofillHints: const <String>[AutofillHints.email],
                prefixIcon: const Icon(Icons.mail_outline_rounded),
                enabled: !action.isLoading,
                onFieldSubmitted: (_) => _submit(),
              ),
              const SizedBox(height: AppSpacing.xl),
              AppButton(
                label: coolingDown
                    ? 'Kirim ulang dalam $_secondsLeft dtk'
                    : (sentTo == null ? 'Kirim tautan' : 'Kirim ulang tautan'),
                expand: true,
                isLoading: action.isLoading,
                onPressed: coolingDown ? null : _submit,
              ),
            ],
          ),
        ),
        const SizedBox(height: AppSpacing.md),
        Align(
          child: TextButton(
            onPressed: _backToLogin,
            child: const Text('Kembali ke halaman masuk'),
          ),
        ),
      ],
    );
  }
}
