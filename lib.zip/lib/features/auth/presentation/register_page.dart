import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:go_router/go_router.dart';

import '../../../app/router/routes.dart';
import '../../../core/widgets/app_button.dart';
import '../../../core/widgets/app_text_field.dart';
import '../../../core/widgets/password_field.dart';
import '../../../theme/app_colors.dart';
import '../../../theme/app_tokens.dart';
import '../application/auth_action_controller.dart';
import '../domain/auth_event.dart';
import '../domain/auth_validators.dart';
import 'widgets/auth_failure_banner.dart';
import 'widgets/auth_layout.dart';

/// S-03 Register.
///
/// Bila Supabase meminta konfirmasi email, halaman berubah menjadi panel
/// "Cek emailmu". Bila sesi langsung aktif, router memindahkan ke Home.
class RegisterPage extends ConsumerStatefulWidget {
  const RegisterPage({super.key});

  @override
  ConsumerState<RegisterPage> createState() => _RegisterPageState();
}

class _RegisterPageState extends ConsumerState<RegisterPage> {
  final GlobalKey<FormState> _formKey = GlobalKey<FormState>();
  final TextEditingController _name = TextEditingController();
  final TextEditingController _email = TextEditingController();
  final TextEditingController _password = TextEditingController();
  final TextEditingController _confirm = TextEditingController();
  final FocusNode _nameFocus = FocusNode();
  final FocusNode _emailFocus = FocusNode();
  final FocusNode _passwordFocus = FocusNode();
  final FocusNode _confirmFocus = FocusNode();

  String? _confirmationEmail;

  @override
  void dispose() {
    _name.dispose();
    _email.dispose();
    _password.dispose();
    _confirm.dispose();
    _nameFocus.dispose();
    _emailFocus.dispose();
    _passwordFocus.dispose();
    _confirmFocus.dispose();
    super.dispose();
  }

  void _focusFirstInvalid() {
    if (AuthValidators.fullName(_name.text) != null) {
      _nameFocus.requestFocus();
    } else if (AuthValidators.email(_email.text) != null) {
      _emailFocus.requestFocus();
    } else if (AuthValidators.newPassword(_password.text) != null) {
      _passwordFocus.requestFocus();
    } else {
      _confirmFocus.requestFocus();
    }
  }

  Future<void> _submit() async {
    if (ref.read(authActionProvider).isLoading) {
      return;
    }
    if (!(_formKey.currentState?.validate() ?? false)) {
      _focusFirstInvalid();
      return;
    }
    FocusManager.instance.primaryFocus?.unfocus();
    final String email = _email.text.trim();
    final SignUpOutcome? outcome =
        await ref.read(authActionProvider.notifier).signUp(
              fullName: _name.text,
              email: email,
              password: _password.text,
            );
    if (outcome == null || !mounted) {
      return;
    }
    TextInput.finishAutofillContext();
    if (outcome == SignUpOutcome.confirmationRequired) {
      setState(() => _confirmationEmail = email);
    }
    // outcome == signedIn: router memindahkan ke Home lewat event sesi.
  }

  @override
  Widget build(BuildContext context) {
    final String? confirmedEmail = _confirmationEmail;
    if (confirmedEmail != null) {
      return _ConfirmationPanel(email: confirmedEmail);
    }

    final AuthActionState action = ref.watch(authActionProvider);

    return AuthLayout(
      showBackButton: true,
      footer: const AuthSecurityNote(),
      children: <Widget>[
        const AuthHeader(
          title: 'Buat akun PLANIFY',
          subtitle: 'Sinkronkan jadwal dan kebiasaanmu di semua perangkat.',
        ),
        AuthFailureBanner(failure: action.failure),
        Form(
          key: _formKey,
          child: AutofillGroup(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.stretch,
              children: <Widget>[
                AppTextField(
                  label: 'Nama lengkap',
                  controller: _name,
                  focusNode: _nameFocus,
                  validator: AuthValidators.fullName,
                  textInputAction: TextInputAction.next,
                  textCapitalization: TextCapitalization.words,
                  autofillHints: const <String>[AutofillHints.name],
                  prefixIcon: const Icon(Icons.person_outline_rounded),
                  maxLength: AuthValidators.maxNameLength,
                  showCounterFrom: 40,
                  isRequired: true,
                  enabled: !action.isLoading,
                ),
                const SizedBox(height: AppSpacing.lg),
                AppTextField(
                  label: 'Email',
                  controller: _email,
                  focusNode: _emailFocus,
                  validator: AuthValidators.email,
                  keyboardType: TextInputType.emailAddress,
                  textInputAction: TextInputAction.next,
                  autofillHints: const <String>[AutofillHints.newUsername],
                  prefixIcon: const Icon(Icons.mail_outline_rounded),
                  isRequired: true,
                  enabled: !action.isLoading,
                ),
                const SizedBox(height: AppSpacing.lg),
                PasswordField(
                  label: 'Password',
                  controller: _password,
                  focusNode: _passwordFocus,
                  validator: AuthValidators.newPassword,
                  helperText: 'Minimal 8 karakter, berisi huruf dan angka.',
                  textInputAction: TextInputAction.next,
                  autofillHints: const <String>[AutofillHints.newPassword],
                  isRequired: true,
                  enabled: !action.isLoading,
                ),
                const SizedBox(height: AppSpacing.lg),
                PasswordField(
                  label: 'Ulangi password',
                  controller: _confirm,
                  focusNode: _confirmFocus,
                  validator: AuthValidators.confirmPassword(
                    () => _password.text,
                  ),
                  textInputAction: TextInputAction.done,
                  onFieldSubmitted: (_) => _submit(),
                  autofillHints: const <String>[AutofillHints.newPassword],
                  isRequired: true,
                  enabled: !action.isLoading,
                ),
                const SizedBox(height: AppSpacing.xl),
                AppButton(
                  label: 'Daftar',
                  expand: true,
                  isLoading: action.isLoading,
                  onPressed: _submit,
                ),
              ],
            ),
          ),
        ),
        const SizedBox(height: AppSpacing.lg),
        Row(
          mainAxisAlignment: MainAxisAlignment.center,
          children: <Widget>[
            Text(
              'Sudah punya akun?',
              style: Theme.of(context).textTheme.bodyMedium!.copyWith(
                    color: context.appColors.textSecondary,
                  ),
            ),
            TextButton(
              onPressed: action.isLoading
                  ? null
                  : () => context.canPop()
                      ? context.pop()
                      : context.go(AppRoutes.login),
              child: const Text('Masuk'),
            ),
          ],
        ),
      ],
    );
  }
}

class _ConfirmationPanel extends StatelessWidget {
  const _ConfirmationPanel({required this.email});

  final String email;

  @override
  Widget build(BuildContext context) {
    final ThemeData theme = Theme.of(context);
    final ColorScheme scheme = theme.colorScheme;

    return AuthLayout(
      children: <Widget>[
        const SizedBox(height: AppSpacing.xxl),
        Icon(
          Icons.mark_email_read_outlined,
          size: 64,
          color: scheme.primary,
        ),
        const SizedBox(height: AppSpacing.lg),
        Semantics(
          header: true,
          liveRegion: true,
          child: Text(
            'Cek emailmu',
            textAlign: TextAlign.center,
            style: theme.textTheme.headlineSmall,
          ),
        ),
        const SizedBox(height: AppSpacing.sm),
        Text(
          'Jika $email belum pernah dipakai, kami mengirim tautan '
          'konfirmasi ke sana. Buka tautannya, lalu kamu akan langsung '
          'masuk ke PLANIFY. Cek juga folder spam.',
          textAlign: TextAlign.center,
          style: theme.textTheme.bodyMedium!.copyWith(
            color: context.appColors.textSecondary,
          ),
        ),
        const SizedBox(height: AppSpacing.xl),
        AppButton(
          label: 'Ke halaman masuk',
          expand: true,
          onPressed: () => context.go(AppRoutes.login),
        ),
      ],
    );
  }
}
