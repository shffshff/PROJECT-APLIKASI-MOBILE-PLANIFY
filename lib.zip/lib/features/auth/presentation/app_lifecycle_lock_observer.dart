import 'package:flutter/widgets.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../application/session_controller.dart';

/// Memberi tahu [SessionController] saat aplikasi masuk/keluar latar belakang
/// agar kunci biometrik dapat dipasang ulang setelah jeda yang cukup lama.
///
/// Hanya `paused` yang dihitung sebagai latar belakang. `inactive` terjadi
/// juga saat dialog sistem (izin, prompt biometrik) tampil, dan tidak boleh
/// memicu kunci ulang.
class AppLifecycleLockObserver extends ConsumerStatefulWidget {
  const AppLifecycleLockObserver({super.key, required this.child});

  final Widget child;

  @override
  ConsumerState<AppLifecycleLockObserver> createState() =>
      _AppLifecycleLockObserverState();
}

class _AppLifecycleLockObserverState
    extends ConsumerState<AppLifecycleLockObserver>
    with WidgetsBindingObserver {
  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addObserver(this);
  }

  @override
  void dispose() {
    WidgetsBinding.instance.removeObserver(this);
    super.dispose();
  }

  @override
  void didChangeAppLifecycleState(AppLifecycleState state) {
    final SessionController controller =
        ref.read(sessionControllerProvider.notifier);
    switch (state) {
      case AppLifecycleState.paused:
        controller.onBackgrounded();
      case AppLifecycleState.resumed:
        controller.onForegrounded();
      case AppLifecycleState.inactive:
      case AppLifecycleState.hidden:
      case AppLifecycleState.detached:
        break;
    }
  }

  @override
  Widget build(BuildContext context) => widget.child;
}
