import 'package:flutter/material.dart';

import '../../../../core/error/app_failure.dart';
import '../../../../core/widgets/status_banner.dart';
import '../../../../theme/app_tokens.dart';

/// Banner error di atas form. Tidak menampilkan apa pun bila [failure] null.
class AuthFailureBanner extends StatelessWidget {
  const AuthFailureBanner({super.key, required this.failure});

  final AppFailure? failure;

  @override
  Widget build(BuildContext context) {
    final AppFailure? value = failure;
    if (value == null) {
      return const SizedBox.shrink();
    }
    return Padding(
      padding: const EdgeInsets.only(bottom: AppSpacing.lg),
      child: StatusBanner(
        type: value.kind == AppFailureKind.network
            ? StatusBannerType.offline
            : StatusBannerType.error,
        title: value.title,
        message: value.userMessage,
      ),
    );
  }
}
