import 'package:flutter/material.dart';

import '../../../../core/widgets/page_container.dart';
import '../../../../core/widgets/planify_logo.dart';
import '../../../../theme/app_colors.dart';
import '../../../../theme/app_tokens.dart';

/// Kerangka halaman autentikasi: konten di tengah, bisa di-scroll saat
/// keyboard muncul, dan dibatasi lebar 720 dp.
class AuthLayout extends StatelessWidget {
  const AuthLayout({
    super.key,
    required this.children,
    this.showBackButton = false,
    this.appBarActions = const <Widget>[],
    this.footer,
  });

  final List<Widget> children;
  final bool showBackButton;
  final List<Widget> appBarActions;
  final Widget? footer;

  @override
  Widget build(BuildContext context) {
    final Widget? footerWidget = footer;
    return Scaffold(
      appBar: showBackButton || appBarActions.isNotEmpty
          ? AppBar(
              automaticallyImplyLeading: showBackButton,
              actions: appBarActions,
            )
          : null,
      body: SafeArea(
        child: LayoutBuilder(
          builder: (BuildContext context, BoxConstraints constraints) {
            return SingleChildScrollView(
              keyboardDismissBehavior: ScrollViewKeyboardDismissBehavior.onDrag,
              child: ConstrainedBox(
                constraints: BoxConstraints(minHeight: constraints.maxHeight),
                child: PageContainer(
                  padding: const EdgeInsets.fromLTRB(
                    AppSpacing.gutter,
                    AppSpacing.xl,
                    AppSpacing.gutter,
                    AppSpacing.xl,
                  ),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.stretch,
                    children: <Widget>[
                      ...children,
                      if (footerWidget != null) ...<Widget>[
                        const SizedBox(height: AppSpacing.xxl),
                        footerWidget,
                      ],
                    ],
                  ),
                ),
              ),
            );
          },
        ),
      ),
    );
  }
}

/// Logo, nama, judul, dan subjudul di bagian atas halaman autentikasi.
class AuthHeader extends StatelessWidget {
  const AuthHeader({super.key, required this.title, this.subtitle});

  final String title;
  final String? subtitle;

  @override
  Widget build(BuildContext context) {
    final ThemeData theme = Theme.of(context);
    final String? sub = subtitle;

    return Column(
      children: <Widget>[
        const SizedBox(height: AppSpacing.lg),
        const PlanifyLogo(width: 210),
        const SizedBox(height: AppSpacing.md),
        Semantics(
          header: true,
          child: Text(
            title,
            textAlign: TextAlign.center,
            style: theme.textTheme.headlineSmall,
          ),
        ),
        if (sub != null) ...<Widget>[
          const SizedBox(height: AppSpacing.xs),
          Text(
            sub,
            textAlign: TextAlign.center,
            style: theme.textTheme.bodyMedium!.copyWith(
              color: context.appColors.textSecondary,
            ),
          ),
        ],
        const SizedBox(height: AppSpacing.xl),
      ],
    );
  }
}

/// Catatan keamanan kecil di dasar halaman Login/Register.
class AuthSecurityNote extends StatelessWidget {
  const AuthSecurityNote({super.key});

  @override
  Widget build(BuildContext context) {
    final Color color = context.appColors.textSecondary;
    return Row(
      mainAxisAlignment: MainAxisAlignment.center,
      children: <Widget>[
        Icon(Icons.verified_user_outlined, size: 14, color: color),
        const SizedBox(width: 6),
        Flexible(
          child: Text(
            'Autentikasi aman melalui Supabase Auth',
            textAlign: TextAlign.center,
            style: Theme.of(
              context,
            ).textTheme.bodySmall!.copyWith(color: color),
          ),
        ),
      ],
    );
  }
}
