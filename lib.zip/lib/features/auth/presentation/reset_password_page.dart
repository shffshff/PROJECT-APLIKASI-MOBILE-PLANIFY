import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../../../core/widgets/app_button.dart';
import '../../../core/widgets/password_field.dart';
import '../../../theme/app_tokens.dart';
import '../application/auth_action_controller.dart';
import '../application/session_controller.dart';
import '../domain/auth_validators.dart';
import 'widgets/auth_failure_banner.dart';
import 'widgets/auth_layout.dart';

/// S-05 Atur ulang password. Hanya bisa dibuka lewat tautan email (mode
/// pemulihan); guard router mengalihkan semua jalur lain.
class ResetPasswordPage extends ConsumerStatefulWidget {
  const ResetPasswordPage({super.key});

  @override
  ConsumerState<ResetPasswordPage> createState() => _ResetPasswordPageState();
}

class _ResetPasswordPageState extends ConsumerState<ResetPasswordPage> {
  final GlobalKey<FormState> _formKey = GlobalKey<FormState>();
  final TextEditingController _password = TextEditingController();
  final TextEditingController _confirm = TextEditingController();
  final FocusNode _passwordFocus = FocusNode();
  final FocusNode _confirmFocus = FocusNode();

  @override
  void dispose() {
    _password.dispose();
    _confirm.dispose();
    _passwordFocus.dispose();
    _confirmFocus.dispose();
    super.dispose();
  }

  Future<void> _submit() async {
    if (ref.read(authActionProvider).isLoading) {
      return;
    }
    if (!(_formKey.currentState?.validate() ?? false)) {
      if (AuthValidators.newPassword(_password.text) != null) {
        _passwordFocus.requestFocus();
      } else {
        _confirmFocus.requestFocus();
      }
      return;
    }
    FocusManager.instance.primaryFocus?.unfocus();
    final ScaffoldMessengerState messenger = ScaffoldMessenger.of(context);
    final bool ok =
        await ref.read(authActionProvider.notifier).updatePassword(
              _password.text,
            );
    if (ok) {
      messenger.showSnackBar(
        const SnackBar(content: Text('Password berhasil diganti.')),
      );
    }
    // Router memindahkan ke Home setelah mode pemulihan selesai.
  }

  @override
  Widget build(BuildContext context) {
    final AuthActionState action = ref.watch(authActionProvider);

    return PopScope(
      // Kembali dari halaman ini = membatalkan pemulihan, bukan sekadar pop.
      canPop: false,
      onPopInvokedWithResult: (bool didPop, Object? result) {
        if (!didPop && !action.isLoading) {
          ref.read(sessionControllerProvider.notifier).cancelRecovery();
        }
      },
      child: AuthLayout(
        appBarActions: <Widget>[
          TextButton(
            onPressed: action.isLoading
                ? null
                : () =>
                    ref.read(sessionControllerProvider.notifier).cancelRecovery(),
            child: const Text('Batal'),
          ),
        ],
        children: <Widget>[
          const AuthHeader(
            title: 'Buat password baru',
            subtitle: 'Gunakan password yang belum pernah kamu pakai di '
                'tempat lain.',
          ),
          AuthFailureBanner(failure: action.failure),
          Form(
            key: _formKey,
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.stretch,
              children: <Widget>[
                PasswordField(
                  label: 'Password baru',
                  controller: _password,
                  focusNode: _passwordFocus,
                  validator: AuthValidators.newPassword,
                  helperText: 'Minimal 8 karakter, berisi huruf dan angka.',
                  textInputAction: TextInputAction.next,
                  autofillHints: const <String>[AutofillHints.newPassword],
                  isRequired: true,
                  enabled: !action.isLoading,
                ),
                const SizedBox(height: AppSpacing.lg),
                PasswordField(
                  label: 'Ulangi password baru',
                  controller: _confirm,
                  focusNode: _confirmFocus,
                  validator: AuthValidators.confirmPassword(
                    () => _password.text,
                  ),
                  textInputAction: TextInputAction.done,
                  onFieldSubmitted: (_) => _submit(),
                  autofillHints: const <String>[AutofillHints.newPassword],
                  isRequired: true,
                  enabled: !action.isLoading,
                ),
                const SizedBox(height: AppSpacing.xl),
                AppButton(
                  label: 'Simpan password',
                  expand: true,
                  isLoading: action.isLoading,
                  onPressed: _submit,
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}
