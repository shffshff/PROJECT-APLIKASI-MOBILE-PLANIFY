import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../../../app/sync/sync_controller.dart';
import '../../../core/error/app_failure.dart';
import '../../../core/notifications/notification_service.dart';
import '../../../core/storage/local_database.dart';
import '../../../core/widgets/confirm_dialog.dart';
import '../../focus/presentation/pomodoro_controller.dart';
import '../../reminder/reminder_scheduler.dart';
import '../application/session_controller.dart';

/// Konfirmasi lalu keluar (S-50). Bila masih ada perubahan yang belum
/// tersinkron, dialog menawarkan "Sinkronkan dulu" (mockup Tahap 3).
///
/// Setelah keluar manual, data akun di perangkat ini dihapus: pengingat
/// dibatalkan, box Hive data pengguna dikosongkan (Tahap 2 §5.1/§15).
Future<void> confirmAndSignOut(
  BuildContext context,
  WidgetRef ref, {
  String title = 'Keluar dari PLANIFY?',
  String message = 'Kamu perlu masuk lagi untuk membuka PLANIFY di '
      'perangkat ini.',
  String confirmLabel = 'Keluar',
}) async {
  final ScaffoldMessengerState messenger = ScaffoldMessenger.of(context);
  final SyncState sync = ref.read(syncControllerProvider);
  final bool hasPending = sync.pending > 0 &&
      sync.phase != SyncPhase.notConfigured;

  final ConfirmResult result = await showConfirmDialog(
    context,
    title: title,
    message: hasPending
        ? '$message Ada ${sync.pending} perubahan yang belum tersinkron dan '
            'akan terhapus dari perangkat ini.'
        : message,
    confirmLabel: confirmLabel,
    isDestructive: true,
    extraActionLabel: hasPending ? 'Sinkronkan dulu' : null,
  );

  if (!context.mounted) {
    return;
  }

  if (result == ConfirmResult.extra) {
    await ref.read(syncControllerProvider.notifier).syncNow();
    final int left = ref.read(syncControllerProvider).pending;
    messenger.showSnackBar(
      SnackBar(
        content: Text(
          left == 0
              ? 'Semua perubahan sudah tersinkron. Kamu bisa keluar sekarang.'
              : 'Masih ada $left perubahan yang belum terkirim. Periksa '
                  'koneksi, lalu coba lagi.',
        ),
      ),
    );
    return;
  }
  if (result != ConfirmResult.confirm) {
    return;
  }

  // Ambil semua dependensi sebelum sesi berakhir (widget bisa dilepas).
  final ReminderScheduler reminders = ref.read(reminderSchedulerProvider);
  final NotificationService notifications =
      ref.read(notificationServiceProvider);
  final LocalDatabase database = ref.read(localDatabaseProvider);
  final ProviderContainer container = ProviderScope.containerOf(context);

  try {
    await ref.read(sessionControllerProvider.notifier).signOut();
  } catch (error) {
    final AppFailure failure = AppFailure.from(error);
    messenger.showSnackBar(
      SnackBar(content: Text('${failure.title}. ${failure.userMessage}')),
    );
    return;
  }

  try {
    await reminders.cancelAll();
    await notifications.cancel(kPomodoroNotificationId);
    await database.clearUserData();
    container.invalidate(pomodoroControllerProvider);
  } catch (error) {
    debugPrint('Pembersihan data lokal setelah keluar gagal: $error');
  }
}
