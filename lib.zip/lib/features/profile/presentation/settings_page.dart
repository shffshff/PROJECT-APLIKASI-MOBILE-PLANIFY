import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:go_router/go_router.dart';
import 'package:timezone/timezone.dart' as tz;

import '../../../app/router/routes.dart';
import '../../../app/theme_mode_controller.dart';
import '../../../core/notifications/notification_service.dart';
import '../../../core/storage/local_box.dart';
import '../../../core/storage/local_database.dart';
import '../../../core/widgets/page_container.dart';
import '../../../core/widgets/section_header.dart';
import '../../../core/widgets/settings_tile.dart';
import '../../../theme/app_tokens.dart';
import '../../auth/application/auth_providers.dart';
import '../../auth/application/session_controller.dart';
import '../../auth/data/biometric_authenticator.dart';
import '../../auto_focus/presentation/auto_focus_controller.dart';
import '../../balance_game/domain/balance_physics.dart';
import '../../navigator/data/navigator_services.dart';
import '../../planner/domain/task_validator.dart';
import '../../timezone_converter/domain/tz_converter.dart';
import '../data/preferences_repository.dart';

/// S-52 Pengaturan (FR-044).
class SettingsPage extends ConsumerWidget {
  const SettingsPage({super.key});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final ThemeMode mode = ref.watch(themeModeProvider);
    final AsyncValue<bool> permission = ref.watch(notificationPermissionProvider);
    final NotificationService notifications =
        ref.watch(notificationServiceProvider);
    final UserPreferences? prefs = ref.watch(userPreferencesProvider).value;
    final AutoFocusState auto = ref.watch(autoFocusControllerProvider);
    final LocalBox device = ref.watch(localDatabaseProvider).deviceSettings;

    String zone = 'Asia/Jakarta';
    try {
      zone = tz.local.name;
    } catch (_) {}
    final AppZone? appZone = TzConverter.fromIana(zone);

    final ReminderOption reminder = ReminderOption.values.firstWhere(
      (ReminderOption o) => o.minutesBefore == prefs?.defaultReminderOffsetMin,
      orElse: () => ReminderOption.none,
    );

    return Scaffold(
      appBar: AppBar(title: const Text('Pengaturan')),
      body: SafeArea(
        child: ListView(
          padding: const EdgeInsets.only(bottom: AppSpacing.xxl),
          children: <Widget>[
            PageContainer(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.stretch,
                children: <Widget>[
                  const SizedBox(height: AppSpacing.lg),
                  const SectionHeader(title: 'Tampilan'),
                  const SizedBox(height: AppSpacing.sm),
                  SegmentedButton<ThemeMode>(
                    segments: const <ButtonSegment<ThemeMode>>[
                      ButtonSegment<ThemeMode>(
                        value: ThemeMode.system,
                        label: Text('Sistem'),
                        icon: Icon(Icons.brightness_auto_rounded),
                      ),
                      ButtonSegment<ThemeMode>(
                        value: ThemeMode.light,
                        label: Text('Terang'),
                        icon: Icon(Icons.light_mode_rounded),
                      ),
                      ButtonSegment<ThemeMode>(
                        value: ThemeMode.dark,
                        label: Text('Gelap'),
                        icon: Icon(Icons.dark_mode_rounded),
                      ),
                    ],
                    selected: <ThemeMode>{mode},
                    onSelectionChanged: (Set<ThemeMode> s) =>
                        ref.read(themeModeProvider.notifier).setMode(s.first),
                  ),
                  const SizedBox(height: AppSpacing.sectionGap),
                  const SectionHeader(title: 'Notifikasi'),
                  Card(
                    margin: EdgeInsets.zero,
                    child: Column(
                      children: <Widget>[
                        SettingsTile.navigation(
                          icon: permission.value == true
                              ? Icons.notifications_active_outlined
                              : Icons.notifications_off_outlined,
                          title: 'Izin notifikasi',
                          subtitle: !notifications.isSupported
                              ? 'Tidak didukung di platform ini'
                              : permission.value == true
                                  ? 'Diizinkan'
                                  : 'Ditolak — pengingat tidak akan muncul',
                          trailingText: permission.value == true ? null : 'Aktifkan',
                          enabled: notifications.isSupported,
                          onTap: () async {
                            final bool ok =
                                await notifications.requestPermission();
                            if (!ok) {
                              await ref
                                  .read(locationServiceProvider)
                                  .openAppSettings();
                            }
                            ref.invalidate(notificationPermissionProvider);
                          },
                        ),
                        ListTile(
                          leading: const Icon(Icons.alarm_rounded),
                          title: const Text('Pengingat default'),
                          subtitle: const Text('Untuk tugas baru'),
                          trailing: DropdownButton<ReminderOption>(
                            value: reminder,
                            underline: const SizedBox.shrink(),
                            items: <DropdownMenuItem<ReminderOption>>[
                              for (final ReminderOption o in ReminderOption.values)
                                DropdownMenuItem<ReminderOption>(
                                  value: o,
                                  child: Text(o.label),
                                ),
                            ],
                            onChanged: (ReminderOption? o) {
                              if (o == null) {
                                return;
                              }
                              ref.read(preferencesRepositoryProvider).save(
                                    defaultReminderOffsetMin: o.minutesBefore,
                                    clearReminder: o.minutesBefore == null,
                                  );
                            },
                          ),
                        ),
                      ],
                    ),
                  ),
                  const SizedBox(height: AppSpacing.sectionGap),
                  const SectionHeader(title: 'Keamanan'),
                  const Card(margin: EdgeInsets.zero, child: BiometricTile()),
                  const SizedBox(height: AppSpacing.sectionGap),
                  const SectionHeader(title: 'Focus & sensor'),
                  Card(
                    margin: EdgeInsets.zero,
                    child: Column(
                      children: <Widget>[
                        SettingsTile.toggle(
                          icon: Icons.screen_rotation_alt_rounded,
                          title: 'Focus Otomatis',
                          subtitle: 'Tawarkan sesi saat ponsel telungkup '
                              '(accelerometer)',
                          value: auto.enabled,
                          enabled: auto.availability !=
                                  SensorAvailability.unsupported ||
                              auto.enabled,
                          disabledReason: 'Tidak didukung di platform ini.',
                          onChanged: (bool v) => ref
                              .read(autoFocusControllerProvider.notifier)
                              .setEnabled(v),
                        ),
                        _GameSensitivityTile(box: device),
                      ],
                    ),
                  ),
                  const SizedBox(height: AppSpacing.sectionGap),
                  const SectionHeader(title: 'Zona waktu'),
                  Card(
                    margin: EdgeInsets.zero,
                    child: SettingsTile.navigation(
                      icon: Icons.public_rounded,
                      title: 'Zona perangkat',
                      subtitle: '$zone${appZone == null ? '' : ' (${appZone.label})'}'
                          ' · mengikuti pengaturan ponsel',
                      trailingText: 'Konversi',
                      onTap: () => context.push(AppRoutes.timezone),
                    ),
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}

/// Toggle login biometrik (dipindah dari Profile, 4B).
class BiometricTile extends ConsumerWidget {
  const BiometricTile({super.key});

  static const String _subtitle = 'Masuk kembali dengan cepat menggunakan '
      'sidik jari setelah logout.';

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final bool enabled = ref.watch(
      sessionControllerProvider.select((s) => s.biometricEnabled),
    );
    final AsyncValue<BiometricAvailability> availability =
        ref.watch(biometricAvailabilityProvider);
    final bool supported =
        availability.value == BiometricAvailability.available;

    return SettingsTile.toggle(
      icon: Icons.fingerprint_rounded,
      title: 'Login biometrik',
      subtitle: _subtitle,
      value: enabled,
      enabled: supported || enabled,
      disabledReason: 'Perangkat ini belum memiliki biometrik atau kunci '
          'layar yang aktif.',
      onChanged: (bool value) => _toggle(context, ref, value),
    );
  }

  Future<void> _toggle(BuildContext context, WidgetRef ref, bool value) async {
    final ScaffoldMessengerState messenger = ScaffoldMessenger.of(context);
    final SessionController controller =
        ref.read(sessionControllerProvider.notifier);

    if (!value) {
      await controller.disableBiometric();
      messenger.showSnackBar(
        const SnackBar(content: Text('Login biometrik dimatikan.')),
      );
      return;
    }

    final BiometricEnableResult result = await controller.enableBiometric(
      reason: 'Aktifkan login biometrik PLANIFY',
    );
    final String? message = switch (result) {
      BiometricEnableResult.enabled => 'Login biometrik diaktifkan.',
      BiometricEnableResult.cancelled => null,
      BiometricEnableResult.lockedOut =>
        'Terlalu banyak percobaan. Coba lagi beberapa saat lagi.',
      BiometricEnableResult.unavailable =>
        'Biometrik atau kunci layar belum tersedia di perangkat ini.',
      BiometricEnableResult.failed => 'Belum berhasil mengaktifkan. Coba lagi.',
    };
    if (message != null) {
      messenger.showSnackBar(SnackBar(content: Text(message)));
    }
  }
}

class _GameSensitivityTile extends StatefulWidget {
  const _GameSensitivityTile({required this.box});

  final LocalBox box;

  @override
  State<_GameSensitivityTile> createState() => _GameSensitivityTileState();
}

class _GameSensitivityTileState extends State<_GameSensitivityTile> {
  static const String _key = 'game_sensitivity';
  late BalanceSensitivity _value =
      BalanceSensitivity.parse(widget.box.getRaw(_key));

  @override
  Widget build(BuildContext context) {
    return ListTile(
      leading: const Icon(Icons.sports_esports_outlined),
      title: const Text('Sensitivitas game'),
      trailing: DropdownButton<BalanceSensitivity>(
        value: _value,
        underline: const SizedBox.shrink(),
        items: <DropdownMenuItem<BalanceSensitivity>>[
          for (final BalanceSensitivity s in BalanceSensitivity.values)
            DropdownMenuItem<BalanceSensitivity>(value: s, child: Text(s.label)),
        ],
        onChanged: (BalanceSensitivity? s) {
          if (s != null) {
            setState(() => _value = s);
            widget.box.putRaw(_key, s.name);
          }
        },
      ),
    );
  }
}
