import 'package:flutter/material.dart';

import '../../../core/widgets/page_container.dart';
import '../../../theme/app_colors.dart';
import '../../../theme/app_tokens.dart';
import '../../auth/presentation/widgets/auth_layout.dart';

/// S-53 Tentang PLANIFY (FR-045). Rute publik: bisa dibuka dari Login.
class AboutPage extends StatelessWidget {
  const AboutPage({super.key});

  static const String version = '0.1.0';

  @override
  Widget build(BuildContext context) {
    final ThemeData theme = Theme.of(context);
    final TextStyle body = theme.textTheme.bodyMedium!;
    final TextStyle muted =
        body.copyWith(color: context.appColors.textSecondary);
    Widget item(String title, String text) => Padding(
          padding: const EdgeInsets.only(bottom: AppSpacing.md),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: <Widget>[
              Text(title, style: theme.textTheme.titleSmall),
              const SizedBox(height: 2),
              Text(text, style: muted),
            ],
          ),
        );

    return Scaffold(
      appBar: AppBar(title: const Text('Tentang PLANIFY')),
      body: SafeArea(
        child: ListView(
          padding: const EdgeInsets.only(bottom: AppSpacing.xxl),
          children: <Widget>[
            PageContainer(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.stretch,
                children: <Widget>[
                  const AuthHeader(
                    title: 'Smart Daily Planner & Productivity Assistant',
                    subtitle: 'Versi $version',
                  ),
                  Text(
                    'Proyek akhir mata kuliah Pemrograman Aplikasi Mobile. '
                    'Dibangun dengan Flutter, Hive (penyimpanan lokal), dan '
                    'Supabase (Auth + PostgreSQL).',
                    style: body,
                  ),
                  const SizedBox(height: AppSpacing.xl),
                  item('Data & privasi',
                      'Data tersimpan dulu di perangkat lalu disinkronkan ke '
                      'akun Supabase-mu. Setiap pengguna hanya bisa membaca '
                      'datanya sendiri (Row Level Security).'),
                  item('AI Assistant',
                      'Usulan AI dibuat di server (Edge Function); kunci '
                      'layanan AI tidak pernah ada di aplikasi. Bila AI tidak '
                      'tersedia, usulan disusun dengan aturan sederhana dan '
                      'diberi label "berbasis aturan (bukan AI)".'),
                  item('Sensor',
                      'Accelerometer hanya untuk Focus Otomatis; gyroscope '
                      'hanya untuk Balance Focus Game. Data sensor tidak '
                      'disimpan.'),
                  item('Biometrik',
                      'Hanya membuka kunci aplikasi di perangkat ini, bukan '
                      'pengganti sesi server.'),
                  item('Hash chain',
                      'Simulasi hash chain lokal SHA-256 untuk mencatat '
                      'pencapaian — bukan blockchain publik.'),
                  item('Sumber data pihak ketiga',
                      'Kurs: Frankfurter (kurs referensi bank sentral). '
                      'Tempat & peta: OpenStreetMap contributors (Overpass '
                      'API, tile OSM).'),
                  const SizedBox(height: AppSpacing.md),
                  OutlinedButton.icon(
                    onPressed: () => showLicensePage(
                      context: context,
                      applicationName: 'PLANIFY',
                      applicationVersion: version,
                    ),
                    icon: const Icon(Icons.description_outlined),
                    label: const Text('Lisensi open source'),
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}
