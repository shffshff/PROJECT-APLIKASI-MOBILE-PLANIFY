import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:go_router/go_router.dart';

import '../../../app/router/routes.dart';
import '../../../app/sync/sync_controller.dart';
import '../../../core/error/app_failure.dart';
import '../../../core/utils/app_date_format.dart';
import '../../../core/widgets/app_button.dart';
import '../../../core/widgets/page_container.dart';
import '../../../core/widgets/section_header.dart';
import '../../../core/widgets/settings_tile.dart';
import '../../../theme/app_colors.dart';
import '../../../theme/app_tokens.dart';
import '../../auth/application/auth_providers.dart';
import '../../auth/application/session_controller.dart';
import '../../auth/domain/auth_user.dart';
import '../../auth/domain/auth_validators.dart';
import '../../auth/presentation/sign_out_flow.dart';

/// S-50 Profile: akun, status sinkron, Alat, Pengaturan, Lainnya, Keluar.
class ProfilePage extends ConsumerWidget {
  const ProfilePage({super.key});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final AuthUser? user = ref.watch(sessionControllerProvider).user;
    final ThemeData theme = Theme.of(context);

    return Scaffold(
      appBar: AppBar(
        title: Text('Profile', style: theme.textTheme.headlineSmall),
      ),
      body: SafeArea(
        child: ListView(
          padding: const EdgeInsets.only(bottom: AppSpacing.xxl),
          children: <Widget>[
            PageContainer(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.stretch,
                children: <Widget>[
                  const SizedBox(height: AppSpacing.md),
                  if (user != null) _AccountCard(user: user),
                  const SizedBox(height: AppSpacing.cardGap),
                  const _SyncCard(),
                  const SizedBox(height: AppSpacing.sectionGap),
                  const SectionHeader(title: 'Alat'),
                  const SizedBox(height: AppSpacing.sm),
                  Card(
                    margin: EdgeInsets.zero,
                    child: Column(
                      children: <Widget>[
                        _nav(context, Icons.repeat_rounded, 'Kebiasaan',
                            AppRoutes.habits),
                        _nav(context, Icons.place_outlined, 'Tempat Produktif',
                            AppRoutes.places),
                        _nav(context, Icons.currency_exchange_rounded,
                            'Budget Helper', AppRoutes.currency),
                        _nav(context, Icons.public_rounded,
                            'Time Zone Planner', AppRoutes.timezone),
                        _nav(context, Icons.sports_esports_outlined,
                            'Balance Focus Game', AppRoutes.focusGame),
                        _nav(context, Icons.history_edu_rounded,
                            'Habit Record',
                            AppRoutes.hashChain),
                      ],
                    ),
                  ),
                  const SizedBox(height: AppSpacing.sectionGap),
                  const SectionHeader(title: 'Pengaturan'),
                  const SizedBox(height: AppSpacing.sm),
                  Card(
                    margin: EdgeInsets.zero,
                    child: SettingsTile.navigation(
                      icon: Icons.tune_rounded,
                      title: 'Pengaturan aplikasi',
                      subtitle: 'Tema, notifikasi, biometrik, sensor',
                      onTap: () => context.push(AppRoutes.profileSettings),
                    ),
                  ),
                  const SizedBox(height: AppSpacing.sectionGap),
                  const SectionHeader(title: 'Lainnya'),
                  const SizedBox(height: AppSpacing.sm),
                  Card(
                    margin: EdgeInsets.zero,
                    child: Column(
                      children: <Widget>[
                        SettingsTile.navigation(
                          icon: Icons.rate_review_outlined,
                          title: 'Kesan & Saran',
                          onTap: () => context.push(AppRoutes.feedback),
                        ),
                        SettingsTile.navigation(
                          icon: Icons.info_outline_rounded,
                          title: 'Tentang PLANIFY',
                          trailingText: 'v0.1.0',
                          onTap: () => context.push(AppRoutes.about),
                        ),
                        if (kDebugMode)
                          SettingsTile.navigation(
                            icon: Icons.widgets_outlined,
                            title: 'Galeri komponen',
                            subtitle: 'Hanya mode debug',
                            onTap: () =>
                                context.push(AppRoutes.componentGallery),
                          ),
                      ],
                    ),
                  ),
                  const SizedBox(height: AppSpacing.xl),
                  AppButton(
                    label: 'Keluar',
                    icon: Icons.logout_rounded,
                    variant: AppButtonVariant.outline,
                    expand: true,
                    onPressed: () => confirmAndSignOut(context, ref),
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _nav(BuildContext context, IconData icon, String title, String path) =>
      SettingsTile.navigation(
        icon: icon,
        title: title,
        onTap: () => context.push(path),
      );
}

class _AccountCard extends ConsumerWidget {
  const _AccountCard({required this.user});

  final AuthUser user;

  Future<void> _edit(BuildContext context, WidgetRef ref) async {
    final String? name = await showModalBottomSheet<String>(
      context: context,
      isScrollControlled: true,
      showDragHandle: true,
      builder: (BuildContext context) => Padding(
        padding:
            EdgeInsets.only(bottom: MediaQuery.viewInsetsOf(context).bottom),
        child: _EditNameSheet(initial: user.displayName ?? ''),
      ),
    );
    if (name == null || !context.mounted) {
      return;
    }
    final ScaffoldMessengerState m = ScaffoldMessenger.of(context);
    try {
      await ref.read(authRepositoryProvider).updateDisplayName(name);
      m.showSnackBar(const SnackBar(content: Text('Profil diperbarui.')));
    } catch (error) {
      final AppFailure f = AppFailure.from(error);
      m.showSnackBar(SnackBar(content: Text('${f.title}. ${f.userMessage}')));
    }
  }

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final ThemeData theme = Theme.of(context);
    final ColorScheme scheme = theme.colorScheme;
    final String name = (user.displayName?.trim().isNotEmpty ?? false)
        ? user.displayName!.trim()
        : user.shortName;
    final List<String> parts = name.split(RegExp(r'\s+'));
    final String initials = parts
        .where((String p) => p.isNotEmpty)
        .take(2)
        .map((String p) => p.characters.first.toUpperCase())
        .join();

    return Card(
      margin: EdgeInsets.zero,
      child: Padding(
        padding: const EdgeInsets.all(AppSpacing.lg),
        child: Row(
          children: <Widget>[
            ExcludeSemantics(
              child: CircleAvatar(
                radius: 28,
                backgroundColor: scheme.primaryContainer,
                child: Text(
                  initials.isEmpty ? '?' : initials,
                  style: theme.textTheme.titleLarge!
                      .copyWith(color: scheme.onPrimaryContainer),
                ),
              ),
            ),
            const SizedBox(width: AppSpacing.lg),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: <Widget>[
                  Text(name,
                      style: theme.textTheme.titleMedium,
                      maxLines: 1,
                      overflow: TextOverflow.ellipsis),
                  Text(
                    user.email,
                    style: theme.textTheme.bodyMedium!
                        .copyWith(color: context.appColors.textSecondary),
                    maxLines: 1,
                    overflow: TextOverflow.ellipsis,
                  ),
                ],
              ),
            ),
            IconButton(
              tooltip: 'Ubah nama',
              icon: const Icon(Icons.edit_outlined),
              onPressed: () => _edit(context, ref),
            ),
          ],
        ),
      ),
    );
  }
}

class _EditNameSheet extends StatefulWidget {
  const _EditNameSheet({required this.initial});

  final String initial;

  @override
  State<_EditNameSheet> createState() => _EditNameSheetState();
}

class _EditNameSheetState extends State<_EditNameSheet> {
  late final TextEditingController _c =
      TextEditingController(text: widget.initial);
  String? _error;

  @override
  void dispose() {
    _c.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return SafeArea(
      child: Padding(
        padding: const EdgeInsets.fromLTRB(
          AppSpacing.lg,
          0,
          AppSpacing.lg,
          AppSpacing.lg,
        ),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: <Widget>[
            Text('Ubah nama', style: Theme.of(context).textTheme.titleLarge),
            const SizedBox(height: AppSpacing.md),
            TextField(
              controller: _c,
              autofocus: true,
              maxLength: AuthValidators.maxNameLength,
              textCapitalization: TextCapitalization.words,
              decoration: InputDecoration(
                labelText: 'Nama lengkap',
                errorText: _error,
              ),
            ),
            const SizedBox(height: AppSpacing.md),
            FilledButton(
              onPressed: () {
                final String? e = AuthValidators.fullName(_c.text);
                if (e != null) {
                  setState(() => _error = e);
                  return;
                }
                Navigator.of(context).pop(_c.text.trim());
              },
              child: const Text('Simpan nama'),
            ),
          ],
        ),
      ),
    );
  }
}

class _SyncCard extends ConsumerWidget {
  const _SyncCard();

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final SyncState s = ref.watch(syncControllerProvider);
    final String last = s.lastSyncAt == null
        ? 'belum pernah'
        : '${AppDateFormat.shortDate(s.lastSyncAt!.toLocal())} '
            '${AppDateFormat.time(s.lastSyncAt!.toLocal())}';
    final (IconData icon, String title) = switch (s.phase) {
      SyncPhase.notConfigured => (
          Icons.cloud_off_rounded,
          'Tersimpan di perangkat (server belum terhubung)',
        ),
      SyncPhase.syncing => (Icons.sync_rounded, 'Menyinkronkan…'),
      SyncPhase.offline => (Icons.cloud_off_rounded, 'Offline · ${s.pending} menunggu'),
      SyncPhase.error => (Icons.sync_problem_rounded, '${s.failed} gagal sinkron'),
      SyncPhase.idle => s.pending > 0
          ? (Icons.cloud_upload_outlined, '${s.pending} perubahan menunggu')
          : (Icons.cloud_done_outlined, 'Semua data tersinkron'),
    };
    return Card(
      margin: EdgeInsets.zero,
      child: SettingsTile.navigation(
        icon: icon,
        title: title,
        subtitle: 'Terakhir: $last'
            '${s.conflicts > 0 ? ' · ${s.conflicts} konflik perlu ditinjau' : ''}',
        onTap: () => context.push(AppRoutes.profileSync),
      ),
    );
  }
}
