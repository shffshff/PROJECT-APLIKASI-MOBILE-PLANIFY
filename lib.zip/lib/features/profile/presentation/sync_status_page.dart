import 'dart:convert';

import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../../../app/sync/sync_controller.dart';
import '../../../core/storage/local_box.dart';
import '../../../core/storage/local_database.dart';
import '../../../core/sync/local_change_signal.dart';
import '../../../core/sync/sync_entity.dart';
import '../../../core/utils/app_date_format.dart';
import '../../../core/widgets/app_button.dart';
import '../../../core/widgets/empty_state.dart';
import '../../../core/widgets/page_container.dart';
import '../../../core/widgets/section_header.dart';
import '../../../theme/app_colors.dart';
import '../../../theme/app_tokens.dart';

/// Status sinkron + peninjauan konflik (FR-050/051, Tahap 2 §10.1).
class SyncStatusPage extends ConsumerStatefulWidget {
  const SyncStatusPage({super.key});

  @override
  ConsumerState<SyncStatusPage> createState() => _SyncStatusPageState();
}

class _SyncStatusPageState extends ConsumerState<SyncStatusPage> {
  bool _busy = false;

  LocalDatabase get _db => ref.read(localDatabaseProvider);

  Future<void> _run(Future<void> Function() action) async {
    setState(() => _busy = true);
    try {
      await action();
    } finally {
      if (mounted) {
        setState(() => _busy = false);
      }
    }
  }

  /// Menerapkan ulang versi lokal yang kalah di atas versi server terbaru
  /// (dikirim sebagai edit baru berstatus pending).
  Future<void> _applyMine(String conflictKey, Map<String, dynamic> c) async {
    final String table = c['table'] as String;
    final String recordKey = c['record_key'] as String;
    final LocalBox box = _db.box(_boxFor(table));
    final Map<String, dynamic>? current = box.getJson(recordKey);
    final Map<String, dynamic> mine =
        Map<String, dynamic>.from(jsonDecode(c['local_json'] as String) as Map);
    if (current != null) {
      await box.putJson(recordKey, <String, dynamic>{
        ...mine,
        'version': current['version'],
        'sync_status': SyncStatus.pending.name,
        'sync_error': null,
      });
    }
    await _db.syncConflicts.delete(conflictKey);
    ref.read(localChangeSignalProvider).notify();
    setState(() {});
  }

  static String _boxFor(String table) => switch (table) {
        'user_preferences' => BoxNames.preferences,
        _ => table,
      };

  static String _tableLabel(String table) => switch (table) {
        'tasks' => 'Tugas',
        'habits' => 'Kebiasaan',
        'habit_logs' => 'Catatan kebiasaan',
        'focus_sessions' => 'Sesi fokus',
        'user_preferences' => 'Preferensi',
        _ => table,
      };

  @override
  Widget build(BuildContext context) {
    final SyncState s = ref.watch(syncControllerProvider);
    final ThemeData theme = Theme.of(context);
    final LocalBox conflicts = _db.syncConflicts;
    final List<String> keys = conflicts.keys.toList()..sort();

    return Scaffold(
      appBar: AppBar(title: const Text('Status sinkron')),
      body: SafeArea(
        child: ListView(
          padding: const EdgeInsets.only(bottom: AppSpacing.xxl),
          children: <Widget>[
            PageContainer(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.stretch,
                children: <Widget>[
                  const SizedBox(height: AppSpacing.lg),
                  Card(
                    margin: EdgeInsets.zero,
                    child: Padding(
                      padding: const EdgeInsets.all(AppSpacing.lg),
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: <Widget>[
                          Text(
                            s.phase == SyncPhase.notConfigured
                                ? 'Server belum terhubung'
                                : 'Terakhir sinkron: ${s.lastSyncAt == null ? 'belum pernah' : '${AppDateFormat.shortDate(s.lastSyncAt!.toLocal())} ${AppDateFormat.time(s.lastSyncAt!.toLocal())}'}',
                            style: theme.textTheme.titleSmall,
                          ),
                          const SizedBox(height: AppSpacing.xs),
                          Text('Menunggu dikirim: ${s.pending}'),
                          Text('Gagal (ditolak server): ${s.failed}'),
                          Text('Konflik untuk ditinjau: ${s.conflicts}'),
                        ],
                      ),
                    ),
                  ),
                  const SizedBox(height: AppSpacing.md),
                  Row(
                    children: <Widget>[
                      Expanded(
                        child: AppButton(
                          label: 'Sinkronkan sekarang',
                          icon: Icons.sync_rounded,
                          expand: true,
                          isLoading: _busy,
                          onPressed: s.phase == SyncPhase.notConfigured
                              ? null
                              : () => _run(() async {
                                    await ref
                                        .read(syncControllerProvider.notifier)
                                        .syncNow();
                                  }),
                        ),
                      ),
                      if (s.failed > 0) ...<Widget>[
                        const SizedBox(width: AppSpacing.sm),
                        Expanded(
                          child: AppButton(
                            label: 'Coba lagi yang gagal',
                            variant: AppButtonVariant.outline,
                            expand: true,
                            onPressed: _busy
                                ? null
                                : () => _run(() => ref
                                    .read(syncControllerProvider.notifier)
                                    .retryFailed()),
                          ),
                        ),
                      ],
                    ],
                  ),
                  const SizedBox(height: AppSpacing.sectionGap),
                  const SectionHeader(title: 'Konflik'),
                  const SizedBox(height: AppSpacing.xs),
                  Text(
                    'Bila data yang sama diubah di dua perangkat saat offline, '
                    'versi server dipakai dan versimu disimpan di sini. Kamu '
                    'bisa menerapkannya lagi atau membuangnya.',
                    style: theme.textTheme.bodySmall!
                        .copyWith(color: context.appColors.textSecondary),
                  ),
                  const SizedBox(height: AppSpacing.sm),
                  if (keys.isEmpty)
                    const EmptyState(
                      icon: Icons.check_circle_outline_rounded,
                      title: 'Tidak ada konflik',
                    )
                  else
                    for (final String k in keys)
                      Builder(builder: (BuildContext context) {
                        final Map<String, dynamic>? c = conflicts.getJson(k);
                        if (c == null) {
                          return const SizedBox.shrink();
                        }
                        Map<String, dynamic> local = <String, dynamic>{};
                        try {
                          local = Map<String, dynamic>.from(
                            jsonDecode(c['local_json'] as String) as Map,
                          );
                        } catch (_) {}
                        final DateTime? at =
                            DateTime.tryParse('${c['detected_at']}')?.toLocal();
                        final String label = (local['title'] ??
                                local['name'] ??
                                local['log_date'] ??
                                c['record_key'])
                            .toString();
                        return Card(
                          margin: const EdgeInsets.only(bottom: AppSpacing.sm),
                          child: Padding(
                            padding: const EdgeInsets.all(AppSpacing.md),
                            child: Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: <Widget>[
                                Text(
                                  '${_tableLabel('${c['table']}')}: $label',
                                  style: theme.textTheme.titleSmall,
                                ),
                                if (at != null)
                                  Text(
                                    'Terdeteksi ${AppDateFormat.shortDate(at)} '
                                    '${AppDateFormat.time(at)}',
                                    style: theme.textTheme.bodySmall,
                                  ),
                                Row(
                                  mainAxisAlignment: MainAxisAlignment.end,
                                  children: <Widget>[
                                    TextButton(
                                      onPressed: () async {
                                        await conflicts.delete(k);
                                        ref
                                            .read(localChangeSignalProvider)
                                            .notify();
                                        setState(() {});
                                      },
                                      child: const Text('Buang versiku'),
                                    ),
                                    FilledButton.tonal(
                                      onPressed: () => _applyMine(k, c),
                                      child: const Text('Terapkan versiku'),
                                    ),
                                  ],
                                ),
                              ],
                            ),
                          ),
                        );
                      }),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}
