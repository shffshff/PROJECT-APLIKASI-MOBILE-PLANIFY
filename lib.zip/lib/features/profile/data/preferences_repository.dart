import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../../../core/storage/local_box.dart';
import '../../../core/storage/local_database.dart';
import '../../../core/sync/local_change_signal.dart';
import '../../../core/sync/remote_gateway.dart';
import '../../../core/sync/sync_entity.dart';
import '../../../core/utils/date_only.dart';
import '../../planner/data/task_repository.dart';

ThemeMode parseThemeMode(Object? v) => switch (v) {
      'light' => ThemeMode.light,
      'dark' => ThemeMode.dark,
      _ => ThemeMode.system,
    };

String themeModeSql(ThemeMode m) => switch (m) {
      ThemeMode.light => 'light',
      ThemeMode.dark => 'dark',
      ThemeMode.system => 'system',
    };

/// Preferensi yang disinkronkan (tabel `public.user_preferences`, FR-044).
@immutable
class UserPreferences implements SyncEntity<UserPreferences> {
  const UserPreferences({
    required this.userId,
    required this.updatedAt,
    this.themeMode = ThemeMode.system,
    this.defaultReminderOffsetMin,
    this.createdAt,
    this.syncInfo = const SyncInfo(),
  });

  static const SyncTableSpec spec = SyncTableSpec(
    table: 'user_preferences',
    boxName: 'preferences',
    pkColumns: <String>['user_id'],
  );

  final String userId;
  final ThemeMode themeMode;

  /// Pengingat bawaan untuk tugas baru (menit sebelum tenggat); `null` =
  /// tanpa pengingat.
  final int? defaultReminderOffsetMin;
  final DateTime? createdAt;
  @override
  final DateTime updatedAt;
  @override
  final SyncInfo syncInfo;

  @override
  DateTime? get deletedAt => null;

  @override
  String get localKey => userId;

  static UserPreferences fromJson(Map<String, dynamic> json) {
    final Object? offset = json['default_reminder_offset_min'];
    return UserPreferences(
      userId: json['user_id'] as String,
      themeMode: parseThemeMode(json['theme_mode']),
      defaultReminderOffsetMin: offset is num ? offset.toInt() : null,
      createdAt: parseTimestamp(json['created_at'])?.toUtc(),
      updatedAt: readUpdatedAt(json),
      syncInfo: SyncInfo.fromJson(json),
    );
  }

  @override
  Map<String, dynamic> toRow() => <String, dynamic>{
        'user_id': userId,
        'theme_mode': themeModeSql(themeMode),
        'default_reminder_offset_min': defaultReminderOffsetMin,
        if (createdAt != null) 'created_at': createdAt!.toUtc().toIso8601String(),
      };

  @override
  UserPreferences withSync(SyncInfo info, {DateTime? updatedAt}) =>
      copyWith(syncInfo: info, updatedAt: updatedAt);

  UserPreferences copyWith({
    ThemeMode? themeMode,
    int? defaultReminderOffsetMin,
    bool clearReminder = false,
    DateTime? updatedAt,
    SyncInfo? syncInfo,
  }) {
    return UserPreferences(
      userId: userId,
      themeMode: themeMode ?? this.themeMode,
      defaultReminderOffsetMin: clearReminder
          ? null
          : (defaultReminderOffsetMin ?? this.defaultReminderOffsetMin),
      createdAt: createdAt,
      updatedAt: updatedAt ?? this.updatedAt,
      syncInfo: syncInfo ?? this.syncInfo,
    );
  }
}

/// Preferensi: tema berlaku per perangkat seketika (juga saat belum masuk),
/// dan bersama pengingat bawaan disinkronkan ke `user_preferences`.
class PreferencesRepository {
  PreferencesRepository({
    required LocalBox device,
    required EntityStore<UserPreferences> store,
    required RemoteGateway? remote,
    required LocalChangeSignal signal,
    required String? Function() userId,
  })  : _device = device,
        _store = store,
        _remote = remote,
        _signal = signal,
        _userId = userId;

  final LocalBox _device;
  final EntityStore<UserPreferences> _store;
  final RemoteGateway? _remote;
  final LocalChangeSignal _signal;
  final String? Function() _userId;

  static const String _themeKey = 'theme_mode';

  ThemeMode deviceTheme() => parseThemeMode(_device.getRaw(_themeKey));

  Future<void> setDeviceTheme(ThemeMode mode) =>
      _device.putRaw(_themeKey, themeModeSql(mode));

  UserPreferences? current() {
    final String? id = _userId();
    return id == null ? null : _store.get(id);
  }

  Stream<List<UserPreferences>> watch() => _store.watch();

  UserPreferences _base(String userId) =>
      current() ??
      UserPreferences(
        userId: userId,
        themeMode: deviceTheme(),
        updatedAt: _store.nowUtc(),
      );

  Future<void> save({
    ThemeMode? themeMode,
    int? defaultReminderOffsetMin,
    bool clearReminder = false,
  }) async {
    if (themeMode != null) {
      await setDeviceTheme(themeMode);
    }
    final String? id = _userId();
    if (id == null) {
      return;
    }
    await _store.saveLocal(_base(id).copyWith(
      themeMode: themeMode,
      defaultReminderOffsetMin: defaultReminderOffsetMin,
      clearReminder: clearReminder,
    ));
    _signal.notify();
  }

  /// Saat sesi aktif: ambil baris server (dibuat trigger saat registrasi)
  /// supaya edit lokal berikutnya memakai jalur UPDATE berversi, bukan
  /// INSERT yang pasti bentrok. Mengembalikan preferensi efektif.
  Future<UserPreferences?> pullInitial() async {
    final String? id = _userId();
    final RemoteGateway? remote = _remote;
    if (id == null || remote == null) {
      return current();
    }
    try {
      final Map<String, dynamic>? row =
          await remote.fetch(UserPreferences.spec.table, <String, Object>{'user_id': id});
      if (row == null) {
        return current();
      }
      final UserPreferences server = UserPreferences.fromJson(row);
      final UserPreferences? local = current();
      if (local != null &&
          local.syncInfo.status == SyncStatus.pending &&
          local.syncInfo.serverVersion == null) {
        // Adopsi versi server, tetap pending → push memakai UPDATE.
        await _store.put(local.withSync(
          SyncInfo(serverVersion: server.syncInfo.serverVersion),
        ));
        return local;
      }
      if (local == null ||
          (local.syncInfo.status != SyncStatus.pending &&
              (server.syncInfo.serverVersion ?? 0) >
                  (local.syncInfo.serverVersion ?? 0))) {
        await _store.put(server);
        await setDeviceTheme(server.themeMode);
        return server;
      }
      return local;
    } catch (error) {
      debugPrint('Preferensi belum bisa ditarik: $error');
      return current();
    }
  }
}

final Provider<EntityStore<UserPreferences>> preferencesStoreProvider =
    Provider<EntityStore<UserPreferences>>(
  (Ref ref) => EntityStore<UserPreferences>(
    ref.watch(localDatabaseProvider).preferences,
    UserPreferences.spec,
    UserPreferences.fromJson,
  ),
);

final Provider<PreferencesRepository> preferencesRepositoryProvider =
    Provider<PreferencesRepository>((Ref ref) {
  final LocalDatabase db = ref.watch(localDatabaseProvider);
  return PreferencesRepository(
    device: db.deviceSettings,
    store: ref.watch(preferencesStoreProvider),
    remote: ref.watch(remoteGatewayProvider),
    signal: ref.watch(localChangeSignalProvider),
    userId: () => ref.read(currentUserIdProvider),
  );
});

/// Preferensi akun saat ini (null bila belum masuk/belum ada).
final StreamProvider<UserPreferences?> userPreferencesProvider =
    StreamProvider<UserPreferences?>((Ref ref) async* {
  final String? id = ref.watch(currentUserIdProvider);
  await for (final List<UserPreferences> all
      in ref.watch(preferencesRepositoryProvider).watch()) {
    UserPreferences? mine;
    for (final UserPreferences p in all) {
      if (p.userId == id) {
        mine = p;
      }
    }
    yield mine;
  }
});
