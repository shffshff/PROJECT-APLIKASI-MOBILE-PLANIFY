import 'package:flutter/foundation.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../../../core/error/app_failure.dart';
import '../../../core/storage/local_database.dart';
import '../../../core/sync/local_change_signal.dart';
import '../../../core/sync/sync_entity.dart';
import '../../../core/utils/date_only.dart';
import '../../auth/application/session_controller.dart';
import '../../hash_chain/data/achievement_repository.dart';
import '../../reminder/reminder_scheduler.dart';
import '../domain/task.dart';
import '../domain/task_priority.dart';

/// Nilai form tugas sebelum disimpan.
@immutable
class TaskDraft {
  const TaskDraft({
    required this.title,
    required this.dueDate,
    this.description,
    this.dueTimeMinutes,
    this.category = TaskCategory.lainnya,
    this.priority = TaskPriority.medium,
    this.reminderAt,
    this.source = TaskSource.manual,
  });

  final String title;
  final String? description;
  final DateTime dueDate;
  final int? dueTimeMinutes;
  final TaskCategory category;
  final TaskPriority priority;

  /// Waktu lokal pengingat; `null` = tanpa pengingat.
  final DateTime? reminderAt;
  final TaskSource source;
}

/// Repository tugas: tulis ke Hive dulu (local-first), lalu jadwalkan
/// pengingat dan beri sinyal ke SyncEngine.
class TaskRepository {
  TaskRepository({
    required EntityStore<Task> store,
    required ReminderScheduler reminders,
    required LocalChangeSignal signal,
    required String? Function() userId,
    Future<void> Function(Map<String, dynamic> data)? onAchievement,
  })  : _store = store,
        _reminders = reminders,
        _signal = signal,
        _userId = userId,
        _onAchievement = onAchievement;

  final EntityStore<Task> _store;
  final ReminderScheduler _reminders;
  final LocalChangeSignal _signal;
  final String? Function() _userId;
  final Future<void> Function(Map<String, dynamic> data)? _onAchievement;

  Stream<List<Task>> watchAll() => _store.watch();

  List<Task> all() => _store.all();

  Task? byId(String id) {
    final Task? task = _store.get(id);
    return task == null || task.isDeleted ? null : task;
  }

  String _requireUser() {
    final String? id = _userId();
    if (id == null) {
      throw const AppFailure(AppFailureKind.unauthorized);
    }
    return id;
  }

  Future<Task> _persist(Task task) async {
    final Task saved = await _store.saveLocal(task);
    await _reminders.syncTask(saved);
    _signal.notify();
    return saved;
  }

  Future<Task> create(TaskDraft draft) {
    final DateTime now = _store.nowUtc();
    final String? description = draft.description?.trim();
    return _persist(
      Task(
        id: Ids.newId(),
        userId: _requireUser(),
        title: draft.title.trim(),
        description:
            description == null || description.isEmpty ? null : description,
        dueDate: DateOnly.of(draft.dueDate),
        dueTimeMinutes: draft.dueTimeMinutes,
        category: draft.category,
        priority: draft.priority,
        reminderAt: draft.reminderAt?.toUtc(),
        source: draft.source,
        createdAt: now,
        updatedAt: now,
      ),
    );
  }

  Future<Task> update(Task original, TaskDraft draft) {
    final String? description = draft.description?.trim();
    return _persist(
      original.copyWith(
        title: draft.title.trim(),
        description:
            description == null || description.isEmpty ? null : description,
        clearDescription: description == null || description.isEmpty,
        dueDate: DateOnly.of(draft.dueDate),
        dueTimeMinutes: draft.dueTimeMinutes,
        clearDueTime: draft.dueTimeMinutes == null,
        category: draft.category,
        priority: draft.priority,
        reminderAt: draft.reminderAt?.toUtc(),
        clearReminder: draft.reminderAt == null,
      ),
    );
  }

  /// Menandai selesai/belum (check `tasks_completed_consistency`).
  Future<Task> setCompleted(Task task, bool completed) async {
    final Task saved = await _persist(
      task.copyWith(
        isCompleted: completed,
        completedAt: completed ? _store.nowUtc() : null,
        clearCompletedAt: !completed,
      ),
    );
    if (completed && !task.isCompleted) {
      await _onAchievement?.call(<String, dynamic>{
        'type': 'task_completed',
        'taskId': task.id,
        'title': task.title,
      });
    }
    return saved;
  }

  /// Soft delete (tidak ada DELETE fisik ke server, Tahap 2 §9).
  Future<void> delete(Task task) async {
    await _persist(task.copyWith(deletedAt: _store.nowUtc()));
  }
}

/// ID pengguna yang sedang masuk.
final Provider<String?> currentUserIdProvider = Provider<String?>(
  (Ref ref) =>
      ref.watch(sessionControllerProvider.select((s) => s.user?.id)),
);

final Provider<EntityStore<Task>> taskStoreProvider =
    Provider<EntityStore<Task>>((Ref ref) {
  return EntityStore<Task>(
    ref.watch(localDatabaseProvider).tasks,
    Task.spec,
    Task.fromJson,
  );
});

final Provider<TaskRepository> taskRepositoryProvider =
    Provider<TaskRepository>((Ref ref) {
  return TaskRepository(
    store: ref.watch(taskStoreProvider),
    reminders: ref.watch(reminderSchedulerProvider),
    signal: ref.watch(localChangeSignalProvider),
    userId: () => ref.read(currentUserIdProvider),
    onAchievement: ref.watch(achievementRepositoryProvider).record,
  );
});

/// Semua tugas aktif milik pengguna di perangkat ini (Hive `watch()`).
final StreamProvider<List<Task>> tasksProvider = StreamProvider<List<Task>>(
  (Ref ref) => ref.watch(taskRepositoryProvider).watchAll(),
);
