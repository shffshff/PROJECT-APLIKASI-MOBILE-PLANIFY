import 'package:flutter/foundation.dart';

import '../../../core/sync/sync_entity.dart';
import '../../../core/utils/date_only.dart';
import 'task_priority.dart';

/// Kategori tugas (check `tasks.category`, Tahap 2 §7.3).
enum TaskCategory {
  kuliah('Kuliah'),
  pekerjaan('Pekerjaan'),
  pribadi('Pribadi'),
  lainnya('Lainnya');

  const TaskCategory(this.label);

  final String label;

  static TaskCategory parse(Object? value) => TaskCategory.values.firstWhere(
        (TaskCategory c) => c.name == value,
        orElse: () => TaskCategory.lainnya,
      );
}

/// Asal tugas (check `tasks.source`).
enum TaskSource {
  manual('manual'),
  aiLlm('ai_llm'),
  ruleBased('rule_based');

  const TaskSource(this.sql);

  final String sql;

  static TaskSource parse(Object? value) => TaskSource.values.firstWhere(
        (TaskSource s) => s.sql == value,
        orElse: () => TaskSource.manual,
      );
}

/// Tugas Planner. Bentuk JSON = kolom tabel `public.tasks` + metadata sinkron.
@immutable
class Task implements SyncEntity<Task> {
  const Task({
    required this.id,
    required this.userId,
    required this.title,
    required this.dueDate,
    required this.createdAt,
    required this.updatedAt,
    this.description,
    this.dueTimeMinutes,
    this.category = TaskCategory.lainnya,
    this.priority = TaskPriority.medium,
    this.isCompleted = false,
    this.completedAt,
    this.reminderAt,
    this.source = TaskSource.manual,
    this.deletedAt,
    this.syncInfo = const SyncInfo(),
  });

  static const SyncTableSpec spec = SyncTableSpec(
    table: 'tasks',
    boxName: 'tasks',
    pkColumns: <String>['id'],
  );

  final String id;
  final String userId;
  final String title;
  final String? description;

  /// Tanggal lokal tanpa jam.
  final DateTime dueDate;

  /// Menit sejak 00:00; `null` = sepanjang hari.
  final int? dueTimeMinutes;
  final TaskCategory category;
  final TaskPriority priority;
  final bool isCompleted;
  final DateTime? completedAt;

  /// Waktu pengingat (UTC). `null` = tanpa pengingat.
  final DateTime? reminderAt;
  final TaskSource source;
  final DateTime createdAt;
  @override
  final DateTime updatedAt;
  @override
  final DateTime? deletedAt;
  @override
  final SyncInfo syncInfo;

  @override
  String get localKey => id;

  bool get isDeleted => deletedAt != null;

  /// Saat tenggat dalam waktu lokal. Tugas tanpa jam dianggap berakhir
  /// pukul 23:59 pada tanggalnya (untuk status "terlambat").
  DateTime get dueMoment {
    final int minutes = dueTimeMinutes ?? (23 * 60 + 59);
    return DateTime(
      dueDate.year,
      dueDate.month,
      dueDate.day,
      minutes ~/ 60,
      minutes % 60,
    );
  }

  bool isOverdue(DateTime now) => !isCompleted && dueMoment.isBefore(now);

  static Task fromJson(Map<String, dynamic> json) {
    final Object? priority = json['priority'];
    return Task(
      id: json['id'] as String,
      userId: json['user_id'] as String,
      title: json['title'] as String,
      description: json['description'] as String?,
      dueDate: DateOnly.parse(json['due_date'] as String),
      dueTimeMinutes: TimeOfDayMinutes.fromSql(json['due_time']),
      category: TaskCategory.parse(json['category']),
      priority: TaskPriority.fromValue(priority is num ? priority.toInt() : 2),
      isCompleted: json['is_completed'] == true,
      completedAt: parseTimestamp(json['completed_at'])?.toUtc(),
      reminderAt: parseTimestamp(json['reminder_at'])?.toUtc(),
      source: TaskSource.parse(json['source']),
      createdAt: parseTimestamp(json['created_at'])?.toUtc() ??
          readUpdatedAt(json),
      updatedAt: readUpdatedAt(json),
      deletedAt: parseTimestamp(json['deleted_at'])?.toUtc(),
      syncInfo: SyncInfo.fromJson(json),
    );
  }

  @override
  Map<String, dynamic> toRow() => <String, dynamic>{
        'id': id,
        'user_id': userId,
        'title': title,
        'description': description,
        'due_date': DateOnly.format(dueDate),
        'due_time': dueTimeMinutes == null
            ? null
            : TimeOfDayMinutes.toSql(dueTimeMinutes!),
        'category': category.name,
        'priority': priority.value,
        'is_completed': isCompleted,
        'completed_at': completedAt?.toUtc().toIso8601String(),
        'reminder_at': reminderAt?.toUtc().toIso8601String(),
        'source': source.sql,
        'created_at': createdAt.toUtc().toIso8601String(),
        'deleted_at': deletedAt?.toUtc().toIso8601String(),
      };

  @override
  Task withSync(SyncInfo info, {DateTime? updatedAt}) =>
      copyWith(syncInfo: info, updatedAt: updatedAt);

  Task copyWith({
    String? title,
    String? description,
    bool clearDescription = false,
    DateTime? dueDate,
    int? dueTimeMinutes,
    bool clearDueTime = false,
    TaskCategory? category,
    TaskPriority? priority,
    bool? isCompleted,
    DateTime? completedAt,
    bool clearCompletedAt = false,
    DateTime? reminderAt,
    bool clearReminder = false,
    TaskSource? source,
    DateTime? updatedAt,
    DateTime? deletedAt,
    SyncInfo? syncInfo,
  }) {
    return Task(
      id: id,
      userId: userId,
      title: title ?? this.title,
      description: clearDescription ? null : (description ?? this.description),
      dueDate: dueDate ?? this.dueDate,
      dueTimeMinutes:
          clearDueTime ? null : (dueTimeMinutes ?? this.dueTimeMinutes),
      category: category ?? this.category,
      priority: priority ?? this.priority,
      isCompleted: isCompleted ?? this.isCompleted,
      completedAt:
          clearCompletedAt ? null : (completedAt ?? this.completedAt),
      reminderAt: clearReminder ? null : (reminderAt ?? this.reminderAt),
      source: source ?? this.source,
      createdAt: createdAt,
      updatedAt: updatedAt ?? this.updatedAt,
      deletedAt: deletedAt ?? this.deletedAt,
      syncInfo: syncInfo ?? this.syncInfo,
    );
  }

  @override
  bool operator ==(Object other) =>
      other is Task &&
      other.id == id &&
      other.updatedAt == updatedAt &&
      other.syncInfo == syncInfo &&
      other.isCompleted == isCompleted &&
      other.deletedAt == deletedAt;

  @override
  int get hashCode => Object.hash(id, updatedAt, syncInfo, isCompleted);
}
