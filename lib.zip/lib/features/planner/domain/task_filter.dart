import 'package:flutter/foundation.dart';

import '../../../core/utils/date_only.dart';
import 'task.dart';
import 'task_priority.dart';

/// Status penyelesaian untuk filter.
enum TaskStatusFilter {
  all('Semua'),
  open('Belum selesai'),
  overdue('Terlambat'),
  done('Selesai');

  const TaskStatusFilter(this.label);

  final String label;
}

enum TaskSort {
  due('Tenggat terdekat'),
  priority('Prioritas tertinggi'),
  newest('Terbaru dibuat');

  const TaskSort(this.label);

  final String label;
}

/// Filter Planner (FR-016). State UI sementara, tidak disimpan.
@immutable
class TaskFilter {
  const TaskFilter({
    this.query = '',
    this.status = TaskStatusFilter.all,
    this.categories = const <TaskCategory>{},
    this.priorities = const <TaskPriority>{},
    this.sort = TaskSort.due,
  });

  final String query;
  final TaskStatusFilter status;
  final Set<TaskCategory> categories;
  final Set<TaskPriority> priorities;
  final TaskSort sort;

  /// Jumlah filter aktif (untuk badge tombol Filter).
  int get activeCount =>
      (status == TaskStatusFilter.all ? 0 : 1) +
      categories.length +
      priorities.length;

  bool get isEmpty => activeCount == 0 && query.trim().isEmpty;

  TaskFilter copyWith({
    String? query,
    TaskStatusFilter? status,
    Set<TaskCategory>? categories,
    Set<TaskPriority>? priorities,
    TaskSort? sort,
  }) {
    return TaskFilter(
      query: query ?? this.query,
      status: status ?? this.status,
      categories: categories ?? this.categories,
      priorities: priorities ?? this.priorities,
      sort: sort ?? this.sort,
    );
  }

  bool matches(Task task, DateTime now) {
    if (task.isDeleted) {
      return false;
    }
    final String q = query.trim().toLowerCase();
    if (q.isNotEmpty &&
        !task.title.toLowerCase().contains(q) &&
        !(task.description?.toLowerCase().contains(q) ?? false)) {
      return false;
    }
    switch (status) {
      case TaskStatusFilter.all:
        break;
      case TaskStatusFilter.open:
        if (task.isCompleted) {
          return false;
        }
      case TaskStatusFilter.overdue:
        if (!task.isOverdue(now)) {
          return false;
        }
      case TaskStatusFilter.done:
        if (!task.isCompleted) {
          return false;
        }
    }
    if (categories.isNotEmpty && !categories.contains(task.category)) {
      return false;
    }
    if (priorities.isNotEmpty && !priorities.contains(task.priority)) {
      return false;
    }
    return true;
  }

  List<Task> apply(Iterable<Task> tasks, DateTime now) {
    final List<Task> out =
        tasks.where((Task t) => matches(t, now)).toList(growable: false);
    return sortTasks(out, sort);
  }
}

/// Urutan stabil: kriteria utama lalu tenggat, lalu judul.
List<Task> sortTasks(List<Task> tasks, TaskSort sort) {
  final List<Task> copy = List<Task>.of(tasks);
  int byDue(Task a, Task b) => a.dueMoment.compareTo(b.dueMoment);
  int byTitle(Task a, Task b) =>
      a.title.toLowerCase().compareTo(b.title.toLowerCase());
  copy.sort((Task a, Task b) {
    final int primary = switch (sort) {
      TaskSort.due => byDue(a, b),
      TaskSort.priority => b.priority.value.compareTo(a.priority.value),
      TaskSort.newest => b.createdAt.compareTo(a.createdAt),
    };
    if (primary != 0) {
      return primary;
    }
    final int due = byDue(a, b);
    return due != 0 ? due : byTitle(a, b);
  });
  return copy;
}

/// Ringkasan hari ini untuk Home (FR-008/009).
@immutable
class DaySummary {
  const DaySummary({
    required this.total,
    required this.completed,
    required this.overdue,
    required this.todayOpen,
    required this.next,
  });

  /// Tugas bertenggat hari ini (selesai maupun belum).
  final int total;
  final int completed;

  /// Tugas belum selesai yang tenggatnya sudah lewat (semua tanggal).
  final int overdue;

  /// Tugas hari ini yang belum selesai, urut prioritas lalu jam.
  final List<Task> todayOpen;

  /// Tugas belum selesai berikutnya yang punya jam dan belum lewat.
  final Task? next;

  double get progress => total == 0 ? 0 : completed / total;

  static DaySummary of(Iterable<Task> tasks, DateTime now) {
    final List<Task> active =
        tasks.where((Task t) => !t.isDeleted).toList(growable: false);
    final List<Task> today = active
        .where((Task t) => DateOnly.isSameDay(t.dueDate, now))
        .toList(growable: false);
    final List<Task> open = sortTasks(
      today.where((Task t) => !t.isCompleted).toList(),
      TaskSort.priority,
    );
    final List<Task> upcoming = sortTasks(
      active
          .where((Task t) =>
              !t.isCompleted &&
              t.dueTimeMinutes != null &&
              t.dueMoment.isAfter(now))
          .toList(),
      TaskSort.due,
    );
    return DaySummary(
      total: today.length,
      completed: today.where((Task t) => t.isCompleted).length,
      overdue: active.where((Task t) => t.isOverdue(now)).length,
      todayOpen: open,
      next: upcoming.isEmpty ? null : upcoming.first,
    );
  }
}
