import '../../../core/utils/date_only.dart';

/// Validasi tugas (FR-015; batas sama dengan check di `public.tasks`).
abstract final class TaskValidator {
  static const int maxTitle = 100;
  static const int maxDescription = 500;

  static String? title(String? value) {
    final String text = value?.trim() ?? '';
    if (text.isEmpty) {
      return 'Judul wajib diisi.';
    }
    if (text.length > maxTitle) {
      return 'Judul maksimal $maxTitle karakter.';
    }
    return null;
  }

  static String? description(String? value) {
    if (value != null && value.length > maxDescription) {
      return 'Deskripsi maksimal $maxDescription karakter.';
    }
    return null;
  }

  /// Tugas BARU tidak boleh bertenggat di masa lalu. Tugas lama yang sudah
  /// lewat boleh diedit tanpa harus memindah tanggalnya.
  static String? dueDate(
    DateTime? date, {
    required DateTime now,
    required bool isNew,
    int? dueTimeMinutes,
  }) {
    if (date == null) {
      return 'Tanggal wajib diisi.';
    }
    if (!isNew) {
      return null;
    }
    final DateTime today = DateOnly.of(now);
    if (DateOnly.of(date).isBefore(today)) {
      return 'Tanggal tidak boleh sebelum hari ini.';
    }
    if (dueTimeMinutes != null && DateOnly.isSameDay(date, now)) {
      final int nowMinutes = now.hour * 60 + now.minute;
      if (dueTimeMinutes < nowMinutes) {
        return 'Waktu sudah lewat. Pilih waktu yang akan datang.';
      }
    }
    return null;
  }

  /// Pengingat harus di masa depan.
  static String? reminder(DateTime? reminderAt, {required DateTime now}) {
    if (reminderAt != null && !reminderAt.isAfter(now)) {
      return 'Waktu pengingat sudah lewat. Pilih yang lebih dekat ke tenggat '
          'atau matikan pengingat.';
    }
    return null;
  }
}

/// Pilihan pengingat relatif terhadap tenggat (mockup S-21: "30 menit
/// sebelum").
enum ReminderOption {
  none('Tanpa pengingat', null),
  atTime('Saat tenggat', 0),
  min10('10 menit sebelum', 10),
  min30('30 menit sebelum', 30),
  hour1('1 jam sebelum', 60),
  day1('1 hari sebelum', 1440);

  const ReminderOption(this.label, this.minutesBefore);

  final String label;
  final int? minutesBefore;

  /// Waktu pengingat (lokal) untuk tenggat [due]; `null` bila [none].
  DateTime? resolve(DateTime due) {
    final int? m = minutesBefore;
    return m == null ? null : due.subtract(Duration(minutes: m));
  }

  /// Menebak opsi dari tugas tersimpan; `null` bila tidak cocok persis.
  static ReminderOption? match(DateTime due, DateTime? reminderLocal) {
    if (reminderLocal == null) {
      return ReminderOption.none;
    }
    final int diff = due.difference(reminderLocal).inMinutes;
    for (final ReminderOption o in ReminderOption.values) {
      if (o.minutesBefore == diff) {
        return o;
      }
    }
    return null;
  }
}
