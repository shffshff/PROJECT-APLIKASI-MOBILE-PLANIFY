/// Prioritas tugas. [value] sama dengan kolom `tasks.priority` (smallint 1–3)
/// pada rancangan Supabase Tahap 2 §7.2.
enum TaskPriority {
  low(1, 'Rendah'),
  medium(2, 'Sedang'),
  high(3, 'Tinggi');

  const TaskPriority(this.value, this.label);

  final int value;
  final String label;

  static TaskPriority fromValue(int value) {
    return TaskPriority.values.firstWhere(
      (priority) => priority.value == value,
      orElse: () => TaskPriority.medium,
    );
  }
}
