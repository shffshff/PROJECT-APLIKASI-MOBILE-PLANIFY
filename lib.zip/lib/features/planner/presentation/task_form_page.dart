import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:go_router/go_router.dart';

import '../../../app/router/routes.dart';
import '../../../core/error/app_failure.dart';
import '../../../core/notifications/notification_service.dart';
import '../../../core/utils/app_date_format.dart';
import '../../../core/utils/date_only.dart';
import '../../../core/widgets/app_button.dart';
import '../../../core/widgets/app_text_field.dart';
import '../../../core/widgets/confirm_dialog.dart';
import '../../../core/widgets/empty_state.dart';
import '../../../core/widgets/page_container.dart';
import '../../../core/widgets/status_banner.dart';
import '../../../theme/app_tokens.dart';
import '../../profile/data/preferences_repository.dart';
import '../data/task_repository.dart';
import '../domain/task.dart';
import '../domain/task_priority.dart';
import '../domain/task_validator.dart';

/// S-21 Tambah/Edit tugas (FR-010, FR-012, FR-015, FR-017).
class TaskFormPage extends ConsumerStatefulWidget {
  const TaskFormPage({super.key, this.taskId, this.initialDate});

  /// `null` = tugas baru.
  final String? taskId;
  final DateTime? initialDate;

  /// Pengingat untuk tugas tanpa jam dihitung dari jam ini (ASUMSI 4C).
  static const int defaultReminderBaseMinutes = 8 * 60;

  @override
  ConsumerState<TaskFormPage> createState() => _TaskFormPageState();
}

class _TaskFormPageState extends ConsumerState<TaskFormPage> {
  final GlobalKey<FormState> _formKey = GlobalKey<FormState>();
  final TextEditingController _title = TextEditingController();
  final TextEditingController _description = TextEditingController();
  final FocusNode _titleFocus = FocusNode();

  Task? _original;
  bool _missing = false;
  late DateTime _date;
  int? _time;
  TaskCategory _category = TaskCategory.kuliah;
  TaskPriority _priority = TaskPriority.medium;
  ReminderOption _reminder = ReminderOption.none;

  /// Pengingat lama yang tidak cocok dengan pilihan baku (dipertahankan
  /// sampai pengguna memilih yang lain).
  DateTime? _customReminder;
  String? _dateError;
  String? _reminderError;
  bool _saving = false;
  bool _dirty = false;

  bool get _isNew => widget.taskId == null;

  @override
  void initState() {
    super.initState();
    final DateTime today = DateOnly.of(DateTime.now());
    _date = widget.initialDate == null
        ? today
        : DateOnly.of(widget.initialDate!);
    if (_date.isBefore(today)) {
      _date = today;
    }
    final String? id = widget.taskId;
    if (id == null) {
      // Pengingat bawaan dari Pengaturan (FR-044), bila jatuh di masa depan.
      final int? offset = ref
          .read(preferencesRepositoryProvider)
          .current()
          ?.defaultReminderOffsetMin;
      for (final ReminderOption o in ReminderOption.values) {
        if (offset != null && o.minutesBefore == offset) {
          final DateTime? at = o.resolve(_reminderBase());
          if (at != null && at.isAfter(DateTime.now())) {
            _reminder = o;
          }
        }
      }
    }
    if (id != null) {
      final Task? task = ref.read(taskRepositoryProvider).byId(id);
      if (task == null) {
        _missing = true;
        return;
      }
      _original = task;
      _title.text = task.title;
      _description.text = task.description ?? '';
      _date = task.dueDate;
      _time = task.dueTimeMinutes;
      _category = task.category;
      _priority = task.priority;
      final DateTime? reminder = task.reminderAt?.toLocal();
      final ReminderOption? matched =
          ReminderOption.match(_reminderBase(), reminder);
      if (matched == null) {
        _customReminder = reminder;
      } else {
        _reminder = matched;
      }
    }
    _title.addListener(_markDirty);
    _description.addListener(_markDirty);
  }

  @override
  void dispose() {
    _title.dispose();
    _description.dispose();
    _titleFocus.dispose();
    super.dispose();
  }

  void _markDirty() {
    if (!_dirty) {
      setState(() => _dirty = true);
    }
  }

  void _change(VoidCallback fn) {
    setState(() {
      fn();
      _dirty = true;
      _dateError = null;
      _reminderError = null;
    });
  }

  DateTime _reminderBase() {
    final int m = _time ?? TaskFormPage.defaultReminderBaseMinutes;
    return DateTime(_date.year, _date.month, _date.day, m ~/ 60, m % 60);
  }

  DateTime? get _reminderAt =>
      _customReminder ?? _reminder.resolve(_reminderBase());

  Future<void> _pickDate() async {
    final DateTime today = DateOnly.of(DateTime.now());
    final DateTime? picked = await showDatePicker(
      context: context,
      initialDate: _date,
      firstDate: _isNew ? today : DateTime(today.year - 5),
      lastDate: DateTime(today.year + 5),
      helpText: 'Pilih tanggal tenggat',
    );
    if (picked != null) {
      _change(() => _date = DateOnly.of(picked));
    }
  }

  Future<void> _pickTime() async {
    final int current = _time ?? 9 * 60;
    final TimeOfDay? picked = await showTimePicker(
      context: context,
      initialTime: TimeOfDay(hour: current ~/ 60, minute: current % 60),
      helpText: 'Pilih waktu tenggat',
    );
    if (picked != null) {
      _change(() => _time = picked.hour * 60 + picked.minute);
    }
  }

  Future<bool> _confirmDiscard() async {
    if (!_dirty) {
      return true;
    }
    final ConfirmResult r = await showConfirmDialog(
      context,
      title: 'Buang perubahan?',
      message: 'Perubahan pada tugas ini belum disimpan.',
      confirmLabel: 'Buang',
      cancelLabel: 'Lanjut mengedit',
      isDestructive: true,
    );
    return r == ConfirmResult.confirm;
  }

  Future<void> _save() async {
    if (_saving) {
      return;
    }
    final DateTime now = DateTime.now();
    final bool fieldsOk = _formKey.currentState?.validate() ?? false;
    final String? dateError = TaskValidator.dueDate(
      _date,
      now: now,
      isNew: _isNew,
      dueTimeMinutes: _time,
    );
    final DateTime? reminderAt = _reminderAt;
    final String? reminderError =
        TaskValidator.reminder(reminderAt, now: now);
    setState(() {
      _dateError = dateError;
      _reminderError = reminderError;
    });
    if (!fieldsOk) {
      _titleFocus.requestFocus();
      return;
    }
    if (dateError != null || reminderError != null) {
      return;
    }

    setState(() => _saving = true);
    final ScaffoldMessengerState messenger = ScaffoldMessenger.of(context);
    final TaskRepository repo = ref.read(taskRepositoryProvider);
    final NotificationService notifications =
        ref.read(notificationServiceProvider);

    // Izin notifikasi diminta saat pengingat pertama kali dipakai (FR-020).
    bool permissionDenied = false;
    if (reminderAt != null && notifications.isSupported) {
      if (!await notifications.areEnabled()) {
        permissionDenied = !await notifications.requestPermission();
      }
      ref.invalidate(notificationPermissionProvider);
    }

    final TaskDraft draft = TaskDraft(
      title: _title.text,
      description: _description.text,
      dueDate: _date,
      dueTimeMinutes: _time,
      category: _category,
      priority: _priority,
      reminderAt: reminderAt,
      source: _original?.source ?? TaskSource.manual,
    );
    try {
      final Task? original = _original;
      if (original == null) {
        await repo.create(draft);
      } else {
        await repo.update(original, draft);
      }
    } catch (error) {
      final AppFailure f = AppFailure.from(error);
      if (mounted) {
        setState(() => _saving = false);
      }
      messenger.showSnackBar(
        SnackBar(content: Text('${f.title}. ${f.userMessage}')),
      );
      return;
    }
    messenger.showSnackBar(
      SnackBar(
        content: Text(
          permissionDenied
              ? 'Tugas disimpan. Pengingat tidak akan muncul karena izin '
                  'notifikasi ditolak; aktifkan di pengaturan perangkat.'
              : 'Tugas disimpan.',
        ),
      ),
    );
    if (!mounted) {
      return;
    }
    setState(() => _dirty = false);
    _leaveAfterFrame();
  }

  /// Keluar setelah frame berikutnya, saat `PopScope.canPop` sudah `true`.
  void _leaveAfterFrame() {
    WidgetsBinding.instance.addPostFrameCallback((_) {
      if (!mounted) {
        return;
      }
      if (context.canPop()) {
        context.pop();
      } else {
        context.go(AppRoutes.planner);
      }
    });
  }

  @override
  Widget build(BuildContext context) {
    if (_missing) {
      return Scaffold(
        appBar: AppBar(title: const Text('Edit tugas')),
        body: EmptyState(
          icon: Icons.search_off_rounded,
          title: 'Tugas tidak ditemukan',
          message: 'Tugas mungkin sudah dihapus.',
          primaryActionLabel: 'Kembali ke Planner',
          onPrimaryAction: () => context.go(AppRoutes.planner),
        ),
      );
    }

    final ThemeData theme = Theme.of(context);
    final DateTime? reminderAt = _reminderAt;
    final bool permissionKnownDenied =
        ref.watch(notificationPermissionProvider).value == false;

    return PopScope(
      canPop: !_dirty,
      onPopInvokedWithResult: (bool didPop, Object? result) async {
        if (didPop) {
          return;
        }
        if (await _confirmDiscard() && mounted) {
          setState(() => _dirty = false);
          _leaveAfterFrame();
        }
      },
      child: Scaffold(
        appBar: AppBar(title: Text(_isNew ? 'Tambah tugas' : 'Edit tugas')),
        body: SafeArea(
          child: Form(
            key: _formKey,
            child: ListView(
              padding: const EdgeInsets.only(bottom: AppSpacing.xxl),
              children: <Widget>[
                PageContainer(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.stretch,
                    children: <Widget>[
                      const SizedBox(height: AppSpacing.lg),
                      AppTextField(
                        label: 'Judul',
                        controller: _title,
                        focusNode: _titleFocus,
                        isRequired: true,
                        autofocus: _isNew,
                        validator: TaskValidator.title,
                        maxLength: TaskValidator.maxTitle,
                        showCounterFrom: 80,
                        textCapitalization: TextCapitalization.sentences,
                        textInputAction: TextInputAction.next,
                        hintText: 'Contoh: Laporan praktikum basis data',
                      ),
                      const SizedBox(height: AppSpacing.lg),
                      AppTextField(
                        label: 'Deskripsi',
                        controller: _description,
                        validator: TaskValidator.description,
                        maxLength: TaskValidator.maxDescription,
                        showCounterFrom: 1,
                        minLines: 2,
                        maxLines: 5,
                        textCapitalization: TextCapitalization.sentences,
                      ),
                      const SizedBox(height: AppSpacing.lg),
                      Row(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: <Widget>[
                          Expanded(
                            child: _PickerField(
                              label: 'Tanggal',
                              isRequired: true,
                              icon: Icons.event_rounded,
                              value: AppDateFormat.shortDate(_date),
                              error: _dateError,
                              onTap: _pickDate,
                            ),
                          ),
                          const SizedBox(width: AppSpacing.md),
                          Expanded(
                            child: _PickerField(
                              label: 'Waktu',
                              icon: Icons.schedule_rounded,
                              value: _time == null
                                  ? 'Sepanjang hari'
                                  : TimeOfDayMinutes.label(_time!),
                              onTap: _pickTime,
                              onClear: _time == null
                                  ? null
                                  : () => _change(() => _time = null),
                            ),
                          ),
                        ],
                      ),
                      const SizedBox(height: AppSpacing.lg),
                      Text('Kategori', style: theme.textTheme.labelLarge),
                      const SizedBox(height: AppSpacing.sm),
                      Wrap(
                        spacing: AppSpacing.sm,
                        runSpacing: AppSpacing.sm,
                        children: <Widget>[
                          for (final TaskCategory c in TaskCategory.values)
                            ChoiceChip(
                              label: Text(c.label),
                              selected: _category == c,
                              onSelected: (_) => _change(() => _category = c),
                            ),
                        ],
                      ),
                      const SizedBox(height: AppSpacing.lg),
                      Text('Prioritas', style: theme.textTheme.labelLarge),
                      const SizedBox(height: AppSpacing.sm),
                      SegmentedButton<TaskPriority>(
                        segments: <ButtonSegment<TaskPriority>>[
                          for (final TaskPriority p in TaskPriority.values)
                            ButtonSegment<TaskPriority>(
                              value: p,
                              label: Text(p.label),
                            ),
                        ],
                        selected: <TaskPriority>{_priority},
                        onSelectionChanged: (Set<TaskPriority> s) =>
                            _change(() => _priority = s.first),
                      ),
                      const SizedBox(height: AppSpacing.lg),
                      Text('Pengingat', style: theme.textTheme.labelLarge),
                      const SizedBox(height: AppSpacing.sm),
                      DropdownButtonFormField<Object>(
                        initialValue: _customReminder ?? _reminder,
                        isExpanded: true,
                        decoration: InputDecoration(
                          prefixIcon:
                              const Icon(Icons.notifications_none_rounded),
                          errorText: _reminderError,
                          errorMaxLines: 3,
                          helperText: _time == null && reminderAt != null
                              ? 'Tanpa jam, pengingat dihitung dari pukul '
                                  '08:00.'
                              : null,
                        ),
                        items: <DropdownMenuItem<Object>>[
                          if (_customReminder != null)
                            DropdownMenuItem<Object>(
                              value: _customReminder,
                              child: Text(
                                'Tetap: ${AppDateFormat.shortDate(_customReminder!)} '
                                '${AppDateFormat.time(_customReminder!)}',
                              ),
                            ),
                          for (final ReminderOption o in ReminderOption.values)
                            DropdownMenuItem<Object>(
                              value: o,
                              child: Text(
                                o == ReminderOption.none
                                    ? o.label
                                    : '${o.label} '
                                        '(${AppDateFormat.time(o.resolve(_reminderBase())!)})',
                              ),
                            ),
                        ],
                        onChanged: (Object? v) {
                          if (v is ReminderOption) {
                            _change(() {
                              _customReminder = null;
                              _reminder = v;
                            });
                          }
                        },
                      ),
                      if (reminderAt != null) ...<Widget>[
                        const SizedBox(height: AppSpacing.md),
                        StatusBanner(
                          type: permissionKnownDenied
                              ? StatusBannerType.warning
                              : StatusBannerType.info,
                          message: permissionKnownDenied
                              ? 'Izin notifikasi ditolak. Tugas tetap '
                                  'tersimpan, tetapi pengingat tidak muncul '
                                  'sampai izin diaktifkan di pengaturan.'
                              : 'Izin notifikasi akan diminta saat kamu '
                                  'menyimpan tugas ini.',
                        ),
                      ],
                      const SizedBox(height: AppSpacing.xl),
                      AppButton(
                        label: 'Simpan',
                        expand: true,
                        isLoading: _saving,
                        onPressed: _save,
                      ),
                    ],
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}

/// Field yang membuka picker (tanggal/waktu) dengan label di atas.
class _PickerField extends StatelessWidget {
  const _PickerField({
    required this.label,
    required this.icon,
    required this.value,
    required this.onTap,
    this.isRequired = false,
    this.error,
    this.onClear,
  });

  final String label;
  final IconData icon;
  final String value;
  final VoidCallback onTap;
  final bool isRequired;
  final String? error;
  final VoidCallback? onClear;

  @override
  Widget build(BuildContext context) {
    final ThemeData theme = Theme.of(context);
    final VoidCallback? clear = onClear;
    return Column(
      crossAxisAlignment: CrossAxisAlignment.stretch,
      children: <Widget>[
        Text.rich(
          TextSpan(
            text: label,
            children: <InlineSpan>[
              if (isRequired)
                TextSpan(
                  text: ' *',
                  style: TextStyle(color: theme.colorScheme.error),
                ),
            ],
          ),
          style: theme.textTheme.labelLarge,
        ),
        const SizedBox(height: 6),
        Semantics(
          button: true,
          label: '$label: $value',
          child: InkWell(
            onTap: onTap,
            borderRadius: AppRadius.mdAll,
            child: InputDecorator(
              decoration: InputDecoration(
                prefixIcon: Icon(icon),
                errorText: error,
                errorMaxLines: 2,
                suffixIcon: clear == null
                    ? null
                    : IconButton(
                        tooltip: 'Hapus $label',
                        icon: const Icon(Icons.close_rounded),
                        onPressed: clear,
                      ),
              ),
              child: Text(
                value,
                style: theme.textTheme.bodyLarge!.copyWith(
                  color: theme.colorScheme.onSurface,
                ),
                overflow: TextOverflow.ellipsis,
              ),
            ),
          ),
        ),
      ],
    );
  }
}
