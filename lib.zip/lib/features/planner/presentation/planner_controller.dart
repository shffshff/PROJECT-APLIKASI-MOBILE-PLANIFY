import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../../../core/error/app_failure.dart';
import '../../../core/utils/date_only.dart';
import '../data/task_repository.dart';
import '../domain/task.dart';
import '../domain/task_filter.dart';

enum PlannerMode { day, all }

@immutable
class PlannerViewState {
  const PlannerViewState({
    required this.selectedDay,
    this.mode = PlannerMode.day,
    this.filter = const TaskFilter(),
  });

  final DateTime selectedDay;
  final PlannerMode mode;
  final TaskFilter filter;

  PlannerViewState copyWith({
    DateTime? selectedDay,
    PlannerMode? mode,
    TaskFilter? filter,
  }) {
    return PlannerViewState(
      selectedDay: selectedDay ?? this.selectedDay,
      mode: mode ?? this.mode,
      filter: filter ?? this.filter,
    );
  }
}

/// State UI Planner (filter, mode, tanggal terpilih). Tidak disimpan.
class PlannerViewController extends Notifier<PlannerViewState> {
  @override
  PlannerViewState build() =>
      PlannerViewState(selectedDay: DateOnly.of(DateTime.now()));

  void selectDay(DateTime day) => state = state.copyWith(
        selectedDay: DateOnly.of(day),
        mode: PlannerMode.day,
      );

  void setMode(PlannerMode mode) => state = state.copyWith(mode: mode);

  void setFilter(TaskFilter filter) => state = state.copyWith(filter: filter);

  void setQuery(String query) =>
      state = state.copyWith(filter: state.filter.copyWith(query: query));

  void clearFilter() => state = state.copyWith(
        filter: TaskFilter(sort: state.filter.sort),
      );
}

final NotifierProvider<PlannerViewController, PlannerViewState>
    plannerViewProvider =
    NotifierProvider<PlannerViewController, PlannerViewState>(
  PlannerViewController.new,
);

/// Kelompok daftar Planner.
@immutable
class TaskSection {
  const TaskSection(this.title, this.tasks);

  final String title;
  final List<Task> tasks;
}

/// Mengelompokkan tugas untuk tampilan (mockup S-20: "Selasa, 20 Okt · 4
/// tugas", "Selesai (1)").
List<TaskSection> buildSections(
  List<Task> tasks,
  PlannerViewState view,
  DateTime now,
  String Function(DateTime) dayLabel,
) {
  final List<Task> filtered = view.filter.apply(tasks, now);
  if (view.mode == PlannerMode.day) {
    final List<Task> day = filtered
        .where((Task t) => DateOnly.isSameDay(t.dueDate, view.selectedDay))
        .toList();
    final List<Task> open = day.where((Task t) => !t.isCompleted).toList();
    final List<Task> done = day.where((Task t) => t.isCompleted).toList();
    return <TaskSection>[
      if (open.isNotEmpty)
        TaskSection(
          '${dayLabel(view.selectedDay)} · ${open.length} tugas',
          open,
        ),
      if (done.isNotEmpty) TaskSection('Selesai (${done.length})', done),
    ];
  }
  final DateTime today = DateOnly.of(now);
  final List<Task> overdue = <Task>[];
  final List<Task> todayList = <Task>[];
  final List<Task> upcoming = <Task>[];
  final List<Task> earlier = <Task>[];
  final List<Task> done = <Task>[];
  for (final Task t in filtered) {
    if (t.isCompleted) {
      done.add(t);
    } else if (t.isOverdue(now)) {
      overdue.add(t);
    } else if (DateOnly.isSameDay(t.dueDate, today)) {
      todayList.add(t);
    } else if (t.dueDate.isAfter(today)) {
      upcoming.add(t);
    } else {
      earlier.add(t);
    }
  }
  return <TaskSection>[
    if (overdue.isNotEmpty) TaskSection('Terlambat (${overdue.length})', overdue),
    if (todayList.isNotEmpty)
      TaskSection('Hari ini (${todayList.length})', todayList),
    if (upcoming.isNotEmpty)
      TaskSection('Mendatang (${upcoming.length})', upcoming),
    if (earlier.isNotEmpty) TaskSection('Sebelumnya', earlier),
    if (done.isNotEmpty) TaskSection('Selesai (${done.length})', done),
  ];
}

/// Mencentang tugas dengan snackbar "Urungkan" (Tahap 3: centang punya undo).
Future<void> toggleTaskWithUndo(
  BuildContext context,
  WidgetRef ref,
  Task task,
  bool completed,
) async {
  final ScaffoldMessengerState messenger = ScaffoldMessenger.of(context);
  final TaskRepository repo = ref.read(taskRepositoryProvider);
  try {
    final Task saved = await repo.setCompleted(task, completed);
    messenger
      ..hideCurrentSnackBar()
      ..showSnackBar(
        SnackBar(
          content: Text(
            completed ? 'Tugas ditandai selesai.' : 'Tugas dibuka lagi.',
          ),
          action: SnackBarAction(
            label: 'Urungkan',
            onPressed: () => repo.setCompleted(saved, !completed),
          ),
        ),
      );
  } catch (error) {
    final AppFailure f = AppFailure.from(error);
    messenger.showSnackBar(
      SnackBar(content: Text('${f.title}. ${f.userMessage}')),
    );
  }
}
