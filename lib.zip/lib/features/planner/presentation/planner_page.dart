import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:go_router/go_router.dart';
import 'package:intl/intl.dart';

import '../../../app/router/routes.dart';
import '../../../app/sync/app_sync_indicator.dart';
import '../../../app/sync/sync_controller.dart';
import '../../../core/notifications/notification_service.dart';
import '../../../core/utils/date_only.dart';
import '../../../core/widgets/async_view.dart';
import '../../../core/widgets/empty_state.dart';
import '../../../core/widgets/page_container.dart';
import '../../../theme/app_colors.dart';
import '../../../theme/app_tokens.dart';
import '../data/task_repository.dart';
import '../domain/task.dart';
import '../domain/task_filter.dart';
import '../domain/task_priority.dart';
import 'planner_controller.dart';
import 'widgets/planner_calendar.dart';
import 'widgets/task_card.dart';
import 'widgets/task_filter_sheet.dart';

/// S-20 Planner: per hari (strip minggu + kalender) atau semua tugas,
/// dengan pencarian, filter, dan urutan (FR-010–016).
class PlannerPage extends ConsumerStatefulWidget {
  const PlannerPage({super.key});

  @override
  ConsumerState<PlannerPage> createState() => _PlannerPageState();
}

class _PlannerPageState extends ConsumerState<PlannerPage> {
  final TextEditingController _search = TextEditingController();
  bool _searching = false;

  @override
  void dispose() {
    _search.dispose();
    super.dispose();
  }

  String _dayLabel(DateTime day) =>
      DateFormat('EEEE, d MMM', 'id_ID').format(day);

  Future<void> _openFilter(TaskFilter current) async {
    final TaskFilter? next = await showTaskFilterSheet(context, current);
    if (next != null) {
      ref.read(plannerViewProvider.notifier).setFilter(next);
    }
  }

  Future<void> _openCalendar(List<Task> tasks, DateTime selected) async {
    bool has(DateTime d) =>
        tasks.any((Task t) => DateOnly.isSameDay(t.dueDate, d));
    final DateTime? picked = await showMonthCalendarSheet(
      context,
      initial: selected,
      hasTasks: has,
    );
    if (picked != null) {
      ref.read(plannerViewProvider.notifier).selectDay(picked);
    }
  }

  void _addTask(PlannerViewState view) {
    final DateTime today = DateOnly.of(DateTime.now());
    final DateTime day =
        view.mode == PlannerMode.day && !view.selectedDay.isBefore(today)
            ? view.selectedDay
            : today;
    context.push('${AppRoutes.taskNew}?date=${DateOnly.format(day)}');
  }

  @override
  Widget build(BuildContext context) {
    final AsyncValue<List<Task>> tasks = ref.watch(tasksProvider);
    final PlannerViewState view = ref.watch(plannerViewProvider);
    final bool notificationsDenied =
        ref.watch(notificationPermissionProvider).value == false;
    final ThemeData theme = Theme.of(context);
    final DateTime now = DateTime.now();

    return Scaffold(
      appBar: AppBar(
        title: _searching
            ? TextField(
                controller: _search,
                autofocus: true,
                textInputAction: TextInputAction.search,
                decoration: const InputDecoration(
                  hintText: 'Cari judul atau deskripsi',
                  border: InputBorder.none,
                  filled: false,
                ),
                onChanged: ref.read(plannerViewProvider.notifier).setQuery,
              )
            : Text('Planner', style: theme.textTheme.headlineSmall),
        actions: <Widget>[
          IconButton(
            tooltip: _searching ? 'Tutup pencarian' : 'Cari tugas',
            icon: Icon(_searching ? Icons.close_rounded : Icons.search_rounded),
            onPressed: () {
              setState(() => _searching = !_searching);
              if (!_searching) {
                _search.clear();
                ref.read(plannerViewProvider.notifier).setQuery('');
              }
            },
          ),
          IconButton(
            tooltip: view.filter.activeCount == 0
                ? 'Filter & urutan'
                : 'Filter & urutan, ${view.filter.activeCount} aktif',
            onPressed: () => _openFilter(view.filter),
            icon: Badge(
              isLabelVisible: view.filter.activeCount > 0,
              label: Text('${view.filter.activeCount}'),
              child: const Icon(Icons.tune_rounded),
            ),
          ),
          const AppSyncIndicator(),
          const SizedBox(width: AppSpacing.sm),
        ],
      ),
      floatingActionButton: FloatingActionButton.extended(
        onPressed: () => _addTask(view),
        icon: const Icon(Icons.add_rounded),
        label: const Text('Tugas'),
      ),
      body: SafeArea(
        child: AsyncView<List<Task>>(
          value: tasks,
          onRetry: () => ref.invalidate(tasksProvider),
          builder: (BuildContext context, List<Task> all) {
            final List<TaskSection> sections =
                buildSections(all, view, now, _dayLabel);
            return RefreshIndicator(
              onRefresh: () async {
                await ref.read(syncControllerProvider.notifier).syncNow();
              },
              child: CustomScrollView(
                slivers: <Widget>[
                  SliverToBoxAdapter(
                    child: PageContainer(
                      child: _Header(
                        view: view,
                        all: all,
                        now: now,
                        onCalendar: () => _openCalendar(all, view.selectedDay),
                      ),
                    ),
                  ),
                  if (sections.isEmpty)
                    SliverToBoxAdapter(
                      child: PageContainer(
                        child: _EmptyPlanner(
                          view: view,
                          hasAnyTask: all.isNotEmpty,
                          onAdd: () => _addTask(view),
                          onClearFilter: () {
                            _search.clear();
                            setState(() => _searching = false);
                            ref.read(plannerViewProvider.notifier).clearFilter();
                          },
                        ),
                      ),
                    ),
                  for (final TaskSection section in sections) ...<Widget>[
                    SliverToBoxAdapter(
                      child: PageContainer(
                        child: Padding(
                          padding: const EdgeInsets.only(
                            top: AppSpacing.lg,
                            bottom: AppSpacing.sm,
                          ),
                          child: Semantics(
                            header: true,
                            child: Text(
                              section.title,
                              style: theme.textTheme.titleSmall!.copyWith(
                                color: context.appColors.textSecondary,
                              ),
                            ),
                          ),
                        ),
                      ),
                    ),
                    SliverList.separated(
                      itemCount: section.tasks.length,
                      separatorBuilder: (_, _) =>
                          const SizedBox(height: AppSpacing.cardGap),
                      itemBuilder: (BuildContext context, int i) {
                        final Task task = section.tasks[i];
                        return PageContainer(
                          child: TaskCard(
                            key: ValueKey<String>(task.id),
                            task: task,
                            now: now,
                            showDate: view.mode == PlannerMode.all,
                            notificationsDenied: notificationsDenied,
                            onTap: () =>
                                context.push(AppRoutes.taskDetail(task.id)),
                            onToggle: (bool v) =>
                                toggleTaskWithUndo(context, ref, task, v),
                          ),
                        );
                      },
                    ),
                  ],
                  const SliverToBoxAdapter(child: SizedBox(height: 96)),
                ],
              ),
            );
          },
        ),
      ),
    );
  }
}

class _Header extends ConsumerWidget {
  const _Header({
    required this.view,
    required this.all,
    required this.now,
    required this.onCalendar,
  });

  final PlannerViewState view;
  final List<Task> all;
  final DateTime now;
  final VoidCallback onCalendar;

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final ThemeData theme = Theme.of(context);
    final PlannerViewController controller =
        ref.read(plannerViewProvider.notifier);
    final List<Widget> activeChips = <Widget>[
      if (view.filter.status != TaskStatusFilter.all)
        InputChip(
          label: Text(view.filter.status.label),
          onDeleted: () => controller.setFilter(
            view.filter.copyWith(status: TaskStatusFilter.all),
          ),
        ),
      for (final TaskCategory c in view.filter.categories)
        InputChip(
          label: Text(c.label),
          onDeleted: () => controller.setFilter(
            view.filter.copyWith(
              categories: Set<TaskCategory>.of(view.filter.categories)
                ..remove(c),
            ),
          ),
        ),
      for (final TaskPriority p in view.filter.priorities)
        InputChip(
          label: Text('Prioritas ${p.label}'),
          onDeleted: () => controller.setFilter(
            view.filter.copyWith(
              priorities: Set<TaskPriority>.of(view.filter.priorities)
                ..remove(p),
            ),
          ),
        ),
    ];

    return Column(
      crossAxisAlignment: CrossAxisAlignment.stretch,
      children: <Widget>[
        const SizedBox(height: AppSpacing.sm),
        Row(
          children: <Widget>[
            SegmentedButton<PlannerMode>(
              segments: const <ButtonSegment<PlannerMode>>[
                ButtonSegment<PlannerMode>(
                  value: PlannerMode.day,
                  label: Text('Per hari'),
                ),
                ButtonSegment<PlannerMode>(
                  value: PlannerMode.all,
                  label: Text('Semua'),
                ),
              ],
              selected: <PlannerMode>{view.mode},
              onSelectionChanged: (Set<PlannerMode> s) =>
                  controller.setMode(s.first),
            ),
            const Spacer(),
            TextButton.icon(
              onPressed: onCalendar,
              icon: const Icon(Icons.calendar_month_rounded),
              label: const Text('Kalender'),
            ),
          ],
        ),
        if (view.mode == PlannerMode.day) ...<Widget>[
          const SizedBox(height: AppSpacing.md),
          Text(
            DateFormat('MMMM yyyy', 'id_ID').format(view.selectedDay),
            style: theme.textTheme.titleSmall,
          ),
          const SizedBox(height: AppSpacing.sm),
          WeekStrip(
            selected: view.selectedDay,
            today: DateOnly.of(now),
            hasTasks: (DateTime d) => all.any(
              (Task t) => DateOnly.isSameDay(t.dueDate, d) && !t.isCompleted,
            ),
            onSelect: controller.selectDay,
          ),
        ],
        if (activeChips.isNotEmpty) ...<Widget>[
          const SizedBox(height: AppSpacing.md),
          Wrap(
            spacing: AppSpacing.sm,
            runSpacing: AppSpacing.sm,
            children: activeChips,
          ),
        ],
      ],
    );
  }
}

class _EmptyPlanner extends StatelessWidget {
  const _EmptyPlanner({
    required this.view,
    required this.hasAnyTask,
    required this.onAdd,
    required this.onClearFilter,
  });

  final PlannerViewState view;
  final bool hasAnyTask;
  final VoidCallback onAdd;
  final VoidCallback onClearFilter;

  @override
  Widget build(BuildContext context) {
    if (!view.filter.isEmpty && hasAnyTask) {
      return EmptyState(
        icon: Icons.filter_alt_off_outlined,
        title: 'Tidak ada tugas yang cocok',
        message: 'Coba ubah kata kunci atau hapus filter.',
        primaryActionLabel: 'Hapus filter',
        onPrimaryAction: onClearFilter,
      );
    }
    if (view.mode == PlannerMode.day && hasAnyTask) {
      return EmptyState(
        icon: Icons.event_available_outlined,
        title: 'Tanggal ini kosong',
        message: 'Belum ada tugas di tanggal ini.',
        primaryActionLabel: 'Tambah tugas',
        onPrimaryAction: onAdd,
      );
    }
    return EmptyState(
      icon: Icons.checklist_rounded,
      title: 'Belum ada tugas',
      message: 'Catat tugas pertamamu. Semua tersimpan di perangkat dan '
          'disinkronkan saat online.',
      primaryActionLabel: 'Tambah tugas',
      onPrimaryAction: onAdd,
    );
  }
}
