import 'package:flutter/material.dart';

import '../../../../core/widgets/section_header.dart';
import '../../../../theme/app_tokens.dart';
import '../../domain/task.dart';
import '../../domain/task_filter.dart';
import '../../domain/task_priority.dart';

/// Lembar filter & urutan Planner (FR-016). Mengembalikan filter baru atau
/// `null` bila ditutup tanpa menerapkan.
Future<TaskFilter?> showTaskFilterSheet(
  BuildContext context,
  TaskFilter initial,
) {
  return showModalBottomSheet<TaskFilter>(
    context: context,
    isScrollControlled: true,
    showDragHandle: true,
    builder: (BuildContext context) => _FilterSheet(initial: initial),
  );
}

class _FilterSheet extends StatefulWidget {
  const _FilterSheet({required this.initial});

  final TaskFilter initial;

  @override
  State<_FilterSheet> createState() => _FilterSheetState();
}

class _FilterSheetState extends State<_FilterSheet> {
  late TaskFilter _filter = widget.initial;

  void _toggleCategory(TaskCategory c) {
    final Set<TaskCategory> set = Set<TaskCategory>.of(_filter.categories);
    set.contains(c) ? set.remove(c) : set.add(c);
    setState(() => _filter = _filter.copyWith(categories: set));
  }

  void _togglePriority(TaskPriority p) {
    final Set<TaskPriority> set = Set<TaskPriority>.of(_filter.priorities);
    set.contains(p) ? set.remove(p) : set.add(p);
    setState(() => _filter = _filter.copyWith(priorities: set));
  }

  @override
  Widget build(BuildContext context) {
    return SafeArea(
      child: SingleChildScrollView(
        padding: const EdgeInsets.fromLTRB(
          AppSpacing.lg,
          0,
          AppSpacing.lg,
          AppSpacing.lg,
        ),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.stretch,
          mainAxisSize: MainAxisSize.min,
          children: <Widget>[
            Text('Filter & urutan', style: Theme.of(context).textTheme.titleLarge),
            const SizedBox(height: AppSpacing.lg),
            const SectionHeader(title: 'Status'),
            Wrap(
              spacing: AppSpacing.sm,
              runSpacing: AppSpacing.sm,
              children: <Widget>[
                for (final TaskStatusFilter s in TaskStatusFilter.values)
                  ChoiceChip(
                    label: Text(s.label),
                    selected: _filter.status == s,
                    onSelected: (_) =>
                        setState(() => _filter = _filter.copyWith(status: s)),
                  ),
              ],
            ),
            const SizedBox(height: AppSpacing.lg),
            const SectionHeader(title: 'Kategori'),
            Wrap(
              spacing: AppSpacing.sm,
              runSpacing: AppSpacing.sm,
              children: <Widget>[
                for (final TaskCategory c in TaskCategory.values)
                  FilterChip(
                    label: Text(c.label),
                    selected: _filter.categories.contains(c),
                    onSelected: (_) => _toggleCategory(c),
                  ),
              ],
            ),
            const SizedBox(height: AppSpacing.lg),
            const SectionHeader(title: 'Prioritas'),
            Wrap(
              spacing: AppSpacing.sm,
              runSpacing: AppSpacing.sm,
              children: <Widget>[
                for (final TaskPriority p in TaskPriority.values.reversed)
                  FilterChip(
                    label: Text(p.label),
                    selected: _filter.priorities.contains(p),
                    onSelected: (_) => _togglePriority(p),
                  ),
              ],
            ),
            const SizedBox(height: AppSpacing.lg),
            const SectionHeader(title: 'Urutkan'),
            RadioGroup<TaskSort>(
              groupValue: _filter.sort,
              onChanged: (TaskSort? v) {
                if (v != null) {
                  setState(() => _filter = _filter.copyWith(sort: v));
                }
              },
              child: Column(
                children: <Widget>[
                  for (final TaskSort s in TaskSort.values)
                    RadioListTile<TaskSort>(
                      value: s,
                      title: Text(s.label),
                      contentPadding: EdgeInsets.zero,
                    ),
                ],
              ),
            ),
            const SizedBox(height: AppSpacing.lg),
            Row(
              children: <Widget>[
                Expanded(
                  child: OutlinedButton(
                    onPressed: () => Navigator.of(context).pop(
                      TaskFilter(query: _filter.query, sort: _filter.sort),
                    ),
                    child: const Text('Hapus filter'),
                  ),
                ),
                const SizedBox(width: AppSpacing.md),
                Expanded(
                  child: FilledButton(
                    onPressed: () => Navigator.of(context).pop(_filter),
                    child: const Text('Terapkan'),
                  ),
                ),
              ],
            ),
          ],
        ),
      ),
    );
  }
}
