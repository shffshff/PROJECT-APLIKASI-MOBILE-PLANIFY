import 'package:flutter/material.dart';
import 'package:intl/intl.dart';

import '../../../../core/utils/date_only.dart';
import '../../../../theme/app_colors.dart';
import '../../../../theme/app_tokens.dart';

const List<String> _weekdayShort = <String>[
  'Sen',
  'Sel',
  'Rab',
  'Kam',
  'Jum',
  'Sab',
  'Min',
];

/// Strip tujuh hari (mockup S-20). Titik di bawah tanggal = ada tugas.
class WeekStrip extends StatelessWidget {
  const WeekStrip({
    super.key,
    required this.selected,
    required this.today,
    required this.hasTasks,
    required this.onSelect,
  });

  final DateTime selected;
  final DateTime today;
  final bool Function(DateTime day) hasTasks;
  final ValueChanged<DateTime> onSelect;

  @override
  Widget build(BuildContext context) {
    final DateTime start = DateOnly.startOfWeek(selected);
    return Row(
      children: <Widget>[
        for (int i = 0; i < 7; i++)
          Expanded(
            child: _DayCell(
              day: DateOnly.addDays(start, i),
              label: _weekdayShort[i],
              selected: DateOnly.isSameDay(DateOnly.addDays(start, i), selected),
              isToday: DateOnly.isSameDay(DateOnly.addDays(start, i), today),
              hasTasks: hasTasks(DateOnly.addDays(start, i)),
              onTap: () => onSelect(DateOnly.addDays(start, i)),
            ),
          ),
      ],
    );
  }
}

class _DayCell extends StatelessWidget {
  const _DayCell({
    required this.day,
    required this.label,
    required this.selected,
    required this.isToday,
    required this.hasTasks,
    required this.onTap,
  });

  final DateTime day;
  final String label;
  final bool selected;
  final bool isToday;
  final bool hasTasks;
  final VoidCallback onTap;

  @override
  Widget build(BuildContext context) {
    final ThemeData theme = Theme.of(context);
    final ColorScheme scheme = theme.colorScheme;
    final Color fg = selected ? scheme.onPrimary : scheme.onSurface;
    return Semantics(
      button: true,
      selected: selected,
      label: '${DateFormat('EEEE, d MMMM', 'id_ID').format(day)}'
          '${isToday ? ', hari ini' : ''}${hasTasks ? ', ada tugas' : ''}',
      excludeSemantics: true,
      child: InkWell(
        borderRadius: AppRadius.mdAll,
        onTap: onTap,
        child: Container(
          margin: const EdgeInsets.symmetric(horizontal: 2),
          padding: const EdgeInsets.symmetric(vertical: 8),
          decoration: BoxDecoration(
            color: selected ? scheme.primary : null,
            borderRadius: AppRadius.mdAll,
            border: isToday && !selected
                ? Border.all(color: scheme.primary)
                : null,
          ),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: <Widget>[
              Text(
                label,
                style: theme.textTheme.labelSmall!.copyWith(
                  color: selected ? fg : context.appColors.textSecondary,
                ),
              ),
              const SizedBox(height: 2),
              Text(
                '${day.day}',
                style: theme.textTheme.titleMedium!.copyWith(color: fg),
              ),
              const SizedBox(height: 4),
              Container(
                width: 5,
                height: 5,
                decoration: BoxDecoration(
                  shape: BoxShape.circle,
                  color: hasTasks
                      ? (selected ? scheme.onPrimary : scheme.primary)
                      : Colors.transparent,
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}

/// Kalender bulanan (mockup S-20 "Pilih tanggal"). Mengembalikan tanggal
/// terpilih atau `null` bila ditutup.
Future<DateTime?> showMonthCalendarSheet(
  BuildContext context, {
  required DateTime initial,
  required bool Function(DateTime day) hasTasks,
}) {
  return showModalBottomSheet<DateTime>(
    context: context,
    isScrollControlled: true,
    showDragHandle: true,
    builder: (BuildContext context) =>
        _MonthCalendar(initial: initial, hasTasks: hasTasks),
  );
}

class _MonthCalendar extends StatefulWidget {
  const _MonthCalendar({required this.initial, required this.hasTasks});

  final DateTime initial;
  final bool Function(DateTime day) hasTasks;

  @override
  State<_MonthCalendar> createState() => _MonthCalendarState();
}

class _MonthCalendarState extends State<_MonthCalendar> {
  late DateTime _month = DateTime(widget.initial.year, widget.initial.month);
  late DateTime _selected = DateOnly.of(widget.initial);

  void _shift(int months) =>
      setState(() => _month = DateTime(_month.year, _month.month + months));

  @override
  Widget build(BuildContext context) {
    final ThemeData theme = Theme.of(context);
    final ColorScheme scheme = theme.colorScheme;
    final DateTime today = DateOnly.of(DateTime.now());
    final DateTime first = _month;
    final int leading = first.weekday - 1;
    final int days = DateTime(first.year, first.month + 1, 0).day;
    final int cells = ((leading + days) / 7).ceil() * 7;

    return SafeArea(
      child: Padding(
        padding: const EdgeInsets.fromLTRB(
          AppSpacing.lg,
          0,
          AppSpacing.lg,
          AppSpacing.lg,
        ),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: <Widget>[
            Row(
              children: <Widget>[
                IconButton(
                  tooltip: 'Bulan sebelumnya',
                  onPressed: () => _shift(-1),
                  icon: const Icon(Icons.chevron_left_rounded),
                ),
                Expanded(
                  child: Text(
                    DateFormat('MMMM yyyy', 'id_ID').format(_month),
                    textAlign: TextAlign.center,
                    style: theme.textTheme.titleMedium,
                  ),
                ),
                IconButton(
                  tooltip: 'Bulan berikutnya',
                  onPressed: () => _shift(1),
                  icon: const Icon(Icons.chevron_right_rounded),
                ),
              ],
            ),
            const SizedBox(height: AppSpacing.sm),
            Row(
              children: <Widget>[
                for (final String d in _weekdayShort)
                  Expanded(
                    child: Text(
                      d,
                      textAlign: TextAlign.center,
                      style: theme.textTheme.labelSmall!.copyWith(
                        color: context.appColors.textSecondary,
                      ),
                    ),
                  ),
              ],
            ),
            const SizedBox(height: AppSpacing.xs),
            GridView.count(
              crossAxisCount: 7,
              shrinkWrap: true,
              physics: const NeverScrollableScrollPhysics(),
              children: <Widget>[
                for (int i = 0; i < cells; i++)
                  if (i < leading || i >= leading + days)
                    const SizedBox.shrink()
                  else
                    _MonthDay(
                      day: DateTime(first.year, first.month, i - leading + 1),
                      selected: DateOnly.isSameDay(
                        DateTime(first.year, first.month, i - leading + 1),
                        _selected,
                      ),
                      isToday: DateOnly.isSameDay(
                        DateTime(first.year, first.month, i - leading + 1),
                        today,
                      ),
                      hasTasks: widget.hasTasks(
                        DateTime(first.year, first.month, i - leading + 1),
                      ),
                      onTap: (DateTime d) => setState(() => _selected = d),
                    ),
              ],
            ),
            const SizedBox(height: AppSpacing.md),
            Row(
              children: <Widget>[
                Icon(Icons.circle, size: 8, color: scheme.primary),
                const SizedBox(width: 6),
                Text('Ada tugas', style: theme.textTheme.bodySmall),
                const Spacer(),
                TextButton(
                  onPressed: () => setState(() {
                    _selected = today;
                    _month = DateTime(today.year, today.month);
                  }),
                  child: const Text('Hari ini'),
                ),
              ],
            ),
            const SizedBox(height: AppSpacing.sm),
            SizedBox(
              width: double.infinity,
              height: AppSizes.buttonHeight,
              child: FilledButton(
                onPressed: () => Navigator.of(context).pop(_selected),
                child: Text(
                  'Pilih ${DateFormat('d MMM', 'id_ID').format(_selected)}',
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}

class _MonthDay extends StatelessWidget {
  const _MonthDay({
    required this.day,
    required this.selected,
    required this.isToday,
    required this.hasTasks,
    required this.onTap,
  });

  final DateTime day;
  final bool selected;
  final bool isToday;
  final bool hasTasks;
  final ValueChanged<DateTime> onTap;

  @override
  Widget build(BuildContext context) {
    final ColorScheme scheme = Theme.of(context).colorScheme;
    return Semantics(
      button: true,
      selected: selected,
      label: '${DateFormat('d MMMM', 'id_ID').format(day)}'
          '${hasTasks ? ', ada tugas' : ''}',
      excludeSemantics: true,
      child: InkWell(
        customBorder: const CircleBorder(),
        onTap: () => onTap(day),
        child: Container(
          margin: const EdgeInsets.all(3),
          decoration: BoxDecoration(
            shape: BoxShape.circle,
            color: selected ? scheme.primary : null,
            border: isToday && !selected
                ? Border.all(color: scheme.primary)
                : null,
          ),
          child: Stack(
            alignment: Alignment.center,
            children: <Widget>[
              Text(
                '${day.day}',
                style: TextStyle(
                  color: selected ? scheme.onPrimary : scheme.onSurface,
                  fontWeight: FontWeight.w600,
                ),
              ),
              if (hasTasks)
                Positioned(
                  bottom: 5,
                  child: Container(
                    width: 4,
                    height: 4,
                    decoration: BoxDecoration(
                      shape: BoxShape.circle,
                      color: selected ? scheme.onPrimary : scheme.primary,
                    ),
                  ),
                ),
            ],
          ),
        ),
      ),
    );
  }
}
