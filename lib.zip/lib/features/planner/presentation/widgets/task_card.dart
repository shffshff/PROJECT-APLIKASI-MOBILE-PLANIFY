import 'package:flutter/material.dart';

import '../../../../core/sync/sync_entity.dart';
import '../../../../core/utils/app_date_format.dart';
import '../../../../core/utils/date_only.dart';
import '../../../../core/widgets/priority_badge.dart';
import '../../../../theme/app_colors.dart';
import '../../../../theme/app_tokens.dart';
import '../../domain/task.dart';

/// C-05 TaskCard (mockup S-10/S-20). Status selalu memakai teks + ikon,
/// tidak hanya warna (NFR-017).
class TaskCard extends StatelessWidget {
  const TaskCard({
    super.key,
    required this.task,
    required this.now,
    required this.onTap,
    required this.onToggle,
    this.showDate = false,
    this.notificationsDenied = false,
  });

  final Task task;
  final DateTime now;
  final VoidCallback onTap;
  final ValueChanged<bool> onToggle;

  /// Tampilkan tanggal (mode "Semua"); di mode per hari cukup jam.
  final bool showDate;

  /// Izin notifikasi ditolak dan tugas ini memakai pengingat.
  final bool notificationsDenied;

  String _when() {
    final String time = task.dueTimeMinutes == null
        ? 'Sepanjang hari'
        : AppDateFormat.time(task.dueMoment);
    if (!showDate) {
      return time;
    }
    final DateTime today = DateOnly.of(now);
    final DateTime due = task.dueDate;
    final String date = DateOnly.isSameDay(due, today)
        ? 'Hari ini'
        : DateOnly.isSameDay(due, DateOnly.addDays(today, 1))
            ? 'Besok'
            : DateOnly.isSameDay(due, DateOnly.addDays(today, -1))
                ? 'Kemarin'
                : AppDateFormat.shortDate(due);
    return '$date · $time';
  }

  @override
  Widget build(BuildContext context) {
    final ThemeData theme = Theme.of(context);
    final ColorScheme scheme = theme.colorScheme;
    final AppColors colors = context.appColors;
    final bool overdue = task.isOverdue(now);
    final bool pending = task.syncInfo.status != SyncStatus.synced;
    final bool failed = task.syncInfo.status == SyncStatus.failed;
    final bool hasReminder =
        task.reminderAt != null && task.reminderAt!.isAfter(now.toUtc());

    final TextStyle metaStyle =
        theme.textTheme.bodySmall!.copyWith(color: colors.textSecondary);

    final List<Widget> meta = <Widget>[
      PriorityBadge(priority: task.priority),
      if (overdue)
        _MetaLabel(
          icon: Icons.schedule_rounded,
          text: 'Terlambat',
          color: scheme.error,
        ),
      _MetaLabel(
        icon: Icons.access_time_rounded,
        text: _when(),
        color: colors.textSecondary,
      ),
      _MetaLabel(
        icon: Icons.label_outline_rounded,
        text: task.category.label,
        color: colors.textSecondary,
      ),
      if (hasReminder && !task.isCompleted)
        notificationsDenied
            ? _MetaLabel(
                icon: Icons.notifications_off_outlined,
                text: 'Izin ditolak',
                color: colors.onWarningContainer,
              )
            : _MetaLabel(
                icon: Icons.notifications_active_outlined,
                text: 'Pengingat',
                color: colors.textSecondary,
              ),
      if (pending)
        _MetaLabel(
          icon: failed ? Icons.sync_problem_rounded : Icons.cloud_upload_outlined,
          text: failed ? 'Gagal sinkron' : 'Belum sinkron',
          color: failed ? scheme.error : colors.textSecondary,
        ),
    ];

    return Card(
      margin: EdgeInsets.zero,
      clipBehavior: Clip.antiAlias,
      child: InkWell(
        onTap: onTap,
        child: Padding(
          padding: const EdgeInsets.fromLTRB(4, 8, AppSpacing.lg, 12),
          child: Row(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: <Widget>[
              SizedBox(
                width: AppSizes.minTouchTarget,
                height: AppSizes.minTouchTarget,
                child: Checkbox(
                  value: task.isCompleted,
                  semanticLabel: task.isCompleted
                      ? 'Tandai belum selesai: ${task.title}'
                      : 'Tandai selesai: ${task.title}',
                  onChanged: (bool? v) => onToggle(v ?? false),
                ),
              ),
              const SizedBox(width: AppSpacing.xs),
              Expanded(
                child: Padding(
                  padding: const EdgeInsets.only(top: 12),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: <Widget>[
                      Text(
                        task.title,
                        maxLines: 2,
                        overflow: TextOverflow.ellipsis,
                        style: theme.textTheme.titleSmall!.copyWith(
                          decoration: task.isCompleted
                              ? TextDecoration.lineThrough
                              : null,
                          color: task.isCompleted
                              ? colors.textSecondary
                              : theme.textTheme.titleSmall!.color,
                        ),
                      ),
                      const SizedBox(height: 6),
                      DefaultTextStyle(
                        style: metaStyle,
                        child: Wrap(
                          spacing: AppSpacing.md,
                          runSpacing: 6,
                          crossAxisAlignment: WrapCrossAlignment.center,
                          children: meta,
                        ),
                      ),
                    ],
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}

class _MetaLabel extends StatelessWidget {
  const _MetaLabel({
    required this.icon,
    required this.text,
    required this.color,
  });

  final IconData icon;
  final String text;
  final Color color;

  @override
  Widget build(BuildContext context) {
    return Row(
      mainAxisSize: MainAxisSize.min,
      children: <Widget>[
        Icon(icon, size: 14, color: color),
        const SizedBox(width: 4),
        Text(
          text,
          style: Theme.of(context).textTheme.bodySmall!.copyWith(color: color),
        ),
      ],
    );
  }
}
