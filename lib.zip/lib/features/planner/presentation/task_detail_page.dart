import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:go_router/go_router.dart';
import 'package:intl/intl.dart';

import '../../../app/router/routes.dart';
import '../../../core/error/app_failure.dart';
import '../../../core/sync/sync_entity.dart';
import '../../../core/utils/app_date_format.dart';
import '../../../core/widgets/app_button.dart';
import '../../../core/widgets/confirm_dialog.dart';
import '../../../core/widgets/empty_state.dart';
import '../../../core/widgets/page_container.dart';
import '../../../core/widgets/priority_badge.dart';
import '../../../core/widgets/status_banner.dart';
import '../../../theme/app_colors.dart';
import '../../../theme/app_tokens.dart';
import '../../focus/presentation/pomodoro_controller.dart';
import '../data/task_repository.dart';
import '../domain/task.dart';
import 'planner_controller.dart';

/// S-22 Detail tugas: lihat, selesaikan, edit, hapus, fokus.
class TaskDetailPage extends ConsumerWidget {
  const TaskDetailPage({super.key, required this.taskId});

  final String taskId;

  Future<void> _delete(BuildContext context, WidgetRef ref, Task task) async {
    final ConfirmResult r = await showConfirmDialog(
      context,
      title: 'Hapus tugas ini?',
      message: 'Pengingatnya juga akan dibatalkan. Tindakan ini tidak dapat '
          'dibatalkan dari layar ini.',
      confirmLabel: 'Hapus',
      isDestructive: true,
    );
    if (r != ConfirmResult.confirm || !context.mounted) {
      return;
    }
    final ScaffoldMessengerState messenger = ScaffoldMessenger.of(context);
    try {
      await ref.read(taskRepositoryProvider).delete(task);
      messenger.showSnackBar(const SnackBar(content: Text('Tugas dihapus.')));
      if (context.mounted) {
        context.canPop() ? context.pop() : context.go(AppRoutes.planner);
      }
    } catch (error) {
      final AppFailure f = AppFailure.from(error);
      messenger.showSnackBar(
        SnackBar(content: Text('${f.title}. ${f.userMessage}')),
      );
    }
  }

  void _focus(BuildContext context, WidgetRef ref, Task task) {
    final PomodoroController pomodoro =
        ref.read(pomodoroControllerProvider.notifier);
    pomodoro.setTask(task.id);
    context.go(AppRoutes.focus);
  }

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final AsyncValue<List<Task>> tasks = ref.watch(tasksProvider);
    final List<Task>? list = tasks.value;
    if (list == null) {
      return const Scaffold(body: Center(child: CircularProgressIndicator()));
    }
    Task? task;
    for (final Task t in list) {
      if (t.id == taskId) {
        task = t;
        break;
      }
    }
    if (task == null) {
      return Scaffold(
        appBar: AppBar(title: const Text('Detail tugas')),
        body: EmptyState(
          icon: Icons.search_off_rounded,
          title: 'Tugas tidak ditemukan',
          message: 'Tugas mungkin sudah dihapus atau belum tersinkron ke '
              'perangkat ini.',
          primaryActionLabel: 'Kembali ke Planner',
          onPrimaryAction: () => context.go(AppRoutes.planner),
        ),
      );
    }
    final Task t = task;
    final ThemeData theme = Theme.of(context);
    final AppColors colors = context.appColors;
    final DateTime now = DateTime.now();
    final DateTime? reminder = t.reminderAt?.toLocal();

    return Scaffold(
      appBar: AppBar(
        title: const Text('Detail tugas'),
        actions: <Widget>[
          IconButton(
            tooltip: 'Edit tugas',
            icon: const Icon(Icons.edit_outlined),
            onPressed: () => context.push(AppRoutes.taskEdit(t.id)),
          ),
          IconButton(
            tooltip: 'Hapus tugas',
            icon: const Icon(Icons.delete_outline_rounded),
            onPressed: () => _delete(context, ref, t),
          ),
        ],
      ),
      body: SafeArea(
        child: ListView(
          padding: const EdgeInsets.only(bottom: AppSpacing.xxl),
          children: <Widget>[
            PageContainer(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.stretch,
                children: <Widget>[
                  const SizedBox(height: AppSpacing.lg),
                  Wrap(
                    spacing: AppSpacing.sm,
                    runSpacing: AppSpacing.sm,
                    children: <Widget>[
                      Chip(
                        avatar: Icon(
                          t.isCompleted
                              ? Icons.check_circle_rounded
                              : t.isOverdue(now)
                                  ? Icons.schedule_rounded
                                  : Icons.radio_button_unchecked_rounded,
                          size: 18,
                        ),
                        label: Text(
                          t.isCompleted
                              ? 'Selesai'
                              : t.isOverdue(now)
                                  ? 'Terlambat'
                                  : 'Belum selesai',
                        ),
                      ),
                      if (t.source != TaskSource.manual)
                        Chip(
                          avatar: const Icon(Icons.auto_awesome_outlined, size: 18),
                          label: Text(
                            t.source == TaskSource.aiLlm
                                ? 'Dari usulan AI'
                                : 'Dari usulan berbasis aturan',
                          ),
                        ),
                    ],
                  ),
                  const SizedBox(height: AppSpacing.md),
                  Text(t.title, style: theme.textTheme.headlineSmall),
                  const SizedBox(height: AppSpacing.lg),
                  Card(
                    margin: EdgeInsets.zero,
                    child: Padding(
                      padding: const EdgeInsets.all(AppSpacing.lg),
                      child: Column(
                        children: <Widget>[
                          _Row(
                            label: 'Tenggat',
                            value:
                                '${DateFormat('EEEE, d MMM yyyy', 'id_ID').format(t.dueDate)}'
                                '${t.dueTimeMinutes == null ? ' · sepanjang hari' : ' · ${AppDateFormat.time(t.dueMoment)}'}',
                          ),
                          _Row(label: 'Kategori', value: t.category.label),
                          _Row(
                            label: 'Prioritas',
                            child: PriorityBadge(priority: t.priority),
                          ),
                          _Row(
                            label: 'Pengingat',
                            value: reminder == null
                                ? 'Tidak ada'
                                : '${AppDateFormat.shortDate(reminder)} '
                                    '${AppDateFormat.time(reminder)}'
                                    '${reminder.isBefore(now) ? ' (sudah lewat)' : ''}',
                          ),
                        ],
                      ),
                    ),
                  ),
                  if ((t.description ?? '').isNotEmpty) ...<Widget>[
                    const SizedBox(height: AppSpacing.lg),
                    Text('Deskripsi', style: theme.textTheme.titleSmall),
                    const SizedBox(height: AppSpacing.xs),
                    Text(t.description!, style: theme.textTheme.bodyLarge),
                  ],
                  const SizedBox(height: AppSpacing.lg),
                  if (t.syncInfo.status == SyncStatus.pending)
                    const StatusBanner(
                      type: StatusBannerType.offline,
                      title: 'Tersimpan di perangkat',
                      message: '· menunggu sinkron.',
                    )
                  else if (t.syncInfo.status == SyncStatus.failed)
                    StatusBanner(
                      type: StatusBannerType.error,
                      title: 'Gagal sinkron.',
                      message: 'Server menolak perubahan ini '
                          '(${t.syncInfo.error ?? 'tidak diketahui'}). '
                          'Ketuk ikon sinkron di Planner untuk mencoba lagi.',
                    ),
                  const SizedBox(height: AppSpacing.xl),
                  AppButton(
                    label: t.isCompleted ? 'Tandai belum selesai' : 'Tandai selesai',
                    icon: t.isCompleted
                        ? Icons.undo_rounded
                        : Icons.check_rounded,
                    expand: true,
                    onPressed: () =>
                        toggleTaskWithUndo(context, ref, t, !t.isCompleted),
                  ),
                  if (!t.isCompleted) ...<Widget>[
                    const SizedBox(height: AppSpacing.sm),
                    AppButton(
                      label: 'Fokus pada tugas ini',
                      icon: Icons.timer_outlined,
                      variant: AppButtonVariant.tonal,
                      expand: true,
                      onPressed: () => _focus(context, ref, t),
                    ),
                  ],
                  const SizedBox(height: AppSpacing.md),
                  Text(
                    'Dibuat ${AppDateFormat.shortDate(t.createdAt.toLocal())}',
                    textAlign: TextAlign.center,
                    style: theme.textTheme.bodySmall!.copyWith(
                      color: colors.textSecondary,
                    ),
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}

class _Row extends StatelessWidget {
  const _Row({required this.label, this.value, this.child});

  final String label;
  final String? value;
  final Widget? child;

  @override
  Widget build(BuildContext context) {
    final ThemeData theme = Theme.of(context);
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 6),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: <Widget>[
          SizedBox(
            width: 96,
            child: Text(
              label,
              style: theme.textTheme.bodyMedium!.copyWith(
                color: context.appColors.textSecondary,
              ),
            ),
          ),
          Expanded(
            child: child == null
                ? Text(value ?? '', style: theme.textTheme.bodyMedium)
                : Align(alignment: Alignment.centerLeft, child: child),
          ),
        ],
      ),
    );
  }
}
