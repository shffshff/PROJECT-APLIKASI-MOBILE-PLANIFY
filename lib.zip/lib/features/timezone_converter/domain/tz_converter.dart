import 'package:flutter/foundation.dart';
import 'package:timezone/timezone.dart' as tz;

/// Zona yang didukung (Tahap 2 §11.5).
enum AppZone {
  wib('WIB', 'Asia/Jakarta'),
  wita('WITA', 'Asia/Makassar'),
  wit('WIT', 'Asia/Jayapura'),
  london('London', 'Europe/London');

  const AppZone(this.label, this.iana);

  final String label;
  final String iana;
}

enum DstIssue {
  none,

  /// Jam tidak ada (London memajukan jam pada akhir Maret).
  nonexistent,

  /// Jam terjadi dua kali (London memundurkan jam pada akhir Oktober).
  ambiguous,
}

@immutable
class ZoneTime {
  const ZoneTime({
    required this.zone,
    required this.local,
    required this.abbreviation,
    required this.offset,
    required this.dayShift,
  });

  final AppZone zone;

  /// Komponen tanggal/jam di zona ini.
  final DateTime local;

  /// WIB/WITA/WIT, atau GMT/BST untuk London.
  final String abbreviation;
  final Duration offset;

  /// −1 / 0 / +1 dibanding tanggal asal.
  final int dayShift;

  String get offsetLabel {
    final int minutes = offset.inMinutes;
    final String sign = minutes < 0 ? '−' : '+';
    final int h = minutes.abs() ~/ 60;
    final int m = minutes.abs() % 60;
    return 'UTC$sign$h${m == 0 ? '' : ':${m.toString().padLeft(2, '0')}'}';
  }
}

@immutable
class TzResult {
  const TzResult({
    required this.utc,
    required this.times,
    required this.issue,
  });

  final DateTime utc;
  final List<ZoneTime> times;
  final DstIssue issue;
}

/// Konversi zona waktu murni berbasis basis data IANA (`timezone`).
/// Bekerja offline. Pemanggil wajib `tz.initializeTimeZones()` lebih dulu.
abstract final class TzConverter {
  static tz.Location location(AppZone z) => tz.getLocation(z.iana);

  static String _abbr(AppZone z, tz.TZDateTime t) {
    if (z != AppZone.london) {
      return z.label;
    }
    return t.timeZone.isDst ? 'BST' : 'GMT';
  }

  /// Mendeteksi jam yang tidak ada/ambigu di zona [from] (relevan untuk
  /// London). Round-trip check + perbandingan offset ±1 jam (Tahap 2 §11.5).
  static DstIssue checkDst(AppZone from, DateTime wall) {
    final tz.Location loc = location(from);
    final tz.TZDateTime t = tz.TZDateTime(
      loc,
      wall.year,
      wall.month,
      wall.day,
      wall.hour,
      wall.minute,
    );
    if (t.hour != wall.hour || t.minute != wall.minute || t.day != wall.day) {
      return DstIssue.nonexistent;
    }
    final Duration before = tz.TZDateTime.fromMillisecondsSinceEpoch(
      loc,
      t.millisecondsSinceEpoch - const Duration(hours: 1).inMilliseconds,
    ).timeZoneOffset;
    final Duration after = tz.TZDateTime.fromMillisecondsSinceEpoch(
      loc,
      t.millisecondsSinceEpoch + const Duration(hours: 1).inMilliseconds,
    ).timeZoneOffset;
    if (before != after) {
      // Offset berubah dalam ±1 jam. Jam ambigu bila komponen yang sama
      // muncul lagi satu jam kemudian dengan offset lain.
      final tz.TZDateTime later = tz.TZDateTime.fromMillisecondsSinceEpoch(
        loc,
        t.millisecondsSinceEpoch + const Duration(hours: 1).inMilliseconds,
      );
      final tz.TZDateTime earlier = tz.TZDateTime.fromMillisecondsSinceEpoch(
        loc,
        t.millisecondsSinceEpoch - const Duration(hours: 1).inMilliseconds,
      );
      if ((later.hour == t.hour && later.minute == t.minute) ||
          (earlier.hour == t.hour && earlier.minute == t.minute)) {
        return DstIssue.ambiguous;
      }
    }
    return DstIssue.none;
  }

  /// Mengonversi [wall] (tanggal+jam dinding di zona [from]) ke semua zona.
  static TzResult convert(AppZone from, DateTime wall) {
    final tz.TZDateTime source = tz.TZDateTime(
      location(from),
      wall.year,
      wall.month,
      wall.day,
      wall.hour,
      wall.minute,
    );
    final DateTime utc = source.toUtc();
    final DateTime originDate = DateTime.utc(wall.year, wall.month, wall.day);
    final List<ZoneTime> times = <ZoneTime>[
      for (final AppZone z in AppZone.values)
        () {
          final tz.TZDateTime t = tz.TZDateTime.from(utc, location(z));
          final DateTime date = DateTime.utc(t.year, t.month, t.day);
          return ZoneTime(
            zone: z,
            local: DateTime(t.year, t.month, t.day, t.hour, t.minute),
            abbreviation: _abbr(z, t),
            offset: t.timeZoneOffset,
            dayShift: date.difference(originDate).inDays,
          );
        }(),
    ];
    return TzResult(utc: utc, times: times, issue: checkDst(from, wall));
  }

  /// Zona aplikasi yang paling cocok dengan nama IANA perangkat.
  static AppZone? fromIana(String name) {
    for (final AppZone z in AppZone.values) {
      if (z.iana == name) {
        return z;
      }
    }
    return null;
  }
}
