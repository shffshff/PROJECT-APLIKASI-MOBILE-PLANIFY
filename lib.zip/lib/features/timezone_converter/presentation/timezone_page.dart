import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:intl/intl.dart';
import 'package:timezone/timezone.dart' as tz;

import '../../../core/utils/app_date_format.dart';
import '../../../core/widgets/app_button.dart';
import '../../../core/widgets/app_text_field.dart';
import '../../../core/widgets/confirm_dialog.dart';
import '../../../core/widgets/page_container.dart';
import '../../../core/widgets/status_banner.dart';
import '../../../theme/app_colors.dart';
import '../../../theme/app_theme.dart';
import '../../../theme/app_tokens.dart';
import '../../planner/data/task_repository.dart';
import '../../planner/domain/task.dart';
import '../../planner/domain/task_priority.dart';
import '../domain/tz_converter.dart';

/// Time Zone Planner (sebelumnya Time Zone Converter).
/// Alat bantu penjadwalan aktivitas lintas zona waktu: WIB, WITA, WIT, dan London (IANA).
/// Mendukung pembuatan agenda baru atau pembaruan jadwal agenda Planner.
class TimezonePage extends ConsumerStatefulWidget {
  const TimezonePage({super.key});

  @override
  ConsumerState<TimezonePage> createState() => _TimezonePageState();
}

typedef TimeZonePlannerPage = TimezonePage;

class _TimezonePageState extends ConsumerState<TimezonePage> {
  AppZone _from = AppZone.wib;
  AppZone _target = AppZone.london;
  late DateTime _wall;

  @override
  void initState() {
    super.initState();
    String device = 'Asia/Jakarta';
    try {
      device = tz.local.name;
    } catch (_) {}
    _from = TzConverter.fromIana(device) ?? AppZone.wib;
    _target = _from == AppZone.london ? AppZone.wib : AppZone.london;
    _setNow();
  }

  void _setNow() {
    final tz.TZDateTime now =
        tz.TZDateTime.now(TzConverter.location(_from));
    _wall = DateTime(now.year, now.month, now.day, now.hour, now.minute);
  }

  Future<void> _pickDate() async {
    final DateTime? d = await showDatePicker(
      context: context,
      initialDate: _wall,
      firstDate: DateTime(2000),
      lastDate: DateTime(2100),
    );
    if (d != null) {
      setState(() => _wall =
          DateTime(d.year, d.month, d.day, _wall.hour, _wall.minute));
    }
  }

  Future<void> _pickTime() async {
    final TimeOfDay? t = await showTimePicker(
      context: context,
      initialTime: TimeOfDay(hour: _wall.hour, minute: _wall.minute),
    );
    if (t != null) {
      setState(() => _wall =
          DateTime(_wall.year, _wall.month, _wall.day, t.hour, t.minute));
    }
  }

  void _swapZones() {
    setState(() {
      final AppZone temp = _from;
      _from = _target;
      _target = temp;
      _setNow();
    });
  }

  ZoneTime _findZoneTime(TzResult result, AppZone zone) {
    return result.times.firstWhere((ZoneTime zt) => zt.zone == zone);
  }

  String _formatDifference(ZoneTime fromTime, ZoneTime targetTime) {
    final Duration diff = targetTime.offset - fromTime.offset;
    final int hours = diff.inHours;
    final int minutes = diff.inMinutes.abs() % 60;

    final String minStr = minutes > 0 ? ' $minutes menit' : '';
    if (hours == 0 && minutes == 0) {
      return 'Kedua zona memiliki waktu yang sama.';
    } else if (hours > 0) {
      return '${targetTime.zone.label} (${targetTime.abbreviation}) lebih cepat $hours jam$minStr dibanding ${fromTime.zone.label}.';
    } else {
      return '${targetTime.zone.label} (${targetTime.abbreviation}) lebih lambat ${hours.abs()} jam$minStr dibanding ${fromTime.zone.label}.';
    }
  }

  Future<void> _showCreateTaskDialog(ZoneTime targetTime) async {
    final TextEditingController titleCtrl = TextEditingController(
      text: 'Pertemuan (${targetTime.zone.label})',
    );
    TaskCategory category = TaskCategory.kuliah;
    TaskPriority priority = TaskPriority.medium;

    final bool? shouldProceed = await showDialog<bool>(
      context: context,
      builder: (BuildContext ctx) => StatefulBuilder(
        builder: (BuildContext context, StateSetter setModalState) => AlertDialog(
          title: const Text('Buat Agenda Baru di Planner'),
          content: SingleChildScrollView(
            child: Column(
              mainAxisSize: MainAxisSize.min,
              crossAxisAlignment: CrossAxisAlignment.start,
              children: <Widget>[
                Text(
                  'Waktu agenda disesuaikan dengan hasil konversi zona waktu:',
                  style: Theme.of(ctx).textTheme.bodySmall,
                ),
                const SizedBox(height: AppSpacing.xs),
                Card(
                  margin: EdgeInsets.zero,
                  color: Theme.of(ctx).colorScheme.primaryContainer.withAlpha(50),
                  child: Padding(
                    padding: const EdgeInsets.all(AppSpacing.sm),
                    child: Row(
                      children: <Widget>[
                        Icon(
                          Icons.schedule_rounded,
                          size: 20,
                          color: Theme.of(ctx).colorScheme.primary,
                        ),
                        const SizedBox(width: AppSpacing.sm),
                        Expanded(
                          child: Text(
                            '${DateFormat('EEEE, d MMM yyyy', 'id_ID').format(targetTime.local)} · ${AppDateFormat.time(targetTime.local)} (${targetTime.abbreviation})',
                            style: Theme.of(ctx).textTheme.bodyMedium!.copyWith(
                                  fontWeight: FontWeight.w600,
                                ),
                          ),
                        ),
                      ],
                    ),
                  ),
                ),
                const SizedBox(height: AppSpacing.md),
                AppTextField(
                  label: 'Judul Agenda',
                  controller: titleCtrl,
                  prefixIcon: const Icon(Icons.title_rounded),
                ),
                const SizedBox(height: AppSpacing.md),
                DropdownButtonFormField<TaskCategory>(
                  initialValue: category,
                  decoration: const InputDecoration(labelText: 'Kategori'),
                  items: <DropdownMenuItem<TaskCategory>>[
                    for (final TaskCategory c in TaskCategory.values)
                      DropdownMenuItem<TaskCategory>(
                        value: c,
                        child: Text(c.label),
                      ),
                  ],
                  onChanged: (TaskCategory? val) {
                    if (val != null) setModalState(() => category = val);
                  },
                ),
                const SizedBox(height: AppSpacing.md),
                DropdownButtonFormField<TaskPriority>(
                  initialValue: priority,
                  decoration: const InputDecoration(labelText: 'Prioritas'),
                  items: <DropdownMenuItem<TaskPriority>>[
                    for (final TaskPriority p in TaskPriority.values)
                      DropdownMenuItem<TaskPriority>(
                        value: p,
                        child: Text(p.label),
                      ),
                  ],
                  onChanged: (TaskPriority? val) {
                    if (val != null) setModalState(() => priority = val);
                  },
                ),
              ],
            ),
          ),
          actions: <Widget>[
            TextButton(
              onPressed: () => Navigator.of(ctx).pop(false),
              child: const Text('Batal'),
            ),
            FilledButton(
              onPressed: () => Navigator.of(ctx).pop(true),
              child: const Text('Lanjutkan'),
            ),
          ],
        ),
      ),
    );

    if (shouldProceed != true || !mounted) return;

    final String title = titleCtrl.text.trim().isEmpty
        ? 'Aktivitas Lintas Zona'
        : titleCtrl.text.trim();

    final String targetDateStr =
        DateFormat('d MMM yyyy', 'id_ID').format(targetTime.local);
    final String targetTimeStr = AppDateFormat.time(targetTime.local);

    // Tampilkan konfirmasi wajib sebelum menyimpan
    final ConfirmResult confirm = await showConfirmDialog(
      context,
      title: 'Konfirmasi Simpan Agenda',
      message:
          'Tambahkan agenda "$title" pada tanggal $targetDateStr pukul $targetTimeStr (${targetTime.abbreviation}) ke Planner?',
      confirmLabel: 'Simpan ke Planner',
    );

    if (confirm != ConfirmResult.confirm || !mounted) return;

    final TaskDraft draft = TaskDraft(
      title: title,
      description:
          'Direncanakan via Time Zone Planner. Zona asal: ${_from.label} (${AppDateFormat.time(_wall)}), Zona target: ${targetTime.zone.label} ($targetTimeStr ${targetTime.abbreviation}).',
      dueDate: DateTime(
        targetTime.local.year,
        targetTime.local.month,
        targetTime.local.day,
      ),
      dueTimeMinutes: targetTime.local.hour * 60 + targetTime.local.minute,
      category: category,
      priority: priority,
      source: TaskSource.manual,
    );

    await ref.read(taskRepositoryProvider).create(draft);

    if (mounted) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text(
            'Agenda "$title" berhasil ditambahkan ke Planner.',
          ),
        ),
      );
    }
  }

  Future<void> _showUpdateTaskDialog(ZoneTime targetTime) async {
    List<Task> tasks = ref.read(tasksProvider).value ?? const <Task>[];
    if (tasks.isEmpty) {
      tasks = ref.read(taskStoreProvider).all();
    }
    final List<Task> activeTasks =
        tasks.where((Task t) => !t.isDeleted && !t.isCompleted).toList();

    if (activeTasks.isEmpty) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(
          content: Text('Tidak ada agenda aktif di Planner untuk diperbarui.'),
        ),
      );
      return;
    }

    String? selectedTaskId = activeTasks.first.id;

    final bool? shouldProceed = await showDialog<bool>(
      context: context,
      builder: (BuildContext ctx) => StatefulBuilder(
        builder: (BuildContext context, StateSetter setModalState) => AlertDialog(
          title: const Text('Perbarui Waktu Agenda di Planner'),
          content: SingleChildScrollView(
            child: Column(
              mainAxisSize: MainAxisSize.min,
              crossAxisAlignment: CrossAxisAlignment.start,
              children: <Widget>[
                Text(
                  'Pilih agenda yang akan disesuaikan dengan waktu hasil konversi:',
                  style: Theme.of(ctx).textTheme.bodySmall,
                ),
                const SizedBox(height: AppSpacing.sm),
                DropdownButtonFormField<String>(
                  initialValue: selectedTaskId,
                  isExpanded: true,
                  decoration: const InputDecoration(labelText: 'Agenda Planner'),
                  items: <DropdownMenuItem<String>>[
                    for (final Task t in activeTasks)
                      DropdownMenuItem<String>(
                        value: t.id,
                        child: Text(
                          t.title,
                          overflow: TextOverflow.ellipsis,
                        ),
                      ),
                  ],
                  onChanged: (String? val) {
                    if (val != null) {
                      setModalState(() => selectedTaskId = val);
                    }
                  },
                ),
                const SizedBox(height: AppSpacing.md),
                Text(
                  'Waktu baru:',
                  style: Theme.of(ctx).textTheme.labelSmall,
                ),
                const SizedBox(height: AppSpacing.xs),
                Text(
                  '${DateFormat('EEEE, d MMM yyyy', 'id_ID').format(targetTime.local)} · ${AppDateFormat.time(targetTime.local)} (${targetTime.abbreviation})',
                  style: Theme.of(ctx).textTheme.bodyMedium!.copyWith(
                        fontWeight: FontWeight.bold,
                        color: Theme.of(ctx).colorScheme.primary,
                      ),
                ),
              ],
            ),
          ),
          actions: <Widget>[
            TextButton(
              onPressed: () => Navigator.of(ctx).pop(false),
              child: const Text('Batal'),
            ),
            FilledButton(
              onPressed: () => Navigator.of(ctx).pop(true),
              child: const Text('Lanjutkan'),
            ),
          ],
        ),
      ),
    );

    if (shouldProceed != true || selectedTaskId == null || !mounted) return;

    final Task selectedTask =
        activeTasks.firstWhere((Task t) => t.id == selectedTaskId);

    final String targetDateStr =
        DateFormat('d MMM yyyy', 'id_ID').format(targetTime.local);
    final String targetTimeStr = AppDateFormat.time(targetTime.local);

    // Tampilkan konfirmasi wajib sebelum menyimpan
    final ConfirmResult confirm = await showConfirmDialog(
      context,
      title: 'Konfirmasi Pembaruan Agenda',
      message:
          'Ubah jadwal tugas "${selectedTask.title}" menjadi tanggal $targetDateStr pukul $targetTimeStr (${targetTime.abbreviation})?',
      confirmLabel: 'Perbarui Jadwal',
    );

    if (confirm != ConfirmResult.confirm || !mounted) return;

    final TaskDraft draft = TaskDraft(
      title: selectedTask.title,
      description: selectedTask.description,
      dueDate: DateTime(
        targetTime.local.year,
        targetTime.local.month,
        targetTime.local.day,
      ),
      dueTimeMinutes: targetTime.local.hour * 60 + targetTime.local.minute,
      category: selectedTask.category,
      priority: selectedTask.priority,
      reminderAt: selectedTask.reminderAt,
      source: selectedTask.source,
    );

    await ref.read(taskRepositoryProvider).update(selectedTask, draft);

    if (mounted) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text(
            'Jadwal agenda "${selectedTask.title}" berhasil diperbarui.',
          ),
        ),
      );
    }
  }

  @override
  Widget build(BuildContext context) {
    final ThemeData theme = Theme.of(context);
    final TzResult result = TzConverter.convert(_from, _wall);
    final ZoneTime originTime = _findZoneTime(result, _from);
    final ZoneTime targetTime = _findZoneTime(result, _target);

    final String wallLabel =
        '${AppDateFormat.time(_wall)} pada ${DateFormat('d MMM yyyy', 'id_ID').format(_wall)}';

    return Scaffold(
      appBar: AppBar(title: const Text('Time Zone Planner')),
      body: SafeArea(
        child: ListView(
          padding: const EdgeInsets.only(bottom: AppSpacing.xxl),
          children: <Widget>[
            PageContainer(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.stretch,
                children: <Widget>[
                  const SizedBox(height: AppSpacing.md),
                  // Pemilih Tanggal & Waktu Asal
                  Row(
                    children: <Widget>[
                      Expanded(
                        child: OutlinedButton.icon(
                          onPressed: _pickDate,
                          icon: const Icon(Icons.event_rounded),
                          label: Text(
                            DateFormat('EEE, d MMM yyyy', 'id_ID').format(_wall),
                          ),
                        ),
                      ),
                      const SizedBox(width: AppSpacing.sm),
                      OutlinedButton.icon(
                        onPressed: _pickTime,
                        icon: const Icon(Icons.schedule_rounded),
                        label: Text(AppDateFormat.time(_wall)),
                      ),
                      const SizedBox(width: AppSpacing.sm),
                      TextButton(
                        onPressed: () => setState(_setNow),
                        child: const Text('Sekarang'),
                      ),
                    ],
                  ),
                  const SizedBox(height: AppSpacing.lg),
                  // Pemilih Zona Asal & Target
                  Row(
                    children: <Widget>[
                      Expanded(
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: <Widget>[
                            Text('Zona Asal', style: theme.textTheme.labelMedium),
                            const SizedBox(height: AppSpacing.xs),
                            DropdownButtonFormField<AppZone>(
                              initialValue: _from,
                              decoration: const InputDecoration(
                                contentPadding: EdgeInsets.symmetric(
                                  horizontal: 12,
                                  vertical: 8,
                                ),
                              ),
                              items: <DropdownMenuItem<AppZone>>[
                                for (final AppZone z in AppZone.values)
                                  DropdownMenuItem<AppZone>(
                                    value: z,
                                    child: Text(z.label),
                                  ),
                              ],
                              onChanged: (AppZone? z) {
                                if (z != null) setState(() => _from = z);
                              },
                            ),
                          ],
                        ),
                      ),
                      Padding(
                        padding: const EdgeInsets.only(top: 18),
                        child: IconButton(
                          tooltip: 'Tukar zona waktu',
                          icon: const Icon(Icons.swap_horiz_rounded),
                          onPressed: _swapZones,
                        ),
                      ),
                      Expanded(
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: <Widget>[
                            Text('Zona Target', style: theme.textTheme.labelMedium),
                            const SizedBox(height: AppSpacing.xs),
                            DropdownButtonFormField<AppZone>(
                              initialValue: _target,
                              decoration: const InputDecoration(
                                contentPadding: EdgeInsets.symmetric(
                                  horizontal: 12,
                                  vertical: 8,
                                ),
                              ),
                              items: <DropdownMenuItem<AppZone>>[
                                for (final AppZone z in AppZone.values)
                                  DropdownMenuItem<AppZone>(
                                    value: z,
                                    child: Text(z.label),
                                  ),
                              ],
                              onChanged: (AppZone? z) {
                                if (z != null) setState(() => _target = z);
                              },
                            ),
                          ],
                        ),
                      ),
                    ],
                  ),
                  const SizedBox(height: AppSpacing.lg),
                  // Kartu Perbandingan Utama Hasil Konversi
                  _MainConversionCard(
                    origin: originTime,
                    target: targetTime,
                    differenceText: _formatDifference(originTime, targetTime),
                  ),
                  const SizedBox(height: AppSpacing.md),
                  // Aksi Penjadwalan Planner
                  Card(
                    margin: EdgeInsets.zero,
                    child: Padding(
                      padding: const EdgeInsets.all(AppSpacing.md),
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: <Widget>[
                          Row(
                            children: <Widget>[
                              Icon(
                                Icons.calendar_month_rounded,
                                size: 18,
                                color: theme.colorScheme.primary,
                              ),
                              const SizedBox(width: AppSpacing.xs),
                              Text(
                                'JADWALKAN DI PLANNER',
                                style: theme.textTheme.labelSmall,
                              ),
                            ],
                          ),
                          const SizedBox(height: AppSpacing.xs),
                          Text(
                            'Gunakan waktu ${targetTime.zone.label} (${AppDateFormat.time(targetTime.local)} ${targetTime.abbreviation}) untuk agenda aktivitas:',
                            style: theme.textTheme.bodySmall,
                          ),
                          const SizedBox(height: AppSpacing.md),
                          Row(
                            children: <Widget>[
                              Expanded(
                                child: AppButton(
                                  label: 'Jadikan Agenda Baru',
                                  icon: Icons.add_task_rounded,
                                  onPressed: () =>
                                      _showCreateTaskDialog(targetTime),
                                ),
                              ),
                              const SizedBox(width: AppSpacing.sm),
                              Expanded(
                                child: AppButton(
                                  label: 'Perbarui Agenda',
                                  icon: Icons.edit_calendar_rounded,
                                  variant: AppButtonVariant.outline,
                                  onPressed: () =>
                                      _showUpdateTaskDialog(targetTime),
                                ),
                              ),
                            ],
                          ),
                        ],
                      ),
                    ),
                  ),
                  if (result.issue != DstIssue.none) ...<Widget>[
                    const SizedBox(height: AppSpacing.md),
                    StatusBanner(
                      type: StatusBannerType.warning,
                      title: result.issue == DstIssue.nonexistent
                          ? 'Jam ini tidak ada.'
                          : 'Jam ini terjadi dua kali.',
                      message: result.issue == DstIssue.nonexistent
                          ? 'Pada $wallLabel jam di ${_from.label} dimajukan '
                              '(mulai BST), jadi hasil memakai jam setelah '
                              'pergantian.'
                          : 'Pada $wallLabel ${_from.label} kembali ke GMT, '
                              'jadi jam itu terjadi dua kali. Periksa '
                              'singkatan BST/GMT pada kartu London untuk '
                              'mengetahui kemunculan yang dipakai.',
                    ),
                  ],
                  const SizedBox(height: AppSpacing.lg),
                  Text('SEMUA ZONA WAKTU', style: theme.textTheme.labelSmall),
                  const SizedBox(height: AppSpacing.xs),
                  for (final ZoneTime t in result.times)
                    _ZoneCard(
                      time: t,
                      isOrigin: t.zone == _from,
                      isTarget: t.zone == _target,
                    ),
                  const SizedBox(height: AppSpacing.md),
                  Text(
                    'Konversi memakai basis data zona waktu IANA di perangkat, '
                    'sehingga tetap berjalan offline dan memperhitungkan '
                    'Daylight Saving Time (BST/GMT London) secara akurat.',
                    style: theme.textTheme.bodySmall!.copyWith(
                      color: context.appColors.textSecondary,
                    ),
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}

class _MainConversionCard extends StatelessWidget {
  const _MainConversionCard({
    required this.origin,
    required this.target,
    required this.differenceText,
  });

  final ZoneTime origin;
  final ZoneTime target;
  final String differenceText;

  @override
  Widget build(BuildContext context) {
    final ThemeData theme = Theme.of(context);
    final AppColors colors = context.appColors;

    final String dayShiftLabel = target.dayShift == 0
        ? 'Hari yang sama'
        : (target.dayShift > 0
            ? '+${target.dayShift} hari (Besok)'
            : '${target.dayShift} hari (Kemarin)');

    return Card(
      margin: EdgeInsets.zero,
      color: theme.colorScheme.primaryContainer.withAlpha(50),
      child: Padding(
        padding: const EdgeInsets.all(AppSpacing.lg),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: <Widget>[
            Text('HASIL KONVERSI JADWAL', style: theme.textTheme.labelSmall),
            const SizedBox(height: AppSpacing.sm),
            Row(
              children: <Widget>[
                // Asal
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: <Widget>[
                      Text(
                        origin.zone.label,
                        style: theme.textTheme.titleSmall!.copyWith(
                          color: colors.textSecondary,
                        ),
                      ),
                      Text(
                        AppDateFormat.time(origin.local),
                        style: theme.textTheme.headlineMedium!.copyWith(
                          fontFeatures: AppTypography.tabularFigures,
                          fontWeight: FontWeight.bold,
                        ),
                      ),
                      Text(
                        '${DateFormat('d MMM', 'id_ID').format(origin.local)} · ${origin.abbreviation}',
                        style: theme.textTheme.bodySmall,
                      ),
                    ],
                  ),
                ),
                Icon(
                  Icons.arrow_forward_rounded,
                  color: theme.colorScheme.primary,
                ),
                // Target
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.end,
                    children: <Widget>[
                      Text(
                        target.zone.label,
                        style: theme.textTheme.titleSmall!.copyWith(
                          color: theme.colorScheme.primary,
                          fontWeight: FontWeight.bold,
                        ),
                      ),
                      Text(
                        AppDateFormat.time(target.local),
                        style: theme.textTheme.headlineMedium!.copyWith(
                          fontFeatures: AppTypography.tabularFigures,
                          fontWeight: FontWeight.bold,
                          color: theme.colorScheme.primary,
                        ),
                      ),
                      Text(
                        '${DateFormat('d MMM', 'id_ID').format(target.local)} · ${target.abbreviation}',
                        style: theme.textTheme.bodySmall!.copyWith(
                          fontWeight: FontWeight.w600,
                        ),
                      ),
                    ],
                  ),
                ),
              ],
            ),
            const Divider(height: AppSpacing.lg),
            Row(
              children: <Widget>[
                Container(
                  padding: const EdgeInsets.symmetric(
                    horizontal: 8,
                    vertical: 2,
                  ),
                  decoration: BoxDecoration(
                    color: target.dayShift == 0
                        ? theme.colorScheme.surfaceContainerHighest
                        : theme.colorScheme.primary.withAlpha(30),
                    borderRadius: AppRadius.smAll,
                  ),
                  child: Text(
                    dayShiftLabel,
                    style: theme.textTheme.labelSmall!.copyWith(
                      color: target.dayShift != 0
                          ? theme.colorScheme.primary
                          : null,
                      fontWeight: FontWeight.w600,
                    ),
                  ),
                ),
                const SizedBox(width: AppSpacing.sm),
                Expanded(
                  child: Text(
                    differenceText,
                    style: theme.textTheme.bodySmall,
                    overflow: TextOverflow.ellipsis,
                  ),
                ),
              ],
            ),
          ],
        ),
      ),
    );
  }
}

class _ZoneCard extends StatelessWidget {
  const _ZoneCard({
    required this.time,
    required this.isOrigin,
    this.isTarget = false,
  });

  final ZoneTime time;
  final bool isOrigin;
  final bool isTarget;

  @override
  Widget build(BuildContext context) {
    final ThemeData theme = Theme.of(context);
    final String shift = time.dayShift == 0
        ? ''
        : (time.dayShift > 0
            ? ' · +${time.dayShift} hari'
            : ' · ${time.dayShift} hari');

    Color? cardColor;
    if (isOrigin) {
      cardColor = theme.colorScheme.primaryContainer.withAlpha(80);
    } else if (isTarget) {
      cardColor = theme.colorScheme.secondaryContainer.withAlpha(50);
    }

    String role = '';
    if (isOrigin && isTarget) {
      role = ' · ASAL & TARGET';
    } else if (isOrigin) {
      role = ' · ASAL';
    } else if (isTarget) {
      role = ' · TARGET';
    }

    return Card(
      margin: const EdgeInsets.only(bottom: AppSpacing.sm),
      color: cardColor,
      child: Padding(
        padding: const EdgeInsets.all(AppSpacing.lg),
        child: Row(
          children: <Widget>[
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: <Widget>[
                  Text(
                    '${time.zone.label}$role',
                    style: theme.textTheme.titleSmall!.copyWith(
                      fontWeight: (isOrigin || isTarget)
                          ? FontWeight.bold
                          : FontWeight.normal,
                    ),
                  ),
                  Text(
                    '${time.zone.iana} · ${time.abbreviation} · ${time.offsetLabel}',
                    style: theme.textTheme.bodySmall,
                  ),
                ],
              ),
            ),
            Column(
              crossAxisAlignment: CrossAxisAlignment.end,
              children: <Widget>[
                Text(
                  AppDateFormat.time(time.local),
                  style: theme.textTheme.headlineSmall!
                      .copyWith(fontFeatures: AppTypography.tabularFigures),
                ),
                Text(
                  '${AppDateFormat.shortDate(time.local)}$shift',
                  style: theme.textTheme.bodySmall,
                ),
              ],
            ),
          ],
        ),
      ),
    );
  }
}
