import 'package:flutter/foundation.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../../../core/error/app_failure.dart';
import '../../../core/storage/local_database.dart';
import '../../../core/sync/local_change_signal.dart';
import '../../../core/sync/sync_entity.dart';
import '../../../core/utils/date_only.dart';
import '../../hash_chain/data/achievement_repository.dart';
import '../../planner/data/task_repository.dart';
import '../domain/habit.dart';
import '../domain/streak_calculator.dart';

/// Nilai form habit.
@immutable
class HabitDraft {
  const HabitDraft({
    required this.name,
    required this.targetWeekdays,
    required this.colorValue,
    this.description,
  });

  final String name;
  final String? description;
  final List<int> targetWeekdays;
  final int colorValue;
}

/// Habit beserta progresnya (turunan, tidak disimpan).
@immutable
class HabitProgress {
  const HabitProgress({
    required this.habit,
    required this.doneToday,
    required this.isTargetToday,
    required this.streak,
    required this.bestStreak,
    required this.weekRate,
    required this.monthRate,
    required this.doneDates,
  });

  final Habit habit;
  final bool doneToday;
  final bool isTargetToday;
  final int streak;
  final int bestStreak;
  final double weekRate;
  final double monthRate;
  final Set<DateTime> doneDates;

  bool isDone(DateTime day) =>
      doneDates.any((DateTime d) => DateOnly.isSameDay(d, day));
}

class HabitRepository {
  HabitRepository({
    required EntityStore<Habit> habits,
    required EntityStore<HabitLog> logs,
    required LocalChangeSignal signal,
    required String? Function() userId,
    Future<void> Function(Map<String, dynamic> data)? onAchievement,
  })  : _onAchievement = onAchievement,
        _habits = habits,
        _logs = logs,
        _signal = signal,
        _userId = userId;

  final EntityStore<Habit> _habits;
  final EntityStore<HabitLog> _logs;
  final LocalChangeSignal _signal;
  final String? Function() _userId;
  final Future<void> Function(Map<String, dynamic> data)? _onAchievement;

  /// Batas pencatatan susulan (K-09 Tahap 2).
  static const int maxBackfillDays = 7;

  String _requireUser() {
    final String? id = _userId();
    if (id == null) {
      throw const AppFailure(AppFailureKind.unauthorized);
    }
    return id;
  }

  Stream<List<Habit>> watchHabits() => _habits.watch();
  Stream<List<HabitLog>> watchLogs() => _logs.watch();

  Habit? byId(String id) {
    final Habit? h = _habits.get(id);
    return h == null || h.deletedAt != null ? null : h;
  }

  Future<Habit> create(HabitDraft draft) async {
    final DateTime now = _habits.nowUtc();
    final String? description = draft.description?.trim();
    final Habit saved = await _habits.saveLocal(
      Habit(
        id: Ids.newId(),
        userId: _requireUser(),
        name: draft.name.trim(),
        description:
            description == null || description.isEmpty ? null : description,
        targetWeekdays: List<int>.of(draft.targetWeekdays)..sort(),
        colorValue: draft.colorValue,
        createdAt: now,
        updatedAt: now,
      ),
    );
    _signal.notify();
    return saved;
  }

  Future<Habit> update(Habit habit, HabitDraft draft) async {
    final String? description = draft.description?.trim();
    final Habit saved = await _habits.saveLocal(
      habit.copyWith(
        name: draft.name.trim(),
        description:
            description == null || description.isEmpty ? null : description,
        clearDescription: description == null || description.isEmpty,
        targetWeekdays: List<int>.of(draft.targetWeekdays)..sort(),
        colorValue: draft.colorValue,
      ),
    );
    _signal.notify();
    return saved;
  }

  Future<void> delete(Habit habit) async {
    await _habits.saveLocal(habit.copyWith(deletedAt: _habits.nowUtc()));
    _signal.notify();
  }

  /// Mencentang/membatalkan habit pada [day] (FR-026). Tanggal masa depan
  /// ditolak. Centang ulang memakai key yang sama → tidak ada duplikat.
  Future<void> setDone(Habit habit, DateTime day, {required bool done}) async {
    final DateTime date = DateOnly.of(day);
    final DateTime today = DateOnly.of(DateTime.now());
    if (date.isAfter(today)) {
      throw const AppFailure(
        AppFailureKind.validation,
        message: 'Tanggal yang akan datang belum bisa dicatat.',
      );
    }
    if (date.isBefore(DateOnly.addDays(today, -maxBackfillDays))) {
      throw const AppFailure(
        AppFailureKind.validation,
        message: 'Hanya $maxBackfillDays hari terakhir yang bisa dicatat '
            'susulan.',
      );
    }
    final DateTime now = _logs.nowUtc();
    final String key = HabitLog.keyFor(habit.id, date);
    final HabitLog? existing = _logs.get(key);
    final HabitLog log = existing?.toggled(done: done, nowUtc: now) ??
        HabitLog(
          habitId: habit.id,
          logDate: date,
          userId: _requireUser(),
          createdAt: now,
          updatedAt: now,
          deletedAt: done ? null : now,
        );
    if (existing == null && !done) {
      return; // tidak ada yang dibatalkan
    }
    await _logs.saveLocal(log);
    _signal.notify();
    if (done) {
      final String eventRef = HabitLog.keyFor(habit.id, date);
      await _onAchievement?.call(<String, dynamic>{
        'type': 'habit_completed',
        'habitId': habit.id,
        'habitName': habit.name,
        'logDate': DateOnly.format(date),
        'status': 'completed',
        'eventRef': eventRef,
      });
      if (DateOnly.isSameDay(date, DateTime.now())) {
        await _maybeStreakAchievement(habit);
      }
    }
  }

  /// Blok hash chain setiap kelipatan 7 hari streak (K-11).
  Future<void> _maybeStreakAchievement(Habit habit) async {
    final Set<DateTime> done = _logs
        .all()
        .where((HabitLog l) => l.habitId == habit.id && l.isDone)
        .map((HabitLog l) => l.logDate)
        .toSet();
    final int streak = StreakCalculator.current(
      doneDates: done,
      targetWeekdays: habit.targetWeekdays,
      today: DateTime.now(),
    );
    if (streak > 0 && streak % 7 == 0) {
      await _onAchievement?.call(<String, dynamic>{
        'type': 'habit_streak',
        'habitId': habit.id,
        'name': habit.name,
        'streak': streak,
      });
    }
  }

  static List<HabitProgress> progress(
    List<Habit> habits,
    List<HabitLog> logs,
    DateTime now,
  ) {
    final Map<String, Set<DateTime>> byHabit = <String, Set<DateTime>>{};
    for (final HabitLog log in logs) {
      if (log.isDone) {
        byHabit.putIfAbsent(log.habitId, () => <DateTime>{}).add(log.logDate);
      }
    }
    final List<HabitProgress> out = <HabitProgress>[];
    for (final Habit habit in habits) {
      if (habit.deletedAt != null || !habit.isActive) {
        continue;
      }
      final Set<DateTime> done = byHabit[habit.id] ?? <DateTime>{};
      final DateTime started = habit.createdAt.toLocal();
      out.add(
        HabitProgress(
          habit: habit,
          doneToday: done.any((DateTime d) => DateOnly.isSameDay(d, now)),
          isTargetToday: habit.isTargetDay(now),
          streak: StreakCalculator.current(
            doneDates: done,
            targetWeekdays: habit.targetWeekdays,
            today: now,
          ),
          bestStreak: StreakCalculator.best(
            doneDates: done,
            targetWeekdays: habit.targetWeekdays,
            today: now,
          ),
          weekRate: StreakCalculator.completionRate(
            doneDates: done,
            targetWeekdays: habit.targetWeekdays,
            today: now,
            startedOn: started,
          ),
          monthRate: StreakCalculator.completionRate(
            doneDates: done,
            targetWeekdays: habit.targetWeekdays,
            today: now,
            days: 30,
            startedOn: started,
          ),
          doneDates: done,
        ),
      );
    }
    out.sort(
      (HabitProgress a, HabitProgress b) =>
          a.habit.createdAt.compareTo(b.habit.createdAt),
    );
    return out;
  }
}

final Provider<EntityStore<Habit>> habitStoreProvider =
    Provider<EntityStore<Habit>>(
  (Ref ref) => EntityStore<Habit>(
    ref.watch(localDatabaseProvider).habits,
    Habit.spec,
    Habit.fromJson,
  ),
);

final Provider<EntityStore<HabitLog>> habitLogStoreProvider =
    Provider<EntityStore<HabitLog>>(
  (Ref ref) => EntityStore<HabitLog>(
    ref.watch(localDatabaseProvider).habitLogs,
    HabitLog.spec,
    HabitLog.fromJson,
  ),
);

final Provider<HabitRepository> habitRepositoryProvider =
    Provider<HabitRepository>(
  (Ref ref) => HabitRepository(
    habits: ref.watch(habitStoreProvider),
    logs: ref.watch(habitLogStoreProvider),
    signal: ref.watch(localChangeSignalProvider),
    userId: () => ref.read(currentUserIdProvider),
    onAchievement: ref.watch(achievementRepositoryProvider).record,
  ),
);

final StreamProvider<List<Habit>> habitsProvider = StreamProvider<List<Habit>>(
  (Ref ref) => ref.watch(habitRepositoryProvider).watchHabits(),
);

/// Log termasuk yang dibatalkan (tombstone) — difilter oleh [progress].
final StreamProvider<List<HabitLog>> habitLogsProvider =
    StreamProvider<List<HabitLog>>(
  (Ref ref) => ref.watch(habitLogStoreProvider).watch(),
);

/// Progres seluruh habit aktif untuk hari ini.
final Provider<AsyncValue<List<HabitProgress>>> habitProgressProvider =
    Provider<AsyncValue<List<HabitProgress>>>((Ref ref) {
  final AsyncValue<List<Habit>> habits = ref.watch(habitsProvider);
  final AsyncValue<List<HabitLog>> logs = ref.watch(habitLogsProvider);
  if (habits.hasError) {
    return AsyncValue<List<HabitProgress>>.error(
      habits.error!,
      habits.stackTrace ?? StackTrace.current,
    );
  }
  final List<Habit>? h = habits.value;
  final List<HabitLog>? l = logs.value;
  if (h == null || l == null) {
    return const AsyncValue<List<HabitProgress>>.loading();
  }
  return AsyncValue<List<HabitProgress>>.data(
    HabitRepository.progress(h, l, DateTime.now()),
  );
});
