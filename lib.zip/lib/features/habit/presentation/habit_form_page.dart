import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:go_router/go_router.dart';

import '../../../app/router/routes.dart';
import '../../../core/error/app_failure.dart';
import '../../../core/widgets/app_button.dart';
import '../../../core/widgets/app_text_field.dart';
import '../../../core/widgets/empty_state.dart';
import '../../../core/widgets/page_container.dart';
import '../../../theme/app_colors.dart';
import '../../../theme/app_tokens.dart';
import '../data/habit_repository.dart';
import '../domain/habit.dart';
import 'habits_page.dart';

/// Form buat/ubah kebiasaan (FR-025).
class HabitFormPage extends ConsumerStatefulWidget {
  const HabitFormPage({super.key, this.habitId});

  final String? habitId;

  @override
  ConsumerState<HabitFormPage> createState() => _HabitFormPageState();
}

class _HabitFormPageState extends ConsumerState<HabitFormPage> {
  final GlobalKey<FormState> _formKey = GlobalKey<FormState>();
  final TextEditingController _name = TextEditingController();
  final TextEditingController _description = TextEditingController();
  Habit? _original;
  bool _missing = false;
  Set<int> _days = <int>{1, 2, 3, 4, 5, 6, 7};
  int _color = AppPalette.habitSwatches.first.toARGB32();
  bool _saving = false;
  String? _daysError;

  @override
  void initState() {
    super.initState();
    final String? id = widget.habitId;
    if (id != null) {
      final Habit? h = ref.read(habitRepositoryProvider).byId(id);
      if (h == null) {
        _missing = true;
        return;
      }
      _original = h;
      _name.text = h.name;
      _description.text = h.description ?? '';
      _days = h.targetWeekdays.toSet();
      _color = h.colorValue;
    }
  }

  @override
  void dispose() {
    _name.dispose();
    _description.dispose();
    super.dispose();
  }

  static String? _validateName(String? v) {
    final String t = v?.trim() ?? '';
    if (t.isEmpty) {
      return 'Nama kebiasaan wajib diisi.';
    }
    if (t.length > Habit.maxName) {
      return 'Maksimal ${Habit.maxName} karakter.';
    }
    return null;
  }

  Future<void> _save() async {
    if (_saving) {
      return;
    }
    final bool ok = _formKey.currentState?.validate() ?? false;
    setState(() => _daysError =
        _days.isEmpty ? 'Pilih minimal satu hari target.' : null);
    if (!ok || _days.isEmpty) {
      return;
    }
    setState(() => _saving = true);
    final ScaffoldMessengerState messenger = ScaffoldMessenger.of(context);
    final HabitDraft draft = HabitDraft(
      name: _name.text,
      description: _description.text,
      targetWeekdays: _days.toList()..sort(),
      colorValue: _color,
    );
    try {
      final Habit? original = _original;
      if (original == null) {
        await ref.read(habitRepositoryProvider).create(draft);
      } else {
        await ref.read(habitRepositoryProvider).update(original, draft);
      }
      messenger.showSnackBar(
        const SnackBar(content: Text('Kebiasaan disimpan.')),
      );
      if (mounted) {
        context.canPop() ? context.pop() : context.go(AppRoutes.habits);
      }
    } catch (error) {
      final AppFailure f = AppFailure.from(error);
      if (mounted) {
        setState(() => _saving = false);
      }
      messenger.showSnackBar(
        SnackBar(content: Text('${f.title}. ${f.userMessage}')),
      );
    }
  }

  @override
  Widget build(BuildContext context) {
    final bool isNew = widget.habitId == null;
    if (_missing) {
      return Scaffold(
        appBar: AppBar(title: const Text('Ubah kebiasaan')),
        body: EmptyState(
          icon: Icons.search_off_rounded,
          title: 'Kebiasaan tidak ditemukan',
          primaryActionLabel: 'Kembali',
          onPrimaryAction: () => context.go(AppRoutes.habits),
        ),
      );
    }
    final ThemeData theme = Theme.of(context);
    return Scaffold(
      appBar: AppBar(title: Text(isNew ? 'Kebiasaan baru' : 'Ubah kebiasaan')),
      body: SafeArea(
        child: Form(
          key: _formKey,
          child: ListView(
            children: <Widget>[
              PageContainer(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.stretch,
                  children: <Widget>[
                    const SizedBox(height: AppSpacing.lg),
                    AppTextField(
                      label: 'Nama',
                      controller: _name,
                      isRequired: true,
                      autofocus: isNew,
                      validator: _validateName,
                      maxLength: Habit.maxName,
                      showCounterFrom: 40,
                      textCapitalization: TextCapitalization.sentences,
                      hintText: 'Contoh: Baca 20 menit',
                    ),
                    const SizedBox(height: AppSpacing.lg),
                    AppTextField(
                      label: 'Catatan',
                      controller: _description,
                      maxLength: Habit.maxDescription,
                      showCounterFrom: 150,
                      minLines: 1,
                      maxLines: 3,
                      validator: (String? v) =>
                          (v?.length ?? 0) > Habit.maxDescription
                              ? 'Maksimal ${Habit.maxDescription} karakter.'
                              : null,
                    ),
                    const SizedBox(height: AppSpacing.lg),
                    Text('Hari target', style: theme.textTheme.labelLarge),
                    const SizedBox(height: AppSpacing.sm),
                    Wrap(
                      spacing: AppSpacing.sm,
                      runSpacing: AppSpacing.sm,
                      children: <Widget>[
                        for (int d = 1; d <= 7; d++)
                          FilterChip(
                            label: Text(kWeekdayShort[d - 1]),
                            selected: _days.contains(d),
                            onSelected: (bool on) => setState(() {
                              on ? _days.add(d) : _days.remove(d);
                              _daysError = null;
                            }),
                          ),
                      ],
                    ),
                    if (_daysError != null)
                      Padding(
                        padding: const EdgeInsets.only(top: AppSpacing.xs),
                        child: Text(
                          _daysError!,
                          style: theme.textTheme.bodySmall!
                              .copyWith(color: theme.colorScheme.error),
                        ),
                      ),
                    const SizedBox(height: AppSpacing.lg),
                    Text('Warna', style: theme.textTheme.labelLarge),
                    const SizedBox(height: AppSpacing.sm),
                    Wrap(
                      spacing: AppSpacing.sm,
                      runSpacing: AppSpacing.sm,
                      children: <Widget>[
                        for (final Color c in AppPalette.habitSwatches)
                          Semantics(
                            button: true,
                            selected: _color == c.toARGB32(),
                            label: 'Warna ${AppPalette.habitSwatches.indexOf(c) + 1}',
                            child: InkWell(
                              customBorder: const CircleBorder(),
                              onTap: () =>
                                  setState(() => _color = c.toARGB32()),
                              child: Container(
                                width: AppSizes.minTouchTarget,
                                height: AppSizes.minTouchTarget,
                                decoration: BoxDecoration(
                                  color: c,
                                  shape: BoxShape.circle,
                                  border: Border.all(
                                    color: _color == c.toARGB32()
                                        ? theme.colorScheme.onSurface
                                        : Colors.transparent,
                                    width: 3,
                                  ),
                                ),
                                child: _color == c.toARGB32()
                                    ? const Icon(Icons.check_rounded,
                                        color: Colors.white)
                                    : null,
                              ),
                            ),
                          ),
                      ],
                    ),
                    const SizedBox(height: AppSpacing.xl),
                    AppButton(
                      label: 'Simpan',
                      expand: true,
                      isLoading: _saving,
                      onPressed: _save,
                    ),
                  ],
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
