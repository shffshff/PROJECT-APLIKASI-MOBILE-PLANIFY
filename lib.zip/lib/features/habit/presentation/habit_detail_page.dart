import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:go_router/go_router.dart';
import 'package:intl/intl.dart';

import '../../../app/router/routes.dart';
import '../../../core/utils/date_only.dart';
import '../../../core/widgets/confirm_dialog.dart';
import '../../../core/widgets/empty_state.dart';
import '../../../core/widgets/page_container.dart';
import '../../../core/widgets/section_header.dart';
import '../../../theme/app_colors.dart';
import '../../../theme/app_tokens.dart';
import '../data/habit_repository.dart';
import '../domain/habit.dart';
import 'habits_page.dart';

/// Detail habit: statistik dan riwayat 5 minggu terakhir (FR-027/028).
/// Hari yang sudah lewat dapat dicentang susulan; hari mendatang tidak.
class HabitDetailPage extends ConsumerWidget {
  const HabitDetailPage({super.key, required this.habitId});

  final String habitId;

  Future<void> _delete(BuildContext context, WidgetRef ref, Habit h) async {
    final ConfirmResult r = await showConfirmDialog(
      context,
      title: 'Hapus kebiasaan ini?',
      message: 'Riwayat centangnya tidak akan tampil lagi.',
      confirmLabel: 'Hapus',
      isDestructive: true,
    );
    if (r != ConfirmResult.confirm || !context.mounted) {
      return;
    }
    await ref.read(habitRepositoryProvider).delete(h);
    if (context.mounted) {
      context.go(AppRoutes.habits);
    }
  }

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final List<HabitProgress>? list = ref.watch(habitProgressProvider).value;
    if (list == null) {
      return const Scaffold(body: Center(child: CircularProgressIndicator()));
    }
    HabitProgress? p;
    for (final HabitProgress e in list) {
      if (e.habit.id == habitId) {
        p = e;
      }
    }
    if (p == null) {
      return Scaffold(
        appBar: AppBar(title: const Text('Kebiasaan')),
        body: EmptyState(
          icon: Icons.search_off_rounded,
          title: 'Kebiasaan tidak ditemukan',
          primaryActionLabel: 'Kembali',
          onPrimaryAction: () => context.go(AppRoutes.habits),
        ),
      );
    }
    final HabitProgress progress = p;
    final Habit habit = progress.habit;
    final ThemeData theme = Theme.of(context);
    final Color color = Color(habit.colorValue);
    final DateTime today = DateOnly.of(DateTime.now());
    final DateTime start =
        DateOnly.addDays(DateOnly.startOfWeek(today), -28); // 5 minggu

    return Scaffold(
      appBar: AppBar(
        title: Text(habit.name),
        actions: <Widget>[
          IconButton(
            tooltip: 'Ubah kebiasaan',
            icon: const Icon(Icons.edit_outlined),
            onPressed: () => context.push(AppRoutes.habitEdit(habit.id)),
          ),
          IconButton(
            tooltip: 'Hapus kebiasaan',
            icon: const Icon(Icons.delete_outline_rounded),
            onPressed: () => _delete(context, ref, habit),
          ),
        ],
      ),
      body: SafeArea(
        child: ListView(
          padding: const EdgeInsets.only(bottom: AppSpacing.xxl),
          children: <Widget>[
            PageContainer(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.stretch,
                children: <Widget>[
                  const SizedBox(height: AppSpacing.lg),
                  Text(
                    targetDaysLabel(habit.targetWeekdays),
                    style: theme.textTheme.bodyMedium!.copyWith(
                      color: context.appColors.textSecondary,
                    ),
                  ),
                  if ((habit.description ?? '').isNotEmpty) ...<Widget>[
                    const SizedBox(height: AppSpacing.xs),
                    Text(habit.description!),
                  ],
                  const SizedBox(height: AppSpacing.lg),
                  Row(
                    children: <Widget>[
                      _Stat(label: 'Streak', value: '${progress.streak}'),
                      _Stat(label: 'Terbaik', value: '${progress.bestStreak}'),
                      _Stat(
                        label: '30 hari',
                        value: '${(progress.monthRate * 100).round()}%',
                      ),
                    ],
                  ),
                  const SizedBox(height: AppSpacing.sectionGap),
                  const SectionHeader(title: 'Riwayat 5 minggu'),
                  const SizedBox(height: AppSpacing.sm),
                  Row(
                    children: <Widget>[
                      for (final String d in kWeekdayShort)
                        Expanded(
                          child: Text(
                            d,
                            textAlign: TextAlign.center,
                            style: theme.textTheme.labelSmall,
                          ),
                        ),
                    ],
                  ),
                  const SizedBox(height: AppSpacing.xs),
                  GridView.count(
                    crossAxisCount: 7,
                    shrinkWrap: true,
                    physics: const NeverScrollableScrollPhysics(),
                    children: <Widget>[
                      for (int i = 0; i < 35; i++)
                        _HistoryCell(
                          day: DateOnly.addDays(start, i),
                          today: today,
                          habit: habit,
                          done: progress.isDone(DateOnly.addDays(start, i)),
                          color: color,
                        ),
                    ],
                  ),
                  const SizedBox(height: AppSpacing.sm),
                  Text(
                    'Ketuk tanggal dalam ${HabitRepository.maxBackfillDays} '
                    'hari terakhir untuk mencentang susulan atau '
                    'membatalkannya.',
                    style: theme.textTheme.bodySmall!.copyWith(
                      color: context.appColors.textSecondary,
                    ),
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}

class _Stat extends StatelessWidget {
  const _Stat({required this.label, required this.value});

  final String label;
  final String value;

  @override
  Widget build(BuildContext context) {
    final ThemeData theme = Theme.of(context);
    return Expanded(
      child: Card(
        margin: const EdgeInsets.only(right: AppSpacing.sm),
        child: Padding(
          padding: const EdgeInsets.all(AppSpacing.md),
          child: Column(
            children: <Widget>[
              Text(value, style: theme.textTheme.headlineSmall),
              Text(label, style: theme.textTheme.bodySmall),
            ],
          ),
        ),
      ),
    );
  }
}

class _HistoryCell extends ConsumerWidget {
  const _HistoryCell({
    required this.day,
    required this.today,
    required this.habit,
    required this.done,
    required this.color,
  });

  final DateTime day;
  final DateTime today;
  final Habit habit;
  final bool done;
  final Color color;

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final AppColors colors = context.appColors;
    final bool future = day.isAfter(today);
    final bool target = habit.isTargetDay(day);
    final bool isToday = DateOnly.isSameDay(day, today);
    return Semantics(
      button: !future,
      label: '${DateFormat('EEEE d MMMM', 'id_ID').format(day)}, '
          '${done ? 'selesai' : target ? 'belum' : 'bukan hari target'}',
      excludeSemantics: true,
      child: InkWell(
        customBorder: const CircleBorder(),
        onTap: future
            ? null
            : () => toggleHabit(context, ref, habit, day, !done),
        child: Container(
          margin: const EdgeInsets.all(4),
          decoration: BoxDecoration(
            shape: BoxShape.circle,
            color: done
                ? color
                : target && !future
                    ? colors.surfaceMuted
                    : null,
            border: isToday
                ? Border.all(color: Theme.of(context).colorScheme.primary)
                : null,
          ),
          alignment: Alignment.center,
          child: Text(
            '${day.day}',
            style: TextStyle(
              color: done
                  ? Colors.white
                  : future
                      ? colors.textDisabled
                      : Theme.of(context).colorScheme.onSurface,
              fontWeight: FontWeight.w600,
            ),
          ),
        ),
      ),
    );
  }
}
