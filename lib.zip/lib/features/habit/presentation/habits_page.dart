import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:go_router/go_router.dart';

import '../../../app/router/routes.dart';
import '../../../core/error/app_failure.dart';
import '../../../core/utils/date_only.dart';
import '../../../core/widgets/async_view.dart';
import '../../../core/widgets/empty_state.dart';
import '../../../core/widgets/page_container.dart';
import '../../../theme/app_colors.dart';
import '../../../theme/app_tokens.dart';
import '../data/habit_repository.dart';
import '../domain/habit.dart';

const List<String> kWeekdayShort = <String>[
  'Sen',
  'Sel',
  'Rab',
  'Kam',
  'Jum',
  'Sab',
  'Min',
];

/// Teks hari target, mis. "Setiap hari", "Sen, Rab, Jum".
String targetDaysLabel(List<int> days) {
  if (days.length == 7) {
    return 'Setiap hari';
  }
  if (days.length == 5 && !days.contains(6) && !days.contains(7)) {
    return 'Hari kerja';
  }
  return days.map((int d) => kWeekdayShort[d - 1]).join(', ');
}

Future<void> toggleHabit(
  BuildContext context,
  WidgetRef ref,
  Habit habit,
  DateTime day,
  bool done,
) async {
  try {
    await ref.read(habitRepositoryProvider).setDone(habit, day, done: done);
  } catch (error) {
    final AppFailure f = AppFailure.from(error);
    if (context.mounted) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text(f.userMessage)),
      );
    }
  }
}

/// S-35 Habit Tracker (FR-025–028).
class HabitsPage extends ConsumerWidget {
  const HabitsPage({super.key});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final AsyncValue<List<HabitProgress>> progress =
        ref.watch(habitProgressProvider);
    final ThemeData theme = Theme.of(context);

    return Scaffold(
      appBar: AppBar(
        title: const Text('Kebiasaan'),
        actions: <Widget>[
          IconButton(
            tooltip: 'Habit Record',
            icon: const Icon(Icons.history_edu_rounded),
            onPressed: () => context.push(AppRoutes.hashChain),
          ),
        ],
      ),
      floatingActionButton: FloatingActionButton.extended(
        onPressed: () => context.push(AppRoutes.habitNew),
        icon: const Icon(Icons.add_rounded),
        label: const Text('Kebiasaan'),
      ),
      body: SafeArea(
        child: AsyncView<List<HabitProgress>>(
          value: progress,
          isEmpty: (List<HabitProgress> l) => l.isEmpty,
          empty: EmptyState(
            icon: Icons.repeat_rounded,
            title: 'Belum ada kebiasaan',
            message: 'Mulai dari yang kecil dan mudah diulang, misalnya '
                '"Minum air" atau "Baca 20 menit".',
            primaryActionLabel: 'Buat kebiasaan',
            onPrimaryAction: () => context.push(AppRoutes.habitNew),
          ),
          builder: (BuildContext context, List<HabitProgress> list) {
            final List<HabitProgress> today =
                list.where((HabitProgress p) => p.isTargetToday).toList();
            final int done =
                today.where((HabitProgress p) => p.doneToday).length;
            final double week = list.isEmpty
                ? 0
                : list.fold<double>(
                        0, (double a, HabitProgress p) => a + p.weekRate) /
                    list.length;
            return ListView(
              padding: const EdgeInsets.only(bottom: 96),
              children: <Widget>[
                PageContainer(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.stretch,
                    children: <Widget>[
                      const SizedBox(height: AppSpacing.lg),
                      Row(
                        children: <Widget>[
                          Expanded(
                            child: _StatCard(
                              label: 'HARI INI',
                              value: '$done/${today.length}',
                            ),
                          ),
                          const SizedBox(width: AppSpacing.md),
                          Expanded(
                            child: _StatCard(
                              label: 'MINGGU INI',
                              value: '${(week * 100).round()}%',
                            ),
                          ),
                        ],
                      ),
                      const SizedBox(height: AppSpacing.lg),
                      for (final HabitProgress p in list) ...<Widget>[
                        _HabitTile(progress: p),
                        const SizedBox(height: AppSpacing.cardGap),
                      ],
                      Text(
                        'Hari non-target tidak memutus streak. Tanggal yang '
                        'akan datang tidak bisa dicentang.',
                        style: theme.textTheme.bodySmall!.copyWith(
                          color: context.appColors.textSecondary,
                        ),
                      ),
                    ],
                  ),
                ),
              ],
            );
          },
        ),
      ),
    );
  }
}

class _StatCard extends StatelessWidget {
  const _StatCard({required this.label, required this.value});

  final String label;
  final String value;

  @override
  Widget build(BuildContext context) {
    final ThemeData theme = Theme.of(context);
    return Card(
      margin: EdgeInsets.zero,
      child: Padding(
        padding: const EdgeInsets.all(AppSpacing.lg),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: <Widget>[
            Text(
              label,
              style: theme.textTheme.labelSmall!.copyWith(
                color: context.appColors.textSecondary,
                letterSpacing: 0.8,
              ),
            ),
            const SizedBox(height: 4),
            Text(value, style: theme.textTheme.headlineSmall),
          ],
        ),
      ),
    );
  }
}

class _HabitTile extends ConsumerWidget {
  const _HabitTile({required this.progress});

  final HabitProgress progress;

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final ThemeData theme = Theme.of(context);
    final Habit habit = progress.habit;
    final Color color = Color(habit.colorValue);
    final DateTime today = DateOnly.of(DateTime.now());
    final DateTime weekStart = DateOnly.startOfWeek(today);

    return Card(
      margin: EdgeInsets.zero,
      clipBehavior: Clip.antiAlias,
      child: InkWell(
        onTap: () => context.push(AppRoutes.habitDetail(habit.id)),
        child: Padding(
          padding: const EdgeInsets.fromLTRB(
            AppSpacing.lg,
            AppSpacing.md,
            AppSpacing.sm,
            AppSpacing.md,
          ),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.stretch,
            children: <Widget>[
              Row(
                children: <Widget>[
                  Container(
                    width: 12,
                    height: 12,
                    decoration:
                        BoxDecoration(color: color, shape: BoxShape.circle),
                  ),
                  const SizedBox(width: AppSpacing.md),
                  Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: <Widget>[
                        Text(habit.name, style: theme.textTheme.titleSmall),
                        Text(
                          '🔥 ${progress.streak} hari · '
                          '${targetDaysLabel(habit.targetWeekdays)}',
                          style: theme.textTheme.bodySmall!.copyWith(
                            color: context.appColors.textSecondary,
                          ),
                        ),
                      ],
                    ),
                  ),
                  SizedBox(
                    width: AppSizes.minTouchTarget,
                    height: AppSizes.minTouchTarget,
                    child: Checkbox(
                      value: progress.doneToday,
                      activeColor: color,
                      semanticLabel: progress.doneToday
                          ? 'Batalkan centang hari ini: ${habit.name}'
                          : 'Centang hari ini: ${habit.name}',
                      onChanged: (bool? v) =>
                          toggleHabit(context, ref, habit, today, v ?? false),
                    ),
                  ),
                ],
              ),
              const SizedBox(height: AppSpacing.sm),
              Row(
                children: <Widget>[
                  for (int i = 0; i < 7; i++)
                    Expanded(
                      child: _DayDot(
                        label: kWeekdayShort[i],
                        day: DateOnly.addDays(weekStart, i),
                        today: today,
                        isTarget: habit.targetWeekdays.contains(i + 1),
                        done: progress.isDone(DateOnly.addDays(weekStart, i)),
                        color: color,
                      ),
                    ),
                ],
              ),
            ],
          ),
        ),
      ),
    );
  }
}

class _DayDot extends StatelessWidget {
  const _DayDot({
    required this.label,
    required this.day,
    required this.today,
    required this.isTarget,
    required this.done,
    required this.color,
  });

  final String label;
  final DateTime day;
  final DateTime today;
  final bool isTarget;
  final bool done;
  final Color color;

  @override
  Widget build(BuildContext context) {
    final ThemeData theme = Theme.of(context);
    final AppColors colors = context.appColors;
    final bool future = day.isAfter(today);
    final String state = done
        ? 'selesai'
        : !isTarget
            ? 'bukan hari target'
            : future
                ? 'belum tiba'
                : 'terlewat';
    return Semantics(
      label: '$label, $state',
      excludeSemantics: true,
      child: Column(
        children: <Widget>[
          Text(
            label,
            style: theme.textTheme.labelSmall!
                .copyWith(color: colors.textSecondary),
          ),
          const SizedBox(height: 4),
          Container(
            width: 22,
            height: 22,
            decoration: BoxDecoration(
              shape: BoxShape.circle,
              color: done ? color : null,
              border: Border.all(
                color: done
                    ? color
                    : isTarget
                        ? colors.borderSubtle
                        : Colors.transparent,
                width: 2,
              ),
            ),
            child: done
                ? const Icon(Icons.check_rounded, size: 14, color: Colors.white)
                : !isTarget
                    ? Icon(Icons.remove_rounded,
                        size: 14, color: colors.textDisabled)
                    : null,
          ),
        ],
      ),
    );
  }
}
