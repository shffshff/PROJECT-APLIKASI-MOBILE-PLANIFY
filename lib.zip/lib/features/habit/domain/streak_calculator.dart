import '../../../core/utils/date_only.dart';

/// Perhitungan streak dan progres habit (FR-027/028). Logika murni.
///
/// Aturan (Tahap 1 §10.2 / Tahap 2 §16):
/// - Hanya hari target yang dihitung; hari non-target tidak memutus streak.
/// - Satu hari target terlewat = streak kembali 0.
/// - Hari ini belum dicatat tidak memutus streak (dihitung dari kemarin).
abstract final class StreakCalculator {
  static int current({
    required Set<DateTime> doneDates,
    required List<int> targetWeekdays,
    required DateTime today,
    DateTime? startedOn,
  }) {
    if (targetWeekdays.isEmpty) {
      return 0;
    }
    final Set<String> done = doneDates.map(DateOnly.format).toSet();
    final DateTime start =
        startedOn == null ? DateTime(1970) : DateOnly.of(startedOn);
    DateTime day = DateOnly.of(today);

    // Hari ini boleh belum dicatat.
    if (targetWeekdays.contains(day.weekday) &&
        !done.contains(DateOnly.format(day))) {
      day = DateOnly.addDays(day, -1);
    }

    int streak = 0;
    // Batas aman: maksimal ~3 tahun ke belakang.
    for (int i = 0; i < 1100 && !day.isBefore(start); i++) {
      if (targetWeekdays.contains(day.weekday)) {
        if (done.contains(DateOnly.format(day))) {
          streak++;
        } else {
          break;
        }
      }
      day = DateOnly.addDays(day, -1);
    }
    return streak;
  }

  static int best({
    required Set<DateTime> doneDates,
    required List<int> targetWeekdays,
    required DateTime today,
  }) {
    if (doneDates.isEmpty || targetWeekdays.isEmpty) {
      return 0;
    }
    final List<DateTime> sorted =
        doneDates.map(DateOnly.of).toSet().toList()..sort();
    final Set<String> done = sorted.map(DateOnly.format).toSet();
    int best = 0;
    int run = 0;
    DateTime day = sorted.first;
    final DateTime end = DateOnly.of(today);
    while (!day.isAfter(end)) {
      if (targetWeekdays.contains(day.weekday)) {
        if (done.contains(DateOnly.format(day))) {
          run++;
          if (run > best) {
            best = run;
          }
        } else if (!DateOnly.isSameDay(day, end)) {
          run = 0;
        }
      }
      day = DateOnly.addDays(day, 1);
    }
    return best;
  }

  /// Persentase hari target yang tercatat dalam [days] hari terakhir
  /// (termasuk hari ini), 0–1. Hari sebelum [startedOn] tidak dihitung.
  static double completionRate({
    required Set<DateTime> doneDates,
    required List<int> targetWeekdays,
    required DateTime today,
    int days = 7,
    DateTime? startedOn,
  }) {
    final Set<String> done = doneDates.map(DateOnly.format).toSet();
    final DateTime start =
        startedOn == null ? DateTime(1970) : DateOnly.of(startedOn);
    int target = 0;
    int hit = 0;
    for (int i = 0; i < days; i++) {
      final DateTime day = DateOnly.addDays(DateOnly.of(today), -i);
      if (day.isBefore(start) || !targetWeekdays.contains(day.weekday)) {
        continue;
      }
      target++;
      if (done.contains(DateOnly.format(day))) {
        hit++;
      }
    }
    return target == 0 ? 0 : hit / target;
  }
}
