import 'package:flutter/foundation.dart';

import '../../../core/sync/sync_entity.dart';
import '../../../core/utils/date_only.dart';

/// Kebiasaan (tabel `public.habits`).
@immutable
class Habit implements SyncEntity<Habit> {
  const Habit({
    required this.id,
    required this.userId,
    required this.name,
    required this.createdAt,
    required this.updatedAt,
    this.description,
    this.targetWeekdays = const <int>[1, 2, 3, 4, 5, 6, 7],
    this.colorValue = 0xFF2D5BD7,
    this.iconKey = 'default',
    this.isActive = true,
    this.deletedAt,
    this.syncInfo = const SyncInfo(),
  });

  static const SyncTableSpec spec = SyncTableSpec(
    table: 'habits',
    boxName: 'habits',
    pkColumns: <String>['id'],
  );

  static const int maxName = 50;
  static const int maxDescription = 200;

  final String id;
  final String userId;
  final String name;
  final String? description;

  /// 1 = Senin … 7 = Minggu.
  final List<int> targetWeekdays;
  final int colorValue;
  final String iconKey;
  final bool isActive;
  final DateTime createdAt;
  @override
  final DateTime updatedAt;
  @override
  final DateTime? deletedAt;
  @override
  final SyncInfo syncInfo;

  @override
  String get localKey => id;

  bool isTargetDay(DateTime day) => targetWeekdays.contains(day.weekday);

  static Habit fromJson(Map<String, dynamic> json) {
    final Object? days = json['target_weekdays'];
    final Object? color = json['color_value'];
    return Habit(
      id: json['id'] as String,
      userId: json['user_id'] as String,
      name: json['name'] as String,
      description: json['description'] as String?,
      targetWeekdays: days is List
          ? (days.whereType<num>().map((num n) => n.toInt()).toList()..sort())
          : const <int>[1, 2, 3, 4, 5, 6, 7],
      colorValue:
          color is num ? color.toInt().toUnsigned(32) : 0xFF2D5BD7,
      iconKey: (json['icon_key'] as String?) ?? 'default',
      isActive: json['is_active'] != false,
      createdAt:
          parseTimestamp(json['created_at'])?.toUtc() ?? readUpdatedAt(json),
      updatedAt: readUpdatedAt(json),
      deletedAt: parseTimestamp(json['deleted_at'])?.toUtc(),
      syncInfo: SyncInfo.fromJson(json),
    );
  }

  @override
  Map<String, dynamic> toRow() => <String, dynamic>{
        'id': id,
        'user_id': userId,
        'name': name,
        'description': description,
        'target_weekdays': targetWeekdays,
        // Kolom server `integer` bertanda: warna ARGB > 2^31 disimpan sebagai
        // nilai bertanda 32-bit.
        'color_value': colorValue.toSigned(32),
        'icon_key': iconKey,
        'is_active': isActive,
        'created_at': createdAt.toUtc().toIso8601String(),
        'deleted_at': deletedAt?.toUtc().toIso8601String(),
      };

  @override
  Habit withSync(SyncInfo info, {DateTime? updatedAt}) =>
      copyWith(syncInfo: info, updatedAt: updatedAt);

  Habit copyWith({
    String? name,
    String? description,
    bool clearDescription = false,
    List<int>? targetWeekdays,
    int? colorValue,
    bool? isActive,
    DateTime? updatedAt,
    DateTime? deletedAt,
    SyncInfo? syncInfo,
  }) {
    return Habit(
      id: id,
      userId: userId,
      name: name ?? this.name,
      description: clearDescription ? null : (description ?? this.description),
      targetWeekdays: targetWeekdays ?? this.targetWeekdays,
      colorValue: colorValue ?? this.colorValue,
      iconKey: iconKey,
      isActive: isActive ?? this.isActive,
      createdAt: createdAt,
      updatedAt: updatedAt ?? this.updatedAt,
      deletedAt: deletedAt ?? this.deletedAt,
      syncInfo: syncInfo ?? this.syncInfo,
    );
  }
}

/// Catatan penyelesaian habit per tanggal (tabel `public.habit_logs`, PK
/// komposit `habit_id + log_date` → tidak mungkin dobel).
@immutable
class HabitLog implements SyncEntity<HabitLog> {
  const HabitLog({
    required this.habitId,
    required this.logDate,
    required this.userId,
    required this.createdAt,
    required this.updatedAt,
    this.deletedAt,
    this.syncInfo = const SyncInfo(),
  });

  static const SyncTableSpec spec = SyncTableSpec(
    table: 'habit_logs',
    boxName: 'habit_logs',
    pkColumns: <String>['habit_id', 'log_date'],
  );

  final String habitId;

  /// Tanggal lokal tanpa jam.
  final DateTime logDate;
  final String userId;
  final DateTime createdAt;
  @override
  final DateTime updatedAt;

  /// Terisi = centang dibatalkan (toggle off, Tahap 2 §6.2).
  @override
  final DateTime? deletedAt;
  @override
  final SyncInfo syncInfo;

  static String keyFor(String habitId, DateTime date) =>
      '$habitId|${DateOnly.format(date)}';

  @override
  String get localKey => keyFor(habitId, logDate);

  bool get isDone => deletedAt == null;

  static HabitLog fromJson(Map<String, dynamic> json) => HabitLog(
        habitId: json['habit_id'] as String,
        logDate: DateOnly.parse(json['log_date'] as String),
        userId: json['user_id'] as String,
        createdAt: parseTimestamp(json['created_at'])?.toUtc() ??
            readUpdatedAt(json),
        updatedAt: readUpdatedAt(json),
        deletedAt: parseTimestamp(json['deleted_at'])?.toUtc(),
        syncInfo: SyncInfo.fromJson(json),
      );

  @override
  Map<String, dynamic> toRow() => <String, dynamic>{
        'habit_id': habitId,
        'log_date': DateOnly.format(logDate),
        'user_id': userId,
        'created_at': createdAt.toUtc().toIso8601String(),
        'deleted_at': deletedAt?.toUtc().toIso8601String(),
      };

  @override
  HabitLog withSync(SyncInfo info, {DateTime? updatedAt}) => HabitLog(
        habitId: habitId,
        logDate: logDate,
        userId: userId,
        createdAt: createdAt,
        updatedAt: updatedAt ?? this.updatedAt,
        deletedAt: deletedAt,
        syncInfo: info,
      );

  /// Versi dengan status centang baru; tombstone dipakai untuk "batal".
  HabitLog toggled({required bool done, required DateTime nowUtc}) => HabitLog(
        habitId: habitId,
        logDate: logDate,
        userId: userId,
        createdAt: createdAt,
        updatedAt: nowUtc,
        deletedAt: done ? null : nowUtc,
        syncInfo: syncInfo,
      );
}
