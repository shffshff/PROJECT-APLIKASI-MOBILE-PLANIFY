import 'package:flutter/foundation.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../../../core/storage/local_box.dart';
import '../../../core/storage/local_database.dart';
import '../../../core/utils/date_only.dart';
import '../../habit/domain/habit.dart';
import '../domain/hash_chain.dart';

/// Penyimpanan rantai integritas kebiasaan (Habit Consistency Record) di Hive
/// (box `achievements`, lokal di perangkat pengguna, tanpa jaringan publik/terdesentralisasi).
/// Key = indeks blok (dipad dengan angka nol agar urut secara leksikografis).
class AchievementRepository {
  AchievementRepository(this._box, {DateTime Function()? clock})
      : _clock = clock ?? DateTime.now;

  final LocalBox _box;
  final DateTime Function() _clock;
  ChainValidation? _lastValidation;

  ChainValidation? get lastValidation => _lastValidation;

  /// Menjalankan validasi integritas terhadap rantai saat ini.
  ChainValidation validateIntegrity() {
    try {
      final List<Block> current = chain();
      final ChainValidation result = HashChain.validate(current);
      _lastValidation = result;
      return result;
    } catch (error) {
      debugPrint('Validasi integritas gagal: $error');
      final ChainValidation failed =
          ChainValidation.invalid(-1, 'Error validasi: $error');
      _lastValidation = failed;
      return failed;
    }
  }

  static String _key(int index) => index.toString().padLeft(8, '0');

  List<Block> chain() {
    final List<String> keys = _box.keys.toList()..sort();
    final List<Block> out = <Block>[];
    for (final String k in keys) {
      final Map<String, dynamic>? json = _box.getJson(k);
      if (json != null) {
        try {
          out.add(Block.fromJson(json));
        } catch (error) {
          debugPrint('Blok rusak diabaikan: $error');
        }
      }
    }
    return out;
  }

  Stream<List<Block>> watch() async* {
    yield chain();
    await for (final _ in _box.changes) {
      yield chain();
    }
  }

  /// Menambah entri ke dalam rantai konsistensi habit.
  /// Menghindari duplikasi bila entri dengan `eventRef` yang sama sudah ada di rantai.
  /// Otomatis membuat genesis block bila rantai masih kosong.
  Future<void> record(Map<String, dynamic> data) async {
    try {
      List<Block> current = chain();

      // Pencegahan duplikasi entri yang sama
      final String? eventRef = data['eventRef'] as String?;
      final String? habitId = data['habitId'] as String?;
      final String? logDate = data['logDate'] as String?;

      if (eventRef != null &&
          current.any((Block b) => b.data['eventRef'] == eventRef)) {
        return;
      }
      if (habitId != null &&
          logDate != null &&
          current.any((Block b) =>
              b.data['habitId'] == habitId && b.data['logDate'] == logDate)) {
        return;
      }

      if (current.isEmpty) {
        final Block g = HashChain.genesis(_clock());
        await _box.putJson(_key(0), g.toJson());
        current = <Block>[g];
      }

      final Block next = HashChain.next(current.last, data, _clock());
      await _box.putJson(_key(next.index), next.toJson());
      // Validasi integritas otomatis setelah penulisan data selesai
      validateIntegrity();
    } catch (error) {
      // Pencatatan hash chain tidak boleh menggagalkan alur aksi utama pengguna.
      debugPrint('Entri konsistensi habit gagal dicatat: $error');
    }
  }

  /// Memeriksa pencapaian habit yang sudah tersimpan di Habit Tracker (Hive)
  /// yang belum masuk ke rangkaian hash, lalu menambahkannya secara kronologis tanpa duplikasi.
  /// Mengembalikan jumlah entri baru yang berhasil ditambahkan.
  Future<int> syncHabitHistory({
    required List<Habit> habits,
    required List<HabitLog> logs,
  }) async {
    final List<Block> current = chain();
    final Set<String> recordedRefs = <String>{};

    for (final Block b in current) {
      final String? ref = b.data['eventRef'] as String?;
      if (ref != null) {
        recordedRefs.add(ref);
      } else if (b.data['habitId'] != null && b.data['logDate'] != null) {
        recordedRefs.add('${b.data['habitId']}|${b.data['logDate']}');
      }
    }

    final Map<String, Habit> habitMap = <String, Habit>{
      for (final Habit h in habits) h.id: h,
    };

    // Filter hanya log yang berstatus selesai (isDone == true)
    final List<HabitLog> doneLogs =
        logs.where((HabitLog l) => l.isDone).toList();

    // Urutkan kronologis: logDate lalu createdAt
    doneLogs.sort((HabitLog a, HabitLog b) {
      final int cmp = a.logDate.compareTo(b.logDate);
      return cmp != 0 ? cmp : a.createdAt.compareTo(b.createdAt);
    });

    int added = 0;
    for (final HabitLog log in doneLogs) {
      final String refKey = HabitLog.keyFor(log.habitId, log.logDate);
      if (!recordedRefs.contains(refKey)) {
        final Habit? habit = habitMap[log.habitId];
        final String habitName = habit?.name ?? 'Kebiasaan';
        await record(<String, dynamic>{
          'type': 'habit_completed',
          'habitId': log.habitId,
          'habitName': habitName,
          'logDate': DateOnly.format(log.logDate),
          'status': 'completed',
          'eventRef': refKey,
        });
        recordedRefs.add(refKey);
        added++;
      }
    }

    // Validasi integritas otomatis setelah seluruh riwayat habit tersimpan
    validateIntegrity();

    return added;
  }

  /// Sinkronisasi generik untuk pencapaian produktivitas terdahulu (kompatibilitas).
  Future<int> syncRealProductivityEvents({
    List<Map<String, dynamic>>? completedTasks,
    List<Map<String, dynamic>>? completedSessions,
  }) async {
    final List<Block> current = chain();
    final Set<String> existingTaskIds = <String>{};
    final Set<String> existingSessionIds = <String>{};

    for (final Block b in current) {
      final String? tid = b.data['taskId'] as String?;
      if (tid != null) existingTaskIds.add(tid);
      final String? sid = b.data['sessionId'] as String?;
      if (sid != null) existingSessionIds.add(sid);
    }

    int added = 0;

    if (completedTasks != null) {
      for (final Map<String, dynamic> t in completedTasks) {
        final String? id = t['id'] as String?;
        if (id != null && !existingTaskIds.contains(id)) {
          await record(<String, dynamic>{
            'type': 'task_completed',
            'taskId': id,
            'title': t['title'] ?? 'Tugas selesai',
            'eventRef': 'task_$id',
          });
          existingTaskIds.add(id);
          added++;
        }
      }
    }

    if (completedSessions != null) {
      for (final Map<String, dynamic> s in completedSessions) {
        final String? id = s['id'] as String?;
        if (id != null && !existingSessionIds.contains(id)) {
          await record(<String, dynamic>{
            'type': 'focus_completed',
            'sessionId': id,
            'minutes': s['minutes'] ?? 25,
            'eventRef': 'session_$id',
          });
          existingSessionIds.add(id);
          added++;
        }
      }
    }

    // Validasi integritas otomatis setelah seluruh riwayat habit tersimpan
    validateIntegrity();

    return added;
  }
}

final Provider<AchievementRepository> achievementRepositoryProvider =
    Provider<AchievementRepository>(
  (Ref ref) =>
      AchievementRepository(ref.watch(localDatabaseProvider).achievements),
);

final StreamProvider<List<Block>> achievementChainProvider =
    StreamProvider<List<Block>>(
  (Ref ref) => ref.watch(achievementRepositoryProvider).watch(),
);

/// Provider status integritas riwayat kebiasaan yang otomatis diperbarui secara reaktif
/// saat data rantai dimuat, disinkronkan, atau ditambahkan entri baru.
final Provider<HabitRecordIntegrityState> habitRecordIntegrityProvider =
    Provider<HabitRecordIntegrityState>((Ref ref) {
  final AsyncValue<List<Block>> chainAsync =
      ref.watch(achievementChainProvider);

  return chainAsync.when(
    data: (List<Block> chain) {
      try {
        final ChainValidation val = HashChain.validate(chain);
        if (val.isValid) {
          return const HabitRecordIntegrityState.valid();
        } else {
          return HabitRecordIntegrityState.invalid(
            val.brokenAt ?? -1,
            val.reason ?? 'Ketidaksesuaian data',
          );
        }
      } catch (e) {
        return HabitRecordIntegrityState.failed(e.toString());
      }
    },
    loading: () => const HabitRecordIntegrityState.checking(),
    error: (Object err, _) =>
        HabitRecordIntegrityState.failed(err.toString()),
  );
});
