import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:go_router/go_router.dart' hide Block;
import 'package:intl/intl.dart';

import '../../../app/router/routes.dart';
import '../../../core/utils/date_only.dart';
import '../../../core/widgets/app_button.dart';
import '../../../core/widgets/empty_state.dart';
import '../../../core/widgets/page_container.dart';
import '../../../theme/app_colors.dart';
import '../../../theme/app_tokens.dart';
import '../../habit/data/habit_repository.dart';
import '../../habit/domain/habit.dart';
import '../data/achievement_repository.dart';
import '../domain/hash_chain.dart';

String blockTitle(Block b) => switch (b.type) {
      'genesis' => 'Genesis',
      'habit_completed' =>
        (b.data['habitName'] ?? b.data['title'] ?? 'Pencapaian kebiasaan').toString(),
      'habit_streak' =>
        'Streak ${b.data['streak'] ?? ''} hari: ${b.data['habitName'] ?? b.data['name'] ?? 'Kebiasaan'}',
      'demo' => (b.data['title'] ?? 'Contoh pencapaian').toString(),
      'task_completed' => 'Tugas: ${b.data['title'] ?? 'Aktivitas'}',
      'focus_completed' => 'Sesi fokus: ${b.data['minutes'] ?? 25} menit',
      _ => b.type,
    };

IconData blockIcon(Block b) => switch (b.type) {
      'genesis' => Icons.verified_user_rounded,
      'habit_completed' => Icons.check_circle_rounded,
      'habit_streak' => Icons.local_fire_department_rounded,
      'demo' => Icons.flag_circle_rounded,
      _ => Icons.task_alt_rounded,
    };

/// Habit Record.
/// Halaman pemantauan konsistensi dan riwayat pencapaian kebiasaan pengguna.
class HashChainPage extends ConsumerStatefulWidget {
  const HashChainPage({super.key});

  @override
  ConsumerState<HashChainPage> createState() => _HashChainPageState();
}

typedef HabitRecordPage = HashChainPage;
typedef HabitConsistencyRecordPage = HashChainPage;
typedef ProductivityIntegrityPage = HashChainPage;

class _HashChainPageState extends ConsumerState<HashChainPage> {
  String? _filterHabitId;
  DateTime? _selectedDate;

  @override
  void initState() {
    super.initState();
    // Jalankan sinkronisasi riwayat habit secara otomatis di latar belakang
    WidgetsBinding.instance.addPostFrameCallback((_) {
      _autoSync();
    });
  }

  Future<void> _autoSync() async {
    try {
      final List<Habit> habits = ref.read(habitsProvider).value ??
          ref.read(habitStoreProvider).all();
      final List<HabitLog> logs = ref.read(habitLogStoreProvider).all();
      await ref
          .read(achievementRepositoryProvider)
          .syncHabitHistory(habits: habits, logs: logs);
    } catch (e) {
      debugPrint('Auto-sync Habit Record: $e');
    }
  }

  void _showBlockDetails(Block block) {
    showModalBottomSheet<void>(
      context: context,
      isScrollControlled: true,
      useSafeArea: true,
      builder: (BuildContext ctx) => _BlockDetailSheet(block: block),
    );
  }

  @override
  Widget build(BuildContext context) {
    final List<Block> chain =
        ref.watch(achievementChainProvider).value ?? const <Block>[];
    final List<Habit> habits =
        ref.watch(habitsProvider).value ?? ref.watch(habitStoreProvider).all();
    final List<HabitLog> logs = ref.watch(habitLogStoreProvider).all();
    final List<HabitProgress> progress =
        ref.watch(habitProgressProvider).value ?? const <HabitProgress>[];
    final ThemeData theme = Theme.of(context);
    final AppColors colors = context.appColors;

    // Filter pencapaian habit (sembunyikan entri genesis dari daftar riwayat normal)
    final List<Block> habitAchievements =
        chain.where((Block b) => b.type != 'genesis').toList();

    // Terapkan filter habit dan filter tanggal jika dipilih
    final List<Block> filteredList = habitAchievements.where((Block b) {
      if (_filterHabitId != null && b.data['habitId'] != _filterHabitId) {
        return false;
      }
      if (_selectedDate != null) {
        final String targetDate = DateOnly.format(_selectedDate!);
        if (b.data['logDate'] != targetDate) {
          return false;
        }
      }
      return true;
    }).toList();

    // Metrik konsistensi riil dari Habit Tracker
    final int uniqueActiveDays = logs
        .where((HabitLog l) => l.isDone)
        .map((HabitLog l) => DateOnly.format(l.logDate))
        .toSet()
        .length;
    final int totalCompletions = logs.where((HabitLog l) => l.isDone).length;
    final int bestStreak = progress.isEmpty
        ? 0
        : progress.fold<int>(
            0,
            (int max, HabitProgress p) =>
                p.bestStreak > max ? p.bestStreak : max,
          );

    return Scaffold(
      appBar: AppBar(
        title: const Text('Habit Record'),
      ),
      body: SafeArea(
        child: ListView(
          padding: const EdgeInsets.only(bottom: AppSpacing.xxl),
          children: <Widget>[
            PageContainer(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.stretch,
                children: <Widget>[
                  const SizedBox(height: AppSpacing.sm),
                  Text(
                    'Pantau konsistensi dan riwayat pencapaian kebiasaanmu.',
                    style: theme.textTheme.bodyMedium!.copyWith(
                      color: colors.textSecondary,
                    ),
                  ),
                  const SizedBox(height: AppSpacing.md),

                  // 1. Ringkasan Konsistensi
                  _ConsistencySummaryCard(
                    activeDays: uniqueActiveDays,
                    bestStreak: bestStreak,
                    totalCompletions: totalCompletions,
                  ),
                  const SizedBox(height: AppSpacing.md),

                  // 2. Kalender Konsistensi 7 Hari Terakhir
                  _WeeklyConsistencyCalendar(
                    logs: logs,
                    selectedDate: _selectedDate,
                    onSelectDate: (DateTime date) {
                      setState(() {
                        if (_selectedDate != null &&
                            DateOnly.isSameDay(_selectedDate!, date)) {
                          _selectedDate = null;
                        } else {
                          _selectedDate = date;
                        }
                      });
                    },
                  ),
                  const SizedBox(height: AppSpacing.md),

                  // Filter Tanggal Aktif (jika tanggal dipilih pada kalender)
                  if (_selectedDate != null) ...<Widget>[
                    Row(
                      children: <Widget>[
                        Chip(
                          avatar: const Icon(Icons.event_rounded, size: 16),
                          label: Text(
                            'Tanggal: ${DateFormat('d MMM yyyy', 'id_ID').format(_selectedDate!)}',
                          ),
                          onDeleted: () => setState(() => _selectedDate = null),
                        ),
                      ],
                    ),
                    const SizedBox(height: AppSpacing.sm),
                  ],

                  // Filter Kebiasaan (jika ada kebiasaan)
                  if (habits.isNotEmpty && habitAchievements.isNotEmpty) ...<Widget>[
                    DropdownButtonFormField<String?>(
                      initialValue: _filterHabitId,
                      isExpanded: true,
                      decoration: const InputDecoration(
                        labelText: 'Filter Kebiasaan',
                        prefixIcon: Icon(Icons.filter_list_rounded),
                        contentPadding: EdgeInsets.symmetric(
                          horizontal: 12,
                          vertical: 8,
                        ),
                      ),
                      items: <DropdownMenuItem<String?>>[
                        const DropdownMenuItem<String?>(
                          value: null,
                          child: Text('Semua Kebiasaan'),
                        ),
                        for (final Habit h in habits)
                          DropdownMenuItem<String?>(
                            value: h.id,
                            child: Text(h.name),
                          ),
                      ],
                      onChanged: (String? val) {
                        setState(() => _filterHabitId = val);
                      },
                    ),
                    const SizedBox(height: AppSpacing.md),
                  ],

                  // 3. Header Daftar Riwayat Pencapaian
                  Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: <Widget>[
                      Text(
                        'RIWAYAT PENCAPAIAN (${filteredList.length})',
                        style: theme.textTheme.labelSmall,
                      ),
                      if (filteredList.isNotEmpty)
                        Text(
                          'Ketuk untuk rincian',
                          style: theme.textTheme.bodySmall!.copyWith(
                            color: colors.textSecondary,
                            fontSize: 11,
                          ),
                        ),
                    ],
                  ),
                  const SizedBox(height: AppSpacing.sm),

                  // 4. Daftar Riwayat / EmptyState
                  if (filteredList.isEmpty)
                    EmptyState(
                      icon: Icons.event_available_rounded,
                      title: 'Belum ada pencapaian yang tercatat',
                      message: _selectedDate != null
                          ? 'Tidak ada pencapaian habit pada tanggal yang dipilih.'
                          : 'Selesaikan habit melalui Habit Tracker untuk mulai membangun riwayat konsistensimu.',
                      primaryActionLabel: 'Buka Habit Tracker',
                      onPrimaryAction: () => context.push(AppRoutes.habits),
                    )
                  else
                    for (final Block b in filteredList.reversed)
                      _HabitCard(
                        block: b,
                        habit: habits.cast<Habit?>().firstWhere(
                              (Habit? h) => h?.id == b.data['habitId'],
                              orElse: () => null,
                            ),
                        onTap: () => _showBlockDetails(b),
                      ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}

/// Ringkasan Konsistensi berbasis data aktual Habit Tracker.
class _ConsistencySummaryCard extends StatelessWidget {
  const _ConsistencySummaryCard({
    required this.activeDays,
    required this.bestStreak,
    required this.totalCompletions,
  });

  final int activeDays;
  final int bestStreak;
  final int totalCompletions;

  @override
  Widget build(BuildContext context) {
    final ThemeData theme = Theme.of(context);

    return Card(
      margin: EdgeInsets.zero,
      color: theme.colorScheme.primaryContainer.withAlpha(40),
      child: Padding(
        padding: const EdgeInsets.all(AppSpacing.md),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: <Widget>[
            Text(
              'KONSISTENSI KEBIASAAN',
              style: theme.textTheme.labelSmall,
            ),
            const SizedBox(height: AppSpacing.md),
            Row(
              children: <Widget>[
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: <Widget>[
                      Text('Hari Aktif', style: theme.textTheme.bodySmall),
                      Text(
                        '$activeDays hari',
                        style: theme.textTheme.titleMedium!.copyWith(
                          fontWeight: FontWeight.bold,
                        ),
                      ),
                    ],
                  ),
                ),
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: <Widget>[
                      Text('Streak Terbaik', style: theme.textTheme.bodySmall),
                      Text(
                        '$bestStreak hari',
                        style: theme.textTheme.titleMedium!.copyWith(
                          fontWeight: FontWeight.bold,
                        ),
                      ),
                    ],
                  ),
                ),
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: <Widget>[
                      Text('Total Selesai', style: theme.textTheme.bodySmall),
                      Text(
                        '$totalCompletions',
                        style: theme.textTheme.titleMedium!.copyWith(
                          fontWeight: FontWeight.bold,
                        ),
                      ),
                    ],
                  ),
                ),
              ],
            ),
          ],
        ),
      ),
    );
  }
}

/// Kalender visual mini (konsistensi 7 hari terakhir dengan interaksi filter tanggal).
class _WeeklyConsistencyCalendar extends StatelessWidget {
  const _WeeklyConsistencyCalendar({
    required this.logs,
    required this.selectedDate,
    required this.onSelectDate,
  });

  final List<HabitLog> logs;
  final DateTime? selectedDate;
  final ValueChanged<DateTime> onSelectDate;

  static const List<String> _shortDays = <String>[
    'Sen',
    'Sel',
    'Rab',
    'Kam',
    'Jum',
    'Sab',
    'Min',
  ];

  @override
  Widget build(BuildContext context) {
    final ThemeData theme = Theme.of(context);
    final AppColors colors = context.appColors;
    final DateTime today = DateOnly.of(DateTime.now());

    final List<DateTime> last7Days = List<DateTime>.generate(
      7,
      (int i) => DateOnly.addDays(today, i - 6),
    );

    return Card(
      margin: EdgeInsets.zero,
      child: Padding(
        padding: const EdgeInsets.all(AppSpacing.md),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: <Widget>[
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: <Widget>[
                Text(
                  'KONSISTENSI 7 HARI TERAKHIR',
                  style: theme.textTheme.labelSmall,
                ),
                Text(
                  'Ketuk tanggal untuk filter',
                  style: theme.textTheme.bodySmall!.copyWith(
                    color: colors.textSecondary,
                    fontSize: 11,
                  ),
                ),
              ],
            ),
            const SizedBox(height: AppSpacing.sm),
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: last7Days.map((DateTime date) {
                final bool isToday = DateOnly.isSameDay(date, today);
                final bool isSelected = selectedDate != null &&
                    DateOnly.isSameDay(selectedDate!, date);
                final int doneCount = logs
                    .where((HabitLog l) =>
                        l.isDone && DateOnly.isSameDay(l.logDate, date))
                    .length;
                final bool hasDone = doneCount > 0;

                return Expanded(
                  child: InkWell(
                    onTap: () => onSelectDate(date),
                    borderRadius: BorderRadius.circular(20),
                    child: Padding(
                      padding: const EdgeInsets.symmetric(vertical: 4),
                      child: Column(
                        children: <Widget>[
                          Text(
                            _shortDays[date.weekday - 1],
                            style: theme.textTheme.bodySmall!.copyWith(
                              fontSize: 11,
                              fontWeight: isToday || isSelected
                                  ? FontWeight.bold
                                  : FontWeight.normal,
                              color: isSelected
                                  ? theme.colorScheme.primary
                                  : colors.textSecondary,
                            ),
                          ),
                          const SizedBox(height: 6),
                          Container(
                            width: 32,
                            height: 32,
                            decoration: BoxDecoration(
                              shape: BoxShape.circle,
                              color: isSelected
                                  ? theme.colorScheme.primary
                                  : (hasDone
                                      ? theme.colorScheme.primary.withAlpha(40)
                                      : theme.colorScheme.surfaceContainerHighest),
                              border: Border.all(
                                color: isSelected || isToday
                                    ? theme.colorScheme.primary
                                    : (hasDone
                                        ? theme.colorScheme.primary
                                        : Colors.transparent),
                                width: isSelected ? 2 : 1.5,
                              ),
                            ),
                            child: Center(
                              child: hasDone
                                  ? Icon(
                                      Icons.check_rounded,
                                      size: 16,
                                      color: isSelected
                                          ? Colors.white
                                          : theme.colorScheme.primary,
                                    )
                                  : Text(
                                      '${date.day}',
                                      style: theme.textTheme.bodySmall!.copyWith(
                                        fontSize: 11,
                                        color: colors.textSecondary,
                                      ),
                                    ),
                            ),
                          ),
                        ],
                      ),
                    ),
                  ),
                );
              }).toList(),
            ),
          ],
        ),
      ),
    );
  }
}

/// Kartu entri pencapaian kebiasaan.
class _HabitCard extends StatelessWidget {
  const _HabitCard({
    required this.block,
    required this.habit,
    required this.onTap,
  });

  final Block block;
  final Habit? habit;
  final VoidCallback onTap;

  @override
  Widget build(BuildContext context) {
    final ThemeData theme = Theme.of(context);
    final AppColors colors = context.appColors;

    final DateTime? recordedTs = DateTime.tryParse(block.timestamp)?.toLocal();
    final String? logDateStr = block.data['logDate'] as String?;
    final Color habitColor =
        habit != null ? Color(habit!.colorValue) : theme.colorScheme.primary;

    return Card(
      margin: const EdgeInsets.only(bottom: AppSpacing.sm),
      child: InkWell(
        onTap: onTap,
        borderRadius: AppRadius.mdAll,
        child: Padding(
          padding: const EdgeInsets.all(AppSpacing.md),
          child: Row(
            children: <Widget>[
              // Ikon warna habit
              Container(
                width: 40,
                height: 40,
                decoration: BoxDecoration(
                  color: habitColor.withAlpha(35),
                  shape: BoxShape.circle,
                ),
                child: Icon(
                  blockIcon(block),
                  color: habitColor,
                  size: 20,
                ),
              ),
              const SizedBox(width: AppSpacing.md),

              // Rincian habit
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: <Widget>[
                    Text(
                      blockTitle(block),
                      style: theme.textTheme.titleSmall!.copyWith(
                        fontWeight: FontWeight.bold,
                      ),
                      maxLines: 1,
                      overflow: TextOverflow.ellipsis,
                    ),
                    const SizedBox(height: 2),
                    Row(
                      children: <Widget>[
                        if (logDateStr != null) ...<Widget>[
                          Text(
                            logDateStr,
                            style: theme.textTheme.bodySmall!.copyWith(
                              color: colors.textSecondary,
                              fontSize: 11,
                            ),
                          ),
                          const SizedBox(width: 6),
                          Text(
                            '•',
                            style: TextStyle(
                              color: colors.textSecondary,
                              fontSize: 10,
                            ),
                          ),
                          const SizedBox(width: 6),
                        ],
                        if (recordedTs != null)
                          Text(
                            DateFormat('HH:mm').format(recordedTs),
                            style: theme.textTheme.bodySmall!.copyWith(
                              color: colors.textSecondary,
                              fontSize: 11,
                            ),
                          ),
                      ],
                    ),
                  ],
                ),
              ),

              // Lencana Status Selesai
              Container(
                padding: const EdgeInsets.symmetric(
                  horizontal: 8,
                  vertical: 3,
                ),
                decoration: BoxDecoration(
                  color: colors.success.withAlpha(30),
                  borderRadius: AppRadius.smAll,
                ),
                child: Row(
                  mainAxisSize: MainAxisSize.min,
                  children: <Widget>[
                    Icon(
                      Icons.check_circle_rounded,
                      size: 11,
                      color: colors.success,
                    ),
                    const SizedBox(width: 3),
                    Text(
                      'Selesai',
                      style: TextStyle(
                        color: colors.success,
                        fontSize: 11,
                        fontWeight: FontWeight.w600,
                      ),
                    ),
                  ],
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}

/// Modal Bottom Sheet Rincian Pencapaian Kebiasaan.
class _BlockDetailSheet extends StatelessWidget {
  const _BlockDetailSheet({
    required this.block,
  });

  final Block block;

  @override
  Widget build(BuildContext context) {
    final ThemeData theme = Theme.of(context);
    final DateTime? ts = DateTime.tryParse(block.timestamp)?.toLocal();
    final String? logDate = block.data['logDate'] as String?;
    final int? streak = block.data['streak'] as int?;
    final String? eventRef = block.data['eventRef'] as String?;

    return Padding(
      padding: const EdgeInsets.all(AppSpacing.lg),
      child: SingleChildScrollView(
        child: Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: <Widget>[
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: <Widget>[
                Text(
                  'Rincian Pencapaian',
                  style: theme.textTheme.titleMedium!.copyWith(
                    fontWeight: FontWeight.bold,
                  ),
                ),
                IconButton(
                  icon: const Icon(Icons.close_rounded),
                  onPressed: () => Navigator.of(context).pop(),
                ),
              ],
            ),
            const SizedBox(height: AppSpacing.md),
            _infoRow('Nama Kebiasaan', blockTitle(block), theme),
            _infoRow('Status', 'Selesai', theme),
            if (logDate != null)
              _infoRow('Tanggal Pencapaian', logDate, theme),
            if (ts != null)
              _infoRow(
                'Waktu Pencatatan',
                DateFormat('EEEE, d MMM yyyy, HH:mm', 'id_ID').format(ts),
                theme,
              ),
            if (streak != null)
              _infoRow(
                'Streak Tercapai',
                '$streak hari berturut-turut',
                theme,
              ),
            if (eventRef != null)
              _infoRow('ID Pencatatan', eventRef, theme),
            const SizedBox(height: AppSpacing.lg),
            Center(
              child: AppButton(
                label: 'Tutup',
                variant: AppButtonVariant.outline,
                onPressed: () => Navigator.of(context).pop(),
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _infoRow(String label, String value, ThemeData theme) => Padding(
        padding: const EdgeInsets.symmetric(vertical: 6),
        child: Row(
          mainAxisAlignment: MainAxisAlignment.spaceBetween,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: <Widget>[
            Text(
              label,
              style: theme.textTheme.bodySmall!.copyWith(
                color: theme.textTheme.bodySmall!.color?.withAlpha(160),
              ),
            ),
            const SizedBox(width: AppSpacing.md),
            Flexible(
              child: Text(
                value,
                textAlign: TextAlign.end,
                style: theme.textTheme.bodySmall!.copyWith(
                  fontWeight: FontWeight.w600,
                ),
              ),
            ),
          ],
        ),
      );
}
