import 'dart:convert';

import 'package:crypto/crypto.dart';
import 'package:flutter/foundation.dart';

/// Satu blok pencapaian (Tahap 2 §12.4). SIMULASI hash chain lokal —
/// bukan blockchain publik, tanpa konsensus/desentralisasi.
@immutable
class Block {
  const Block({
    required this.index,
    required this.timestamp,
    required this.data,
    required this.prevHash,
    required this.hash,
  });

  final int index;

  /// ISO-8601 UTC (string apa adanya agar hash deterministik).
  final String timestamp;
  final Map<String, dynamic> data;
  final String prevHash;
  final String hash;

  Map<String, dynamic> toJson() => <String, dynamic>{
        'index': index,
        'timestamp': timestamp,
        'data': data,
        'prev_hash': prevHash,
        'hash': hash,
      };

  static Block fromJson(Map<String, dynamic> json) => Block(
        index: (json['index'] as num).toInt(),
        timestamp: json['timestamp'] as String,
        data: Map<String, dynamic>.from(json['data'] as Map),
        prevHash: json['prev_hash'] as String,
        hash: json['hash'] as String,
      );

  Block copyWith({Map<String, dynamic>? data, String? hash}) => Block(
        index: index,
        timestamp: timestamp,
        data: data ?? this.data,
        prevHash: prevHash,
        hash: hash ?? this.hash,
      );

  String get type => (data['type'] as String?) ?? 'unknown';

  /// Properti pendukung Habit Consistency Record
  String? get habitId => data['habitId'] as String?;
  String? get habitName => (data['habitName'] ?? data['name'] ?? data['title']) as String?;
  String? get logDate => data['logDate'] as String?;
  String? get status => (data['status'] as String?) ?? (isDone ? 'completed' : null);
  String? get eventRef => data['eventRef'] as String?;
  bool get isHabit => type == 'habit_completed' || type == 'habit_streak';
  bool get isDone => type == 'habit_completed' || type == 'task_completed';
}

/// Hasil validasi.
@immutable
class ChainValidation {
  const ChainValidation.valid()
      : isValid = true,
        brokenAt = null,
        reason = null;

  const ChainValidation.invalid(int this.brokenAt, String this.reason)
      : isValid = false;

  final bool isValid;
  final int? brokenAt;
  final String? reason;
}

/// Status integritas hash chain untuk tampilan antarmuka Habit Record.
enum HabitRecordIntegrityStatus {
  notReady, // Status belum tersedia
  checking, // Sedang memeriksa
  valid, // Riwayat tercatat dengan baik
  invalid, // Riwayat perlu diperiksa
  failed, // Pemeriksaan gagal
}

/// Representasi status pemeriksaan integritas yang ramah pengguna.
@immutable
class HabitRecordIntegrityState {
  const HabitRecordIntegrityState({
    required this.status,
    this.brokenAt,
    this.reason,
    this.errorMessage,
  });

  const HabitRecordIntegrityState.notReady()
      : status = HabitRecordIntegrityStatus.notReady,
        brokenAt = null,
        reason = null,
        errorMessage = null;

  const HabitRecordIntegrityState.checking()
      : status = HabitRecordIntegrityStatus.checking,
        brokenAt = null,
        reason = null,
        errorMessage = null;

  const HabitRecordIntegrityState.valid()
      : status = HabitRecordIntegrityStatus.valid,
        brokenAt = null,
        reason = null,
        errorMessage = null;

  const HabitRecordIntegrityState.invalid(int this.brokenAt, String this.reason)
      : status = HabitRecordIntegrityStatus.invalid,
        errorMessage = null;

  const HabitRecordIntegrityState.failed(String this.errorMessage)
      : status = HabitRecordIntegrityStatus.failed,
        brokenAt = null,
        reason = null;

  final HabitRecordIntegrityStatus status;
  final int? brokenAt;
  final String? reason;
  final String? errorMessage;

  bool get isValid => status == HabitRecordIntegrityStatus.valid;
  bool get isChecking => status == HabitRecordIntegrityStatus.checking;
  bool get isInvalid => status == HabitRecordIntegrityStatus.invalid;
  bool get isFailed => status == HabitRecordIntegrityStatus.failed;
  bool get isNotReady => status == HabitRecordIntegrityStatus.notReady;

  String get title => switch (status) {
        HabitRecordIntegrityStatus.checking => 'Sedang memeriksa',
        HabitRecordIntegrityStatus.valid => 'Riwayat tercatat dengan baik',
        HabitRecordIntegrityStatus.invalid => 'Riwayat perlu diperiksa',
        HabitRecordIntegrityStatus.notReady => 'Status belum tersedia',
        HabitRecordIntegrityStatus.failed => 'Pemeriksaan gagal',
      };

  String get description => switch (status) {
        HabitRecordIntegrityStatus.checking =>
          'Memeriksa konsistensi dan integritas riwayat kebiasaan...',
        HabitRecordIntegrityStatus.valid =>
          'Seluruh catatan kebiasaan utuh, berurutan, dan konsisten.',
        HabitRecordIntegrityStatus.invalid =>
          'Ditemukan ketidaksesuaian data pada riwayat kebiasaan. Catatan perlu ditinjau.',
        HabitRecordIntegrityStatus.notReady =>
          'Menyiapkan data riwayat kebiasaan dari penyimpanan...',
        HabitRecordIntegrityStatus.failed =>
          errorMessage ?? 'Terjadi kendala teknis saat membaca data riwayat.',
      };
}

abstract final class HashChain {
  static final String zeroHash = '0' * 64;

  /// JSON dengan key diurutkan secara rekursif (hash deterministik).
  static String canonicalJson(Object? value) {
    if (value is Map) {
      final List<String> keys =
          value.keys.map((Object? k) => k.toString()).toList()..sort();
      return '{${keys.map((String k) => '${jsonEncode(k)}:${canonicalJson(value[k])}').join(',')}}';
    }
    if (value is List) {
      return '[${value.map(canonicalJson).join(',')}]';
    }
    return jsonEncode(value);
  }

  /// SHA-256 dari `"$index|$timestamp|canonicalJson(data)|$prevHash"`.
  static String computeHash(
    int index,
    String timestamp,
    Map<String, dynamic> data,
    String prevHash,
  ) {
    final String input =
        '$index|$timestamp|${canonicalJson(data)}|$prevHash';
    return sha256.convert(utf8.encode(input)).toString();
  }

  static Block genesis(DateTime now) {
    final String ts = now.toUtc().toIso8601String();
    const Map<String, dynamic> data = <String, dynamic>{'type': 'genesis'};
    return Block(
      index: 0,
      timestamp: ts,
      data: data,
      prevHash: zeroHash,
      hash: computeHash(0, ts, data, zeroHash),
    );
  }

  static Block next(Block prev, Map<String, dynamic> data, DateTime now) {
    final int index = prev.index + 1;
    final String ts = now.toUtc().toIso8601String();
    return Block(
      index: index,
      timestamp: ts,
      data: data,
      prevHash: prev.hash,
      hash: computeHash(index, ts, data, prev.hash),
    );
  }

  /// Hash hitung ulang dari isi blok (untuk ditampilkan saat demo).
  static String recompute(Block b) =>
      computeHash(b.index, b.timestamp, b.data, b.prevHash);

  /// Validasi: hash cocok dengan isi, `prevHash` menunjuk blok sebelumnya,
  /// dan indeks berurutan.
  static ChainValidation validate(List<Block> chain) {
    for (int i = 0; i < chain.length; i++) {
      final Block b = chain[i];
      if (b.index != i) {
        return ChainValidation.invalid(i, 'Indeks tidak berurutan.');
      }
      if (recompute(b) != b.hash) {
        return ChainValidation.invalid(
          i,
          'Hash tidak cocok setelah data diubah.',
        );
      }
      final String expectedPrev = i == 0 ? zeroHash : chain[i - 1].hash;
      if (b.prevHash != expectedPrev) {
        return ChainValidation.invalid(
          i,
          'prevHash tidak menunjuk hash blok sebelumnya.',
        );
      }
    }
    return const ChainValidation.valid();
  }
}
