import 'dart:convert';

import 'package:flutter/foundation.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:http/http.dart' as http;

import '../../../core/storage/local_box.dart';
import '../../../core/storage/local_database.dart';
import '../../auth/application/auth_providers.dart';
import '../domain/currency.dart';

/// Sumber kurs. Diabstraksi agar penyedia bisa diganti (K-02) dan agar
/// dapat diuji.
abstract interface class RatesService {
  String get sourceLabel;

  Future<RateSnapshot> fetch(Currency base);
}

/// Frankfurter (api.frankfurter.dev) — tanpa API key; data referensi harian
/// bank sentral (asal ECB). Dipilih untuk K-02 karena tidak butuh secret,
/// sehingga aman dipanggil langsung dari aplikasi. `[PERLU DIKONFIRMASI]`
class FrankfurterRatesService implements RatesService {
  FrankfurterRatesService([http.Client? client])
      : _client = client ?? http.Client();

  final http.Client _client;
  static const Duration timeout = Duration(seconds: 12);

  @override
  String get sourceLabel => 'Frankfurter (kurs referensi bank sentral)';

  @override
  Future<RateSnapshot> fetch(Currency base) async {
    final List<String> quotes = Currency.values
        .where((Currency c) => c != base)
        .map((Currency c) => c.code.toLowerCase())
        .toList();
    final Uri uri = Uri.https('api.frankfurter.dev', '/v2/rates', <String, String>{
      'base': base.code.toLowerCase(),
      'quotes': quotes.join(','),
    });
    final http.Response res = await _client
        .get(uri, headers: <String, String>{'Accept': 'application/json'})
        .timeout(timeout);
    if (res.statusCode != 200) {
      throw http.ClientException('HTTP ${res.statusCode}', uri);
    }
    return parse(base, res.body, sourceLabel, DateTime.now().toUtc());
  }

  /// Menerima bentuk v2 (array `{date, base, quote, rate}`) maupun v1
  /// (`{base, date, rates: {...}}`).
  @visibleForTesting
  static RateSnapshot parse(
    Currency base,
    String body,
    String source,
    DateTime fetchedAt,
  ) {
    final Object? decoded = jsonDecode(body);
    final Map<Currency, double> rates = <Currency, double>{};
    String? date;
    if (decoded is List) {
      for (final Object? row in decoded) {
        if (row is Map) {
          final Currency? c = Currency.parse('${row['quote']}');
          final Object? rate = row['rate'];
          if (c != null && rate is num) {
            rates[c] = rate.toDouble();
            date ??= row['date'] as String?;
          }
        }
      }
    } else if (decoded is Map && decoded['rates'] is Map) {
      (decoded['rates'] as Map).forEach((Object? k, Object? v) {
        final Currency? c = Currency.parse('$k');
        if (c != null && v is num) {
          rates[c] = v.toDouble();
        }
      });
      date = decoded['date'] as String?;
    } else {
      throw const FormatException('Format kurs tidak dikenal');
    }
    if (rates.isEmpty) {
      throw const FormatException('Kurs kosong');
    }
    return RateSnapshot(
      base: base,
      rates: rates,
      fetchedAt: fetchedAt,
      providerDate: date,
      source: source,
    );
  }
}

/// Hasil untuk UI.
@immutable
class RatesResult {
  const RatesResult({required this.snapshot, this.isStale = false});

  final RateSnapshot snapshot;

  /// `true` = API gagal, menampilkan data cache terakhir.
  final bool isStale;
}

class RatesUnavailable implements Exception {
  const RatesUnavailable();
}

/// Cache + fallback (Tahap 2 §11.3).
class CurrencyRepository {
  CurrencyRepository(this._service, this._cache, this._clock);

  final RatesService _service;
  final LocalBox _cache;
  final DateTime Function() _clock;

  /// TTL cache — ASUMSI 4F (Tahap 2 `[PERLU DIKONFIRMASI]`).
  static const Duration ttl = Duration(hours: 6);
  static const Currency base = Currency.usd;

  RateSnapshot? cached() => RateSnapshot.fromJson(_cache.getJson(base.code));

  /// Pakai cache bila masih segar; selain itu ambil dari API. Bila API gagal
  /// dan cache ada → cache berlabel "data terakhir"; tanpa cache →
  /// [RatesUnavailable].
  Future<RatesResult> load({bool force = false}) async {
    final RateSnapshot? cache = cached();
    if (!force &&
        cache != null &&
        _clock().toUtc().difference(cache.fetchedAt) < ttl) {
      return RatesResult(snapshot: cache);
    }
    try {
      final RateSnapshot fresh = await _service.fetch(base);
      await _cache.putJson(base.code, fresh.toJson());
      return RatesResult(snapshot: fresh);
    } catch (error) {
      debugPrint('Kurs gagal dimuat: ${error.runtimeType}');
      if (cache != null) {
        return RatesResult(snapshot: cache, isStale: true);
      }
      throw const RatesUnavailable();
    }
  }
}

final Provider<RatesService> ratesServiceProvider =
    Provider<RatesService>((Ref ref) => FrankfurterRatesService());

final Provider<CurrencyRepository> currencyRepositoryProvider =
    Provider<CurrencyRepository>((Ref ref) {
  return CurrencyRepository(
    ref.watch(ratesServiceProvider),
    ref.watch(localDatabaseProvider).currencyCache,
    ref.watch(clockProvider),
  );
});
