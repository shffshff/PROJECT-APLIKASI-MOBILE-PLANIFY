import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../../../core/storage/local_box.dart';
import '../../../core/storage/local_database.dart';
import '../domain/budget_item.dart';

/// Repository lokal untuk menyimpan dan mengelola data anggaran aktivitas (Budget Helper).
/// Disimpan di Hive Box `currencyCache` dengan awalan kunci `budget_`.
class BudgetRepository {
  BudgetRepository(this._box, {DateTime Function()? clock})
      : _clock = clock ?? DateTime.now;

  final LocalBox _box;
  final DateTime Function() _clock;

  static const String prefix = 'budget_';
  static String _key(String id) => '$prefix$id';

  List<BudgetItem> getAll() {
    final List<BudgetItem> list = <BudgetItem>[];
    for (final String key in _box.keys) {
      if (key.startsWith(prefix)) {
        final Map<String, dynamic>? json = _box.getJson(key);
        final BudgetItem? item = BudgetItem.fromJson(json);
        if (item != null) {
          list.add(item);
        }
      }
    }
    // Urutkan dari yang terbaru dibuat
    list.sort((BudgetItem a, BudgetItem b) => b.createdAt.compareTo(a.createdAt));
    return list;
  }

  Stream<List<BudgetItem>> watch() async* {
    yield getAll();
    await for (final _ in _box.changes) {
      yield getAll();
    }
  }

  Future<void> save(BudgetItem item) async {
    final BudgetItem updated = item.copyWith(
      updatedAt: _clock(),
    );
    await _box.putJson(_key(updated.id), updated.toJson());
  }

  Future<void> delete(String id) async {
    await _box.delete(_key(id));
  }

  Future<void> updateActualSpent(String id, double spent) async {
    final String key = _key(id);
    final Map<String, dynamic>? json = _box.getJson(key);
    final BudgetItem? existing = BudgetItem.fromJson(json);
    if (existing != null) {
      final BudgetItem updated = existing.copyWith(
        actualSpent: spent,
        updatedAt: _clock(),
      );
      await _box.putJson(key, updated.toJson());
    }
  }
}

final Provider<BudgetRepository> budgetRepositoryProvider =
    Provider<BudgetRepository>((Ref ref) {
  return BudgetRepository(
    ref.watch(localDatabaseProvider).currencyCache,
  );
});

final StreamProvider<List<BudgetItem>> budgetsProvider =
    StreamProvider<List<BudgetItem>>((Ref ref) {
  return ref.watch(budgetRepositoryProvider).watch();
});
