import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:intl/intl.dart';
import 'package:uuid/uuid.dart';

import '../../../core/error/app_failure.dart';
import '../../../core/widgets/app_button.dart';
import '../../../core/widgets/app_text_field.dart';
import '../../../core/widgets/confirm_dialog.dart';
import '../../../core/widgets/empty_state.dart';
import '../../../core/widgets/error_state.dart';
import '../../../core/widgets/loading_indicator.dart';
import '../../../core/widgets/page_container.dart';
import '../../../core/widgets/status_banner.dart';
import '../../../theme/app_colors.dart';
import '../../../theme/app_tokens.dart';
import '../../planner/data/task_repository.dart';
import '../../planner/domain/task.dart';
import '../data/budget_repository.dart';
import '../data/currency_repository.dart';
import '../domain/budget_item.dart';
import '../domain/currency.dart';

/// Kurs aktif. `ref.invalidate` untuk memuat ulang; argumen `true` memaksa
/// panggilan API.
final FutureProvider<RatesResult> ratesProvider =
    FutureProvider.autoDispose<RatesResult>(
  (Ref ref) => ref.read(currencyRepositoryProvider).load(),
  retry: (int count, Object error) => null,
);

/// Budget Helper (sebelumnya Currency Converter).
/// Mendukung konversi mata uang (IDR, USD, MYR, SGD) serta pengelolaan
/// anggaran rencana aktivitas yang terhubung dengan Planner.
class CurrencyPage extends ConsumerStatefulWidget {
  const CurrencyPage({super.key});

  @override
  ConsumerState<CurrencyPage> createState() => _CurrencyPageState();
}

typedef BudgetHelperPage = CurrencyPage;

class _CurrencyPageState extends ConsumerState<CurrencyPage> {
  final TextEditingController _amount = TextEditingController(text: '1');
  Currency _from = Currency.usd;
  Currency _to = Currency.idr;
  bool _refreshing = false;
  int _selectedTab = 0; // 0: Kalkulator, 1: Rencana Anggaran

  @override
  void dispose() {
    _amount.dispose();
    super.dispose();
  }

  Future<void> _refresh() async {
    setState(() => _refreshing = true);
    try {
      await ref.read(currencyRepositoryProvider).load(force: true);
    } catch (_) {
      // ditangani tampilan
    }
    ref.invalidate(ratesProvider);
    if (mounted) {
      setState(() => _refreshing = false);
    }
  }

  void _openBudgetDialog({BudgetItem? itemToEdit, double? initialConverted}) {
    final AsyncValue<RatesResult> rates = ref.read(ratesProvider);
    final RateSnapshot? snapshot = rates.value?.snapshot;

    showModalBottomSheet<void>(
      context: context,
      isScrollControlled: true,
      useSafeArea: true,
      builder: (BuildContext ctx) => _BudgetFormSheet(
        itemToEdit: itemToEdit,
        defaultFromCurrency: itemToEdit?.currency ?? _from,
        defaultTargetCurrency: itemToEdit?.targetCurrency ?? _to,
        defaultAmount: itemToEdit != null
            ? itemToEdit.amount.toString()
            : _amount.text.trim(),
        defaultConvertedAmount: initialConverted ?? itemToEdit?.convertedAmount,
        snapshot: snapshot,
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final AsyncValue<RatesResult> rates = ref.watch(ratesProvider);
    final ThemeData theme = Theme.of(context);

    return Scaffold(
      appBar: AppBar(
        title: const Text('Budget Helper'),
        actions: <Widget>[
          IconButton(
            tooltip: 'Muat ulang kurs',
            onPressed: _refreshing ? null : _refresh,
            icon: const Icon(Icons.refresh_rounded),
          ),
        ],
      ),
      body: SafeArea(
        child: ListView(
          padding: const EdgeInsets.only(bottom: AppSpacing.xxl),
          children: <Widget>[
            PageContainer(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.stretch,
                children: <Widget>[
                  const SizedBox(height: AppSpacing.md),
                  SegmentedButton<int>(
                    showSelectedIcon: false,
                    segments: const <ButtonSegment<int>>[
                      ButtonSegment<int>(
                        value: 0,
                        label: Text('Kalkulator Kurs'),
                        icon: Icon(Icons.currency_exchange_rounded),
                      ),
                      ButtonSegment<int>(
                        value: 1,
                        label: Text('Rencana Anggaran'),
                        icon: Icon(Icons.account_balance_wallet_outlined),
                      ),
                    ],
                    selected: <int>{_selectedTab},
                    onSelectionChanged: (Set<int> sel) {
                      setState(() => _selectedTab = sel.first);
                    },
                  ),
                  const SizedBox(height: AppSpacing.lg),
                  if (_selectedTab == 0) ...<Widget>[
                    _buildCalculatorSection(rates, theme),
                  ] else ...<Widget>[
                    _buildBudgetsSection(rates, theme),
                  ],
                ],
              ),
            ),
          ],
        ),
      ),
      floatingActionButton: _selectedTab == 1
          ? FloatingActionButton.extended(
              onPressed: () => _openBudgetDialog(),
              icon: const Icon(Icons.add_rounded),
              label: const Text('Tambah Anggaran'),
            )
          : null,
    );
  }

  Widget _buildCalculatorSection(
    AsyncValue<RatesResult> rates,
    ThemeData theme,
  ) {
    final RateSnapshot? snapshot = rates.value?.snapshot;
    final double? parsedAmount = CurrencyConverter.parseAmount(_amount.text);
    final double? convertedValue = (parsedAmount != null && snapshot != null)
        ? CurrencyConverter.convert(parsedAmount, _from, _to, snapshot)
        : null;

    return Column(
      crossAxisAlignment: CrossAxisAlignment.stretch,
      children: <Widget>[
        AppTextField(
          label: 'Nominal',
          controller: _amount,
          keyboardType: const TextInputType.numberWithOptions(decimal: true),
          prefixIcon: const Icon(Icons.payments_outlined),
          onChanged: (_) => setState(() {}),
          validator: (String? value) =>
              CurrencyConverter.validateAmount(value ?? ''),
        ),
        const SizedBox(height: AppSpacing.lg),
        Row(
          children: <Widget>[
            Expanded(
              child: _CurrencyPicker(
                label: 'Dari',
                value: _from,
                onChanged: (Currency c) => setState(() => _from = c),
              ),
            ),
            IconButton(
              tooltip: 'Tukar mata uang',
              onPressed: () => setState(() {
                final Currency t = _from;
                _from = _to;
                _to = t;
              }),
              icon: const Icon(Icons.swap_horiz_rounded),
            ),
            Expanded(
              child: _CurrencyPicker(
                label: 'Ke',
                value: _to,
                onChanged: (Currency c) => setState(() => _to = c),
              ),
            ),
          ],
        ),
        const SizedBox(height: AppSpacing.lg),
        rates.when(
          loading: () => const Padding(
            padding: EdgeInsets.all(AppSpacing.xl),
            child: Center(
              child: LoadingIndicator(label: 'Memuat kurs…'),
            ),
          ),
          error: (Object e, StackTrace _) => ErrorState(
            failure: const AppFailure(
              AppFailureKind.network,
              customTitle: 'Kurs belum bisa dimuat',
              message: 'Periksa koneksi internet, lalu coba lagi. '
                  'Belum ada data kurs tersimpan di perangkat.',
            ),
            onRetry: _refresh,
          ),
          data: (RatesResult r) => _Result(
            result: r,
            amountText: _amount.text,
            from: _from,
            to: _to,
          ),
        ),
        if (convertedValue != null) ...<Widget>[
          const SizedBox(height: AppSpacing.md),
          AppButton(
            label: 'Simpan sebagai Rencana Anggaran',
            icon: Icons.bookmark_add_outlined,
            variant: AppButtonVariant.outline,
            onPressed: () => _openBudgetDialog(initialConverted: convertedValue),
          ),
        ],
        const SizedBox(height: AppSpacing.lg),
        Text(
          'MATA UANG TERSEDIA: IDR · USD · MYR · SGD',
          style: theme.textTheme.labelSmall,
        ),
        const SizedBox(height: AppSpacing.xs),
        Text(
          'Kurs referensi untuk perencanaan anggaran aktivitas produktivitas.',
          style: theme.textTheme.bodySmall!.copyWith(
            color: context.appColors.textSecondary,
          ),
        ),
      ],
    );
  }

  Widget _buildBudgetsSection(
    AsyncValue<RatesResult> rates,
    ThemeData theme,
  ) {
    final AsyncValue<List<BudgetItem>> budgetsAsync =
        ref.watch(budgetsProvider);

    return budgetsAsync.when(
      loading: () => const Center(
        child: Padding(
          padding: EdgeInsets.all(AppSpacing.xl),
          child: LoadingIndicator(label: 'Memuat anggaran…'),
        ),
      ),
      error: (Object e, StackTrace _) => ErrorState(
        failure: AppFailure(
          AppFailureKind.unknown,
          customTitle: 'Gagal memuat anggaran',
          message: e.toString(),
        ),
      ),
      data: (List<BudgetItem> budgets) {
        if (budgets.isEmpty) {
          return EmptyState(
            icon: Icons.account_balance_wallet_outlined,
            title: 'Belum ada anggaran aktivitas',
            message:
                'Catat rencana biaya untuk aktivitas atau agenda di Planner, '
                'lalu pantau perbandingannya dengan pengeluaran aktual.',
            primaryActionLabel: 'Buat Anggaran Baru',
            onPrimaryAction: () => _openBudgetDialog(),
          );
        }

        // Hitung total ringkasan
        double totalConvertedBudget = 0;
        double totalActualSpent = 0;
        for (final BudgetItem b in budgets) {
          totalConvertedBudget += b.convertedAmount;
          totalActualSpent += b.actualSpent;
        }
        final double totalRemaining = totalConvertedBudget - totalActualSpent;

        return Column(
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: <Widget>[
            _BudgetSummaryCard(
              totalBudget: totalConvertedBudget,
              totalSpent: totalActualSpent,
              totalRemaining: totalRemaining,
              itemCount: budgets.length,
            ),
            const SizedBox(height: AppSpacing.lg),
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: <Widget>[
                Text(
                  'DAFTAR ANGGARAN (${budgets.length})',
                  style: theme.textTheme.labelSmall,
                ),
                TextButton.icon(
                  onPressed: () => _openBudgetDialog(),
                  icon: const Icon(Icons.add_rounded, size: 18),
                  label: const Text('Tambah'),
                ),
              ],
            ),
            const SizedBox(height: AppSpacing.xs),
            for (final BudgetItem item in budgets) ...<Widget>[
              _BudgetItemCard(
                item: item,
                onEdit: () => _openBudgetDialog(itemToEdit: item),
                onDelete: () => _confirmDelete(item),
                onUpdateSpent: (double spent) async {
                  await ref
                      .read(budgetRepositoryProvider)
                      .updateActualSpent(item.id, spent);
                },
              ),
              const SizedBox(height: AppSpacing.sm),
            ],
          ],
        );
      },
    );
  }

  Future<void> _confirmDelete(BudgetItem item) async {
    final ConfirmResult result = await showConfirmDialog(
      context,
      title: 'Hapus Anggaran?',
      message: 'Anggaran "${item.title}" akan dihapus permanen dari perangkat.',
      confirmLabel: 'Hapus',
      isDestructive: true,
    );
    if (result == ConfirmResult.confirm) {
      await ref.read(budgetRepositoryProvider).delete(item.id);
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text('Anggaran berhasil dihapus.')),
        );
      }
    }
  }
}

class _CurrencyPicker extends StatelessWidget {
  const _CurrencyPicker({
    required this.label,
    required this.value,
    required this.onChanged,
  });

  final String label;
  final Currency value;
  final ValueChanged<Currency> onChanged;

  @override
  Widget build(BuildContext context) {
    return DropdownButtonFormField<Currency>(
      key: ValueKey<String>('$label-${value.code}'),
      initialValue: value,
      isExpanded: true,
      decoration: InputDecoration(labelText: label),
      items: <DropdownMenuItem<Currency>>[
        for (final Currency c in Currency.values)
          DropdownMenuItem<Currency>(
            value: c,
            child: Text(
              '${c.code} · ${c.name}',
              overflow: TextOverflow.ellipsis,
            ),
          ),
      ],
      onChanged: (Currency? c) {
        if (c != null) {
          onChanged(c);
        }
      },
    );
  }
}

class _Result extends StatelessWidget {
  const _Result({
    required this.result,
    required this.amountText,
    required this.from,
    required this.to,
  });

  final RatesResult result;
  final String amountText;
  final Currency from;
  final Currency to;

  @override
  Widget build(BuildContext context) {
    final ThemeData theme = Theme.of(context);
    final RateSnapshot s = result.snapshot;
    final String? invalid = CurrencyConverter.validateAmount(amountText);
    final double? amount = CurrencyConverter.parseAmount(amountText);
    final double? value = invalid == null && amount != null
        ? CurrencyConverter.convert(amount, from, to, s)
        : null;
    final double? unit = CurrencyConverter.convert(1, from, to, s);
    final String fetched =
        DateFormat('d MMM, HH:mm', 'id_ID').format(s.fetchedAt.toLocal());

    return Column(
      crossAxisAlignment: CrossAxisAlignment.stretch,
      children: <Widget>[
        if (result.isStale) ...<Widget>[
          StatusBanner(
            type: StatusBannerType.offline,
            title: 'Data terakhir:',
            message: 'kurs terbaru tidak dapat dimuat, menampilkan data '
                'tersimpan ($fetched).',
          ),
          const SizedBox(height: AppSpacing.md),
        ],
        Card(
          margin: EdgeInsets.zero,
          child: Padding(
            padding: const EdgeInsets.all(AppSpacing.lg),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: <Widget>[
                Text('HASIL', style: theme.textTheme.labelSmall),
                const SizedBox(height: AppSpacing.xs),
                Semantics(
                  liveRegion: true,
                  child: Text(
                    value == null
                        ? (invalid ?? 'Kurs tidak tersedia untuk pasangan ini.')
                        : CurrencyConverter.format(value, to),
                    style: value == null
                        ? theme.textTheme.bodyMedium!
                            .copyWith(color: theme.colorScheme.error)
                        : theme.textTheme.headlineMedium,
                  ),
                ),
                if (unit != null) ...<Widget>[
                  const SizedBox(height: AppSpacing.sm),
                  Text(
                    '1 ${from.code} = ${CurrencyConverter.formatRate(unit)} ${to.code}',
                    style: theme.textTheme.bodyMedium,
                  ),
                ],
                const SizedBox(height: AppSpacing.xs),
                Text(
                  'Diperbarui: ${s.providerDate ?? '-'} (diambil $fetched)',
                  style: theme.textTheme.bodySmall,
                ),
                Text('Sumber: ${s.source}', style: theme.textTheme.bodySmall),
              ],
            ),
          ),
        ),
      ],
    );
  }
}

class _BudgetSummaryCard extends StatelessWidget {
  const _BudgetSummaryCard({
    required this.totalBudget,
    required this.totalSpent,
    required this.totalRemaining,
    required this.itemCount,
  });

  final double totalBudget;
  final double totalSpent;
  final double totalRemaining;
  final int itemCount;

  @override
  Widget build(BuildContext context) {
    final ThemeData theme = Theme.of(context);
    final AppColors colors = context.appColors;
    final NumberFormat idrFmt = NumberFormat.currency(
      locale: 'id_ID',
      symbol: 'Rp ',
      decimalDigits: 0,
    );

    final double ratio =
        totalBudget > 0 ? (totalSpent / totalBudget).clamp(0.0, 1.0) : 0.0;
    final bool isOver = totalRemaining < 0;

    return Card(
      margin: EdgeInsets.zero,
      color: theme.colorScheme.primaryContainer.withAlpha(50),
      child: Padding(
        padding: const EdgeInsets.all(AppSpacing.lg),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: <Widget>[
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: <Widget>[
                Text(
                  'RINGKASAN ANGGARAN',
                  style: theme.textTheme.labelSmall,
                ),
                Text(
                  '$itemCount aktivitas',
                  style: theme.textTheme.bodySmall!.copyWith(
                    color: colors.textSecondary,
                  ),
                ),
              ],
            ),
            const SizedBox(height: AppSpacing.sm),
            Row(
              children: <Widget>[
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: <Widget>[
                      Text('Total Anggaran', style: theme.textTheme.bodySmall),
                      Text(
                        idrFmt.format(totalBudget),
                        style: theme.textTheme.titleMedium!.copyWith(
                          fontWeight: FontWeight.bold,
                        ),
                      ),
                    ],
                  ),
                ),
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: <Widget>[
                      Text('Pengeluaran Aktual', style: theme.textTheme.bodySmall),
                      Text(
                        idrFmt.format(totalSpent),
                        style: theme.textTheme.titleMedium!.copyWith(
                          color: isOver ? theme.colorScheme.error : null,
                          fontWeight: FontWeight.bold,
                        ),
                      ),
                    ],
                  ),
                ),
              ],
            ),
            const SizedBox(height: AppSpacing.md),
            LinearProgressIndicator(
              value: ratio,
              backgroundColor: theme.colorScheme.surfaceContainerHighest,
              color: isOver ? theme.colorScheme.error : theme.colorScheme.primary,
              borderRadius: AppRadius.smAll,
            ),
            const SizedBox(height: AppSpacing.xs),
            Text(
              isOver
                  ? 'Melebihi anggaran sebesar ${idrFmt.format(totalRemaining.abs())}'
                  : 'Sisa anggaran: ${idrFmt.format(totalRemaining)}',
              style: theme.textTheme.bodySmall!.copyWith(
                color: isOver ? theme.colorScheme.error : colors.textSecondary,
                fontWeight: isOver ? FontWeight.w600 : FontWeight.normal,
              ),
            ),
          ],
        ),
      ),
    );
  }
}

class _BudgetItemCard extends StatelessWidget {
  const _BudgetItemCard({
    required this.item,
    required this.onEdit,
    required this.onDelete,
    required this.onUpdateSpent,
  });

  final BudgetItem item;
  final VoidCallback onEdit;
  final VoidCallback onDelete;
  final ValueChanged<double> onUpdateSpent;

  @override
  Widget build(BuildContext context) {
    final ThemeData theme = Theme.of(context);
    final AppColors colors = context.appColors;

    final String budgetFormatted =
        CurrencyConverter.format(item.convertedAmount, item.targetCurrency);
    final String originalFormatted =
        CurrencyConverter.format(item.amount, item.currency);
    final String spentFormatted =
        CurrencyConverter.format(item.actualSpent, item.targetCurrency);
    final double remaining = item.remainingBudget;
    final bool isOver = remaining < 0;

    return Card(
      margin: EdgeInsets.zero,
      child: Padding(
        padding: const EdgeInsets.all(AppSpacing.md),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: <Widget>[
            Row(
              children: <Widget>[
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: <Widget>[
                      Text(
                        item.title,
                        style: theme.textTheme.titleSmall!.copyWith(
                          fontWeight: FontWeight.bold,
                        ),
                      ),
                      if (item.hasLinkedTask) ...<Widget>[
                        const SizedBox(height: 2),
                        Row(
                          children: <Widget>[
                            Icon(
                              Icons.event_note_rounded,
                              size: 14,
                              color: theme.colorScheme.primary,
                            ),
                            const SizedBox(width: 4),
                            Expanded(
                              child: Text(
                                item.taskTitle ?? 'Terkait aktivitas Planner',
                                style: theme.textTheme.bodySmall!.copyWith(
                                  color: theme.colorScheme.primary,
                                ),
                                overflow: TextOverflow.ellipsis,
                              ),
                            ),
                          ],
                        ),
                      ],
                    ],
                  ),
                ),
                PopupMenuButton<String>(
                  icon: const Icon(Icons.more_vert_rounded),
                  onSelected: (String action) {
                    if (action == 'edit') {
                      onEdit();
                    } else if (action == 'delete') {
                      onDelete();
                    } else if (action == 'quick_spent') {
                      _showQuickSpentDialog(context);
                    }
                  },
                  itemBuilder: (BuildContext ctx) => <PopupMenuEntry<String>>[
                    const PopupMenuItem<String>(
                      value: 'quick_spent',
                      child: Text('Catat Pengeluaran'),
                    ),
                    const PopupMenuItem<String>(
                      value: 'edit',
                      child: Text('Edit Anggaran'),
                    ),
                    const PopupMenuItem<String>(
                      value: 'delete',
                      child: Text('Hapus'),
                    ),
                  ],
                ),
              ],
            ),
            const Divider(height: AppSpacing.md),
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: <Widget>[
                Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: <Widget>[
                    Text('Anggaran Terencana', style: theme.textTheme.bodySmall),
                    Text(
                      budgetFormatted,
                      style: theme.textTheme.bodyMedium!.copyWith(
                        fontWeight: FontWeight.w600,
                      ),
                    ),
                    if (item.currency != item.targetCurrency)
                      Text(
                        'Asal: $originalFormatted',
                        style: theme.textTheme.bodySmall!.copyWith(
                          color: colors.textSecondary,
                          fontSize: 11,
                        ),
                      ),
                  ],
                ),
                Column(
                  crossAxisAlignment: CrossAxisAlignment.end,
                  children: <Widget>[
                    Text('Realisasi Aktual', style: theme.textTheme.bodySmall),
                    Text(
                      spentFormatted,
                      style: theme.textTheme.bodyMedium!.copyWith(
                        fontWeight: FontWeight.w600,
                        color: isOver ? theme.colorScheme.error : null,
                      ),
                    ),
                    Text(
                      isOver
                          ? 'Lebih ${CurrencyConverter.format(remaining.abs(), item.targetCurrency)}'
                          : 'Hemat ${CurrencyConverter.format(remaining, item.targetCurrency)}',
                      style: theme.textTheme.bodySmall!.copyWith(
                        color: isOver
                            ? theme.colorScheme.error
                            : theme.colorScheme.primary,
                        fontSize: 11,
                        fontWeight: FontWeight.w500,
                      ),
                    ),
                  ],
                ),
              ],
            ),
            const SizedBox(height: AppSpacing.sm),
            ClipRRect(
              borderRadius: AppRadius.smAll,
              child: LinearProgressIndicator(
                value: item.spentRatio.clamp(0.0, 1.0),
                backgroundColor: theme.colorScheme.surfaceContainerHighest,
                color: isOver
                    ? theme.colorScheme.error
                    : theme.colorScheme.primary,
                minHeight: 6,
              ),
            ),
          ],
        ),
      ),
    );
  }

  void _showQuickSpentDialog(BuildContext context) {
    final TextEditingController spentCtrl =
        TextEditingController(text: item.actualSpent.toStringAsFixed(0));
    showDialog<void>(
      context: context,
      builder: (BuildContext ctx) => AlertDialog(
        title: const Text('Catat Pengeluaran Aktual'),
        content: Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: <Widget>[
            Text(
              'Masukkan jumlah pengeluaran aktual untuk "${item.title}" (${item.targetCurrency.code}):',
              style: Theme.of(ctx).textTheme.bodyMedium,
            ),
            const SizedBox(height: AppSpacing.md),
            AppTextField(
              label: 'Nominal Aktual',
              controller: spentCtrl,
              keyboardType:
                  const TextInputType.numberWithOptions(decimal: true),
              prefixIcon: const Icon(Icons.attach_money_rounded),
            ),
          ],
        ),
        actions: <Widget>[
          TextButton(
            onPressed: () => Navigator.of(ctx).pop(),
            child: const Text('Batal'),
          ),
          FilledButton(
            onPressed: () {
              final double? val =
                  CurrencyConverter.parseAmount(spentCtrl.text);
              if (val != null) {
                onUpdateSpent(val);
                Navigator.of(ctx).pop();
              }
            },
            child: const Text('Simpan'),
          ),
        ],
      ),
    );
  }
}

class _BudgetFormSheet extends ConsumerStatefulWidget {
  const _BudgetFormSheet({
    this.itemToEdit,
    required this.defaultFromCurrency,
    required this.defaultTargetCurrency,
    required this.defaultAmount,
    this.defaultConvertedAmount,
    this.snapshot,
  });

  final BudgetItem? itemToEdit;
  final Currency defaultFromCurrency;
  final Currency defaultTargetCurrency;
  final String defaultAmount;
  final double? defaultConvertedAmount;
  final RateSnapshot? snapshot;

  @override
  ConsumerState<_BudgetFormSheet> createState() => _BudgetFormSheetState();
}

class _BudgetFormSheetState extends ConsumerState<_BudgetFormSheet> {
  final GlobalKey<FormState> _formKey = GlobalKey<FormState>();
  late final TextEditingController _titleCtrl;
  late final TextEditingController _amountCtrl;
  late final TextEditingController _actualSpentCtrl;
  late Currency _fromCurrency;
  late Currency _targetCurrency;
  String? _selectedTaskId;
  String? _selectedTaskTitle;

  @override
  void initState() {
    super.initState();
    final BudgetItem? edit = widget.itemToEdit;
    _titleCtrl = TextEditingController(text: edit?.title ?? '');
    _amountCtrl = TextEditingController(
      text: edit != null ? edit.amount.toString() : widget.defaultAmount,
    );
    _actualSpentCtrl = TextEditingController(
      text: edit != null && edit.actualSpent > 0
          ? edit.actualSpent.toString()
          : '',
    );
    _fromCurrency = edit?.currency ?? widget.defaultFromCurrency;
    _targetCurrency = edit?.targetCurrency ?? widget.defaultTargetCurrency;
    _selectedTaskId = edit?.taskId;
    _selectedTaskTitle = edit?.taskTitle;
  }

  @override
  void dispose() {
    _titleCtrl.dispose();
    _amountCtrl.dispose();
    _actualSpentCtrl.dispose();
    super.dispose();
  }

  double _calculateConverted(double amount) {
    if (_fromCurrency == _targetCurrency) {
      return amount;
    }
    final RateSnapshot? snap = widget.snapshot;
    if (snap != null) {
      final double? c =
          CurrencyConverter.convert(amount, _fromCurrency, _targetCurrency, snap);
      if (c != null) {
        return c;
      }
    }
    return widget.defaultConvertedAmount ?? amount;
  }

  Future<void> _save() async {
    if (!(_formKey.currentState?.validate() ?? false)) {
      return;
    }

    final double? amount = CurrencyConverter.parseAmount(_amountCtrl.text);
    if (amount == null || amount <= 0) {
      return;
    }

    final double actualSpent =
        CurrencyConverter.parseAmount(_actualSpentCtrl.text) ?? 0.0;
    final double converted = _calculateConverted(amount);

    final BudgetItem item = BudgetItem(
      id: widget.itemToEdit?.id ?? const Uuid().v4(),
      title: _titleCtrl.text.trim(),
      amount: amount,
      currency: _fromCurrency,
      targetCurrency: _targetCurrency,
      convertedAmount: converted,
      taskId: _selectedTaskId,
      taskTitle: _selectedTaskTitle,
      actualSpent: actualSpent,
      createdAt: widget.itemToEdit?.createdAt ?? DateTime.now(),
      updatedAt: DateTime.now(),
    );

    await ref.read(budgetRepositoryProvider).save(item);
    if (mounted) {
      Navigator.of(context).pop();
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text(
            widget.itemToEdit == null
                ? 'Anggaran aktivitas berhasil disimpan.'
                : 'Anggaran aktivitas berhasil diperbarui.',
          ),
        ),
      );
    }
  }

  @override
  Widget build(BuildContext context) {
    final ThemeData theme = Theme.of(context);
    final List<Task> tasks =
        ref.watch(tasksProvider).value ?? const <Task>[];
    final List<Task> activeTasks =
        tasks.where((Task t) => !t.isDeleted).toList();

    final double? parsedAmount =
        CurrencyConverter.parseAmount(_amountCtrl.text);
    final double estimatedConverted = parsedAmount != null
        ? _calculateConverted(parsedAmount)
        : 0.0;

    return Padding(
      padding: EdgeInsets.only(
        left: AppSpacing.lg,
        right: AppSpacing.lg,
        top: AppSpacing.lg,
        bottom: MediaQuery.of(context).viewInsets.bottom + AppSpacing.xl,
      ),
      child: Form(
        key: _formKey,
        child: SingleChildScrollView(
          child: Column(
            mainAxisSize: MainAxisSize.min,
            crossAxisAlignment: CrossAxisAlignment.stretch,
            children: <Widget>[
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: <Widget>[
                  Text(
                    widget.itemToEdit == null
                        ? 'Tambah Rencana Anggaran'
                        : 'Edit Rencana Anggaran',
                    style: theme.textTheme.titleMedium!.copyWith(
                      fontWeight: FontWeight.bold,
                    ),
                  ),
                  IconButton(
                    icon: const Icon(Icons.close_rounded),
                    onPressed: () => Navigator.of(context).pop(),
                  ),
                ],
              ),
              const SizedBox(height: AppSpacing.md),
              AppTextField(
                label: 'Nama Anggaran / Keperluan',
                controller: _titleCtrl,
                prefixIcon: const Icon(Icons.description_outlined),
                validator: (String? v) =>
                    v == null || v.trim().isEmpty ? 'Nama anggaran wajib diisi.' : null,
              ),
              const SizedBox(height: AppSpacing.md),
              Row(
                children: <Widget>[
                  Expanded(
                    flex: 3,
                    child: AppTextField(
                      label: 'Nominal Asal',
                      controller: _amountCtrl,
                      keyboardType: const TextInputType.numberWithOptions(
                        decimal: true,
                      ),
                      prefixIcon: const Icon(Icons.payments_outlined),
                      onChanged: (_) => setState(() {}),
                      validator: (String? v) =>
                          CurrencyConverter.validateAmount(v ?? ''),
                    ),
                  ),
                  const SizedBox(width: AppSpacing.sm),
                  Expanded(
                    flex: 2,
                    child: _CurrencyPicker(
                      label: 'Mata Uang',
                      value: _fromCurrency,
                      onChanged: (Currency c) =>
                          setState(() => _fromCurrency = c),
                    ),
                  ),
                ],
              ),
              const SizedBox(height: AppSpacing.md),
              Row(
                children: <Widget>[
                  Expanded(
                    child: _CurrencyPicker(
                      label: 'Konversi ke Target',
                      value: _targetCurrency,
                      onChanged: (Currency c) =>
                          setState(() => _targetCurrency = c),
                    ),
                  ),
                ],
              ),
              if (parsedAmount != null && parsedAmount > 0) ...<Widget>[
                const SizedBox(height: AppSpacing.xs),
                Text(
                  'Estimasi Anggaran: ${CurrencyConverter.format(estimatedConverted, _targetCurrency)}',
                  style: theme.textTheme.bodySmall!.copyWith(
                    color: theme.colorScheme.primary,
                    fontWeight: FontWeight.w600,
                  ),
                ),
              ],
              const SizedBox(height: AppSpacing.md),
              DropdownButtonFormField<String?>(
                initialValue: _selectedTaskId,
                decoration: const InputDecoration(
                  labelText: 'Hubungkan Aktivitas Planner (Opsional)',
                  prefixIcon: Icon(Icons.link_rounded),
                ),
                isExpanded: true,
                items: <DropdownMenuItem<String?>>[
                  const DropdownMenuItem<String?>(
                    value: null,
                    child: Text('Tidak terhubung ke aktivitas'),
                  ),
                  for (final Task t in activeTasks)
                    DropdownMenuItem<String?>(
                      value: t.id,
                      child: Text(
                        '${t.category.label}: ${t.title}',
                        overflow: TextOverflow.ellipsis,
                      ),
                    ),
                ],
                onChanged: (String? val) {
                  setState(() {
                    _selectedTaskId = val;
                    if (val == null) {
                      _selectedTaskTitle = null;
                    } else {
                      final Task matched = activeTasks.firstWhere(
                        (Task t) => t.id == val,
                      );
                      _selectedTaskTitle = matched.title;
                    }
                  });
                },
              ),
              const SizedBox(height: AppSpacing.md),
              AppTextField(
                label: 'Pengeluaran Aktual (${_targetCurrency.code}) (Opsional)',
                controller: _actualSpentCtrl,
                keyboardType:
                    const TextInputType.numberWithOptions(decimal: true),
                prefixIcon: const Icon(Icons.receipt_long_outlined),
                helperText: 'Isi jika sudah ada realisasi pengeluaran.',
              ),
              const SizedBox(height: AppSpacing.lg),
              AppButton(
                label: widget.itemToEdit == null
                    ? 'Simpan Anggaran'
                    : 'Perbarui Anggaran',
                icon: Icons.check_rounded,
                onPressed: _save,
              ),
            ],
          ),
        ),
      ),
    );
  }
}
