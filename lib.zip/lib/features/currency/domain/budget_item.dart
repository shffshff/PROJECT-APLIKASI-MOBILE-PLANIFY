import 'package:flutter/foundation.dart';
import 'currency.dart';

/// Model anggaran aktivitas untuk Budget Helper.
@immutable
class BudgetItem {
  const BudgetItem({
    required this.id,
    required this.title,
    required this.amount,
    required this.currency,
    required this.targetCurrency,
    required this.convertedAmount,
    this.taskId,
    this.taskTitle,
    this.actualSpent = 0.0,
    required this.createdAt,
    this.updatedAt,
  });

  final String id;
  final String title;
  final double amount;
  final Currency currency;
  final Currency targetCurrency;
  final double convertedAmount;

  /// ID tugas terkait di Planner (opsional).
  final String? taskId;

  /// Judul tugas terkait di Planner (opsional, untuk tampilan cepat).
  final String? taskTitle;

  /// Pengeluaran aktual yang dicatat pengguna (dalam targetCurrency).
  final double actualSpent;

  final DateTime createdAt;
  final DateTime? updatedAt;

  /// Selisih anggaran dengan realisasi: positif = hemat, negatif = over-budget.
  double get remainingBudget => convertedAmount - actualSpent;

  /// Persentase pemakaian anggaran (0.0 – 1.0+).
  double get spentRatio =>
      convertedAmount > 0 ? (actualSpent / convertedAmount) : 0.0;

  bool get hasLinkedTask => taskId != null && taskId!.isNotEmpty;

  BudgetItem copyWith({
    String? id,
    String? title,
    double? amount,
    Currency? currency,
    Currency? targetCurrency,
    double? convertedAmount,
    String? taskId,
    String? taskTitle,
    bool clearTask = false,
    double? actualSpent,
    DateTime? createdAt,
    DateTime? updatedAt,
  }) {
    return BudgetItem(
      id: id ?? this.id,
      title: title ?? this.title,
      amount: amount ?? this.amount,
      currency: currency ?? this.currency,
      targetCurrency: targetCurrency ?? this.targetCurrency,
      convertedAmount: convertedAmount ?? this.convertedAmount,
      taskId: clearTask ? null : (taskId ?? this.taskId),
      taskTitle: clearTask ? null : (taskTitle ?? this.taskTitle),
      actualSpent: actualSpent ?? this.actualSpent,
      createdAt: createdAt ?? this.createdAt,
      updatedAt: updatedAt ?? this.updatedAt,
    );
  }

  Map<String, dynamic> toJson() => <String, dynamic>{
        'id': id,
        'title': title,
        'amount': amount,
        'currency': currency.code,
        'target_currency': targetCurrency.code,
        'converted_amount': convertedAmount,
        'task_id': taskId,
        'task_title': taskTitle,
        'actual_spent': actualSpent,
        'created_at': createdAt.toUtc().toIso8601String(),
        'updated_at': updatedAt?.toUtc().toIso8601String(),
      };

  static BudgetItem? fromJson(Map<String, dynamic>? json) {
    if (json == null) return null;
    final String? id = json['id'] as String?;
    final String? title = json['title'] as String?;
    final num? amount = json['amount'] as num?;
    final Currency? currency =
        Currency.parse(json['currency'] as String? ?? '');
    final Currency? targetCurrency =
        Currency.parse(json['target_currency'] as String? ?? '');
    final num? convertedAmount = json['converted_amount'] as num?;
    final DateTime? createdAt =
        DateTime.tryParse(json['created_at'] as String? ?? '');

    if (id == null ||
        title == null ||
        amount == null ||
        currency == null ||
        targetCurrency == null ||
        convertedAmount == null ||
        createdAt == null) {
      return null;
    }

    return BudgetItem(
      id: id,
      title: title,
      amount: amount.toDouble(),
      currency: currency,
      targetCurrency: targetCurrency,
      convertedAmount: convertedAmount.toDouble(),
      taskId: json['task_id'] as String?,
      taskTitle: json['task_title'] as String?,
      actualSpent: (json['actual_spent'] as num?)?.toDouble() ?? 0.0,
      createdAt: createdAt.toLocal(),
      updatedAt: DateTime.tryParse(json['updated_at'] as String? ?? '')?.toLocal(),
    );
  }
}
