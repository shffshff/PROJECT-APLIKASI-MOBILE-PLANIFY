import 'package:flutter/foundation.dart';
import 'package:intl/intl.dart';

/// Mata uang yang didukung (FR-039).
enum Currency {
  idr('IDR', 'Rupiah', 'Rp', 0),
  usd('USD', 'Dolar AS', r'US$', 2),
  myr('MYR', 'Ringgit Malaysia', 'RM', 2),
  sgd('SGD', 'Dolar Singapura', r'S$', 2);

  const Currency(this.code, this.name, this.symbol, this.decimals);

  final String code;
  final String name;
  final String symbol;

  /// Desimal saat ditampilkan (IDR 0, lainnya 2) — `[PERLU DIKONFIRMASI]`.
  final int decimals;

  static Currency? parse(String code) {
    for (final Currency c in Currency.values) {
      if (c.code == code.toUpperCase()) {
        return c;
      }
    }
    return null;
  }
}

/// Snapshot kurs (Tahap 2 §11.3). `rates[x]` = berapa x untuk 1 [base].
@immutable
class RateSnapshot {
  const RateSnapshot({
    required this.base,
    required this.rates,
    required this.fetchedAt,
    required this.source,
    this.providerDate,
  });

  final Currency base;
  final Map<Currency, double> rates;

  /// Saat aplikasi mengambil data (UTC).
  final DateTime fetchedAt;

  /// Tanggal kurs menurut penyedia (mis. kurs referensi harian).
  final String? providerDate;
  final String source;

  double? rateOf(Currency c) => c == base ? 1 : rates[c];

  Map<String, dynamic> toJson() => <String, dynamic>{
        'base': base.code,
        'rates': <String, double>{
          for (final MapEntry<Currency, double> e in rates.entries)
            e.key.code: e.value,
        },
        'fetched_at': fetchedAt.toUtc().toIso8601String(),
        'provider_date': providerDate,
        'source': source,
      };

  static RateSnapshot? fromJson(Map<String, dynamic>? json) {
    if (json == null) {
      return null;
    }
    final Currency? base = Currency.parse(json['base'] as String? ?? '');
    final Object? raw = json['rates'];
    final DateTime? fetched =
        DateTime.tryParse(json['fetched_at'] as String? ?? '');
    if (base == null || raw is! Map || fetched == null) {
      return null;
    }
    final Map<Currency, double> rates = <Currency, double>{};
    raw.forEach((Object? k, Object? v) {
      final Currency? c = Currency.parse(k.toString());
      if (c != null && v is num) {
        rates[c] = v.toDouble();
      }
    });
    return RateSnapshot(
      base: base,
      rates: rates,
      fetchedAt: fetched,
      providerDate: json['provider_date'] as String?,
      source: json['source'] as String? ?? '-',
    );
  }
}

abstract final class CurrencyConverter {
  static const double maxAmount = 1e12;

  /// Konversi silang via base: `amount × rate[to] / rate[from]`.
  /// `null` bila kurs salah satu mata uang tidak tersedia.
  static double? convert(
    double amount,
    Currency from,
    Currency to,
    RateSnapshot snapshot,
  ) {
    final double? rf = snapshot.rateOf(from);
    final double? rt = snapshot.rateOf(to);
    if (rf == null || rt == null || rf == 0) {
      return null;
    }
    return amount * rt / rf;
  }

  /// Mengurai nominal ketikan pengguna. Menerima format Indonesia
  /// (`1.250.000,50`) maupun titik desimal (`1250000.50`).
  static double? parseAmount(String input) {
    String s = input.trim().replaceAll(' ', '');
    if (s.isEmpty) {
      return null;
    }
    if (!RegExp(r'^[0-9.,]+$').hasMatch(s)) {
      return null;
    }
    final int lastComma = s.lastIndexOf(',');
    final int lastDot = s.lastIndexOf('.');
    if (lastComma >= 0 && lastDot >= 0) {
      // Pemisah yang muncul terakhir = desimal.
      if (lastComma > lastDot) {
        s = s.replaceAll('.', '').replaceAll(',', '.');
      } else {
        s = s.replaceAll(',', '');
      }
    } else if (lastComma >= 0) {
      // Hanya koma: desimal Indonesia, kecuali pola ribuan (1,000,000).
      s = RegExp(r'^\d{1,3}(,\d{3})+$').hasMatch(s)
          ? s.replaceAll(',', '')
          : s.replaceAll(',', '.');
    } else if (lastDot >= 0) {
      // Hanya titik: ribuan Indonesia bila pola 1.000 / 1.000.000.
      if (RegExp(r'^\d{1,3}(\.\d{3})+$').hasMatch(s)) {
        s = s.replaceAll('.', '');
      }
    }
    return double.tryParse(s);
  }

  /// Pesan validasi nominal atau `null` bila valid.
  static String? validateAmount(String input) {
    if (input.trim().isEmpty) {
      return 'Nominal wajib diisi.';
    }
    final double? v = parseAmount(input);
    if (v == null) {
      return 'Nominal hanya boleh berisi angka.';
    }
    if (v <= 0) {
      return 'Nominal harus lebih dari 0.';
    }
    if (v > maxAmount) {
      return 'Nominal terlalu besar.';
    }
    return null;
  }

  static String format(double value, Currency c) {
    final NumberFormat f = NumberFormat.currency(
      locale: 'id_ID',
      symbol: '${c.symbol} ',
      decimalDigits: c.decimals,
    );
    return f.format(value);
  }

  static String formatRate(double rate) {
    final int digits = rate >= 100 ? 2 : 4;
    return NumberFormat.decimalPatternDigits(
      locale: 'id_ID',
      decimalDigits: digits,
    ).format(rate);
  }
}
