import 'dart:math' as math;

import 'package:flutter/foundation.dart';

enum PlaceCategory {
  library('Perpustakaan'),
  cafe('Kafe'),
  coworking('Coworking');

  const PlaceCategory(this.label);

  final String label;
}

/// Tempat produktif di sekitar (Tahap 2 §11.4).
@immutable
class Place {
  const Place({
    required this.id,
    required this.name,
    required this.category,
    required this.lat,
    required this.lng,
    required this.distanceMeters,
    this.address,
  });

  final String id;
  final String name;
  final PlaceCategory category;
  final double lat;
  final double lng;
  final String? address;
  final double distanceMeters;

  String get distanceLabel => distanceMeters < 1000
      ? '${distanceMeters.round()} m'
      : '${(distanceMeters / 1000).toStringAsFixed(1).replaceAll('.', ',')} km';
}

/// Jarak haversine (meter). Dipakai juga di test; tidak butuh plugin.
double haversineMeters(double lat1, double lng1, double lat2, double lng2) {
  const double r = 6371000;
  double rad(double d) => d * math.pi / 180;
  final double dLat = rad(lat2 - lat1);
  final double dLng = rad(lng2 - lng1);
  final double a =
      math.sin(dLat / 2) * math.sin(dLat / 2) +
      math.cos(rad(lat1)) *
          math.cos(rad(lat2)) *
          math.sin(dLng / 2) *
          math.sin(dLng / 2);
  return 2 * r * math.asin(math.min(1, math.sqrt(a)));
}

/// Mengurai respons Overpass API (`out body center`) menjadi [Place].
/// Elemen tanpa nama atau koordinat diabaikan.
List<Place> parseOverpass(
  Map<String, dynamic> json, {
  required double originLat,
  required double originLng,
}) {
  final Object? elements = json['elements'];
  if (elements is! List) {
    throw const FormatException('elements tidak ada');
  }
  final List<Place> out = <Place>[];
  for (final Object? e in elements) {
    if (e is! Map) {
      continue;
    }
    final Map<dynamic, dynamic> tags =
        (e['tags'] as Map?) ?? const <dynamic, dynamic>{};
    final String? name = tags['name'] as String?;
    final Object? lat = e['lat'] ?? (e['center'] as Map?)?['lat'];
    final Object? lng = e['lon'] ?? (e['center'] as Map?)?['lon'];
    if (name == null || name.trim().isEmpty || lat is! num || lng is! num) {
      continue;
    }
    final String amenity = '${tags['amenity'] ?? ''}';
    final String office = '${tags['office'] ?? ''}';
    final PlaceCategory? category = amenity == 'library'
        ? PlaceCategory.library
        : amenity == 'cafe'
        ? PlaceCategory.cafe
        : (amenity == 'coworking_space' || office == 'coworking')
        ? PlaceCategory.coworking
        : null;
    if (category == null) {
      continue;
    }
    final String street = '${tags['addr:street'] ?? ''}';
    final String number = '${tags['addr:housenumber'] ?? ''}';
    out.add(
      Place(
        id: '${e['type']}/${e['id']}',
        name: name.trim(),
        category: category,
        lat: lat.toDouble(),
        lng: lng.toDouble(),
        address: street.isEmpty ? null : '$street $number'.trim(),
        distanceMeters: haversineMeters(
          originLat,
          originLng,
          lat.toDouble(),
          lng.toDouble(),
        ),
      ),
    );
  }
  out.sort((Place a, Place b) => a.distanceMeters.compareTo(b.distanceMeters));
  return out;
}

/// Geoapify uses GeoJSON coordinates in longitude, latitude order.
List<Place> parseGeoapify(
  Map<String, dynamic> json, {
  required double originLat,
  required double originLng,
  required int radiusMeters,
  PlaceCategory? category,
}) {
  final Object? features = json['features'];
  if (json['type'] != 'FeatureCollection' || features is! List) {
    throw const FormatException('features tidak ada');
  }
  final List<Place> places = <Place>[];
  final Set<String> seen = <String>{};
  for (final Object? feature in features) {
    if (feature is! Map || feature['properties'] is! Map) continue;
    final Map<dynamic, dynamic> properties = feature['properties'] as Map;
    final Object? name = properties['name'];
    final Object? id = properties['place_id'];
    final Object? categories = properties['categories'];
    if (name is! String ||
        name.trim().isEmpty ||
        id is! String ||
        id.isEmpty ||
        categories is! List) {
      continue;
    }
    bool matches(String key) => categories.any(
      (Object? c) => c is String && (c == key || c.startsWith('$key.')),
    );
    final PlaceCategory? kind = matches('education.library')
        ? PlaceCategory.library
        : matches('office.coworking')
        ? PlaceCategory.coworking
        : matches('catering.cafe')
        ? PlaceCategory.cafe
        : null;
    if (kind == null || (category != null && kind != category)) continue;
    final Object? geometry = feature['geometry'];
    final Object? coordinates = geometry is Map && geometry['type'] == 'Point'
        ? geometry['coordinates']
        : null;
    final Object? lng =
        properties['lon'] ??
        (coordinates is List && coordinates.length >= 2
            ? coordinates[0]
            : null);
    final Object? lat =
        properties['lat'] ??
        (coordinates is List && coordinates.length >= 2
            ? coordinates[1]
            : null);
    if (lat is! num ||
        lng is! num ||
        !lat.isFinite ||
        !lng.isFinite ||
        lat.abs() > 90 ||
        lng.abs() > 180) {
      continue;
    }
    final double distance = haversineMeters(
      originLat,
      originLng,
      lat.toDouble(),
      lng.toDouble(),
    );
    if (distance > radiusMeters || !seen.add(id)) continue;
    final Object? address =
        properties['formatted'] ?? properties['address_line2'];
    places.add(
      Place(
        id: 'geoapify/$id',
        name: name.trim(),
        category: kind,
        lat: lat.toDouble(),
        lng: lng.toDouble(),
        distanceMeters: distance,
        address: address is String && address.trim().isNotEmpty
            ? address.trim()
            : null,
      ),
    );
  }
  places.sort(
    (Place a, Place b) => a.distanceMeters.compareTo(b.distanceMeters),
  );
  return places;
}
