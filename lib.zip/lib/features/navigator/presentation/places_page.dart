import 'package:flutter/material.dart';
import 'package:flutter_map/flutter_map.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:latlong2/latlong.dart';
import 'package:url_launcher/url_launcher.dart';

import '../../../core/widgets/empty_state.dart';
import '../../../core/widgets/loading_indicator.dart';
import '../../../core/widgets/page_container.dart';
import '../../../theme/app_colors.dart';
import '../../../theme/app_tokens.dart';
import '../data/navigator_services.dart';
import '../domain/place.dart';

enum _Phase { idle, locating, searching, ready, error }

/// S-62 Tempat Produktif (FR-033–035): lokasi → cari tempat → peta → rute.
class PlacesPage extends ConsumerStatefulWidget {
  const PlacesPage({super.key});

  @override
  ConsumerState<PlacesPage> createState() => _PlacesPageState();
}

class _PlacesPageState extends ConsumerState<PlacesPage> {
  _Phase _phase = _Phase.idle;
  LocationProblem? _locationProblem;
  bool _apiFailed = false;
  PlacesProblem? _placesProblem;
  int _requestId = 0;
  LatLngPoint? _origin;
  List<Place> _places = const <Place>[];
  PlaceCategory? _category;
  int _radius = 1000;

  Future<void> _load({bool refreshLocation = false}) async {
    final int request = ++_requestId;
    final int radius = _radius;
    final PlaceCategory? category = _category;
    setState(() {
      _phase = _Phase.locating;
      _locationProblem = null;
      _apiFailed = false;
      _placesProblem = null;
    });
    LatLngPoint at;
    try {
      at =
          (refreshLocation ? null : _origin) ??
          await ref.read(locationServiceProvider).currentPosition();
    } on LocationFailure catch (f) {
      if (!mounted || request != _requestId) {
        return;
      }
      setState(() {
        _phase = _Phase.error;
        _locationProblem = f.problem;
      });
      return;
    }
    if (!mounted || request != _requestId) {
      return;
    }
    setState(() {
      _origin = at;
      _phase = _Phase.searching;
    });
    try {
      final List<Place> places = await ref
          .read(placesServiceProvider)
          .nearby(at, radiusMeters: radius, category: category);
      if (mounted && request == _requestId) {
        setState(() {
          _places = places;
          _phase = _Phase.ready;
        });
      }
    } catch (error) {
      if (mounted && request == _requestId) {
        setState(() {
          _phase = _Phase.error;
          _apiFailed = true;
          _placesProblem = error is PlacesFailure ? error.problem : null;
        });
      }
    }
  }

  Future<void> _route(Place p) async {
    final ScaffoldMessengerState m = ScaffoldMessenger.of(context);
    if (!await openRoute(p)) {
      m.showSnackBar(
        const SnackBar(content: Text('Aplikasi peta tidak dapat dibuka.')),
      );
    }
  }

  void _selectCategory(PlaceCategory? category) {
    if (_category == category) return;
    setState(() => _category = category);
    if (_origin != null) _load();
  }

  Future<void> _searchInMaps() async {
    bool opened = false;
    try {
      opened = await ref.read(placesMapsLauncherProvider)(
        googleMapsPlacesSearchUri(_category),
      );
    } catch (_) {}
    if (!opened && mounted) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Google Maps belum bisa dibuka.')),
      );
    }
  }

  @override
  Widget build(BuildContext context) {
    final ThemeData theme = Theme.of(context);
    final bool busy = _phase == _Phase.locating || _phase == _Phase.searching;
    final List<Place> visible = _category == null
        ? _places
        : _places.where((Place p) => p.category == _category).toList();

    return Scaffold(
      appBar: AppBar(
        title: const Text('Tempat Produktif'),
        actions: <Widget>[
          IconButton(
            tooltip: 'Perbarui lokasi',
            onPressed: _phase == _Phase.locating || _phase == _Phase.searching
                ? null
                : () => _load(refreshLocation: true),
            icon: const Icon(Icons.my_location_rounded),
          ),
        ],
      ),
      body: SafeArea(
        child: ListView(
          padding: const EdgeInsets.only(bottom: AppSpacing.xxl),
          children: <Widget>[
            PageContainer(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.stretch,
                children: <Widget>[
                  const SizedBox(height: AppSpacing.md),
                  Wrap(
                    spacing: AppSpacing.sm,
                    children: <Widget>[
                      ChoiceChip(
                        label: const Text('Semua'),
                        selected: _category == null,
                        onSelected: busy ? null : (_) => _selectCategory(null),
                      ),
                      for (final PlaceCategory c in PlaceCategory.values)
                        ChoiceChip(
                          label: Text(c.label),
                          selected: _category == c,
                          onSelected: busy ? null : (_) => _selectCategory(c),
                        ),
                    ],
                  ),
                  const SizedBox(height: AppSpacing.sm),
                  Row(
                    children: <Widget>[
                      Text('Radius', style: theme.textTheme.labelLarge),
                      const SizedBox(width: AppSpacing.sm),
                      for (final int r in const <int>[1000, 3000, 5000])
                        Padding(
                          padding: const EdgeInsets.only(right: AppSpacing.xs),
                          child: ChoiceChip(
                            label: Text('${r ~/ 1000} km'),
                            selected: _radius == r,
                            onSelected: busy
                                ? null
                                : (_) {
                                    if (_radius == r) return;
                                    setState(() => _radius = r);
                                    if (_origin != null) {
                                      _load();
                                    }
                                  },
                          ),
                        ),
                    ],
                  ),
                  const SizedBox(height: AppSpacing.md),
                  ..._body(theme, visible),
                  const SizedBox(height: AppSpacing.md),
                  if (!(_phase == _Phase.error && _apiFailed))
                    OutlinedButton.icon(
                      onPressed: _searchInMaps,
                      icon: const Icon(Icons.open_in_new_rounded),
                      label: const Text('Cari di Google Maps'),
                    ),
                  TextButton(
                    onPressed: () =>
                        launchUrl(Uri.parse('https://www.geoapify.com/')),
                    child: const Text('Powered by Geoapify'),
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }

  List<Widget> _body(ThemeData theme, List<Place> visible) {
    switch (_phase) {
      case _Phase.idle:
        return <Widget>[
          EmptyState(
            icon: Icons.place_outlined,
            title: 'Cari tempat untuk fokus',
            message:
                'Izin lokasi dipakai sekali untuk mencari perpustakaan, '
                'kafe, dan coworking terdekat. Koordinat dikirim ke layanan '
                'Geoapify untuk '
                'pencarian ini dan tidak disimpan permanen.',
            primaryActionLabel: 'Gunakan lokasiku',
            onPrimaryAction: _load,
          ),
        ];
      case _Phase.locating:
      case _Phase.searching:
        return <Widget>[
          if (_phase == _Phase.searching && _origin != null)
            _locationMap(theme, const <Place>[]),
          Padding(
            padding: const EdgeInsets.all(AppSpacing.xl),
            child: Center(
              child: LoadingIndicator(
                label: _phase == _Phase.locating
                    ? 'Membaca lokasi…'
                    : 'Mencari tempat di sekitar…',
              ),
            ),
          ),
        ];
      case _Phase.error:
        return <Widget>[
          if (_apiFailed && _origin != null) ...<Widget>[
            _locationMap(theme, const <Place>[]),
            const SizedBox(height: AppSpacing.md),
            Text(
              'Lokasi perangkat sudah didapat.',
              style: theme.textTheme.bodyMedium,
            ),
          ],
          _errorView(),
        ];
      case _Phase.ready:
        return <Widget>[
          _locationMap(theme, visible),
          const SizedBox(height: AppSpacing.md),
          Text(
            'Menampilkan ${visible.length} tempat dalam radius ${_radius ~/ 1000} km',
            style: theme.textTheme.titleSmall,
          ),
          const SizedBox(height: AppSpacing.sm),
          if (visible.isEmpty)
            EmptyState(
              icon: Icons.search_off_rounded,
              title: 'Tidak ada tempat ditemukan',
              message: 'Coba perbesar radius atau pilih kategori lain.',
              primaryActionLabel: 'Perbesar radius',
              onPrimaryAction: _radius >= 5000
                  ? null
                  : () {
                      setState(() => _radius = _radius == 1000 ? 3000 : 5000);
                      _load();
                    },
            )
          else
            for (final Place p in visible)
              Card(
                margin: const EdgeInsets.only(bottom: AppSpacing.sm),
                child: ListTile(
                  title: Text(p.name),
                  subtitle: Text(
                    '${p.category.label}'
                    '${p.address == null ? '' : ' · ${p.address}'}',
                  ),
                  trailing: Column(
                    mainAxisAlignment: MainAxisAlignment.center,
                    crossAxisAlignment: CrossAxisAlignment.end,
                    children: <Widget>[
                      Text(p.distanceLabel),
                      Text(
                        'Rute',
                        style: theme.textTheme.labelSmall!.copyWith(
                          color: theme.colorScheme.primary,
                        ),
                      ),
                    ],
                  ),
                  onTap: () => _route(p),
                ),
              ),
          const SizedBox(height: AppSpacing.sm),
          Text(
            'Data tempat: Geoapify · peta © OpenStreetMap contributors. '
            'Rute dibuka di aplikasi peta.',
            style: theme.textTheme.bodySmall!.copyWith(
              color: context.appColors.textSecondary,
            ),
          ),
        ];
    }
  }

  Widget _locationMap(ThemeData theme, List<Place> visible) {
    final LatLngPoint origin = _origin!;
    return ClipRRect(
      borderRadius: AppRadius.mdAll,
      child: SizedBox(
        height: 260,
        child: FlutterMap(
          key: ValueKey<String>('${origin.lat}:${origin.lng}:$_radius'),
          options: MapOptions(
            initialCenter: LatLng(origin.lat, origin.lng),
            initialZoom: _radius <= 1000 ? 15 : (_radius <= 3000 ? 13.5 : 12.5),
          ),
          children: <Widget>[
            TileLayer(
              urlTemplate: 'https://tile.openstreetmap.org/{z}/{x}/{y}.png',
              userAgentPackageName: 'id.planify.planify',
            ),
            MarkerLayer(
              markers: <Marker>[
                Marker(
                  point: LatLng(origin.lat, origin.lng),
                  width: 24,
                  height: 24,
                  child: Icon(
                    Icons.my_location_rounded,
                    color: theme.colorScheme.primary,
                  ),
                ),
                for (final Place p in visible)
                  Marker(
                    point: LatLng(p.lat, p.lng),
                    width: 36,
                    height: 36,
                    child: Semantics(
                      label: p.name,
                      child: Icon(
                        Icons.location_on_rounded,
                        color: theme.colorScheme.error,
                        size: 32,
                      ),
                    ),
                  ),
              ],
            ),
            RichAttributionWidget(
              attributions: <SourceAttribution>[
                TextSourceAttribution(
                  'Geoapify',
                  onTap: () =>
                      launchUrl(Uri.parse('https://www.geoapify.com/')),
                ),
                TextSourceAttribution(
                  'OpenStreetMap contributors',
                  onTap: () => launchUrl(
                    Uri.parse('https://www.openstreetmap.org/copyright'),
                  ),
                ),
              ],
            ),
          ],
        ),
      ),
    );
  }

  Widget _errorView() {
    final LocationService loc = ref.read(locationServiceProvider);
    if (_apiFailed) {
      return EmptyState(
        icon: Icons.cloud_off_rounded,
        title: 'Tempat belum bisa dimuat',
        message: switch (_placesProblem) {
          PlacesProblem.notConfigured =>
            'Pencarian tempat belum dikonfigurasi. '
                'Kamu tetap bisa mencari lewat Google Maps.',
          PlacesProblem.unauthorized =>
            'Akses layanan tempat ditolak. '
                'Kamu tetap bisa mencari lewat Google Maps.',
          PlacesProblem.quotaExceeded =>
            'Batas pencarian sementara tercapai. Coba beberapa saat lagi '
                'atau cari lewat Google Maps.',
          PlacesProblem.serverBusy =>
            'Server pencarian tempat sedang sibuk. '
                'Tunggu 30 detik, lalu coba lagi.',
          PlacesProblem.timeout =>
            'Pencarian tempat terlalu lama merespons. '
                'Periksa internet dan tunggu 30 detik sebelum mencoba lagi.',
          PlacesProblem.invalidResponse =>
            'Jawaban layanan tempat belum '
                'bisa dibaca. Coba lagi beberapa saat lagi.',
          _ =>
            'Layanan pencarian tempat tidak merespons. Periksa koneksi, '
                'lalu coba lagi.',
        },
        primaryActionLabel: 'Coba lagi',
        onPrimaryAction: _load,
        secondaryActionLabel: 'Cari di Google Maps',
        onSecondaryAction: _searchInMaps,
      );
    }
    return switch (_locationProblem) {
      LocationProblem.serviceDisabled => EmptyState(
        icon: Icons.location_disabled_rounded,
        title: 'Lokasi perangkat mati',
        message: 'Nyalakan layanan lokasi (GPS), lalu coba lagi.',
        primaryActionLabel: 'Buka pengaturan lokasi',
        onPrimaryAction: loc.openLocationSettings,
        secondaryActionLabel: 'Coba lagi',
        onSecondaryAction: _load,
      ),
      LocationProblem.denied => EmptyState(
        icon: Icons.location_off_outlined,
        title: 'Izin lokasi ditolak',
        message:
            'Tanpa izin lokasi, PLANIFY tidak bisa mencari tempat di '
            'sekitarmu. Fitur lain tetap berjalan normal.',
        primaryActionLabel: 'Izinkan lokasi',
        onPrimaryAction: _load,
      ),
      LocationProblem.deniedForever => EmptyState(
        icon: Icons.location_off_outlined,
        title: 'Izin lokasi diblokir',
        message:
            'Aktifkan izin lokasi untuk PLANIFY di pengaturan '
            'aplikasi.',
        primaryActionLabel: 'Buka pengaturan aplikasi',
        onPrimaryAction: loc.openAppSettings,
        secondaryActionLabel: 'Coba lagi',
        onSecondaryAction: _load,
      ),
      LocationProblem.timeout => EmptyState(
        icon: Icons.gps_not_fixed_rounded,
        title: 'Lokasi belum didapat',
        message:
            'Perangkat belum mengirim posisi GPS terbaru. Di HP, coba '
            'di dekat jendela. Di emulator, buka menu tiga titik → Location '
            '→ Set location, lalu tekan Coba lagi.',
        primaryActionLabel: 'Coba lagi',
        onPrimaryAction: () => _load(refreshLocation: true),
      ),
      _ => EmptyState(
        icon: Icons.error_outline_rounded,
        title: 'Lokasi tidak tersedia',
        message: 'Perangkat tidak dapat membaca lokasi saat ini.',
        primaryActionLabel: 'Coba lagi',
        onPrimaryAction: _load,
      ),
    };
  }
}
