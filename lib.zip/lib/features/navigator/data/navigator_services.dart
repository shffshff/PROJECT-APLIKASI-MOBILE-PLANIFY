import 'dart:async';
import 'dart:convert';

import 'package:flutter/foundation.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:geolocator/geolocator.dart';
import 'package:http/http.dart' as http;
import 'package:url_launcher/url_launcher.dart';

import '../domain/place.dart';

/// Kondisi lokasi yang ditangani UI (Tahap 2 §11.4).
enum LocationProblem {
  unsupported,
  serviceDisabled,
  denied,
  deniedForever,
  timeout,
  unknown,
}

class LocationFailure implements Exception {
  const LocationFailure(this.problem);

  final LocationProblem problem;
}

@immutable
class LatLngPoint {
  const LatLngPoint(this.lat, this.lng);

  final double lat;
  final double lng;
}

abstract interface class LocationService {
  /// Meminta izin bila perlu lalu membaca posisi sekali. Melempar
  /// [LocationFailure]. Koordinat TIDAK disimpan maupun dikirim ke Supabase
  /// (NFR-006).
  Future<LatLngPoint> currentPosition();

  Future<void> openAppSettings();

  Future<void> openLocationSettings();
}

class GeolocatorLocationService implements LocationService {
  const GeolocatorLocationService();

  @override
  Future<LatLngPoint> currentPosition() async {
    try {
      if (!await Geolocator.isLocationServiceEnabled()) {
        throw const LocationFailure(LocationProblem.serviceDisabled);
      }
      LocationPermission p = await Geolocator.checkPermission();
      if (p == LocationPermission.denied) {
        p = await Geolocator.requestPermission();
      }
      if (p == LocationPermission.denied) {
        throw const LocationFailure(LocationProblem.denied);
      }
      if (p == LocationPermission.deniedForever) {
        throw const LocationFailure(LocationProblem.deniedForever);
      }
      // A recent GPS fix also works on emulators that emit a single location
      // when "Set location" is pressed rather than continuously streaming.
      try {
        final Position? recent = await Geolocator.getLastKnownPosition();
        if (recent != null && isRecentPosition(recent, DateTime.now())) {
          return LatLngPoint(recent.latitude, recent.longitude);
        }
      } catch (_) {
        // Last-known lookup is an optimization; still request a fresh fix.
      }
      final Position pos = await Geolocator.getCurrentPosition(
        locationSettings: const LocationSettings(
          accuracy: LocationAccuracy.high,
          timeLimit: Duration(seconds: 15),
        ),
      );
      return LatLngPoint(pos.latitude, pos.longitude);
    } on LocationFailure {
      rethrow;
    } on TimeoutException {
      throw const LocationFailure(LocationProblem.timeout);
    } catch (error) {
      debugPrint('Lokasi gagal: ${error.runtimeType}');
      throw const LocationFailure(LocationProblem.unknown);
    }
  }

  static bool isRecentPosition(Position position, DateTime now) {
    final Duration age = now.toUtc().difference(position.timestamp.toUtc());
    return !age.isNegative &&
        age <= const Duration(minutes: 2) &&
        position.accuracy >= 0 &&
        position.accuracy <= 100 &&
        position.latitude.isFinite &&
        position.longitude.isFinite &&
        position.latitude.abs() <= 90 &&
        position.longitude.abs() <= 180;
  }

  @override
  Future<void> openAppSettings() async {
    try {
      await Geolocator.openAppSettings();
    } catch (_) {}
  }

  @override
  Future<void> openLocationSettings() async {
    try {
      await Geolocator.openLocationSettings();
    } catch (_) {}
  }
}

abstract interface class PlacesService {
  String get attribution;

  Future<List<Place>> nearby(
    LatLngPoint at, {
    required int radiusMeters,
    PlaceCategory? category,
  });
}

enum PlacesProblem {
  notConfigured,
  unauthorized,
  quotaExceeded,
  serverBusy,
  timeout,
  unavailable,
  invalidResponse,
}

class PlacesFailure implements Exception {
  const PlacesFailure(this.problem);

  final PlacesProblem problem;
}

/// Direct device → Geoapify; no device coordinates are sent to Supabase.
class GeoapifyPlacesService implements PlacesService {
  GeoapifyPlacesService({required String apiKey, http.Client? client})
    : _apiKey = apiKey.trim(),
      _client = client ?? http.Client();

  final String _apiKey;
  final http.Client _client;
  final Map<String, ({DateTime time, List<Place> places})> _cache =
      <String, ({DateTime time, List<Place> places})>{};
  DateTime? _retryAfter;

  @override
  String get attribution =>
      'Powered by Geoapify · © OpenStreetMap contributors';

  static String categoryKey(PlaceCategory? category) => switch (category) {
    PlaceCategory.library => 'education.library',
    PlaceCategory.cafe => 'catering.cafe',
    PlaceCategory.coworking => 'office.coworking',
    null => 'education.library,catering.cafe,office.coworking',
  };

  @override
  Future<List<Place>> nearby(
    LatLngPoint at, {
    required int radiusMeters,
    PlaceCategory? category,
  }) async {
    if (_apiKey.isEmpty) throw const PlacesFailure(PlacesProblem.notConfigured);
    final String key = '${at.lat}:${at.lng}:$radiusMeters:${category?.name}';
    final cached = _cache[key];
    if (cached != null &&
        DateTime.now().difference(cached.time) < const Duration(minutes: 5)) {
      return cached.places;
    }
    if (_retryAfter?.isAfter(DateTime.now()) ?? false) {
      throw const PlacesFailure(PlacesProblem.quotaExceeded);
    }
    final Uri uri =
        Uri.https('api.geoapify.com', '/v2/places', <String, String>{
          'categories': categoryKey(category),
          'filter': 'circle:${at.lng},${at.lat},$radiusMeters',
          'bias': 'proximity:${at.lng},${at.lat}',
          'conditions': 'named',
          'limit': category == null ? '60' : '20',
          'apiKey': _apiKey,
        });
    try {
      final http.Response response = await _client
          .get(uri, headers: <String, String>{'Accept': 'application/json'})
          .timeout(const Duration(seconds: 15));
      if (response.statusCode == 401 || response.statusCode == 403) {
        throw const PlacesFailure(PlacesProblem.unauthorized);
      }
      if (response.statusCode == 429) {
        _retryAfter = DateTime.now().add(const Duration(seconds: 30));
        throw const PlacesFailure(PlacesProblem.quotaExceeded);
      }
      if (<int>[502, 503, 504].contains(response.statusCode)) {
        throw const PlacesFailure(PlacesProblem.serverBusy);
      }
      if (response.statusCode != 200) {
        throw const PlacesFailure(PlacesProblem.unavailable);
      }
      final Object? body = jsonDecode(utf8.decode(response.bodyBytes));
      if (body is! Map<String, dynamic>) {
        throw const FormatException('invalid body');
      }
      final List<Place> places = List<Place>.unmodifiable(
        parseGeoapify(
          body,
          originLat: at.lat,
          originLng: at.lng,
          radiusMeters: radiusMeters,
          category: category,
        ),
      );
      if (_cache.length >= 16) _cache.remove(_cache.keys.first);
      _cache[key] = (time: DateTime.now(), places: places);
      return places;
    } on PlacesFailure {
      rethrow;
    } on TimeoutException {
      throw const PlacesFailure(PlacesProblem.timeout);
    } on FormatException {
      throw const PlacesFailure(PlacesProblem.invalidResponse);
    } catch (_) {
      // Never log the request URL: it contains the key and device coordinates.
      throw const PlacesFailure(PlacesProblem.unavailable);
    }
  }

  void dispose() {
    _cache.clear();
    _client.close();
  }
}

/// K-03 opsi A: Overpass API (OpenStreetMap), tanpa API key. Wajib mematuhi
/// kebijakan penggunaan Overpass (beban rendah, User-Agent jelas).
class OverpassPlacesService implements PlacesService {
  OverpassPlacesService([http.Client? client])
    : _client = client ?? http.Client();

  final http.Client _client;
  // Public instances listed by OpenStreetMap. Two sequential attempts at
  // most; cooldown and memory cache prevent repeated taps overloading them.
  static final List<Uri> endpoints = <Uri>[
    Uri.parse('https://overpass.private.coffee/api/interpreter'),
    Uri.parse('https://overpass-api.de/api/interpreter'),
  ];
  final Map<Uri, DateTime> _retryAfter = <Uri, DateTime>{};
  final Map<Uri, PlacesFailure> _failures = <Uri, PlacesFailure>{};
  final Map<String, ({DateTime time, List<Place> places})> _cache =
      <String, ({DateTime time, List<Place> places})>{};

  @override
  String get attribution => '© OpenStreetMap contributors';

  static String query(LatLngPoint at, int radius) {
    final String around = 'around:$radius,${at.lat},${at.lng}';
    return '[out:json][timeout:12];('
        'nwr["amenity"="library"]($around);'
        'nwr["amenity"="cafe"]($around);'
        'nwr["amenity"="coworking_space"]($around);'
        'nwr["office"="coworking"]($around);'
        // `tags` omits node coordinates. `body` retains lat/lon while center
        // adds a usable point for ways and relations.
        ');out body center 60;';
  }

  @override
  Future<List<Place>> nearby(
    LatLngPoint at, {
    required int radiusMeters,
    PlaceCategory? category,
  }) async {
    final String key = '${at.lat}:${at.lng}:$radiusMeters';
    final cached = _cache[key];
    if (cached != null &&
        DateTime.now().difference(cached.time) < const Duration(minutes: 5)) {
      return cached.places
          .where((Place p) => category == null || p.category == category)
          .toList();
    }
    PlacesFailure failure = const PlacesFailure(PlacesProblem.unavailable);
    for (final Uri endpoint in endpoints) {
      final DateTime? retry = _retryAfter[endpoint];
      if (retry != null && retry.isAfter(DateTime.now())) {
        failure = _failures[endpoint] ?? failure;
        continue;
      }
      try {
        final List<Place> places = await _fetch(endpoint, at, radiusMeters);
        if (_cache.length >= 16) _cache.remove(_cache.keys.first);
        _cache[key] = (
          time: DateTime.now(),
          places: List<Place>.unmodifiable(places),
        );
        return places
            .where((Place p) => category == null || p.category == category)
            .toList();
      } on PlacesFailure catch (error) {
        failure = error;
        _failures[endpoint] = error;
        _retryAfter[endpoint] = DateTime.now().add(const Duration(seconds: 30));
      }
    }
    throw failure;
  }

  Future<List<Place>> _fetch(
    Uri endpoint,
    LatLngPoint at,
    int radiusMeters,
  ) async {
    try {
      final http.Response res = await _client
          .post(
            endpoint,
            headers: <String, String>{
              'User-Agent':
                  'PLANIFY/0.1 (proyek mata kuliah; id.planify.planify)',
              'Content-Type': 'application/x-www-form-urlencoded',
              'Accept': 'application/json',
            },
            body: <String, String>{'data': query(at, radiusMeters)},
          )
          .timeout(const Duration(seconds: 25));
      if (<int>[406, 429, 502, 503, 504].contains(res.statusCode)) {
        throw const PlacesFailure(PlacesProblem.serverBusy);
      }
      if (res.statusCode != 200) {
        throw const PlacesFailure(PlacesProblem.unavailable);
      }
      final Object? json = jsonDecode(res.body);
      if (json is! Map<String, dynamic>) {
        throw const PlacesFailure(PlacesProblem.invalidResponse);
      }
      if (json['remark'] is String && (json['remark'] as String).isNotEmpty) {
        throw const PlacesFailure(PlacesProblem.serverBusy);
      }
      return parseOverpass(json, originLat: at.lat, originLng: at.lng);
    } on PlacesFailure {
      rethrow;
    } on TimeoutException {
      throw const PlacesFailure(PlacesProblem.timeout);
    } on FormatException {
      throw const PlacesFailure(PlacesProblem.invalidResponse);
    } catch (_) {
      throw const PlacesFailure(PlacesProblem.unavailable);
    }
  }

  void dispose() {
    _cache.clear();
    _client.close();
  }
}

/// Rute: membuka aplikasi peta eksternal (baseline Tahap 2 §11.4).
Future<bool> openRoute(Place p) async {
  final Uri geo = Uri.parse(
    'geo:${p.lat},${p.lng}?q=${p.lat},${p.lng}(${Uri.encodeComponent(p.name)})',
  );
  final Uri web = Uri.https('www.google.com', '/maps/dir/', <String, String>{
    'api': '1',
    'destination': '${p.lat},${p.lng}',
  });
  try {
    if (!kIsWeb && await launchUrl(geo, mode: LaunchMode.externalApplication)) {
      return true;
    }
  } catch (_) {}
  try {
    return await launchUrl(web, mode: LaunchMode.externalApplication);
  } catch (_) {
    return false;
  }
}

final Provider<LocationService> locationServiceProvider =
    Provider<LocationService>((Ref ref) => const GeolocatorLocationService());

final Provider<String> geoapifyApiKeyProvider = Provider<String>(
  (Ref ref) => const String.fromEnvironment('GEOAPIFY_API_KEY'),
);

final Provider<PlacesService> placesServiceProvider = Provider<PlacesService>((
  Ref ref,
) {
  final GeoapifyPlacesService service = GeoapifyPlacesService(
    apiKey: ref.watch(geoapifyApiKeyProvider),
  );
  ref.onDispose(service.dispose);
  return service;
});

Uri googleMapsPlacesSearchUri(PlaceCategory? category) =>
    Uri.https('www.google.com', '/maps/search/', <String, String>{
      'api': '1',
      'query': switch (category) {
        PlaceCategory.library => 'perpustakaan terdekat',
        PlaceCategory.cafe => 'kafe untuk kerja terdekat',
        PlaceCategory.coworking => 'coworking terdekat',
        null => 'tempat belajar terdekat',
      },
    });

typedef PlacesMapsLauncher = Future<bool> Function(Uri uri);
final Provider<PlacesMapsLauncher> placesMapsLauncherProvider =
    Provider<PlacesMapsLauncher>(
      (Ref ref) =>
          (Uri uri) => launchUrl(uri, mode: LaunchMode.externalApplication),
    );
